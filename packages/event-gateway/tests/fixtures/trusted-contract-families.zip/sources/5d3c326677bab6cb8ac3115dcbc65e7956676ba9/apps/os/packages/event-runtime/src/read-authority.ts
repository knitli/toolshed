import { z } from "zod";
import type { EventAuthorityCredentialsV1 } from "gatekeeper-messaging/src/event-authority-contract";
import { parseAuthorityAuthResult } from "./authority-client.ts";
import { EventApiError, NodeProofSchema, type EventApiEnvironment } from "./contracts.ts";
import { EVENT_POLICY_V1 } from "./policy.ts";
import type { NodeAuthorization, NodeProof, ProofBinding } from "./registry.ts";
import { withDeadline } from "./request-deadline.ts";

type ReadAuthorityEnvironment = Pick<EventApiEnvironment, "OWNER_REGISTRY" | "MESSAGE_AUTHORITY">;
export type ReadAuthorityScope = {
  principal: string; agent: string; keyThumbprint: string; proof: NodeProof;
  proofBinding: ProofBinding; credentials: EventAuthorityCredentialsV1; bodySha256: string;
  nodeId: string; nodeGeneration: number;
};
const nativeKeyThumbprint = z.string().regex(/^[A-Za-z0-9_-]{43}$/);
const nativeProofDigest = z.string().regex(/^[0-9a-f]{64}$/);

export async function authenticateReadAuthority(env: ReadAuthorityEnvironment, identity: { principal: string; agent: string }, rawBody: string, scope: ReadAuthorityScope, path: "/internal/github/initial-plan/material" | "/v1/runtimes/status" | "/v1/github/source/read" | "/v1/github/source/material" | "/v1/github/source/reference/issue" | "/v1/github/source/reference/resolve"): Promise<EventAuthorityCredentialsV1> {
  const credentials = z.strictObject({ accessAssertion: z.string().min(1).max(16_384), agentToken: z.string().min(1).max(4_096) }).safeParse(scope.credentials);
  if (scope.principal !== identity.principal || scope.agent !== identity.agent
    || !nativeKeyThumbprint.safeParse(scope.keyThumbprint).success || !NodeProofSchema.safeParse(scope.proof).success
    || scope.nodeId !== scope.proof.nodeId || scope.nodeGeneration !== scope.proof.nodeGeneration
    || !credentials.success || !nativeProofDigest.safeParse(scope.bodySha256).success
    || scope.proofBinding.method !== "POST" || scope.proofBinding.path !== path
    || scope.proofBinding.bodySha256 !== scope.bodySha256) throw new EventApiError("invalid", 400);
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(rawBody)));
  if ([...digest].map(byte => byte.toString(16).padStart(2, "0")).join("") !== scope.bodySha256)
    throw new EventApiError("invalid", 400);
  const registry = env.OWNER_REGISTRY.getByName(JSON.stringify(["event-owner-v1", scope.principal]));
  let nodeAuth: NodeAuthorization;
  try { nodeAuth = await withDeadline<NodeAuthorization>(Promise.resolve(registry.authenticateNode(scope.proof, scope.proofBinding)), EVENT_POLICY_V1.nativeRpcDeadlineMs); }
  catch { throw new EventApiError("registry_unavailable", 503); }
  if (nodeAuth.status !== "authorized" || nodeAuth.node.nodeId !== scope.nodeId
    || nodeAuth.node.generation !== scope.nodeGeneration || !nodeAuth.node.agents.includes(scope.agent))
    throw new EventApiError("node_denied", 403);
  await revalidateReadAuthority(env, scope, credentials.data);
  return credentials.data;
}

export async function revalidateReadAuthority(env: ReadAuthorityEnvironment, scope: ReadAuthorityScope, credentials: EventAuthorityCredentialsV1): Promise<void> {
  const registry = env.OWNER_REGISTRY.getByName(JSON.stringify(["event-owner-v1", scope.principal]));
  let auth;
  try { auth = parseAuthorityAuthResult(await withDeadline(env.MESSAGE_AUTHORITY.currentAuth(credentials), EVENT_POLICY_V1.nativeRpcDeadlineMs)); }
  catch { throw new EventApiError("authority_unavailable", 503); }
  if (auth.status === "unavailable") throw new EventApiError("authority_unavailable", 503);
  if (auth.status !== "authorized" || auth.identity.principal !== scope.principal
    || auth.identity.agent !== scope.agent || auth.identity.keyThumbprint !== scope.keyThumbprint)
    throw new EventApiError("denied", 403);
  let currentNode: NodeAuthorization;
  try { currentNode = await withDeadline<NodeAuthorization>(Promise.resolve(registry.currentNode({ nodeId: scope.nodeId,
    agent: scope.agent, generation: scope.nodeGeneration })), EVENT_POLICY_V1.nativeRpcDeadlineMs); }
  catch { throw new EventApiError("registry_unavailable", 503); }
  if (currentNode.status !== "authorized" || currentNode.node.nodeId !== scope.nodeId
    || currentNode.node.generation !== scope.nodeGeneration || !currentNode.node.agents.includes(scope.agent))
    throw new EventApiError("node_denied", 403);
}

