import { z } from 'zod';
import type { AccessPorts } from 'openapi-operator/src/access.ts';
import { AccessDenied, AccessUnavailable } from 'openapi-operator/src/access.ts';
import type { EventAdminCall } from '../admin-types';
import { EventApiError, type EventApiEnvironment } from '../contracts';
import { EventRequestDeadline } from '../request-deadline';
import { requireNativeAdmissionCanary } from '../native-admission-gate';
import { NativeRuntimeStore } from '../native-runtime-store';
import { NativeRuntimeBindingSchema } from '../native-admission-contract';
import { ownerRegistryName, type NodeAuthorization } from '../registry';
import { GitHubGrantStore } from './grants';
import { GitHubSourceControlStore, sourceTokenEquals } from './source-control';
import { GitHubWatchPromotionCheckpointSchema, githubHostName, type GitHubAttentionHost } from './host';
import { WatchOwnerProofVerifier, type WatchOwnerEnvironment } from './watch-owner-proof';
import { GitHubWatchControlStore } from './watch-store';
import { WatchRequestSchema, WatchActivateTokenSchema, WatchStopTokenSchema, WatchOutcomeSchema,
  WATCH_CONTROL_LIMITS, watchJson, type WatchOutcome, type CreateWatchRequest, type WatchHolder,
  type WatchRequest, type WatchControlToken } from './watch-control-internal';

export function watchCoordinatorIdentity(state: DurableObjectState): { principal: string; agent: string } {
  let raw: unknown;
  try { raw = JSON.parse(state.id.name ?? 'null'); } catch { throw new Error('github_denied'); }
  const parsed = z.tuple([z.literal('event-agent-v1'), z.string().email().max(254).refine(value => value === value.toLowerCase()),
    z.string().regex(/^[a-z0-9-]{1,32}$/)]).safeParse(raw);
  if (!parsed.success || JSON.stringify(parsed.data) !== state.id.name) throw new Error('github_denied');
  return { principal: parsed.data[1], agent: parsed.data[2] };
}
function sourceEpoch(raw: string | undefined): number | null {
  if (!raw || !/^[1-9][0-9]*$/.test(raw)) return null;
  const value = Number(raw); return Number.isSafeInteger(value) ? value : null;
}
function next(value: number): number {
  if (!Number.isSafeInteger(value) || value < 1 || value >= Number.MAX_SAFE_INTEGER) throw new Error('github_watch_conflict');
  return value + 1;
}
function errorOutcome(error: unknown): WatchOutcome {
  if (error instanceof z.ZodError || error instanceof SyntaxError) return { status: 'error', code: 'invalid' };
  if (error instanceof AccessDenied) return { status: 'error', code: 'denied' };
  if (error instanceof AccessUnavailable) return { status: 'error', code: 'unavailable' };
  if (error instanceof EventApiError && error.code === 'unsupported') return { status: 'error', code: 'unsupported' };
  if (error instanceof EventApiError) return { status: 'error', code: error.status === 403 ? 'denied' : error.status === 503 ? 'unavailable' : error.status === 400 ? 'invalid' : 'conflict' };
  const reason = error instanceof Error ? error.message : '';
  if (/capacity/.test(reason)) return { status: 'error', code: 'capacity' };
  if (/denied/.test(reason)) return { status: 'error', code: 'denied' };
  if (/conflict|fenced/.test(reason)) return { status: 'error', code: 'conflict' };
  if (['unsupported', 'unsupported coordinator schema', 'github_watch_unsupported'].includes(reason))
    return { status: 'error', code: 'unsupported' };
  return { status: 'error', code: 'unavailable' };
}

export type WatchKernelEnvironment = WatchOwnerEnvironment & Pick<EventApiEnvironment,
  'OWNER_REGISTRY' | 'EVENT_NATIVE_BINDING_ENABLED' | 'EVENT_NATIVE_BINDING_CANARY' | 'GITHUB_SOURCE_MAP' | 'EVENT_GITHUB_WATCH_CONTROL_ENABLED'> & {
  EVENT_ENABLED?: string; EVENT_GITHUB_ENABLED?: string; EVENT_GITHUB_SOURCE_CONTROL_ENABLED?: string;
  EVENT_GITHUB_SOURCE_GATE_EPOCH?: string; GITHUB_ATTENTION_HOST?: DurableObjectNamespace<GitHubAttentionHost>;
};

/** Internal owner RPC kernel; no public HTTP route or delivery admission. */
export class WatchControlKernel {
  readonly #identity: { principal: string; agent: string };
  readonly #store: GitHubWatchControlStore;
  readonly #owner: WatchOwnerProofVerifier;
  constructor(private readonly state: DurableObjectState, private readonly env: WatchKernelEnvironment, ports?: AccessPorts) {
    this.#identity = watchCoordinatorIdentity(state);
    this.#store = new GitHubWatchControlStore(state.storage.sql, this.#identity.principal, this.#identity.agent);
    this.#owner = new WatchOwnerProofVerifier(env, ports);
  }
  async execute(call: EventAdminCall, rawRequest: string): Promise<WatchOutcome> {
    const deadline = new EventRequestDeadline();
    try {
      if (typeof rawRequest !== 'string' || rawRequest.length > WATCH_CONTROL_LIMITS.messageBytes || new TextEncoder().encode(rawRequest).byteLength > WATCH_CONTROL_LIMITS.messageBytes)
        return { status: 'error', code: 'invalid' };
      const raw: unknown = JSON.parse(rawRequest);
      if (raw && typeof raw === 'object' && 'kind' in raw && typeof raw.kind === 'string'
        && !['create', 'read', 'operation_readback', 'detach', 'unsubscribe'].includes(raw.kind)) return { status: 'error', code: 'unsupported' };
      const request = WatchRequestSchema.parse(raw);
      watchJson(request);
      const originalCall = Object.freeze({ ...call });
      const proof = await this.#owner.requireOwner(originalCall, this.#identity, request.kind, deadline);
      this.#owner.assertCurrent(proof);
      if (request.kind === 'read') {
        const watch = this.#store.read(request.input.subject);
        return this.#checked(watch ? { status: 'present', watch, attachmentStatus: watch.attachment === null ? 'none'
          : watch.attachment.leaseUntil > Date.now() ? 'live' : 'expired' } : { status: 'absent' });
      }
      if (request.kind === 'operation_readback') return this.#checked(this.#store.operation(request.input.subject, request.input.operationId, Date.now()));
      const replay = this.#store.exactOperation(request.input.operationId, request, Date.now());
      if (replay) return this.#checked(replay);
      if (request.kind === 'create') return await this.#create(originalCall, request, deadline);
      // Cleanup is owner/CAS authorized even when the node, runtime, grant or admission gate is dead.
      const view = await this.state.storage.transaction(async () => {
        const alarm = await this.state.storage.getAlarm();
        this.#owner.assertCurrent(proof);
        const again = this.#store.exactOperation(request.input.operationId, request, Date.now());
        if (again) return again;
        const current = this.#store.authority(request.input.subject);
        if (current.status !== 'watch') throw new Error('github_watch_conflict');
        const now = Date.now();
        const result = request.kind === 'detach' ? this.#store.detach(request.input, now)
          : this.#store.retireOrJoinStop(request.input, current.token.mode === 'stopped' ? current.token : this.#stopToken(current.token, request.input.operationId), now);
        const nextAt = this.#store.nextAt(now);
        if (nextAt !== null && (alarm === null || alarm > nextAt)) await this.state.storage.setAlarm(Math.max(now + 1, nextAt));
        this.#owner.assertCurrent(proof);
        return { status: 'committed' as const, operationId: request.input.operationId, result };
      });
      return this.#checked(view);
    } catch (error) { return errorOutcome(error); }
    finally { deadline.dispose(); }
  }
  #requireCreateEnabled(): void {
    if (this.env.EVENT_GITHUB_WATCH_CONTROL_ENABLED !== 'true') throw new Error('github_denied');
  }
  #checked(outcome: WatchOutcome): WatchOutcome { const parsed = WatchOutcomeSchema.parse(outcome); watchJson(parsed); return parsed; }
  #stopToken(token: WatchControlToken, operationId: string) {
    const view = this.#store.read(token.subject);
    if (!view) throw new Error('github_watch_conflict');
    return WatchStopTokenSchema.parse({ ...token, operationId, obligationId: crypto.randomUUID(), action: 'stop', mode: 'stopped',
      routingRevision: next(view.routingRevision), lifecycleEpoch: next(token.lifecycleEpoch) });
  }
  #holderSnapshot(holder: WatchHolder) {
    const store = new NativeRuntimeStore(this.state.storage.sql), runtime = store.runtime(holder.runtimeId), binding = store.binding(holder.runtimeId);
    if (!runtime || runtime.qualified !== 1 || runtime.runtime_generation !== holder.runtimeGeneration
      || runtime.attachment_generation !== holder.attachmentGeneration || runtime.node_id !== holder.nodeId
      || runtime.node_generation !== holder.nodeGeneration || runtime.lease_until <= Date.now() || !binding
      || !binding.key_thumbprint || !/^[A-Za-z0-9_-]{43}$/.test(binding.key_thumbprint)
      || !Number.isSafeInteger(binding.nonce) || binding.nonce < 0 || !Number.isSafeInteger(binding.sequence) || binding.sequence < 1)
      throw new Error('github_denied');
    const native = NativeRuntimeBindingSchema.parse(JSON.parse(binding.binding_json));
    if (native.clientId !== binding.client_id) throw new Error('github_denied');
    return { runtime, binding };
  }
  async #create(call: Readonly<EventAdminCall>, request: Extract<WatchRequest, { kind: 'create' }>, deadline: EventRequestDeadline): Promise<WatchOutcome> {
    const input: CreateWatchRequest = request.input;
    this.#requireCreateEnabled();
    requireNativeAdmissionCanary(this.env, this.#identity);
    if (this.env.EVENT_ENABLED !== 'true' || this.env.EVENT_GITHUB_ENABLED !== 'true'
      || this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED !== 'true' || !this.env.GITHUB_ATTENTION_HOST) throw new Error('github_denied');
    const sourceStore = new GitHubSourceControlStore(this.state.storage.sql, this.#identity.principal, this.#identity.agent);
    sourceStore.requireSourceOnlyOwnership(input.subject);
    const prior = sourceStore.control(input.subject);
    if (!prior || prior.state !== 'active' || sourceStore.pendingFor(input.subject)
      || prior.token.lifecycleEpoch > Number.MAX_SAFE_INTEGER - 2
      || prior.token.sourceIncarnation !== input.expectedSourceIncarnation || prior.token.lifecycleEpoch !== input.expectedLifecycleEpoch
      || prior.token.installationId !== input.source.installationId || this.#store.read(input.subject)) throw new Error('github_watch_conflict');
    const subject = { installationId: input.source.installationId, ...input.subject };
    const grants = new GitHubGrantStore(this.state.storage, this.#identity.principal, this.#identity.agent,
      () => this.env.GITHUB_SOURCE_MAP ?? '[]', () => this.env.EVENT_GITHUB_ENABLED === 'true' && this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED === 'true',
      () => sourceEpoch(this.env.EVENT_GITHUB_SOURCE_GATE_EPOCH));
    const sourceSnapshot = (inTransaction = false) => {
      const grant = grants.grant(subject), gate = inTransaction ? grants.sourceGateInTransaction(subject) : grants.sourceGate(subject);
      if (!grant || !gate.enabled || gate.deploymentEpoch === null || grant.revision !== input.source.grantRevision
        || grant.mappingRevision !== input.source.mappingRevision || grant.policyRevision !== input.source.policyRevision
        || gate.generation !== prior.token.sourceEnableGeneration || grant.revision !== prior.token.grantRevision
        || grant.mappingRevision !== prior.token.mappingRevision || grant.policyRevision !== prior.token.policyRevision)
        throw new Error('github_watch_conflict');
      return { grant, gate };
    };
    const source = sourceSnapshot(), sourceJson = JSON.stringify(source), holder = this.#holderSnapshot(input.holder), holderJson = JSON.stringify(holder);
    const identity = { ...this.#identity, subject };
    const checkpoint = GitHubWatchPromotionCheckpointSchema.parse(await deadline.run(() =>
      this.env.GITHUB_ATTENTION_HOST!.getByName(githubHostName(identity)).watchPromotionCheckpoint(identity), 20_000));
    if (checkpoint.sourceStatus.status === 'absent' || checkpoint.sourceStatus.hostControl !== 'active'
      || Math.max(checkpoint.snapshotEpoch, checkpoint.sourceStatus.hostEpoch, checkpoint.sourceRpcGeneration) > Number.MAX_SAFE_INTEGER - 2)
      throw new Error('github_watch_conflict');
    const node = await deadline.run<NodeAuthorization>(() => Promise.resolve(this.env.OWNER_REGISTRY.getByName(ownerRegistryName(this.#identity.principal))
      .currentNode({ nodeId: input.holder.nodeId, agent: this.#identity.agent, generation: input.holder.nodeGeneration })), 5000);
    if (node.status !== 'authorized' || node.node.nodeId !== input.holder.nodeId || node.node.generation !== input.holder.nodeGeneration
      || !node.node.agents.includes(this.#identity.agent)) throw new Error('github_denied');
    const proof = await this.#owner.requireOwner(call, this.#identity, 'create', deadline);
    const finalNode = await deadline.run<NodeAuthorization>(() => Promise.resolve(this.env.OWNER_REGISTRY.getByName(ownerRegistryName(this.#identity.principal))
      .currentNode({ nodeId: input.holder.nodeId, agent: this.#identity.agent, generation: input.holder.nodeGeneration })), 5000);
    if (finalNode.status !== 'authorized' || JSON.stringify(finalNode.node) !== JSON.stringify(node.node)) throw new Error('github_denied');
    this.#owner.assertCurrent(proof);
    const token = WatchActivateTokenSchema.parse({ ...prior.token, operationId: input.operationId, obligationId: crypto.randomUUID(),
      watchIncarnation: 1, routingRevision: 1, lifecycleEpoch: next(prior.token.lifecycleEpoch), action: 'activate', mode: 'watch' });
    const promotion = { predecessor: { operationId: prior.token.operationId, obligationId: prior.token.obligationId, lifecycleEpoch: prior.token.lifecycleEpoch },
      token, expectedSourceVersion: checkpoint.sourceStatus.sourceVersion, expectedHostEpoch: checkpoint.sourceStatus.hostEpoch };
    watchJson(promotion);
    const result = await this.state.storage.transaction(async () => {
      const alarm = await this.state.storage.getAlarm();
      this.#owner.assertCurrent(proof);
      const again = this.#store.exactOperation(input.operationId, request, Date.now());
      if (again) return again;
      this.#requireCreateEnabled();
      requireNativeAdmissionCanary(this.env, this.#identity);
      sourceStore.requireSourceOnlyOwnership(input.subject);
      const current = sourceStore.control(input.subject);
      if (!current || current.state !== 'active' || !sourceTokenEquals(current.token, prior.token) || sourceStore.pendingFor(input.subject)
        || JSON.stringify(sourceSnapshot(true)) !== sourceJson || JSON.stringify(this.#holderSnapshot(input.holder)) !== holderJson)
        throw new Error('github_watch_conflict');
      const now = Date.now(), leaseUntil = Math.min(now + input.leaseMs, holder.runtime.lease_until);
      const view = this.#store.promote({ request: input, predecessor: prior.token, token, leaseUntil,
        expectedSourceVersion: checkpoint.sourceStatus.sourceVersion, expectedHostEpoch: checkpoint.sourceStatus.hostEpoch, now });
      const nextAt = this.#store.nextAt(now);
      if (nextAt !== null && (alarm === null || alarm > nextAt)) await this.state.storage.setAlarm(Math.max(now + 1, nextAt));
      this.#requireCreateEnabled();
      this.#owner.assertCurrent(proof);
      requireNativeAdmissionCanary(this.env, this.#identity);
      if (JSON.stringify(sourceSnapshot(true)) !== sourceJson || JSON.stringify(this.#holderSnapshot(input.holder)) !== holderJson)
        throw new Error('github_watch_conflict');
      return { status: 'committed' as const, operationId: input.operationId, result: view };
    });
    return this.#checked(result);
  }
}
