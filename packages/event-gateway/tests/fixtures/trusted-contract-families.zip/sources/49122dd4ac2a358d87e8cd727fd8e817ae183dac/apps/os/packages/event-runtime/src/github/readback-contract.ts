import { z } from 'zod';

export const GITHUB_SOURCE_READ_REQUEST_BYTES = 4096;
export const GITHUB_SOURCE_READ_RESPONSE_BYTES = 8192;
const positive = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);
const nonnegative = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER);
const subject = z.object({ installationId: positive, repositoryId: positive, prNumber: positive }).strict();
const cursor = z.object({ subjectKey: z.string().max(128), fromVersion: positive, toVersion: positive, anchorVersion: positive, anchorEpoch: positive, observationEpoch: positive, revision: z.string().max(256), policyRevision: z.string().max(256), offset: nonnegative }).strict();
export const GitHubSourceReadRequestSchema = z.object({ subject, fromVersion: positive, toVersion: positive, cursor: cursor.optional() }).strict().refine(value => value.fromVersion <= value.toVersion);
export type GitHubSourceReadRequest = z.infer<typeof GitHubSourceReadRequestSchema>;
export type GitHubSourceReadCursor = z.infer<typeof cursor>;
export function parseGitHubSourceReadRequest(value: unknown): GitHubSourceReadRequest | null {
  try {
    if (new TextEncoder().encode(JSON.stringify(value)).length > GITHUB_SOURCE_READ_REQUEST_BYTES) return null;
    const result = GitHubSourceReadRequestSchema.safeParse(value);
    return result.success ? result.data : null;
  } catch { return null; }
}
const sha = z.string().regex(/^[a-f0-9]{40}$/);
const state = z.enum(['open', 'closed', 'merged']);
const finding = z.union([z.object({ presence: z.literal('absent') }), z.object({ presence: z.literal('present'), kind: z.enum(['review', 'thread', 'comment']), sourceHeadSha: sha.nullable(), fingerprint: z.string().regex(/^[a-f0-9]{64}$/), disposition: z.enum(['open', 'resolved']), outdated: z.boolean() })]);
const run = z.union([z.object({ presence: z.literal('absent') }), z.object({ presence: z.literal('present'), kind: z.enum(['check', 'status', 'workflow']), sourceId: z.string().max(64), headSha: sha, attempt: positive.nullable(), status: z.string().max(128).nullable(), conclusion: z.string().max(128).nullable(), startedAt: nonnegative.nullable(), completedAt: nonnegative.nullable(), workflowId: positive.optional(), runNumber: positive.optional() })]);
const projections = {
  version: z.object({ complete: z.literal(true), observedAt: nonnegative, candidateGeneration: nonnegative, coverageStartVersion: positive, candidate: z.object({ headSha: sha, baseSha: sha, observedMergeSha: sha.nullable() }), state }),
  terminal: z.object({ from: state.nullable(), to: state }),
  finding: z.object({ sourceId: z.string().max(4096), from: finding.nullable(), to: finding }),
  request: z.object({ kind: z.literal('review_request'), identity: z.string().max(128), from: z.enum(['present', 'absent']).nullable(), to: z.enum(['present', 'absent']) }),
  run: z.object({ from: run.nullable(), to: run }),
};
export type GitHubSourceRecordType = keyof typeof projections;
export interface GitHubSourceReadItem { phase: 'anchor' | 'transition'; sourceVersion: number; epoch: number; recordType: GitHubSourceRecordType; recordKey: string; value: Record<string, unknown> }
/** Strip every non-contract field, including nested provider metadata. */
export function projectGitHubSourceRecord(type: GitHubSourceRecordType, value: unknown): Record<string, unknown> {
  return projections[type].parse(value);
}
export interface GitHubSourceReadPage {
  status: 'ok'; subject: GitHubSourceReadRequest['subject']; requestedRange: { fromVersion: number; toVersion: number };
  // Envelope epoch fences lifecycle changes; item epochs identify committed observations and may be older.
  coverageStartVersion: number; anchor: { sourceVersion: number; epoch: number; observationEpoch: number; observedAt: number };
  items: GitHubSourceReadItem[]; nextCursor: GitHubSourceReadCursor | null; complete: boolean;
}
export type GitHubSourceReadResult = GitHubSourceReadPage | { status: 'coverage_unavailable' | 'conflict' };

const itemBase = { phase: z.enum(['anchor', 'transition']), sourceVersion: positive, epoch: positive, recordKey: z.string().max(4096) };
const item = z.discriminatedUnion('recordType', [
  z.object({ ...itemBase, recordType: z.literal('version'), value: projections.version }).strict(),
  z.object({ ...itemBase, recordType: z.literal('finding'), value: projections.finding }).strict(),
  z.object({ ...itemBase, recordType: z.literal('terminal'), value: projections.terminal }).strict(),
  z.object({ ...itemBase, recordType: z.literal('request'), value: projections.request }).strict(),
  z.object({ ...itemBase, recordType: z.literal('run'), value: projections.run }).strict(),
]);
export const GitHubSourceReadResultSchema = z.union([
  z.object({ status: z.enum(['coverage_unavailable', 'conflict']) }).strict(),
  z.object({ status: z.literal('ok'), subject, requestedRange: z.object({ fromVersion: positive, toVersion: positive }).strict(), coverageStartVersion: positive,
    anchor: z.object({ sourceVersion: positive, epoch: positive, observationEpoch: positive, observedAt: nonnegative }).strict(),
    items: z.array(item), nextCursor: cursor.nullable(), complete: z.boolean(),
  }).strict().refine(value => value.complete === (value.nextCursor === null) && value.anchor.observationEpoch <= value.anchor.epoch
    && value.items.every(entry => entry.phase !== 'anchor' || entry.epoch === value.anchor.observationEpoch)
    && (value.nextCursor === null || value.nextCursor.observationEpoch === value.anchor.observationEpoch)),
]).refine(value => new TextEncoder().encode(JSON.stringify(value)).length <= GITHUB_SOURCE_READ_RESPONSE_BYTES);
