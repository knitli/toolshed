import { z } from 'zod';
import { GitHubPublicationInputSchema } from './grants';
import type { GitHubSourceReadItem } from './readback-contract';

const positive = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);
const cursor = z.strictObject({ rangeDigest: z.string().regex(/^[a-f0-9]{64}$/), offset: z.number().int().positive().max(16_384) });
/** Internal storage locator only; neither a public reference nor read authority. */
export const PinnedMetadataReadSchema = z.strictObject({ publication: GitHubPublicationInputSchema,
  toVersion: positive, cursor: cursor.optional() }).refine(input => input.publication.event.sourceVersion <= input.toVersion);
export type PinnedMetadataRead = z.infer<typeof PinnedMetadataReadSchema>;
export type PinnedMetadataReadResult = { status: 'unavailable' | 'coverage_unavailable' | 'conflict' } | {
  status: 'ok'; publicationId: string; fromVersion: number; toVersion: number;
  items: GitHubSourceReadItem[]; nextCursor: z.infer<typeof cursor> | null; complete: boolean;
};
