import type { WatchOutcome } from './github/watch-control-internal';
import type { GitHubGrantInput, GitHubGrantView, GitHubSourceOwnerView } from "./github/grants.ts";
import type { GitHubSourceAdoptionInput, GitHubSourceInitializationInput } from "./github/source-control.ts";
export type GitHubSourceStatusView = GitHubSourceOwnerView;
/** Original human assertion; mutation metadata is forwarded from the browser unchanged. */
export type EventAdminCall = { token: string; origin?: string | null; fetchSite?: string | null; csrf?: string | null };
export type EventAdminOutcome<T> =
  | { outcome: "allowed"; value: T }
  | { outcome: "denied" }
  | { outcome: "unavailable" }
  | { outcome: "refused"; code: string; message: string };
export type EventNodeView = {
  nodeId: string; publicKey: string; meshIp: string; meshPort: number;
  agents: string[]; generation: number; revoked: boolean;
};
export type EventDeliveryStatusView = {
  deliveryId: string; runtimeId: string; state: string; reason: string | null; createdAt: number;
};
export type EventDeliveryCounts = {
  pending: number; submitted: number; ambiguous: number; expired: number; observed: number;
  failed: number; over_budget: number; unavailable: number; revoked: number;
};
export type EventStatusView = {
  agent: string; enabled: boolean; nodes: EventNodeView[];
  counts: EventDeliveryCounts;
  recent: EventDeliveryStatusView[];
  recentLimit: 20;
  recentTruncated: boolean;
  nativeBinding: "unqualified";
  inFlightCaveat: string;
};
export type EventChallengeInput = {
  nodeId: string; publicKey: string; meshIp: string; meshPort: number; agents: string[];
};
export type EventChallengeView = { challengeId: string; nodeId: string; expiresAt: string; signingPayload: string };
export type EventRevokeInput = { nodeId: string; expectedGeneration: number };
export type EventEnabledInput = { agent: string; enabled: boolean };
export type EventManualInput = { agent: string; runtimeId: string; subjectId: string };
export type EventTransferInput = { agent: string; runtimeId: string; replacementRuntimeId: string; expectedAttachmentGeneration: number };
export interface EventAdminService {
  githubWatchControl(call: EventAdminCall, input: { agent: string; request: string }): Promise<EventAdminOutcome<WatchOutcome>>;
  capabilities(call: EventAdminCall): Promise<EventAdminOutcome<{ owner: true }>>;
  status(call: EventAdminCall, input: { agent: string }): Promise<EventAdminOutcome<EventStatusView>>;
  createChallenge(call: EventAdminCall, input: EventChallengeInput): Promise<EventAdminOutcome<EventChallengeView>>;
  revokeNode(call: EventAdminCall, input: EventRevokeInput): Promise<EventAdminOutcome<EventNodeView>>;
  setEnabled(call: EventAdminCall, input: EventEnabledInput): Promise<EventAdminOutcome<{ enabled: boolean }>>;
  manual(call: EventAdminCall, input: EventManualInput): Promise<EventAdminOutcome<{ deliveryId: string }>>;
  githubSourceStatus(call: EventAdminCall, input: { agent: string; subject: GitHubGrantInput['subject']; operationId?: string }): Promise<EventAdminOutcome<GitHubSourceOwnerView>>;
  initializeGitHubSource(call: EventAdminCall, input: GitHubSourceInitializationInput & { agent: string }): Promise<EventAdminOutcome<GitHubSourceOwnerView>>;
  adoptGitHubSource(call: EventAdminCall, input: GitHubSourceAdoptionInput & { agent: string }): Promise<EventAdminOutcome<GitHubSourceOwnerView>>;
  setGitHubGrant(call: EventAdminCall, input: GitHubGrantInput & { agent: string }): Promise<EventAdminOutcome<GitHubGrantView>>;
  transfer(call: EventAdminCall, input: EventTransferInput): Promise<EventAdminOutcome<{ attachmentGeneration: number }>>;
}
