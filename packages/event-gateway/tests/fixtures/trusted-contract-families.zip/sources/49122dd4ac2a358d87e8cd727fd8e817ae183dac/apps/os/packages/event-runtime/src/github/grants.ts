import { z } from 'zod';
import { canonicalEmail } from 'openapi-operator/src/access';
import { agent } from '../contracts';
import { EVENT_POLICY_V1 } from '../policy';
import { subjectKey } from './state';
import { InternalControlTokenSchema, WatchSubjectSchema } from './watch-control-internal';
import { canonicalSourceKey, GITHUB_SOURCE_CONTROL_LIMITS, GitHubSourceControlViewSchema, GitHubSourceOperationReceiptSchema, type GitHubSourceControlView } from './source-control';

const positive = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);
const revision = z.string().min(1).max(128);
const retainedGrantRows = 128; // 64 enabled plus the 64 retained disabled grants.
const retainedSourceGateRows = retainedGrantRows + GITHUB_SOURCE_CONTROL_LIMITS.sourceOnlyAssociationsPerAgent;
export const GitHubGrantSubjectSchema = z.strictObject({ installationId: positive, repositoryId: positive, prNumber: positive });
const principalSchema = z.string().refine(value => canonicalEmail(value) && value === value.toLowerCase());
const mappingSchema = z.array(z.strictObject({ principal: principalSchema, agent, installationId: positive, repositoryId: positive, revision })).max(64)
  .refine(values => new Set(values.map(value => JSON.stringify([value.principal, value.agent, value.repositoryId]))).size === values.length);
export function parseGitHubSourceMap(raw: string) {
  if (typeof raw !== 'string' || raw.length > 32768) throw new Error('github_mapping_invalid');
  return mappingSchema.parse(JSON.parse(raw));
}
export const GitHubGrantInputSchema = z.strictObject({ subject: GitHubGrantSubjectSchema, enabled: z.boolean(), expectedRevision: positive.or(z.literal(0)), policyRevision: revision });
const eventSchema = z.strictObject({
  publicationId: z.string().min(1).max(256), subject: GitHubGrantSubjectSchema, sourceVersion: positive,
  candidateGeneration: positive, observedAt: positive, eventKind: z.enum(['attention', 'ci', 'terminal']),
  reasonCode: z.enum(['review_requested', 'review_submitted', 'review_comment', 'check_failed', 'status_failed', 'pull_request_closed', 'pull_request_merged']),
}).refine(event => event.candidateGeneration <= event.sourceVersion && event.publicationId === `${subjectKey(event.subject)}:${event.sourceVersion}:${event.reasonCode}` &&
  event.eventKind === (event.reasonCode.startsWith('pull_request_') ? 'terminal' : event.reasonCode.endsWith('_failed') ? 'ci' : 'attention'));
const publicationSchema = z.strictObject({ event: eventSchema, grantRevision: positive, mappingRevision: revision, policyRevision: revision });
export const GitHubPublicationInputSchema = publicationSchema;
export type GitHubGrantInput = z.infer<typeof GitHubGrantInputSchema>;
export type GitHubPublicationInput = z.infer<typeof publicationSchema>;
const publicationPinSchema = z.strictObject({ principal: principalSchema, agent, publicationId: z.string().min(1).max(256), subject: GitHubGrantSubjectSchema, sourceVersion: positive });
export type GitHubPublicationPin = z.infer<typeof publicationPinSchema>;
export const GitHubGrantViewSchema = z.strictObject({ subject: GitHubGrantSubjectSchema, enabled: z.boolean(), revision: positive, mappingRevision: revision, policyRevision: revision });
export type GitHubGrantView = z.infer<typeof GitHubGrantViewSchema>;
export type GitHubPublicationDisposition = {
  status: 'accepted'; publicationId: string; sourceVersion: number;
  disposition: 'unsettled' | 'settled' | 'terminal'; releaseAcknowledged: boolean;
};
export type GitHubPublicationRelease = {
  status: 'released' | 'absent'; publicationId: string; sourceVersion: number;
  disposition: 'settled' | 'terminal';
};
const acceptedPublication = (input: GitHubPublicationInput, disposition: GitHubPublicationDisposition['disposition'], releaseAcknowledged: boolean): GitHubPublicationDisposition => ({
  status: 'accepted', publicationId: input.event.publicationId, sourceVersion: input.event.sourceVersion, disposition, releaseAcknowledged,
});

export const GitHubSourceStatusSchema = z.strictObject({
  status: z.enum(['absent', 'pending', 'ready']), sourceVersion: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  health: z.enum(['unknown', 'fresh', 'stale', 'denied']).nullable(),
  failureReason: z.enum(['denied', 'incomplete', 'capacity', 'unavailable']).nullable(),
  nextAttemptAt: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER).nullable(),
  /** Local host fencing checkpoint; it never substitutes for canonical owner CAS. */
  hostEpoch: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  hostControl: z.enum(['absent', 'prepared', 'quiesced', 'active', 'parked']),
});
export const GitHubSourceOwnerViewSchema = z.strictObject({ grant: GitHubGrantViewSchema.nullable(), mappingCurrent: z.boolean(), source: GitHubSourceStatusSchema, control: GitHubSourceControlViewSchema, sourceControlEnabled: z.boolean(), operation: GitHubSourceOperationReceiptSchema.nullable() });
export type GitHubSourceOwnerView = z.infer<typeof GitHubSourceOwnerViewSchema>;
export type GitHubSourceStatus = z.infer<typeof GitHubSourceStatusSchema>;
export type GitHubSourceControlStatus = GitHubSourceControlView;
export type GitHubSourceGate = { enabled: boolean; generation: number; deploymentEpoch: number | null };
export type GitHubSourceGateEvidence = GitHubSourceGate & { configurationEnabled: boolean; epochInvalid: boolean };

/** Coordinator-local source authorization only; this does not authorize external dispatch or prove queue exclusion. */
export class GitHubGrantStore {
  // eslint-disable-next-line no-unused-vars -- TypeScript parameter properties are read through this.installationMappingJson.
  constructor(private readonly storage: DurableObjectStorage, private readonly principal: string, private readonly agentName: string,
    private readonly installationMappingJson: string | (() => string), private readonly configurationEnabled: boolean | (() => boolean) = true,
    private readonly configurationEpoch: number | null | (() => number | null) = null) {
    principalSchema.parse(principal); agent.parse(agentName);
    storage.transactionSync(() => {
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_grants (subject TEXT PRIMARY KEY, value TEXT NOT NULL)');
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_grant_sequence (id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL)');
      storage.sql.exec("INSERT INTO github_grant_sequence(id,revision) SELECT 1,COALESCE(MAX(json_extract(value,'$.revision')),0) FROM github_grants WHERE true ON CONFLICT(id) DO UPDATE SET revision=MAX(revision,excluded.revision)");
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_publications (id TEXT PRIMARY KEY, value TEXT NOT NULL, accepted_at INTEGER NOT NULL)');
      storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_source_gates(
        subject TEXT PRIMARY KEY, enabled INTEGER NOT NULL CHECK(enabled IN (0,1)), generation INTEGER NOT NULL CHECK(generation>0), deployment_epoch INTEGER, configuration_enabled INTEGER NOT NULL DEFAULT 0 CHECK(configuration_enabled IN (0,1)), epoch_invalid INTEGER NOT NULL DEFAULT 0 CHECK(epoch_invalid IN (0,1)))`);
      const gateColumns = storage.sql.exec<{ name: string }>('PRAGMA table_info(github_source_gates)').toArray();
      if (!gateColumns.some(column => column.name === 'deployment_epoch')) storage.sql.exec('ALTER TABLE github_source_gates ADD COLUMN deployment_epoch INTEGER');
      if (!gateColumns.some(column => column.name === 'configuration_enabled')) storage.sql.exec('ALTER TABLE github_source_gates ADD COLUMN configuration_enabled INTEGER NOT NULL DEFAULT 0');
      if (!gateColumns.some(column => column.name === 'epoch_invalid')) storage.sql.exec('ALTER TABLE github_source_gates ADD COLUMN epoch_invalid INTEGER NOT NULL DEFAULT 0');
      const columns = storage.sql.exec<{ name: string }>('PRAGMA table_info(github_publications)').toArray();
      if (!columns.some(column => column.name === 'accepted_at')) {
        storage.sql.exec('ALTER TABLE github_publications ADD COLUMN accepted_at INTEGER NOT NULL DEFAULT 0');
        // Legacy receipts get a full recovery window; construction never renews it.
        storage.sql.exec('UPDATE github_publications SET accepted_at=?', Date.now());
      }
      if (!columns.some(column => column.name === 'source_version')) storage.sql.exec('ALTER TABLE github_publications ADD COLUMN source_version INTEGER');
      if (!columns.some(column => column.name === 'disposition')) storage.sql.exec("ALTER TABLE github_publications ADD COLUMN disposition TEXT NOT NULL DEFAULT 'legacy'");
      if (!columns.some(column => column.name === 'release_ack_at')) storage.sql.exec('ALTER TABLE github_publications ADD COLUMN release_ack_at INTEGER');
      storage.sql.exec('CREATE INDEX IF NOT EXISTS github_publications_disposition ON github_publications(disposition,accepted_at,release_ack_at)');
    });
  }
  private mappings() { return parseGitHubSourceMap(typeof this.installationMappingJson === 'function' ? this.installationMappingJson() : this.installationMappingJson); }
  private mapping(subject: GitHubGrantView['subject']) {
    return this.mappings().find(value => value.principal === this.principal && value.agent === this.agentName && value.installationId === subject.installationId && value.repositoryId === subject.repositoryId);
  }
  private stored(subject: GitHubGrantView['subject']): GitHubGrantView | null {
    const row = this.storage.sql.exec<{ value: string }>('SELECT value FROM github_grants WHERE subject=?', subjectKey(subject)).toArray().at(0);
    return row ? JSON.parse(row.value) as GitHubGrantView : null;
  }
  setGrant(input: GitHubGrantInput): GitHubGrantView {
    const parsed = GitHubGrantInputSchema.parse(input);
    return this.storage.transactionSync(() => {
      const prior = this.stored(parsed.subject), mapping = this.mapping(parsed.subject);
      // Revocation remains possible after the operator removes a mapping.
      if (!mapping && (parsed.enabled || !prior)) throw new Error('github_denied');
      if ((prior?.revision ?? 0) !== parsed.expectedRevision || parsed.expectedRevision === Number.MAX_SAFE_INTEGER) throw new Error('github_grant_conflict');
      if (parsed.enabled && !prior?.enabled && this.storage.sql.exec<{ n: number }>("SELECT count(*) AS n FROM github_grants WHERE json_extract(value,'$.enabled')=1").one().n >= 64) throw new Error('github_capacity');
      const previousRevision = this.storage.sql.exec<{ revision: number }>('SELECT revision FROM github_grant_sequence WHERE id=1').one().revision;
      if (previousRevision >= Number.MAX_SAFE_INTEGER) throw new Error('github_grant_conflict');
      const nextRevision = previousRevision + 1;
      this.storage.sql.exec('UPDATE github_grant_sequence SET revision=? WHERE id=1', nextRevision);
      const value: GitHubGrantView = { subject: parsed.subject, enabled: parsed.enabled, revision: nextRevision, mappingRevision: mapping?.revision ?? prior!.mappingRevision, policyRevision: parsed.policyRevision };
      this.storage.sql.exec('INSERT OR REPLACE INTO github_grants(subject,value) VALUES (?,?)', subjectKey(parsed.subject), JSON.stringify(value));
      // The global revision survives eviction, so an absent subject can never reuse an old grant generation.
      this.storage.sql.exec("DELETE FROM github_grants WHERE subject IN (SELECT subject FROM github_grants WHERE json_extract(value,'$.enabled')=0 ORDER BY json_extract(value,'$.revision') DESC LIMIT -1 OFFSET 64)");
      this.#syncSourceGate(parsed.subject);
      this.pruneSourceGates();
      return value;
    });
  }
  #syncSourceGate(subject: GitHubGrantView['subject']): GitHubSourceGate {
    const grant = this.stored(subject), mapping = this.mapping(subject);
    const retainedAssociation = this.hasRetainedSourceAssociation(subject);
    const configured = typeof this.configurationEnabled === 'function' ? this.configurationEnabled() : this.configurationEnabled;
    const rawEpoch = typeof this.configurationEpoch === 'function' ? this.configurationEpoch() : this.configurationEpoch;
    const validEpoch = Number.isSafeInteger(rawEpoch) && rawEpoch! > 0 ? rawEpoch! : null;
    const key = subjectKey(subject), prior = this.storage.sql.exec<{ enabled: number; generation: number; deployment_epoch: number | null; configuration_enabled: number; epoch_invalid: number }>('SELECT enabled,generation,deployment_epoch,configuration_enabled,epoch_invalid FROM github_source_gates WHERE subject=?', key).toArray().at(0);
    // A status read for an unknown subject must not allocate permanent authority
    // state. Existing source controls/outbox rows retain their gate tombstone.
    if (!grant && !prior && !retainedAssociation)
      return { enabled: false, generation: 0, deploymentEpoch: validEpoch };
    const enabled = configured && validEpoch !== null && !!grant?.enabled && mapping?.revision === grant.mappingRevision;
    if (!prior) {
      this.storage.sql.exec('INSERT INTO github_source_gates(subject,enabled,generation,deployment_epoch,configuration_enabled,epoch_invalid) VALUES (?,?,1,?,?,?)', key, Number(enabled), validEpoch, Number(configured), Number(validEpoch === null));
      return { enabled, generation: 1, deploymentEpoch: validEpoch };
    }
    if (validEpoch === null) {
      const invalidate = prior.epoch_invalid === 0 || prior.enabled === 1;
      // The invalid marker is itself a fail-closed fence when the monotonic
      // generation is exhausted. Never roll back a grant revocation because
      // advancing this secondary generation is no longer possible.
      const generation = prior.generation + Number(invalidate && prior.generation < Number.MAX_SAFE_INTEGER);
      this.storage.sql.exec('UPDATE github_source_gates SET enabled=0,generation=?,configuration_enabled=?,epoch_invalid=1 WHERE subject=? AND generation=?', generation, Number(configured), key, prior.generation);
      return { enabled: false, generation, deploymentEpoch: prior.deployment_epoch };
    }
    const epochRegressed = prior.deployment_epoch !== null && validEpoch < prior.deployment_epoch;
    const epochChanged = prior.deployment_epoch === null || validEpoch > prior.deployment_epoch;
    const configChanged = (prior.configuration_enabled === 1) !== configured;
    const invalidSameEpoch = prior.epoch_invalid === 1 && !epochChanged;
    const unqualifiedConfigChange = configChanged && !epochChanged;
    if (epochRegressed || invalidSameEpoch || unqualifiedConfigChange) {
      // Persist the fail-closed state. Throwing here would roll back the fence and
      // allow the old epoch to revive a token after a disable/restore cycle.
      const invalidate = prior.epoch_invalid === 0 || prior.enabled === 1;
      const generation = prior.generation + Number(invalidate && prior.generation < Number.MAX_SAFE_INTEGER);
      this.storage.sql.exec('UPDATE github_source_gates SET enabled=0,generation=?,configuration_enabled=?,epoch_invalid=1 WHERE subject=? AND generation=?', generation, Number(configured), key, prior.generation);
      return { enabled: false, generation, deploymentEpoch: prior.deployment_epoch };
    }
    const gateChanged = (prior.enabled === 1) !== enabled;
    if (epochChanged || gateChanged || configChanged) {
      if (prior.generation >= Number.MAX_SAFE_INTEGER) {
        // Persist closure at the maximum counter. A larger deployment epoch
        // cannot revive this authority because no fresh source generation can
        // be issued without wrapping or reusing a prior token value.
        this.storage.sql.exec('UPDATE github_source_gates SET enabled=0,configuration_enabled=?,epoch_invalid=1 WHERE subject=? AND generation=?', Number(configured), key, prior.generation);
        return { enabled: false, generation: prior.generation, deploymentEpoch: prior.deployment_epoch };
      }
      const generation = prior.generation + 1;
      // Every distinct deployment epoch invalidates old tokens, including a disable/restore
      // cycle that happened while the Durable Object was idle.
      this.storage.sql.exec('UPDATE github_source_gates SET enabled=?,generation=?,deployment_epoch=?,configuration_enabled=?,epoch_invalid=0 WHERE subject=? AND generation=?', Number(enabled), generation, validEpoch, Number(configured), key, prior.generation);
      return { enabled, generation, deploymentEpoch: validEpoch };
    }
    return { enabled: enabled && prior.epoch_invalid === 0, generation: prior.generation, deploymentEpoch: prior.deployment_epoch };
  }
  private retainedSourceTokens(subject: GitHubGrantView['subject']) {
    const canonical = canonicalSourceKey(subject);
    const tables = new Set(this.storage.sql.exec<{ name: string }>("SELECT name FROM sqlite_master WHERE type='table'").toArray().map(row => row.name));
    const tokens = [];
    for (const table of ['github_source_controls', 'github_source_outbox', 'github_watch_outbox'] as const) {
      if (!tables.has(table)) continue;
      const hasOwner = this.storage.sql.exec<{ name: string }>(`PRAGMA table_info(${table})`).toArray().some(column => column.name === 'control_owner');
      const rows = this.storage.sql.exec<{ operation_id: string; token_json: string; control_owner: string | null; subject_json: string | null }>(
        `SELECT operation_id,token_json,${table === 'github_source_controls' ? 'subject_json' : 'NULL AS subject_json'},${hasOwner ? 'control_owner' : 'NULL AS control_owner'} FROM ${table} WHERE canonical_subject=? LIMIT 65`, canonical).toArray();
      if (rows.length > 64) throw new Error('github_source_history_capacity');
      for (const row of rows) {
        let raw: unknown;
        try { raw = JSON.parse(row.token_json); } catch { throw new Error('github_source_history_unavailable'); }
        const parsed = InternalControlTokenSchema.safeParse(raw);
        if (!parsed.success || parsed.data.operationId !== row.operation_id || parsed.data.principal !== this.principal
          || parsed.data.agent !== this.agentName || canonicalSourceKey(parsed.data.subject) !== canonical)
          throw new Error('github_source_history_unavailable');
        if (table === 'github_source_controls') {
          let rawSubject: unknown;
          try { rawSubject = JSON.parse(row.subject_json!); } catch { throw new Error('github_source_history_unavailable'); }
          const storedSubject = WatchSubjectSchema.or(GitHubGrantSubjectSchema).safeParse(rawSubject);
          if (!storedSubject.success || canonicalSourceKey(storedSubject.data) !== canonical
            || ('installationId' in storedSubject.data && storedSubject.data.installationId !== parsed.data.installationId)) throw new Error('github_source_history_unavailable');
        }
        const owner = parsed.data.mode === 'source_only' ? 'source_only' : 'watch';
        if ((hasOwner && row.control_owner !== owner) || (table === 'github_source_controls' && !hasOwner && owner !== 'source_only')
          || (table === 'github_source_outbox' && owner !== 'source_only')
          || (table === 'github_watch_outbox' && owner !== 'watch'))
          throw new Error('github_source_history_unavailable');
        tokens.push(parsed.data);
      }
    }
    return tokens;
  }
  private hasRetainedSourceAssociation(subject: GitHubGrantView['subject']): boolean {
    return this.retainedSourceTokens(subject).some(token => token.installationId === subject.installationId);
  }
  private pruneSourceGates(): void {
    for (const row of this.storage.sql.exec<{ subject: string }>('SELECT subject FROM github_source_gates').toArray()) {
      if (this.storage.sql.exec('SELECT 1 FROM github_grants WHERE subject=? LIMIT 1', row.subject).toArray().length) continue;
      let values: unknown[];
      try { values = JSON.parse(row.subject) as unknown[]; } catch { continue; }
      if (!Array.isArray(values) || values.length !== 3) continue;
      const parsed = GitHubGrantSubjectSchema.safeParse({ installationId: values[0], repositoryId: values[1], prNumber: values[2] });
      if (!parsed.success) continue;
      if (!this.hasRetainedSourceAssociation(parsed.data)) this.storage.sql.exec('DELETE FROM github_source_gates WHERE subject=? AND enabled=0', row.subject);
    }
  }
  sourceGate(subject: GitHubGrantView['subject']): GitHubSourceGate {
    GitHubGrantSubjectSchema.parse(subject);
    return this.storage.transactionSync(() => this.#syncSourceGate(subject));
  }
  sourceGateInTransaction(subject: GitHubGrantView['subject']): GitHubSourceGate {
    GitHubGrantSubjectSchema.parse(subject);
    return this.#syncSourceGate(subject);
  }
  sourceGateEvidence(subject: GitHubGrantView['subject']): GitHubSourceGateEvidence {
    GitHubGrantSubjectSchema.parse(subject);
    return this.storage.transactionSync(() => this.sourceGateEvidenceInTransaction(subject));
  }
  sourceGateEvidenceInTransaction(subject: GitHubGrantView['subject']): GitHubSourceGateEvidence {
    GitHubGrantSubjectSchema.parse(subject);
    const gate = this.#syncSourceGate(subject);
    const stored = this.storage.sql.exec<{ configuration_enabled: number; epoch_invalid: number }>(
      'SELECT configuration_enabled,epoch_invalid FROM github_source_gates WHERE subject=?', subjectKey(subject)).toArray().at(0);
    return { ...gate, configurationEnabled: stored?.configuration_enabled === 1, epochInvalid: stored?.epoch_invalid === 1 };
  }
  storedGrantValue(input: GitHubGrantView['subject']): GitHubGrantView | null {
    return this.stored(GitHubGrantSubjectSchema.parse(input));
  }
  storedGrant(input: GitHubGrantView['subject']) {
    const subject = GitHubGrantSubjectSchema.parse(input), grant = this.stored(subject);
    return { grant, mappingCurrent: !!grant && this.mapping(subject)?.revision === grant.mappingRevision };
  }
  grant(input: GitHubGrantView['subject']): GitHubGrantView | null {
    const subject = GitHubGrantSubjectSchema.parse(input), value = this.stored(subject);
    return value?.enabled && this.mapping(subject)?.revision === value.mappingRevision ? value : null;
  }
  watches(): GitHubGrantView['subject'][] {
    return this.storage.sql.exec<{ value: string }>("SELECT value FROM github_grants WHERE json_extract(value,'$.enabled')=1 ORDER BY subject LIMIT 64").toArray()
      .map(row => JSON.parse(row.value) as GitHubGrantView).filter(value => this.grant(value.subject)).map(value => value.subject);
  }
  /**
   * Bounded retained evidence of installation-specific hosts for one canonical PR.
   * This is deliberately broader than current grants: disabled grants, retained
   * publications, gates, watches, and source receipts can reveal a prior host.
   * It cannot prove absence for history already pruned from every coordinator table.
   */
  historicalSourceSubjects(input: GitHubGrantView['subject']): GitHubGrantView['subject'][] {
    const requested = GitHubGrantSubjectSchema.parse(input), byInstallation = new Map<number, GitHubGrantView['subject']>();
    const add = (value: unknown) => {
      const parsed = GitHubGrantSubjectSchema.safeParse(value);
      if (!parsed.success) throw new Error('github_source_history_unavailable');
      if (parsed.data.repositoryId === requested.repositoryId && parsed.data.prNumber === requested.prNumber)
        byInstallation.set(parsed.data.installationId, parsed.data);
    };
    const parseKey = (raw: string) => {
      let values: unknown;
      try { values = JSON.parse(raw); } catch { throw new Error('github_source_history_unavailable'); }
      if (!Array.isArray(values) || values.length !== 3) throw new Error('github_source_history_unavailable');
      const parsed = GitHubGrantSubjectSchema.safeParse({ installationId: values[0], repositoryId: values[1], prNumber: values[2] });
      if (!parsed.success) throw new Error('github_source_history_unavailable');
      return parsed.data;
    };
    add(requested);
    const tables = new Set(this.storage.sql.exec<{ name: string }>("SELECT name FROM sqlite_master WHERE type='table'").toArray().map(row => row.name));
    if (tables.has('github_grants')) {
      const rows = this.storage.sql.exec<{ subject: string; value: string }>(`SELECT subject,value FROM github_grants LIMIT ${retainedGrantRows + 1}`).toArray();
      if (rows.length > retainedGrantRows) throw new Error('github_source_history_capacity');
      for (const row of rows) {
        const key = parseKey(row.subject);
        if (key.repositoryId !== requested.repositoryId || key.prNumber !== requested.prNumber) continue;
        let raw: unknown;
        try { raw = JSON.parse(row.value); } catch { throw new Error('github_source_history_unavailable'); }
        const value = GitHubGrantViewSchema.safeParse(raw);
        if (!value.success || subjectKey(value.data.subject) !== row.subject) throw new Error('github_source_history_unavailable');
        add(value.data.subject);
      }
    }
    if (tables.has('github_publications')) {
      const rows = this.storage.sql.exec<{ id: string; value: string }>('SELECT id,value FROM github_publications LIMIT 1001').toArray();
      if (rows.length > 1000) throw new Error('github_source_history_capacity');
      for (const row of rows) {
        const separator = row.id.indexOf(']:');
        if (separator < 0) throw new Error('github_source_history_unavailable');
        const key = parseKey(row.id.slice(0, separator + 1));
        if (key.repositoryId !== requested.repositoryId || key.prNumber !== requested.prNumber) continue;
        let raw: unknown;
        try { raw = JSON.parse(row.value); } catch { throw new Error('github_source_history_unavailable'); }
        const value = publicationSchema.safeParse(raw);
        if (!value.success || value.data.event.publicationId !== row.id || subjectKey(value.data.event.subject) !== row.id.slice(0, separator + 1))
          throw new Error('github_source_history_unavailable');
        add(value.data.event.subject);
      }
    }
    if (tables.has('github_source_gates')) {
      const rows = this.storage.sql.exec<{ subject: string }>(`SELECT subject FROM github_source_gates LIMIT ${retainedSourceGateRows + 1}`).toArray();
      if (rows.length > retainedSourceGateRows) throw new Error('github_source_history_capacity');
      for (const row of rows) {
        const key = parseKey(row.subject);
        if (key.repositoryId === requested.repositoryId && key.prNumber === requested.prNumber) add(key);
      }
    }
    if (tables.has('github_delivery_watches')) {
      const watch = this.storage.sql.exec<{ value: string }>(
        'SELECT value FROM github_delivery_watches WHERE owner=? AND subject=? LIMIT 1',
        JSON.stringify([this.principal, this.agentName]), JSON.stringify([requested.repositoryId, requested.prNumber])).toArray().at(0);
      if (watch) {
        let value: unknown;
        try { value = JSON.parse(watch.value); } catch { throw new Error('github_source_history_unavailable'); }
        if (!value || typeof value !== 'object' || !('subject' in value) || !('installationId' in value)) throw new Error('github_source_history_unavailable');
        const record = value as { subject: unknown; installationId: unknown };
        const parsedSubject = z.strictObject({ repositoryId: positive, prNumber: positive }).safeParse(record.subject);
        if (!parsedSubject.success || parsedSubject.data.repositoryId !== requested.repositoryId || parsedSubject.data.prNumber !== requested.prNumber)
          throw new Error('github_source_history_unavailable');
        add({ ...parsedSubject.data, installationId: record.installationId });
      }
    }
    for (const token of this.retainedSourceTokens(requested)) add({ ...token.subject, installationId: token.installationId });
    if (tables.has('github_source_operations')) {
      const rows = this.storage.sql.exec<{ request_json: string }>(
        'SELECT request_json FROM github_source_operations WHERE canonical_subject=? LIMIT 65', canonicalSourceKey(requested)).toArray();
      if (rows.length > 64) throw new Error('github_source_history_capacity');
      for (const row of rows) {
        let value: unknown;
        try { value = JSON.parse(row.request_json); } catch { throw new Error('github_source_history_unavailable'); }
        if (!value || typeof value !== 'object' || !('subject' in value)) throw new Error('github_source_history_unavailable');
        const operationSubject = GitHubGrantSubjectSchema.safeParse((value as { subject: unknown }).subject);
        if (!operationSubject.success || canonicalSourceKey(operationSubject.data) !== canonicalSourceKey(requested))
          throw new Error('github_source_history_unavailable');
        add(operationSubject.data);
      }
    }
    if (byInstallation.size > GITHUB_SOURCE_CONTROL_LIMITS.historicalHostPreflightsPerSource) throw new Error('github_source_history_capacity');
    return [...byInstallation.values()].toSorted((left, right) => left.installationId - right.installationId);
  }
  /** Recover an already committed outcome without granting any new source or dispatch authority. */
  publicationReceipt(input: GitHubPublicationInput, now = Date.now()): { status: 'accepted'; publicationId: string } | null {
    const parsed = publicationSchema.parse(input);
    const prior = this.storage.sql.exec<{ value: string; accepted_at: number; disposition: string }>('SELECT value,accepted_at,disposition FROM github_publications WHERE id=?', parsed.event.publicationId).toArray().at(0);
    if (!prior) return null;
    if (prior.value !== JSON.stringify(parsed)) throw new Error('github_publication_conflict');
    if (prior.disposition === 'legacy' && prior.accepted_at <= now - EVENT_POLICY_V1.terminalDeduplicationRetentionMs) return null;
    return { status: 'accepted', publicationId: parsed.event.publicationId };
  }
  /** Read the exact durable obligation. Legacy receipts intentionally carry no fabricated source version. */
  publicationDisposition(input: GitHubPublicationInput, _now = Date.now()): GitHubPublicationDisposition | null {
    const parsed = publicationSchema.parse(input);
    const prior = this.storage.sql.exec<{ value: string; source_version: number | null; disposition: string; release_ack_at: number | null }>(
      'SELECT value,source_version,disposition,release_ack_at FROM github_publications WHERE id=?', parsed.event.publicationId,
    ).toArray().at(0);
    if (!prior) return null;
    if (prior.value !== JSON.stringify(parsed)) throw new Error('github_publication_conflict');
    if (prior.disposition === 'legacy') throw new Error('github_publication_unpinned');
    if (!['unsettled', 'settled', 'terminal'].includes(prior.disposition) || prior.source_version !== parsed.event.sourceVersion)
      throw new Error('github_publication_conflict');
    return acceptedPublication(parsed, prior.disposition as GitHubPublicationDisposition['disposition'], prior.release_ack_at !== null);
  }
  /** Adopt only an exact already-accepted receipt; absence never creates a publication. */
  adoptPublication(input: GitHubPublicationInput, pin: GitHubPublicationPin, now = Date.now()): GitHubPublicationDisposition | null {
    const parsed = publicationSchema.parse(input), exactPin = publicationPinSchema.parse(pin), value = JSON.stringify(parsed);
    this.assertPublicationPin(parsed, exactPin);
    return this.storage.transactionSync(() => {
      const prior = this.storage.sql.exec<{ value: string; accepted_at: number; source_version: number | null; disposition: string; release_ack_at: number | null }>(
        'SELECT value,accepted_at,source_version,disposition,release_ack_at FROM github_publications WHERE id=?', parsed.event.publicationId,
      ).toArray().at(0);
      if (!prior) return null;
      if (prior.value !== value) throw new Error('github_publication_conflict');
      if (prior.disposition === 'legacy' && prior.accepted_at <= now - EVENT_POLICY_V1.terminalDeduplicationRetentionMs) return null;
      if (prior.source_version === null && prior.disposition === 'legacy') {
        this.storage.sql.exec("UPDATE github_publications SET source_version=?,disposition='unsettled',release_ack_at=NULL WHERE id=? AND source_version IS NULL AND disposition='legacy'",
          parsed.event.sourceVersion, parsed.event.publicationId);
        return acceptedPublication(parsed, 'unsettled', false);
      }
      if (prior.source_version !== parsed.event.sourceVersion || !['unsettled', 'settled', 'terminal'].includes(prior.disposition))
        throw new Error('github_publication_conflict');
      return acceptedPublication(parsed, prior.disposition as GitHubPublicationDisposition['disposition'], prior.release_ack_at !== null);
    });
  }
  /** Immutable metadata receipt only. No runtime delivery, wake, or stored bearer credentials. */
  acceptPublication(input: GitHubPublicationInput, pin: GitHubPublicationPin, now = Date.now(), sourcePermit?: () => boolean): GitHubPublicationDisposition {
    const parsed = publicationSchema.parse(input), exactPin = publicationPinSchema.parse(pin), value = JSON.stringify(parsed);
    this.assertPublicationPin(parsed, exactPin);
    return this.storage.transactionSync(() => {
      const cutoff = now - EVENT_POLICY_V1.terminalDeduplicationRetentionMs;
      this.storage.sql.exec(`DELETE FROM github_publications WHERE accepted_at<=? AND
        (disposition='legacy' OR (disposition IN ('settled','terminal') AND release_ack_at IS NOT NULL))`, cutoff);
      const prior = this.storage.sql.exec<{ value: string; source_version: number | null; disposition: string; release_ack_at: number | null }>(
        'SELECT value,source_version,disposition,release_ack_at FROM github_publications WHERE id=?', parsed.event.publicationId,
      ).toArray().at(0);
      if (prior && prior.value !== value) throw new Error('github_publication_conflict');
      if (prior) {
        if (prior.source_version === null && prior.disposition === 'legacy') {
          // A validated source pin is persisted by the host before this exact duplicate-adoption call.
          this.storage.sql.exec("UPDATE github_publications SET source_version=?,disposition='unsettled',release_ack_at=NULL WHERE id=? AND source_version IS NULL AND disposition='legacy'",
            parsed.event.sourceVersion, parsed.event.publicationId);
          return acceptedPublication(parsed, 'unsettled', false);
        }
        if (prior.source_version !== parsed.event.sourceVersion || !['unsettled', 'settled', 'terminal'].includes(prior.disposition))
          throw new Error('github_publication_conflict');
        return acceptedPublication(parsed, prior.disposition as GitHubPublicationDisposition['disposition'], prior.release_ack_at !== null);
      }
      if (sourcePermit && !sourcePermit()) throw new Error('github_source_fenced');
      const grant = this.grant(parsed.event.subject);
      if (!grant || grant.revision !== parsed.grantRevision || grant.mappingRevision !== parsed.mappingRevision || grant.policyRevision !== parsed.policyRevision) throw new Error('github_denied');
      if (parsed.event.observedAt + EVENT_POLICY_V1.deliveryTransportRetryHorizonMs <= now || parsed.event.observedAt > now + EVENT_POLICY_V1.clockSkewMs) throw new Error('github_publication_expired');
      if (this.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_publications').one().n >= 1000) throw new Error('github_capacity');
      this.storage.sql.exec("INSERT INTO github_publications(id,value,accepted_at,source_version,disposition,release_ack_at) VALUES (?,?,?,?,'unsettled',NULL)",
        parsed.event.publicationId, value, now, parsed.event.sourceVersion);
      return acceptedPublication(parsed, 'unsettled', false);
    });
  }
  private assertPublicationPin(input: GitHubPublicationInput, pin: GitHubPublicationPin): void {
    if (pin.principal !== this.principal || pin.agent !== this.agentName || pin.publicationId !== input.event.publicationId ||
      pin.sourceVersion !== input.event.sourceVersion || subjectKey(pin.subject) !== subjectKey(input.event.subject))
      throw new Error('github_publication_pin_conflict');
  }
  settlePublication(input: GitHubPublicationInput): GitHubPublicationDisposition {
    return this.transitionPublication(input, 'settled');
  }
  terminalPublication(input: GitHubPublicationInput): GitHubPublicationDisposition {
    return this.transitionPublication(input, 'terminal');
  }
  private transitionPublication(input: GitHubPublicationInput, disposition: 'settled' | 'terminal'): GitHubPublicationDisposition {
    const parsed = publicationSchema.parse(input), value = JSON.stringify(parsed);
    return this.storage.transactionSync(() => {
      const prior = this.storage.sql.exec<{ value: string; source_version: number | null; disposition: string; release_ack_at: number | null }>(
        'SELECT value,source_version,disposition,release_ack_at FROM github_publications WHERE id=?', parsed.event.publicationId,
      ).toArray().at(0);
      if (!prior || prior.value !== value || prior.source_version !== parsed.event.sourceVersion) throw new Error('github_publication_conflict');
      if (prior.disposition === 'legacy') throw new Error('github_publication_unpinned');
      if (prior.disposition !== 'unsettled' && prior.disposition !== disposition) throw new Error('github_publication_state_conflict');
      if (prior.disposition === 'unsettled') this.storage.sql.exec('UPDATE github_publications SET disposition=? WHERE id=?', disposition, parsed.event.publicationId);
      return acceptedPublication(parsed, disposition, prior.release_ack_at !== null);
    });
  }
  acknowledgePublicationRelease(input: GitHubPublicationInput, disposition: 'settled' | 'terminal'): GitHubPublicationRelease {
    const parsed = publicationSchema.parse(input), value = JSON.stringify(parsed);
    return this.storage.transactionSync(() => {
      const prior = this.storage.sql.exec<{ value: string; source_version: number | null; disposition: string }>(
        'SELECT value,source_version,disposition FROM github_publications WHERE id=?', parsed.event.publicationId,
      ).toArray().at(0);
      if (!prior) return { status: 'absent', publicationId: parsed.event.publicationId, sourceVersion: parsed.event.sourceVersion, disposition };
      if (prior.value !== value || prior.source_version !== parsed.event.sourceVersion || prior.disposition !== disposition)
        throw new Error('github_publication_conflict');
      this.storage.sql.exec('UPDATE github_publications SET release_ack_at=COALESCE(release_ack_at,?) WHERE id=?', Date.now(), parsed.event.publicationId);
      return { status: 'released', publicationId: parsed.event.publicationId, sourceVersion: parsed.event.sourceVersion, disposition };
    });
  }
}
