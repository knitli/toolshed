export function withDeadline<T>(work: Promise<T>, ms: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("unavailable")), ms);
    work.then(value => { clearTimeout(timer); resolve(value); }, error => { clearTimeout(timer); reject(error); });
  });
}

export const EVENT_REQUEST_RPC_DEADLINE_MS = 30_000;

/** One timer shared by a public request and all of its state RPCs; workerd clocks can stay frozen. */
export class EventRequestDeadline {
  readonly #deadline: Promise<Error>;
  readonly #timer: ReturnType<typeof setTimeout>;
  #expired = false;
  #expire!: (error: Error) => void;

  constructor(timeoutMs = EVENT_REQUEST_RPC_DEADLINE_MS) {
    if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) throw new RangeError("invalid_deadline");
    this.#deadline = new Promise(resolve => { this.#expire = resolve; });
    this.#timer = setTimeout(() => {
      this.#expired = true;
      this.#expire(new Error("request_deadline_exceeded"));
    }, timeoutMs);
  }

  dispose(): void {
    clearTimeout(this.#timer);
    this.#expired = true;
    this.#expire(new Error("request_deadline_exceeded"));
  }

  async run<T>(work: () => T | Promise<T>, maxMs = Number.POSITIVE_INFINITY): Promise<T> {
    if (this.#expired || maxMs <= 0) throw new Error("request_deadline_exceeded");
    let timer: ReturnType<typeof setTimeout> | undefined;
    const deadline = this.#deadline.then(error => { throw error; });
    const cap = new Promise<never>((_, reject) => {
      if (Number.isFinite(maxMs)) timer = setTimeout(() => { reject(new Error("request_deadline_exceeded")); }, maxMs);
    });
    const operation = new Promise<T>((resolve, reject) => {
      try { Promise.resolve(work()).then(resolve, reject); }
      catch (error) { reject(error); }
    });
    try { return await Promise.race<T>([operation, deadline, cap]); }
    finally { if (timer !== undefined) clearTimeout(timer); }
  }
}
