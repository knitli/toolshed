import {
  AccessDenied,
  AccessUnavailable,
  canonicalEmail,
  identifier,
  verifyJwtClaims,
  type AccessPorts,
} from "openapi-operator/src/access.ts";

/** Configuration shared by the UI and both private gatekeeper admin entrypoints. */
export type AdminSecurityVars = Readonly<{
  ACCESS_ISSUER: string;
  ACCESS_UI_AUD: string;
  ADMIN_UI_ORIGIN: string;
}>;

/** The signed-in human. Each gatekeeper applies its own allowlist and domain authority. */
export type AdminPrincipal = Readonly<{
  principal: string;
  token: string;
  via: "user";
}>;

export type AdminMutationMetadata = Readonly<{
  origin: string | null;
  fetchSite: string | null;
  csrf: string | null;
}>;

const utf8 = new TextEncoder();

/** `https://host[:port]` exactly: no path, no trailing slash, nothing else. The admin UI treats anything else as unconfigured, and so do the hosts that redirect to it. */
export function isHttpsOrigin(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && url.origin === value;
  } catch {
    return false;
  }
}

/** Invalid deployment configuration is an outage, never a caller denial. */
export function configured(vars: AdminSecurityVars): void {
  if (
    !vars ||
    !isHttpsOrigin(vars.ACCESS_ISSUER) ||
    !identifier(vars.ACCESS_UI_AUD, 256) ||
    !isHttpsOrigin(vars.ADMIN_UI_ORIGIN)
  )
    throw new AccessUnavailable();
}

/** Same deterministic, Access-session-bound value used by the legacy review forms. */
export async function csrfToken(accessJwt: string): Promise<string> {
  const digest = new Uint8Array(
    await crypto.subtle.digest("SHA-256", utf8.encode(`knitli-memory-review-csrf\n${accessJwt}`)),
  );
  return btoa(String.fromCharCode(...digest))
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replace(/=+$/, "");
}

function sameToken(actual: string, expected: string): boolean {
  const actualBytes = utf8.encode(actual);
  const expectedBytes = utf8.encode(expected);
  return actualBytes.length === expectedBytes.length && crypto.subtle.timingSafeEqual(actualBytes, expectedBytes);
}

/**
 * Verify the original Cloudflare Access assertion and derive a human identity from its signed
 * email claim. This deliberately applies no allowlist: Memory and Messaging retain their own
 * principal policies and then apply their distinct reviewer, reader, owner, and mailbox rules.
 */
export async function verifyAdminAssertionWithExpiry(
  token: string,
  vars: AdminSecurityVars,
  ports: AccessPorts,
): Promise<Readonly<{ principal: AdminPrincipal; expiresAtSeconds: number }>> {
  configured(vars);
  if (typeof token !== "string" || !token) throw new AccessDenied();

  const claims = await verifyJwtClaims(
    token,
    "access",
    { issuer: vars.ACCESS_ISSUER, audience: vars.ACCESS_UI_AUD },
    ports,
  );
  const audiences = typeof claims.aud === "string" ? [claims.aud] : claims.aud;
  if (
    !Array.isArray(audiences) ||
    audiences.length !== 1 ||
    audiences[0] !== vars.ACCESS_UI_AUD ||
    Object.hasOwn(claims, "common_name") ||
    typeof claims.email !== "string"
  )
    throw new AccessDenied();

  // canonicalEmail on the value as given, before lower-casing: a non-ASCII look-alike (the Kelvin sign lower-cases to "k") is refused.
  if (!canonicalEmail(claims.email)) throw new AccessDenied();
  const principal = claims.email.toLowerCase();
  // verifyJwtClaims has validated this signed expiry; retain it for post-await checks.
  const expiresAtSeconds = claims.exp;
  if (typeof expiresAtSeconds !== "number" || !Number.isSafeInteger(expiresAtSeconds)) throw new AccessDenied();
  return { principal: { principal, token, via: "user" }, expiresAtSeconds };
}

/** Preserve the existing exact identity shape for all current admin callers. */
export async function verifyAdminAssertion(
  token: string,
  vars: AdminSecurityVars,
  ports: AccessPorts,
): Promise<AdminPrincipal> {
  return (await verifyAdminAssertionWithExpiry(token, vars, ports)).principal;
}

/** Validate a mutation's browser metadata and session-bound CSRF value. */
export async function verifyAdminMutation(
  token: string,
  metadata: AdminMutationMetadata,
  vars: AdminSecurityVars,
): Promise<void> {
  configured(vars);
  if (
    typeof token !== "string" ||
    !token ||
    !metadata ||
    metadata.origin !== vars.ADMIN_UI_ORIGIN ||
    metadata.fetchSite !== "same-origin" ||
    typeof metadata.csrf !== "string" ||
    !sameToken(metadata.csrf, await csrfToken(token))
  )
    throw new AccessDenied();
}
