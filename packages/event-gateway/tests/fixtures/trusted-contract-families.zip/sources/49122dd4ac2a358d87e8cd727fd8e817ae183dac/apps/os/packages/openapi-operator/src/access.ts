import {
  decodeBase64Url,
  parseOperatorJson,
} from "gatekeeper-openapi/operator-contracts";

export type AccessConfig = Readonly<{
  issuer: string;
  audience: string;
  allowedEmails: readonly string[];
}>;
export type AccessPorts = Readonly<{ now(): number; fetch: typeof fetch }>;
export class AccessDenied extends Error {}
export class AccessUnavailable extends Error {}
export class BodyTooLarge extends Error {}
const utf8 = new TextEncoder();
const RSA_SHA256 = { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" } as const;

/**
 * Minimal public-key JWK shape this module builds for `crypto.subtle.importKey`.
 * Structural on purpose: `scripts/tsconfig.json` type-checks this file for the
 * deploy tooling without DOM lib, so the global `JsonWebKey` is unavailable
 * there — this alias satisfies both `importKey` signatures instead.
 */
type PublicJsonWebKey = {
  kty: string;
  alg: string;
  use?: string;
  crv?: string;
  n?: string;
  e?: string;
  x?: string;
  y?: string;
};

type JwksProfile = Readonly<{
  jwksUrl: (issuer: string) => string;
  alg: string;
  verify: typeof RSA_SHA256;
  importAlg: typeof RSA_SHA256;
  /** Returns the kid plus importable key, or null to fail the refresh closed. */
  checkKey: (key: Record<string, unknown>) => { kid: string; jwk: PublicJsonWebKey } | null;
}>;

function checkRsaKey(
  key: Record<string, unknown>,
): { kid: string; jwk: PublicJsonWebKey } | null {
  if (
    !identifier(key.kid, 128) ||
    key.kty !== "RSA" ||
    key.alg !== "RS256" ||
    key.use !== "sig" ||
    ["d", "p", "q", "dp", "dq", "qi", "oth"].some((name) => name in key) ||
    typeof key.n !== "string" ||
    typeof key.e !== "string"
  )
    return null;
  const modulus = decodeBase64Url(key.n);
  const exponent = decodeBase64Url(key.e);
  if (modulus.length < 256 || modulus.length > 1024 || exponent.length < 1 || exponent.length > 8)
    return null;
  return {
    kid: key.kid,
    jwk: { kty: "RSA", alg: "RS256", use: "sig", n: key.n, e: key.e },
  };
}

const GITHUB_OIDC_JWKS_URL = "https://token.actions.githubusercontent.com/.well-known/jwks";

export type JwtProfile = "access" | "github-oidc";

const PROFILES: Record<JwtProfile, JwksProfile> = {
  access: {
    jwksUrl: (issuer: string) => `${issuer}/cdn-cgi/access/certs`,
    alg: "RS256",
    verify: RSA_SHA256,
    importAlg: RSA_SHA256,
    checkKey: checkRsaKey,
  },
  // GitHub signs Actions OIDC tokens RS256 (live-verified Sep 2026, including the
  // token's own kid in the published JWKS). ES256 here denies every runner request.
  "github-oidc": {
    jwksUrl: () => GITHUB_OIDC_JWKS_URL,
    alg: "RS256",
    verify: RSA_SHA256,
    importAlg: RSA_SHA256,
    checkKey: checkRsaKey,
  },
};

function record(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new AccessDenied();
  return value as Record<string, unknown>;
}
export function identifier(value: unknown, max: number): value is string {
  return (
    typeof value === "string" &&
    value.length > 0 &&
    utf8.encode(value).length <= max &&
    !Array.from(value).some((character) => {
      const code = character.charCodeAt(0);
      return code <= 0x20 || (code >= 0x7f && code <= 0x9f);
    }) &&
    value.isWellFormed()
  );
}
export function canonicalEmail(value: unknown): value is string {
  if (!identifier(value, 254)) return false;
  const parts = value.split("@");
  if (parts.length !== 2) return false;
  const [local, domain] = parts as [string, string];
  return (
    local.length <= 64 &&
    /^[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+)*$/.test(local) &&
    domain.length <= 253 &&
    domain.includes(".") &&
    domain
      .split(".")
      .every((label) => /^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$/.test(label))
  );
}
export function parseAccessConfig(value: unknown): AccessConfig {
  const config = record(value);
  if (
    Object.keys(config).toSorted().join(",") !== "allowedEmails,audience,issuer" ||
    typeof config.issuer !== "string"
  )
    throw new AccessUnavailable();
  const url = new URL(config.issuer);
  if (
    url.protocol !== "https:" ||
    url.origin !== config.issuer ||
    url.username ||
    url.password ||
    url.port ||
    !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.cloudflareaccess\.com$/.test(url.hostname) ||
    !identifier(config.audience, 256) ||
    !Array.isArray(config.allowedEmails) ||
    config.allowedEmails.length > 256 ||
    !config.allowedEmails.every(canonicalEmail) ||
    new Set(config.allowedEmails).size !== config.allowedEmails.length
  )
    throw new AccessUnavailable();
  return Object.freeze({
    issuer: config.issuer,
    audience: config.audience,
    allowedEmails: Object.freeze([...config.allowedEmails]),
  });
}

export async function readBoundedBody(
  body: ReadableStream<Uint8Array> | null,
  limit: number,
): Promise<Uint8Array> {
  if (!body) return new Uint8Array();
  const reader = body.getReader();
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const next = await reader.read();
      if (next.done) break;
      size += next.value.byteLength;
      if (size > limit) {
        void reader.cancel().catch(() => {});
        throw new BodyTooLarge();
      }
      chunks.push(next.value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.length;
  }
  return bytes;
}

type KeyCache = {
  keys: Map<string, CryptoKey>;
  loadedAt: number;
  refresh?: Promise<void>;
  unknownAt: number;
};
// Each immutable transport/clock pair owns a cache; request data cannot select ports.
const caches = new WeakMap<AccessPorts, Map<string, KeyCache>>();
function cacheFor(ports: AccessPorts, key: string): KeyCache {
  let issuers = caches.get(ports);
  if (!issuers) {
    issuers = new Map();
    caches.set(ports, issuers);
  }
  let cache = issuers.get(key);
  if (!cache) {
    // A Worker version verifies at most two issuers (Access, GitHub OIDC), keyed with
    // their profile so RSA and EC keys never share a cache entry. Bound retained state
    // even for library callers.
    if (issuers.size >= 8) throw new AccessUnavailable();
    cache = { keys: new Map(), loadedAt: -Infinity, unknownAt: -Infinity };
    issuers.set(key, cache);
  }
  return cache;
}
async function refresh(
  cache: KeyCache,
  profile: JwksProfile,
  issuer: string,
  ports: AccessPorts,
): Promise<void> {
  if (cache.refresh) return cache.refresh;
  cache.refresh = (async () => {
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout> | undefined;
    const deadline = new Promise<never>((_, reject) => {
      timer = setTimeout(() => {
        controller.abort();
        reject(new AccessUnavailable());
      }, 5_000);
    });
    try {
      const startedAt = ports.now();
      const operation = (async () => {
        const url = profile.jwksUrl(issuer);
        const response = await ports.fetch(url, {
          // Workers supports manual redirects; reject redirect responses below
          // before reading any keys instead of asking fetch to follow them.
          redirect: "manual",
          signal: controller.signal,
          headers: { Accept: "application/json" },
        });
        if (!response.ok || response.redirected || (response.url && response.url !== url))
          throw new AccessUnavailable();
        const jwks = record(
          parseOperatorJson(await readBoundedBody(response.body, 65_536), 65_536),
        );
        if (!Array.isArray(jwks.keys) || !jwks.keys.length || jwks.keys.length > 8)
          throw new AccessUnavailable();
        const keys = new Map<string, CryptoKey>();
        for (const value of jwks.keys) {
          const checked = profile.checkKey(record(value));
          if (!checked || keys.has(checked.kid)) throw new AccessUnavailable();
          const imported = await crypto.subtle.importKey(
            "jwk",
            checked.jwk,
            profile.importAlg,
            false,
            ["verify"],
          );
          keys.set(checked.kid, imported);
        }
        return keys;
      })();
      const keys = await Promise.race([operation, deadline]);
      // Overdue refresh or a backward clock both fail closed: a re-wound
      // clock must not resurrect an expired key set.
      if (ports.now() - startedAt >= 300 || ports.now() < startedAt) throw new AccessUnavailable();
      cache.keys = keys;
      cache.loadedAt = startedAt;
    } catch {
      throw new AccessUnavailable();
    } finally {
      if (timer !== undefined) clearTimeout(timer);
    }
  })();
  try {
    await cache.refresh;
  } finally {
    cache.refresh = undefined;
  }
}

/**
 * Verifies a JWT's header, JWKS-backed signature, and registered claims (issuer,
 * audience, time bounds) under one closed key profile, and returns the verified
 * claims for the caller to authorize. Subject checks (email allowlist, service-token
 * identity, OIDC job claims) stay with the caller: this core never decides who a
 * token authorizes, only that its issuer signed it and its registered claims match.
 */
async function verifiedJwtClaims(
  token: string,
  profileName: JwtProfile,
  expected: Readonly<{ issuer: string; audience: string }>,
  ports: AccessPorts,
): Promise<Record<string, unknown>> {
  const profile = PROFILES[profileName];
  let header: Record<string, unknown>;
  let claims: Record<string, unknown>;
  let signature: Uint8Array<ArrayBuffer>;
  let parts: string[];
  try {
    if (utf8.encode(token).length > 16_384) throw new AccessDenied();
    parts = token.split(".");
    if (parts.length !== 3 || parts.some((part) => !part)) throw new AccessDenied();
    header = record(parseOperatorJson(decodeBase64Url(parts[0]!)));
    claims = record(parseOperatorJson(decodeBase64Url(parts[1]!)));
    signature = decodeBase64Url(parts[2]!);
    if (
      header.alg !== profile.alg ||
      !identifier(header.kid, 128) ||
      ["crit", "jku", "jwk", "x5u", "b64"].some((key) => key in header)
    )
      throw new AccessDenied();
  } catch {
    throw new AccessDenied();
  }
  const cache = cacheFor(ports, `${profileName}:${expected.issuer}`);
  let refreshed = false;
  if (ports.now() < cache.loadedAt || ports.now() - cache.loadedAt >= 300) {
    await refresh(cache, profile, expected.issuer, ports);
    refreshed = true;
  }
  let key = cache.keys.get(header.kid as string);
  if (!key && !refreshed && ports.now() - cache.unknownAt >= 30) {
    cache.unknownAt = ports.now();
    await refresh(cache, profile, expected.issuer, ports);
    key = cache.keys.get(header.kid as string);
  }
  if (!key) {
    if (refreshed) cache.unknownAt = ports.now();
    throw new AccessDenied();
  }
  if (
    !(await crypto.subtle.verify(
      profile.verify,
      key,
      signature,
      utf8.encode(`${parts[0]}.${parts[1]}`),
    ))
  )
    throw new AccessDenied();
  const now = ports.now();
  const audiences = typeof claims.aud === "string" ? [claims.aud] : claims.aud;
  if (
    !Number.isSafeInteger(now) ||
    claims.iss !== expected.issuer ||
    !Array.isArray(audiences) ||
    !audiences.length ||
    audiences.length > 16 ||
    !audiences.every((aud) => identifier(aud, 256)) ||
    !audiences.includes(expected.audience) ||
    !Number.isSafeInteger(claims.iat) ||
    !Number.isSafeInteger(claims.exp) ||
    (claims.iat as number) > now + 5 ||
    (claims.iat as number) >= (claims.exp as number) ||
    now >= (claims.exp as number) ||
    ("nbf" in claims && (!Number.isSafeInteger(claims.nbf) || (claims.nbf as number) > now))
  )
    throw new AccessDenied();
  return claims;
}

/**
 * Machine-verifier entrypoint: verifies header, signature, and registered claims,
 * leaving subject authorization to the caller. The expected issuer must be an exact
 * https origin — it selects the JWKS URL on the access profile — and misconfigured
 * expectations fail closed as unavailable, never as a caller denial.
 */
export async function verifyJwtClaims(
  token: string,
  profile: JwtProfile,
  expected: Readonly<{ issuer: string; audience: string }>,
  ports: AccessPorts,
): Promise<Record<string, unknown>> {
  let origin: string;
  try {
    const url = new URL(expected.issuer);
    origin = url.origin;
  } catch {
    throw new AccessUnavailable();
  }
  if (
    !expected.issuer.startsWith("https://") ||
    origin !== expected.issuer ||
    !identifier(expected.audience, 256)
  )
    throw new AccessUnavailable();
  return verifiedJwtClaims(token, profile, expected, ports);
}

// Cloudflare documents the signed email claim (not email_verified):
// https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/application-token/
export async function verifyAccess(
  token: string,
  rawConfig: AccessConfig,
  ports: AccessPorts,
): Promise<{ subject: string }> {
  const config = parseAccessConfig(rawConfig);
  const claims = await verifiedJwtClaims(
    token,
    "access",
    { issuer: config.issuer, audience: config.audience },
    ports,
  );
  if (!canonicalEmail(claims.email)) throw new AccessDenied();
  if (!config.allowedEmails.includes(claims.email)) throw new AccessDenied();
  return { subject: claims.email };
}
