// Cloudflare Access → principal. Access already gates memory.knitli.app; the Worker verifies the
// Cf-Access-Jwt-Assertion itself (issuer JWKS + AUD) with openapi-operator's hardened verifier, and
// only then resolves who is calling. `verifyAccess` is not used because it needs a closed email
// allowlist and refuses service tokens; this service accepts whole domains and maps service tokens.

import {
  AccessDenied,
  AccessUnavailable,
  canonicalEmail,
  verifyJwtClaims,
  type AccessPorts,
} from "openapi-operator/src/access.ts";
import { allowed, parseAllowedPrincipals, parseReviewers, parseServiceTokens } from "./principals.ts";

/** `via` says how the caller signed in: an Access user login, or a mapped Access service token. */
export type Principal = { principal: string; token: string; via: "user" | "service" };
/** Which Access application the request must come through: the agent-facing app or the human-only review app. */
export type Surface = "agent" | "review";
export type AuthConfig = {
  issuer: string;
  audience: string;
  /** AUD of the separate human-only Access app on memory.knitli.app/review (no managed OAuth, no service tokens). */
  reviewAudience: string;
  reviewers: readonly string[];
  /** Lowercased `@domain` entries and exact emails from ALLOWED_PRINCIPALS. */
  allowedDomains: readonly string[];
  allowedEmails: readonly string[];
  serviceTokens: Readonly<Record<string, string>>;
};

/** The Worker vars this module reads; structural, so it does not depend on the generated Env. */
export type MemoryAuthVars = {
  ACCESS_ISSUER: string;
  ACCESS_AUD: string;
  ACCESS_REVIEW_AUD: string;
  MEMORY_REVIEWERS: string;
  ALLOWED_PRINCIPALS: string;
  MEMORY_SERVICE_TOKENS: string;
};

const portsByIssuer = new Map<string, AccessPorts>();

/**
 * Ports for the configured Access team domain. The only request the verifier makes is the team's
 * JWKS; this fetch refuses every other URL and requests a URL built from the configuration, never
 * one taken from its argument. Detached wrapper (workerd throws "Illegal invocation" when a bare
 * `fetch` stored on an object is called as a method); cached per issuer, because the verifier
 * caches JWKS per ports object.
 */
export function productionPorts(issuer: string): AccessPorts {
  let ports = portsByIssuer.get(issuer);
  if (!ports) {
    const jwks = URL.canParse(issuer) ? `${new URL(issuer).origin}/cdn-cgi/access/certs` : null;
    ports = Object.freeze({
      now: () => Math.floor(Date.now() / 1000),
      fetch: (input: RequestInfo | URL, init?: RequestInit) => {
        const requested = input instanceof Request ? input.url : String(input);
        if (jwks === null || requested !== jwks) return Promise.reject(new AccessUnavailable());
        return fetch(jwks, init);
      },
    });
    portsByIssuer.set(issuer, ports);
  }
  return ports;
}

export function authConfig(env: MemoryAuthVars): AuthConfig {
  const issuer: string = env.ACCESS_ISSUER;
  const audience: string = env.ACCESS_AUD;
  const reviewAudience: string = env.ACCESS_REVIEW_AUD;
  if (!issuer || !audience || !reviewAudience || audience === reviewAudience) throw new AccessUnavailable();
  try {
    return {
      issuer,
      audience,
      reviewAudience,
      reviewers: parseReviewers(env.MEMORY_REVIEWERS),
      ...parseAllowedPrincipals(env.ALLOWED_PRINCIPALS ?? ""),
      serviceTokens: parseServiceTokens(env.MEMORY_SERVICE_TOKENS),
    };
  } catch {
    throw new AccessUnavailable();
  }
}

/**
 * Each surface requires its own Access app's AUD. /review also refuses a token that names the agent
 * app, so an agent's token can never be replayed against it. The agent surface tolerates the review
 * AUD alongside its own: `cloudflared access login` issues exactly that, it is the same verified
 * person on the less privileged surface, and service tokens can never carry the review AUD.
 */
export type DenyReason =
  | "no_token"
  | "verify_failed"
  | "other_aud"
  | "bad_email"
  | "not_allowed"
  | "unknown_service_token"
  | "service_on_review";

/**
 * A refusal with a reason, for the 401 log line. Carries only what is safe to log: the token's
 * audiences, the email's domain (never the whole address) and how the caller signed in.
 */
export class Denied extends AccessDenied {
  constructor(
    readonly reason: DenyReason,
    readonly detail: { aud?: unknown; emailDomain?: string; via?: "user" | "service"; error?: string } = {},
  ) {
    super(reason);
  }
}

/** Only the part after "@"; nothing at all for a value without one, so a whole value is never logged. */
const emailDomain = (email: string): string | undefined =>
  email.includes("@") ? email.slice(email.lastIndexOf("@") + 1) : undefined;

/** The token's `aud` claim without verifying it, only for the denial log: string entries, at most 4. */
function unverifiedAud(token: string): string[] | undefined {
  try {
    const payload = token.split(".")[1] ?? "";
    const json = atob(payload.replaceAll("-", "+").replaceAll("_", "/"));
    const aud: unknown = (JSON.parse(json) as { aud?: unknown }).aud;
    const list: unknown[] = typeof aud === "string" ? [aud] : Array.isArray(aud) ? aud : [];
    return list.filter((entry) => typeof entry === "string").slice(0, 4);
  } catch {
    return undefined;
  }
}

async function verify(token: string, config: AuthConfig, audience: string, ports: AccessPorts) {
  try {
    return await verifyJwtClaims(token, "access", { issuer: config.issuer, audience }, ports);
  } catch (error) {
    if (error instanceof AccessUnavailable) throw error;
    const name = error instanceof Error ? error.constructor.name : typeof error;
    const message = error instanceof Error && error.message ? `: ${error.message.slice(0, 200)}` : "";
    throw new Denied("verify_failed", { aud: unverifiedAud(token), error: `${name}${message}` });
  }
}

/**
 * Each surface requires its own Access app's AUD. /review also refuses a token that names the agent
 * app, so an agent's token can never be replayed against it. The agent surface tolerates the review
 * AUD alongside its own: `cloudflared access login` issues exactly that, it is the same verified
 * person on the less privileged surface, and service tokens can never carry the review AUD.
 */
export async function authenticate(
  request: Request,
  config: AuthConfig,
  ports: AccessPorts,
  surface: Surface,
): Promise<Principal> {
  const token = request.headers.get("Cf-Access-Jwt-Assertion");
  if (!token) throw new Denied("no_token");
  const [audience, other] = surface === "review" ? [config.reviewAudience, config.audience] : [config.audience, null];
  const claims = await verify(token, config, audience, ports);
  const audiences = typeof claims.aud === "string" ? [claims.aud] : claims.aud;
  // canonicalEmail on the value as given, before lower-casing: a non-ASCII look-alike (the Kelvin sign lower-cases to "k") is refused.
  const signed = typeof claims.email === "string" && claims.email ? claims.email : null;
  const email = signed?.toLowerCase() ?? null;
  const domain = email ? emailDomain(email) : undefined;
  const seen = { aud: claims.aud, ...(email ? { via: "user" as const } : {}), ...(domain ? { emailDomain: domain } : {}) };
  if (!Array.isArray(audiences) || (other !== null && audiences.includes(other))) throw new Denied("other_aud", seen);
  if (email) {
    if (!canonicalEmail(signed)) throw new Denied("bad_email", seen);
    if (!allowed(email, config)) throw new Denied("not_allowed", seen);
    return { principal: email, token, via: "user" };
  }
  // Service tokens carry no email; the explicit map is their only way in, so ALLOWED_PRINCIPALS
  // does not apply to them.
  const clientId = claims.common_name;
  if (typeof clientId !== "string" || !Object.hasOwn(config.serviceTokens, clientId))
    throw new Denied("unknown_service_token", { aud: claims.aud, via: "service" });
  return { principal: config.serviceTokens[clientId]!, token, via: "service" };
}
