import { assertMixedWatchCapacity, canonicalSourceKey, sourceTokenEquals, upgradeSourceControlParkingSchema, type GitHubSourceControlToken } from './source-control';
import { WatchViewSchema, CreateWatchRequestSchema, CleanupWatchRequestSchema, WatchControlTokenSchema, WatchActivateTokenSchema, WatchStopTokenSchema, WatchAppliedOutcomeSchema, WatchSettlementWitnessSchema, internalTokenEquals, watchJson, WATCH_CONTROL_LIMITS as L, type WatchView, type WatchActivateToken, type WatchStopToken, type WatchControlToken, type CreateWatchRequest, type CleanupWatchRequest, type SourceKey, type WatchAppliedOutcome, type WatchSettlementWitness, type WatchAuthorityReadback, type WatchOutcome } from './watch-control-internal';

export function upgradeWatchControlSchema(sql: SqlStorage, now: number): void {
  const version = sql.exec<{ version: number }>('SELECT max(version) AS version FROM schema_migrations').one().version;
  if (version > 6) throw new Error('unsupported coordinator schema');
  if (version === 6) return;
  upgradeSourceControlParkingSchema(sql);
  sql.exec("ALTER TABLE github_source_controls ADD COLUMN control_owner TEXT NOT NULL DEFAULT 'source_only' CHECK(control_owner IN ('source_only','watch'))");
  sql.exec(`CREATE TABLE github_source_cleanup_bundles_v6(canonical_subject TEXT PRIMARY KEY,operation_id TEXT NOT NULL,
    control_owner TEXT NOT NULL DEFAULT 'source_only' CHECK(control_owner IN ('source_only','watch')),protected_bytes INTEGER NOT NULL,
    created_at INTEGER NOT NULL,CHECK((control_owner='source_only' AND protected_bytes=4096) OR (control_owner='watch' AND protected_bytes=12288)));
    INSERT INTO github_source_cleanup_bundles_v6 SELECT canonical_subject,operation_id,'source_only',protected_bytes,created_at FROM github_source_cleanup_bundles;
    DROP TABLE github_source_cleanup_bundles;
    ALTER TABLE github_source_cleanup_bundles_v6 RENAME TO github_source_cleanup_bundles;
    CREATE TABLE github_watch_operations(operation_id TEXT PRIMARY KEY,canonical_subject TEXT NOT NULL,request_json TEXT NOT NULL,result_json TEXT NOT NULL,terminal_at INTEGER,protected INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE github_watch_outbox(operation_id TEXT PRIMARY KEY,canonical_subject TEXT NOT NULL,token_json TEXT NOT NULL,
      phase TEXT NOT NULL CHECK(phase IN ('activate','stop','retire')),predecessor_json TEXT,expected_source_version INTEGER,expected_host_epoch INTEGER,
      attempts INTEGER NOT NULL DEFAULT 0,next_at INTEGER NOT NULL,claim_id TEXT,claim_until INTEGER);
    CREATE TABLE github_watch_history(operation_id TEXT PRIMARY KEY,canonical_subject TEXT NOT NULL,token_json TEXT NOT NULL);
    CREATE TABLE github_watch_state(canonical_subject TEXT PRIMARY KEY,phase TEXT NOT NULL,retirement_operation_id TEXT,
      stop_outcome TEXT,settlement TEXT,updated_at INTEGER NOT NULL,released INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS github_delivery_watches(owner TEXT NOT NULL,subject TEXT NOT NULL,value TEXT NOT NULL,operation TEXT NOT NULL,PRIMARY KEY(owner,subject));`);
  sql.exec('INSERT INTO schema_migrations(version,applied_at) VALUES (6,?)', now);
}
export type WatchOutbox = { operation_id: string; canonical_subject: string; token_json: string; phase: 'activate'|'stop'|'retire'; predecessor_json: string|null; expected_source_version: number|null; expected_host_epoch: number|null; attempts: number; next_at: number; claim_id: string|null; claim_until: number|null };
type WatchState = { phase: 'activation_pending'|'active'|'stop_pending'|'stopped'; retirement_operation_id: string|null; stop_outcome: string|null; settlement: string|null; updated_at: number; released: number };
/** All mutations run in the coordinator's transaction, including its alarm write. */
export class GitHubWatchStore {
  constructor(private readonly sql: SqlStorage, private readonly principal: string, private readonly agent: string) {}
  private enabled(): boolean { return this.sql.exec<{version:number}>('SELECT max(version) AS version FROM schema_migrations').one().version === 6; }
  private owner(): string { return JSON.stringify([this.principal,this.agent]); }
  private state(subject: SourceKey): WatchState|null { return this.enabled() ? this.sql.exec<WatchState>('SELECT * FROM github_watch_state WHERE canonical_subject=?',canonicalSourceKey(subject)).toArray()[0] ?? null : null; }
  read(subject: SourceKey): WatchView|null {
    const exists = this.sql.exec("SELECT 1 FROM sqlite_master WHERE name='github_delivery_watches'").toArray().length;
    if (!exists) return null;
    const row = this.sql.exec<{value:string}>('SELECT value FROM github_delivery_watches WHERE owner=? AND subject=?',this.owner(),canonicalSourceKey(subject)).toArray()[0];
    if (!row) return null;
    const data = JSON.parse(row.value);
    if (data.kernelVersion !== 1) throw new Error('github_watch_unsupported');
    return WatchViewSchema.parse(data.watch);
  }
  private write(view: WatchView): void {
    WatchViewSchema.parse(view);
    this.sql.exec('INSERT OR REPLACE INTO github_delivery_watches(owner,subject,value,operation) VALUES (?,?,?,?)',this.owner(),canonicalSourceKey(view.subject),watchJson({kernelVersion:1,state:view.state,watch:view}),view.sourceControl.operationId);
  }
  private token(subject: SourceKey): WatchControlToken {
    const row = this.sql.exec<{token_json:string;control_owner:string}>('SELECT token_json,control_owner FROM github_source_controls WHERE canonical_subject=?',canonicalSourceKey(subject)).toArray()[0];
    if (!row || row.control_owner !== 'watch') throw new Error('github_source_conflict');
    const token = WatchControlTokenSchema.parse(JSON.parse(row.token_json));
    if (token.principal !== this.principal || token.agent !== this.agent || canonicalSourceKey(token.subject)!==canonicalSourceKey(subject)) throw new Error('github_source_conflict');
    return token;
  }
  exactOperation(operationId:string, request:unknown, now = Date.now()): WatchOutcome|null {
    if (!this.enabled()) return null;
    const row = this.sql.exec<{request_json:string;result_json:string}>('SELECT request_json,result_json FROM github_watch_operations WHERE operation_id=? AND (terminal_at IS NULL OR terminal_at>? OR (protected=1 AND canonical_subject IN (SELECT canonical_subject FROM github_watch_state WHERE settlement IS NULL)))',operationId,now-L.terminalRetentionMs).toArray()[0];
    if (!row) return null;
    if (row.request_json !== watchJson(request)) throw new Error('github_operation_conflict');
    return this.currentResult(operationId,WatchViewSchema.parse(JSON.parse(row.result_json)));
  }
  operation(subject:SourceKey, operationId:string, now=Date.now()):WatchOutcome {
    if (!this.enabled()) return {status:'unresolved',operationId};
    const row = this.sql.exec<{canonical_subject:string;result_json:string}>('SELECT canonical_subject,result_json FROM github_watch_operations WHERE operation_id=? AND (terminal_at IS NULL OR terminal_at>? OR (protected=1 AND canonical_subject IN (SELECT canonical_subject FROM github_watch_state WHERE settlement IS NULL)))',operationId,now-L.terminalRetentionMs).toArray()[0];
    if(!row)return {status:'unresolved',operationId};
    if(row.canonical_subject!==canonicalSourceKey(subject))return {status:'conflict',operationId};
    return this.currentResult(operationId,WatchViewSchema.parse(JSON.parse(row.result_json)));
  }
  private currentResult(operationId:string,result:WatchView):WatchOutcome {
    const current=this.read(result.subject);
    const target=(view:WatchView)=>{const {status:_status,reason:_reason,...control}=view.sourceControl;return {...view,sourceControl:control};};
    if(!current || JSON.stringify(target(current))!==JSON.stringify(target(result))) return {status:'conflict',operationId};
    return {status:'committed',operationId,result};
  }
  private unused(id:string):void {
    for(const table of ['github_source_operations','github_source_controls','github_source_outbox','github_watch_history','github_watch_operations']) {
      if(this.sql.exec(`SELECT 1 FROM ${table} WHERE operation_id=? LIMIT 1`,id).toArray().length)throw new Error('github_operation_conflict');
    }
    if(this.sql.exec('SELECT 1 FROM github_watch_state WHERE retirement_operation_id=? LIMIT 1',id).toArray().length)throw new Error('github_operation_conflict');
  }
  private receipt(id:string,request:unknown,view:WatchView,now:number,protectedReceipt=false):void {
    if(protectedReceipt)watchJson({request,result:view});
    this.sql.exec('INSERT INTO github_watch_operations VALUES (?,?,?,?,?,?)',id,canonicalSourceKey(view.subject),watchJson(request),watchJson(view),((request as {kind?:string}).kind==='create'||protectedReceipt)?null:now,protectedReceipt?1:0);
  }
  private protectedOwner(subject:SourceKey,token:WatchControlToken):void {
    const row=this.sql.exec<{operation_id:string;control_owner:string;protected_bytes:number}>('SELECT operation_id,control_owner,protected_bytes FROM github_source_cleanup_bundles WHERE canonical_subject=?',canonicalSourceKey(subject)).toArray()[0];
    if (!row || row.operation_id!==token.operationId || row.control_owner!=='watch' || row.protected_bytes!==L.coordinatorProtectedBytes) throw new Error('github_source_conflict');
  }
  promote(input:{request:CreateWatchRequest;predecessor:GitHubSourceControlToken;token:WatchActivateToken;expectedSourceVersion:number;expectedHostEpoch:number;leaseUntil:number;now:number}):WatchView {
    const {predecessor:p,now}=input, r=CreateWatchRequestSchema.parse(input.request), t=WatchActivateTokenSchema.parse(input.token), key=canonicalSourceKey(r.subject);
    upgradeWatchControlSchema(this.sql,now);
    this.prune(now);
    const replay=this.exactOperation(r.operationId,{kind:'create',input:r},now); if(replay?.status==='committed')return replay.result;if(replay)throw new Error('github_operation_conflict');
    if (this.read(r.subject)) throw new Error('github_source_conflict');
    this.unused(r.operationId);
    if (!Number.isSafeInteger(input.leaseUntil) || input.leaseUntil<=now || input.leaseUntil>now+r.leaseMs)throw new Error('github_source_conflict');
    const watchCount=this.sql.exec<{n:number}>('SELECT count(*) AS n FROM github_delivery_watches WHERE owner=?',this.owner()).one().n;
    if(watchCount>=L.retainedWatches)throw new Error('github_capacity');
    const live=this.sql.exec<{n:number}>("SELECT count(*) AS n FROM github_delivery_watches WHERE owner=? AND json_extract(value,'$.state')!='retired'",this.owner()).one().n;
    const manualTable=this.sql.exec("SELECT 1 FROM sqlite_master WHERE name='manual_sources'").toArray().length;
    const manual=manualTable?this.sql.exec<{n:number}>("SELECT count(*) AS n FROM manual_sources").one().n:0;
    if(live+manual>=L.associations)throw new Error('github_capacity');
    const old=this.sql.exec<{token_json:string;state:string;control_owner:string;operation_id:string}>('SELECT token_json,state,control_owner,operation_id FROM github_source_controls WHERE canonical_subject=?',key).toArray()[0];
    if (!old || old.control_owner!=='source_only' || old.state!=='active' || !sourceTokenEquals(JSON.parse(old.token_json),p)
      || t.operationId!==r.operationId || t.principal!==this.principal || t.agent!==this.agent || canonicalSourceKey(t.subject)!==key
      || p.lifecycleEpoch>Number.MAX_SAFE_INTEGER-2
      || t.grantRevision!==p.grantRevision || t.mappingRevision!==p.mappingRevision || t.policyRevision!==p.policyRevision || t.sourceEnableGeneration!==p.sourceEnableGeneration
      || p.sourceIncarnation!==r.expectedSourceIncarnation || p.lifecycleEpoch!==r.expectedLifecycleEpoch
      || t.sourceIncarnation!==p.sourceIncarnation || t.lifecycleEpoch!==p.lifecycleEpoch+1 || t.watchIncarnation!==1 || t.routingRevision!==1
      || t.installationId!==p.installationId || t.installationId!==r.source.installationId || t.grantRevision!==r.source.grantRevision || t.mappingRevision!==r.source.mappingRevision || t.policyRevision!==r.source.policyRevision
      || this.sql.exec('SELECT 1 FROM github_source_outbox WHERE canonical_subject=?',key).toArray().length) throw new Error('github_source_conflict');
    const changed=this.sql.exec("UPDATE github_source_cleanup_bundles SET control_owner='watch',protected_bytes=12288,operation_id=? WHERE canonical_subject=? AND operation_id=? AND control_owner='source_only' AND protected_bytes=4096",t.operationId,key,p.operationId);
    if(changed.rowsWritten!==1)throw new Error('github_source_conflict');
    this.sql.exec("UPDATE github_source_controls SET control_owner='watch',token_json=?,operation_id=?,updated_at=? WHERE canonical_subject=?",watchJson(t),t.operationId,now,key);
    const view:WatchView={subject:r.subject,incarnation:1,routingRevision:1,lifecycleEpoch:t.lifecycleEpoch,state:'attached',source:{...r.source,sourceIncarnation:t.sourceIncarnation},attachment:{holder:r.holder,leaseRevision:1,leaseUntil:input.leaseUntil},sourceControl:{mode:'watch',status:'pending',operationId:t.operationId,obligationId:t.obligationId,reason:null}};
    this.assertProtectedFuture(t,view);
    this.write(view);
    this.sql.exec("INSERT INTO github_watch_state VALUES (?,'activation_pending',NULL,NULL,NULL,?,0)",key,now);
    this.sql.exec("INSERT INTO github_watch_outbox(operation_id,canonical_subject,token_json,phase,predecessor_json,expected_source_version,expected_host_epoch,next_at) VALUES (?,?,?,'activate',?,?,?,?)",t.operationId,key,watchJson(t),watchJson(p),input.expectedSourceVersion,input.expectedHostEpoch,now);
    this.sql.exec('INSERT INTO github_watch_history VALUES (?,?,?)',p.operationId,key,watchJson(p));
    this.sql.exec('INSERT INTO github_watch_history VALUES (?,?,?)',t.operationId,key,watchJson(t));
    this.receipt(r.operationId,{kind:'create',input:r},view,now); this.assertCapacity(); return view;
  }
  private assertProtectedFuture(token:WatchActivateToken,view:WatchView):void {
    const stop=WatchStopTokenSchema.parse({...token,action:'stop',mode:'stopped',lifecycleEpoch:Number.MAX_SAFE_INTEGER,routingRevision:Number.MAX_SAFE_INTEGER});
    watchJson(stop);
    watchJson({token:stop,outcome:{status:'stopped',sourceVersion:Number.MAX_SAFE_INTEGER,hostEpoch:Number.MAX_SAFE_INTEGER},settlement:{status:'settled',retirementOperationId:token.operationId}},L.hostProtectedBytes);
    const retired:WatchView={...view,state:'retired',attachment:null,routingRevision:Number.MAX_SAFE_INTEGER,lifecycleEpoch:Number.MAX_SAFE_INTEGER,
      sourceControl:{mode:'stopped',status:'acknowledged',operationId:token.operationId,obligationId:token.obligationId,reason:'authority_unavailable'}};
    watchJson({request:{kind:'unsubscribe',input:{operationId:token.operationId,subject:view.subject,fence:{expectedIncarnation:view.incarnation,expectedRoutingRevision:Number.MAX_SAFE_INTEGER}}},result:retired});
  }
  private fenced(r:CleanupWatchRequest):WatchView {
    const view=this.read(r.subject);
    if(!view || view.incarnation!==r.fence.expectedIncarnation || view.routingRevision!==r.fence.expectedRoutingRevision)throw new Error('github_source_conflict');
    return view;
  }
  detach(r:CleanupWatchRequest,now:number):WatchView {
    this.prune(now);
    CleanupWatchRequestSchema.parse(r);
    const replay=this.exactOperation(r.operationId,{kind:'detach',input:r},now);if(replay?.status==='committed')return replay.result;if(replay)throw new Error('github_operation_conflict');
    this.unused(r.operationId); const view=this.fenced(r);
    if(view.state!=='attached')throw new Error('github_source_conflict');
    if(view.routingRevision>=Number.MAX_SAFE_INTEGER-1)throw new Error('github_source_conflict');
    view.routingRevision++;view.state='detached';view.attachment=null;this.write(view);this.receipt(r.operationId,{kind:'detach',input:r},view,now);this.assertCapacity();return view;
  }
  retireOrJoinStop(r:CleanupWatchRequest,stopToken:WatchStopToken,now:number):WatchView {
    CleanupWatchRequestSchema.parse(r);
    const replay=this.exactOperation(r.operationId,{kind:'unsubscribe',input:r},now);if(replay?.status==='committed')return replay.result;if(replay)throw new Error('github_operation_conflict');
    this.unused(r.operationId);let view=this.fenced(r); if(view.state==='retired')throw new Error('github_source_conflict');
    const current=this.token(r.subject);this.protectedOwner(r.subject,current);
    if(view.routingRevision===Number.MAX_SAFE_INTEGER)throw new Error('github_source_conflict');
    view.routingRevision++;this.write(view);
    if(current.action!=='stop' && stopToken.operationId!==r.operationId)throw new Error('github_source_conflict');
    if(current.action==='stop' && !internalTokenEquals(current,stopToken))throw new Error('github_source_conflict');
    if(current.action!=='stop') view=this.beginAuthorityStop(r.subject,stopToken,null,now);
    view.state='retired';view.attachment=null;this.write(view);
    this.sql.exec('UPDATE github_watch_state SET retirement_operation_id=?,updated_at=? WHERE canonical_subject=?',r.operationId,now,canonicalSourceKey(r.subject));
    if(this.state(r.subject)?.phase==='stopped')this.queueRetirement(r.subject,now);
    this.receipt(r.operationId,{kind:'unsubscribe',input:r},view,now,true);return view;
  }
  beginAuthorityStop(subject:SourceKey,raw:WatchStopToken,reason:WatchView['sourceControl']['reason'],now:number):WatchView {
    const view=this.read(subject);if(!view)throw new Error('github_source_conflict');
    const current=this.token(subject);this.protectedOwner(subject,current);if(current.action==='stop')return view;
    const t=WatchStopTokenSchema.parse(raw);
    watchJson({token:t,outcome:{status:'stopped',sourceVersion:Number.MAX_SAFE_INTEGER,hostEpoch:Number.MAX_SAFE_INTEGER},settlement:{status:'settled',retirementOperationId:t.operationId}},L.hostProtectedBytes);
    if(t.principal!==current.principal || t.agent!==current.agent || canonicalSourceKey(t.subject)!==canonicalSourceKey(subject) || t.sourceIncarnation!==current.sourceIncarnation || t.watchIncarnation!==current.watchIncarnation || t.routingRevision!==view.routingRevision || t.lifecycleEpoch!==current.lifecycleEpoch+1 || t.installationId!==current.installationId || t.grantRevision!==current.grantRevision || t.mappingRevision!==current.mappingRevision || t.policyRevision!==current.policyRevision || t.sourceEnableGeneration!==current.sourceEnableGeneration)throw new Error('github_source_conflict');
    this.unused(t.operationId);const key=canonicalSourceKey(subject);
    this.sql.exec('DELETE FROM github_watch_outbox WHERE canonical_subject=?',key);
    this.sql.exec('UPDATE github_source_controls SET token_json=?,operation_id=?,updated_at=? WHERE canonical_subject=?',watchJson(t),t.operationId,now,key);
    this.sql.exec('UPDATE github_source_cleanup_bundles SET operation_id=? WHERE canonical_subject=?',t.operationId,key);
    this.sql.exec("INSERT INTO github_watch_outbox(operation_id,canonical_subject,token_json,phase,next_at) VALUES (?,?,?,'stop',?)",t.operationId,key,watchJson(t),now);
    this.sql.exec("UPDATE github_watch_state SET phase='stop_pending',updated_at=? WHERE canonical_subject=?",now,key);
    view.lifecycleEpoch=t.lifecycleEpoch;view.sourceControl={mode:'stopped',status:'pending',operationId:t.operationId,obligationId:t.obligationId,reason};this.write(view);return view;
  }
  outbox(id:string):WatchOutbox|null {return this.enabled()?this.sql.exec<WatchOutbox>('SELECT * FROM github_watch_outbox WHERE operation_id=?',id).toArray()[0]??null:null;}
  claim(now:number,claimId:string):WatchOutbox|null {
    if(!this.enabled())return null;
    const row=this.sql.exec<WatchOutbox>('SELECT * FROM github_watch_outbox WHERE next_at<=? AND (claim_until IS NULL OR claim_until<=?) ORDER BY next_at,operation_id LIMIT 1',now,now).toArray()[0];if(!row)return null;
    const token=WatchControlTokenSchema.parse(JSON.parse(row.token_json));
    if(!internalTokenEquals(this.token(token.subject),token) || row.canonical_subject!==canonicalSourceKey(token.subject))throw new Error('github_source_conflict');
    this.protectedOwner(token.subject,token);
    this.sql.exec('UPDATE github_watch_outbox SET claim_id=?,claim_until=?,attempts=attempts+1 WHERE operation_id=?',claimId,now+L.operationLeaseMs,row.operation_id);return this.outbox(row.operation_id);
  }
  retry(id:string,claimId:string,nextAt:number,now:number):boolean {return this.sql.exec('UPDATE github_watch_outbox SET claim_id=NULL,claim_until=NULL,next_at=? WHERE operation_id=? AND claim_id=? AND claim_until>?',nextAt,id,claimId,now).rowsWritten===1;}
  private claimed(id:string,claimId:string,phase:WatchOutbox['phase'],now:number):WatchOutbox|null {const row=this.outbox(id);return row?.phase===phase && row.claim_id===claimId && row.claim_until!==null && row.claim_until>now?row:null;}
  settleActivation(id:string,claimId:string,raw:WatchAppliedOutcome,now:number):boolean {
    const row=this.claimed(id,claimId,'activate',now);if(!row)return false;
    const outcome=WatchAppliedOutcomeSchema.parse(raw), t=WatchActivateTokenSchema.parse(JSON.parse(row.token_json));
    if(outcome.status!=='activated' || !internalTokenEquals(this.token(t.subject),t))throw new Error('github_source_conflict');
    const view=this.read(t.subject)!;view.sourceControl.status='acknowledged';this.write(view);
    this.sql.exec("UPDATE github_watch_state SET phase='active',updated_at=? WHERE canonical_subject=?",now,row.canonical_subject);
    this.sql.exec('UPDATE github_watch_operations SET terminal_at=? WHERE operation_id=? AND terminal_at IS NULL',now,id);
    this.sql.exec('DELETE FROM github_watch_outbox WHERE operation_id=?',id);return true;
  }
  retainStopAck(id:string,claimId:string,raw:WatchAppliedOutcome,now:number):boolean {
    const row=this.claimed(id,claimId,'stop',now);if(!row)return false;
    const outcome=WatchAppliedOutcomeSchema.parse(raw),t=WatchStopTokenSchema.parse(JSON.parse(row.token_json));
    if(outcome.status!=='stopped' || !internalTokenEquals(this.token(t.subject),t))throw new Error('github_source_conflict');this.protectedOwner(t.subject,t);
    this.sql.exec("UPDATE github_watch_state SET phase='stopped',stop_outcome=?,updated_at=? WHERE canonical_subject=?",watchJson(outcome),now,row.canonical_subject);
    const view=this.read(t.subject)!;view.sourceControl.status='acknowledged';this.write(view);
    this.sql.exec('UPDATE github_watch_operations SET terminal_at=? WHERE canonical_subject=? AND terminal_at IS NULL AND protected=0',now,row.canonical_subject);
    this.sql.exec('DELETE FROM github_watch_outbox WHERE operation_id=?',id);
    if(this.state(t.subject)?.retirement_operation_id)this.queueRetirement(t.subject,now);return true;
  }
  private queueRetirement(subject:SourceKey,now:number):void {const t=this.token(subject);this.sql.exec("INSERT INTO github_watch_outbox(operation_id,canonical_subject,token_json,phase,next_at) VALUES (?,?,?,'retire',?)",t.operationId,canonicalSourceKey(subject),watchJson(t),now);}
  settleRetirement(id:string,claimId:string,raw:WatchSettlementWitness,now:number):boolean {
    const row=this.claimed(id,claimId,'retire',now);if(!row)return false;
    const witness=WatchSettlementWitnessSchema.parse(raw),t=WatchStopTokenSchema.parse(JSON.parse(row.token_json)),state=this.state(t.subject);
    if(!state || state.retirement_operation_id!==witness.retirementOperationId || !state.stop_outcome || this.read(t.subject)?.state!=='retired' || !internalTokenEquals(this.token(t.subject),t))throw new Error('github_source_conflict');this.protectedOwner(t.subject,t);
    this.sql.exec('UPDATE github_watch_state SET settlement=?,updated_at=? WHERE canonical_subject=?',watchJson(witness),now,row.canonical_subject);
    this.sql.exec('UPDATE github_watch_operations SET terminal_at=? WHERE operation_id=? AND terminal_at IS NULL AND protected=1',now,witness.retirementOperationId);
    this.sql.exec('DELETE FROM github_watch_outbox WHERE operation_id=?',id);return true;
  }
  authority(subject:SourceKey):WatchAuthorityReadback {
    if(!this.enabled())return {status:'source_only'};const state=this.state(subject);if(!state){const row=this.sql.exec<{control_owner:string}>('SELECT control_owner FROM github_source_controls WHERE canonical_subject=?',canonicalSourceKey(subject)).toArray()[0];return row?.control_owner==='source_only'?{status:'source_only'}:row?{status:'unavailable'}:{status:'absent'};}
    const t=this.token(subject);if(!state.released)this.protectedOwner(subject,t);
    return {status:'watch',token:t,phase:state.phase,reservation:state.released?'released':'protected',retirementOperationId:state.retirement_operation_id,stopOutcome:state.stop_outcome?JSON.parse(state.stop_outcome):null};
  }
  activeDue(now:number):WatchControlToken[] {if(!this.enabled())return [];return this.sql.exec<{token_json:string}>("SELECT c.token_json FROM github_watch_state s JOIN github_source_controls c USING(canonical_subject) WHERE s.phase='active' AND s.updated_at+?<=? LIMIT 32",L.authorityAuditMs,now).toArray().map(row=>WatchControlTokenSchema.parse(JSON.parse(row.token_json)));}
  touch(token:WatchControlToken,now:number,reason: 'authority_unavailable'|null=null):void {if(!internalTokenEquals(this.token(token.subject),token))throw new Error('github_source_conflict');this.sql.exec('UPDATE github_watch_state SET updated_at=? WHERE canonical_subject=?',now,canonicalSourceKey(token.subject));const view=this.read(token.subject)!;view.sourceControl.reason=reason;view.sourceControl.status=reason?'blocked':'acknowledged';this.write(view);}
  nextAt(now=Date.now()):number|null {if(!this.enabled())return null;return this.sql.exec<{n:number|null}>(`SELECT min(n) AS n FROM (SELECT CASE WHEN claim_until>? THEN claim_until ELSE next_at END AS n FROM github_watch_outbox UNION ALL SELECT updated_at+? FROM github_watch_state WHERE phase='active' UNION ALL SELECT o.terminal_at+? FROM github_watch_operations o JOIN github_watch_state s ON s.retirement_operation_id=o.operation_id WHERE s.settlement IS NOT NULL AND s.released=0)`,now,L.authorityAuditMs,L.terminalRetentionMs).one().n;}
  prune(now:number):void {
    if(!this.enabled())return;
    this.sql.exec('DELETE FROM github_source_operations WHERE terminal_at IS NOT NULL AND terminal_at<=? AND operation_id NOT IN (SELECT operation_id FROM github_source_outbox)',now-L.terminalRetentionMs);
    for(const row of this.sql.exec<{canonical_subject:string}>(`SELECT s.canonical_subject FROM github_watch_state s JOIN github_watch_operations o ON o.operation_id=s.retirement_operation_id WHERE s.settlement IS NOT NULL AND s.released=0 AND o.terminal_at<=?`,now-L.terminalRetentionMs).toArray()) {
      this.sql.exec("DELETE FROM github_source_cleanup_bundles WHERE canonical_subject=? AND control_owner='watch'",row.canonical_subject);
      this.sql.exec('UPDATE github_watch_state SET released=1 WHERE canonical_subject=?',row.canonical_subject);
    }
    this.sql.exec('DELETE FROM github_watch_operations WHERE terminal_at<=? AND (protected=0 OR canonical_subject IN (SELECT canonical_subject FROM github_watch_state WHERE released=1))',now-L.terminalRetentionMs);
  }
  assertCapacity():void { assertMixedWatchCapacity(this.sql); }
}
export { GitHubWatchStore as GitHubWatchControlStore };
