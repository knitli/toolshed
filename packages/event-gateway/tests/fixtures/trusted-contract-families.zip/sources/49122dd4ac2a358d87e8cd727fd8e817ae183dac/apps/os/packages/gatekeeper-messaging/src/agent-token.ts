// Agent tokens (spec 2026-09-30 "Signed agent credentials"): an external agent signs a short-lived
// Ed25519 JWT (JWS compact, RFC 7515) with a key whose public half its owner registered; the Worker
// finds that key by the header's kid, the key's RFC 7638 thumbprint. Imports nothing and is free of
// Worker types, so the Worker, the tests and the Node scripts (agent-key.ts, inbox-hook.ts) share it.

export const TOKEN_MAX_SECONDS = 300;
export const TOKEN_SKEW_SECONDS = 30;
/** An RFC 7638 SHA-256 thumbprint, base64url: 43 characters. */
export const THUMBPRINT = /^[A-Za-z0-9_-]{43}$/;
const TOKEN_MAX_LENGTH = 4096;
const AGENT = /^[a-z0-9-]{1,32}$/; // model.ts AGENT, copied: this file imports nothing
const ALGS: readonly unknown[] = ["Ed25519", "EdDSA"];
const FORBIDDEN_HEADERS = ["crit", "jku", "jwk", "x5u", "x5c"];

const encoder = new TextEncoder();
const decoder = new TextDecoder();

export function b64u(data: Uint8Array): string {
  let text = "";
  for (const byte of data) text += String.fromCharCode(byte);
  return btoa(text).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
const B64U = /^[A-Za-z0-9_-]*$/;
/**
 * Canonical unpadded base64url (RFC 7515 section 2) only, else null. atob alone also takes padding
 * and non-zero pad bits, so one signature would have several encodings that all verify.
 */
export function unb64u(text: string): Uint8Array<ArrayBuffer> | null {
  if (!B64U.test(text) || text.length % 4 === 1) return null;
  const data = Uint8Array.from(atob(text.replace(/-/g, "+").replace(/_/g, "/")), (c) => c.charCodeAt(0));
  return b64u(data) === text ? data : null;
}

const record = (value: unknown): value is Record<string, unknown> => !!value && typeof value === "object" && !Array.isArray(value);
const json = (bytes: Uint8Array): unknown => {
  try {
    return JSON.parse(decoder.decode(bytes));
  } catch {
    return null;
  }
};

/** RFC 7638 §3.2 over the required OKP members, in lexicographic order. `x` is already validated. */
export async function thumbprint(x: string): Promise<string> {
  const members = JSON.stringify({ crv: "Ed25519", kty: "OKP", x });
  return b64u(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(members))));
}

const hex = (bytes: Uint8Array): string => Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
/**
 * The eight small-order Ed25519 points (orders 1, 2, 4 and 8; libsodium's blocklist, canonical
 * encodings). A public key among them lets signatures verify that its holder never made: refused as bad_x.
 */
export const SMALL_ORDER: ReadonlySet<string> = new Set([
  "0100000000000000000000000000000000000000000000000000000000000000", // identity
  "ecffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff7f", // order 2
  "0000000000000000000000000000000000000000000000000000000000000000", // order 4
  "0000000000000000000000000000000000000000000000000000000000000080", // order 4
  "26e8958fc2b227b045c3f489f2ef98f0d5dfac05d3c63339b13802886d53fc05", // order 8
  "26e8958fc2b227b045c3f489f2ef98f0d5dfac05d3c63339b13802886d53fc85", // order 8
  "c7176a703d4dd84fba3c0b760d10670f2a2053fa2c39ccc64ec7fd7792ac037a", // order 8
  "c7176a703d4dd84fba3c0b760d10670f2a2053fa2c39ccc64ec7fd7792ac03fa", // order 8
]);

const importPublic = (x: string): Promise<CryptoKey> => crypto.subtle.importKey("jwk", { kty: "OKP", crv: "Ed25519", x }, "Ed25519", false, ["verify"]);

/**
 * A public Ed25519 JWK (an object, or its JSON text), or the reason it is not one: "not_json" |
 * "not_ed25519" | "private" | "bad_x". kid, alg, use and key_ops are ignored: only x is kept.
 */
export async function publicJwk(value: unknown): Promise<{ x: string; thumbprint: string } | { refused: string }> {
  let jwk = value;
  if (typeof value === "string") {
    try {
      jwk = JSON.parse(value);
    } catch {
      return { refused: "not_json" };
    }
  }
  if (!record(jwk)) return { refused: "not_json" };
  // First: a private key is refused as one whatever else is wrong with it, so the owner learns to replace it.
  if ("d" in jwk) return { refused: "private" };
  if (jwk.kty !== "OKP" || jwk.crv !== "Ed25519") return { refused: "not_ed25519" };
  const x = jwk.x;
  const bytes = typeof x === "string" ? unb64u(x) : null;
  if (typeof x !== "string" || bytes?.length !== 32 || SMALL_ORDER.has(hex(bytes))) return { refused: "bad_x" };
  try {
    await importPublic(x);
  } catch {
    return { refused: "bad_x" };
  }
  return { x, thumbprint: await thumbprint(x) };
}

/** An agent's Ed25519 JWK, as WebCrypto exports it (DOM's JsonWebKey, which Node's script types lack). */
export type AgentJwk = { kty?: string; crv?: string; x?: string; d?: string };

export type ReadToken = { agent: string; kid: string; input: string; signature: Uint8Array<ArrayBuffer>; expiresAt: number };

/**
 * Structure and claims only: no key, so nothing is looked up for a token that fails here. A reason
 * ("malformed" | "alg" | "header" | "aud" | "sub" | "time") when refused.
 */
export function readToken(token: string, expected: { audience: string; principal: string; now: number /* seconds */ }): ReadToken | { refused: string } {
  if (token.length > TOKEN_MAX_LENGTH) return { refused: "malformed" };
  const parts = token.split(".");
  if (parts.length !== 3) return { refused: "malformed" };
  const [head, body, signature] = parts.map(unb64u);
  if (!head || !body || !signature) return { refused: "malformed" };
  const header = json(head);
  const claims = json(body);
  if (!record(header) || !record(claims)) return { refused: "malformed" };
  if (!ALGS.includes(header.alg)) return { refused: "alg" };
  if (typeof header.kid !== "string" || !THUMBPRINT.test(header.kid)) return { refused: "header" };
  if (header.typ !== undefined && header.typ !== "JWT") return { refused: "header" };
  if (FORBIDDEN_HEADERS.some((name) => name in header)) return { refused: "header" };
  const sub = claims.sub;
  const slash = typeof sub === "string" ? sub.lastIndexOf("/") : -1;
  if (typeof sub !== "string" || slash < 0 || sub.slice(0, slash) !== expected.principal || !AGENT.test(sub.slice(slash + 1))) return { refused: "sub" };
  if (typeof claims.aud !== "string" || claims.aud !== expected.audience) return { refused: "aud" };
  const { iat, exp } = claims;
  // agent-key.ts never issues nbf: a token carrying one was made by something else, whose clock rules we do not know.
  if ("nbf" in claims) return { refused: "time" };
  if (!Number.isSafeInteger(iat) || !Number.isSafeInteger(exp)) return { refused: "time" };
  const [issued, expires] = [iat as number, exp as number];
  if (issued >= expires || expires - issued > TOKEN_MAX_SECONDS || issued > expected.now + TOKEN_SKEW_SECONDS || expires <= expected.now - TOKEN_SKEW_SECONDS)
    return { refused: "time" };
  return { agent: sub.slice(slash + 1), kid: header.kid, input: `${parts[0]}.${parts[1]}`, signature, expiresAt: expires };
}

/** Whether `read` was signed by the key whose public half is `x`. A key or signature WebCrypto refuses is false. */
export async function signatureValid(read: ReadToken, x: string): Promise<boolean> {
  try {
    return await crypto.subtle.verify("Ed25519", await importPublic(x), read.signature, encoder.encode(read.input));
  } catch {
    return false;
  }
}

/** A token for `claims.sub`, signed with the agent's private JWK, valid from `now` (seconds) for `lifetime` seconds. */
export async function signToken(privateJwk: AgentJwk, claims: { sub: string; aud: string; lifetime: number }, now: number): Promise<string> {
  const { crv, x, d } = privateJwk;
  if (typeof x !== "string") throw new Error("the agent key has no x");
  const signer = await crypto.subtle.importKey("jwk", { kty: "OKP", crv, x, d }, "Ed25519", false, ["sign"]);
  const header = { alg: "Ed25519", kid: await thumbprint(x), typ: "JWT" };
  const payload = { sub: claims.sub, aud: claims.aud, iat: now, exp: now + claims.lifetime };
  const input = `${b64u(encoder.encode(JSON.stringify(header)))}.${b64u(encoder.encode(JSON.stringify(payload)))}`;
  return `${input}.${b64u(new Uint8Array(await crypto.subtle.sign("Ed25519", signer, encoder.encode(input))))}`;
}
