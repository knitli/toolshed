import { z } from "zod";

// Keep deployment validation usable by the plain-Node installation runner.
export const NativeAdmissionCanarySchema = z.strictObject({
  principal: z.email().max(254).refine(value => value === value.toLowerCase()),
  agent: z.string().regex(/^[a-z0-9-]{1,32}$/),
});
