import { z } from "zod";

const subjectId = z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/);
const expiresAt = z.iso.datetime({ precision: 3 });
export const ManualCanarySchema = z.union([
  z.strictObject({ subjectId, expiresAt }),
  z.strictObject({
    subjectIds: z.array(subjectId).min(1).max(7).refine(ids => new Set(ids).size === ids.length),
    expiresAt,
  }),
]);
export type ManualCanary = z.infer<typeof ManualCanarySchema>;
