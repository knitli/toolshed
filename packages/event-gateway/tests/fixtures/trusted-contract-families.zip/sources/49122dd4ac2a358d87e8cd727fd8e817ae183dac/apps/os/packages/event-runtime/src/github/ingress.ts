import type { GitHubSubjectV1 } from './state';

export interface GitHubTriggerV1 { deliveryId: string; event: string; installationId: number; repositoryId: number; prNumber: number | null; commitSha: string | null }
export interface GitHubIngress {
  secret: string;
  /** Admission and canonical watched-PR routing occur only after signature verification. */
  accept(trigger: GitHubTriggerV1): Promise<'accepted' | 'denied'>;
}
const events = new Set(['pull_request', 'pull_request_review', 'pull_request_review_comment', 'pull_request_review_thread', 'issue_comment', 'check_run', 'check_suite', 'status', 'workflow_run']);
const positiveId = (value: unknown): value is number => Number.isSafeInteger(value) && Number(value) > 0;
const record = (value: unknown): Record<string, unknown> => typeof value === 'object' && value !== null && !Array.isArray(value) ? value as Record<string, unknown> : {};
export function validSubject(value: GitHubSubjectV1): boolean { return positiveId(value.installationId) && positiveId(value.repositoryId) && positiveId(value.prNumber); }

/** A signed webhook is a reconcile hint, never authoritative PR state. */
export async function githubIngress(request: Request, receiver: GitHubIngress): Promise<Response> {
  if (request.method !== 'POST') return new Response(null, { status: 405 });
  if (!receiver.secret) return new Response(null, { status: 503 });
  if (request.headers.get('content-type')?.split(';')[0]?.trim() !== 'application/json' || request.headers.has('content-encoding')) return new Response(null, { status: 415 });
  const signature = request.headers.get('x-hub-signature-256') ?? '';
  if (!/^sha256=[0-9a-f]{64}$/.test(signature)) return new Response(null, { status: 401 });
  const reader = request.body?.getReader();
  if (!reader) return new Response(null, { status: 400 });
  const chunks: Uint8Array[] = [];
  let length = 0, timedOut = false;
  const timer = setTimeout(() => { timedOut = true; void reader.cancel(); }, 5000);
  try {
    while (true) {
      const chunk = await reader.read();
      if (chunk.done) break;
      length += chunk.value.length;
      if (length > 256 * 1024) { await reader.cancel(); return new Response(null, { status: 413 }); }
      chunks.push(chunk.value);
    }
  } catch { return new Response(null, { status: timedOut ? 408 : 400 }); }
  finally { clearTimeout(timer); reader.releaseLock(); }
  if (timedOut) return new Response(null, { status: 408 });
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(receiver.secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
  const digest = Uint8Array.from(signature.slice(7).match(/../g)!, byte => parseInt(byte, 16));
  if (!await crypto.subtle.verify('HMAC', key, digest, bytes)) return new Response(null, { status: 401 });
  const event = request.headers.get('x-github-event') ?? '';
  const deliveryId = request.headers.get('x-github-delivery') ?? '';
  if (!events.has(event) || !/^[a-zA-Z0-9-]{1,128}$/.test(deliveryId)) return new Response(null, { status: 400 });
  let payload: Record<string, unknown>;
  try { payload = record(JSON.parse(new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(bytes))); }
  catch { return new Response(null, { status: 400 }); }
  const installationId = record(payload.installation).id, repositoryId = record(payload.repository).id;
  if (!positiveId(installationId) || !positiveId(repositoryId)) return new Response(null, { status: 400 });
  let prNumber: unknown = null, commitSha: unknown = null;
  if (event.startsWith('pull_request')) prNumber = record(payload.pull_request).number;
  else if (event === 'issue_comment' && record(payload.issue).pull_request) prNumber = record(payload.issue).number;
  else if (event === 'status') commitSha = payload.sha;
  else commitSha = record(payload[event]).head_sha;
  if (!positiveId(prNumber) && !(typeof commitSha === 'string' && /^[0-9a-f]{40}$/.test(commitSha))) return new Response(null, { status: 400 });
  const status = await receiver.accept({ deliveryId, event, installationId, repositoryId, prNumber: positiveId(prNumber) ? prNumber : null, commitSha: typeof commitSha === 'string' ? commitSha : null });
  return new Response(null, { status: status === 'accepted' ? 202 : 403 });
}
