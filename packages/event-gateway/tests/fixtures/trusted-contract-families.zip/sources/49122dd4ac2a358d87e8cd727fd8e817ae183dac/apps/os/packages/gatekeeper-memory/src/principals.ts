// The Worker's config grammar for who may use memory: ALLOWED_PRINCIPALS, MEMORY_REVIEWERS,
// MEMORY_SERVICE_TOKENS and SERVICE_OWNERS. Kept free of Worker types and runtime APIs, because scripts/deploy.ts
// imports these same parsers to refuse at deploy time a config the Worker would answer with 503.

import { AccessUnavailable, canonicalEmail } from "openapi-operator/src/access.ts";

/** Lowercased `@domain` entries and exact emails from ALLOWED_PRINCIPALS. */
export type PrincipalRules = { allowedDomains: readonly string[]; allowedEmails: readonly string[] };

const SERVICE_CLIENT_ID = /^[a-f0-9]{32}\.access$/;
export const SERVICE_PRINCIPAL = /^svc:[a-z0-9-]{1,64}$/;
// Checked label by label, so no pattern ever backtracks over the whole domain.
const DOMAIN_LABEL = /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/;
const TOP_LEVEL_DOMAIN = /^[a-z]{2,63}$/;
function isDomain(value: string): boolean {
  const labels = value.toLowerCase().split(".");
  return labels.length >= 2 && TOP_LEVEL_DOMAIN.test(labels.at(-1)!) && labels.every((label) => DOMAIN_LABEL.test(label));
}

export function parseServiceTokens(raw: string): Readonly<Record<string, string>> {
  const parsed: unknown = JSON.parse(raw || "{}");
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new AccessUnavailable();
  const map: Record<string, string> = Object.create(null);
  for (const [clientId, principal] of Object.entries(parsed)) {
    if (!SERVICE_CLIENT_ID.test(clientId)) throw new AccessUnavailable();
    if (typeof principal !== "string" || !(SERVICE_PRINCIPAL.test(principal) || canonicalEmail(principal)))
      throw new AccessUnavailable();
    map[clientId] = principal.toLowerCase();
  }
  return Object.freeze(map);
}

export function parseAllowedPrincipals(raw: string): PrincipalRules {
  const allowedDomains: string[] = [];
  const allowedEmails: string[] = [];
  for (const entry of raw.split(",").map((value) => value.trim().toLowerCase())) {
    if (!entry) continue;
    if (entry.startsWith("@") && isDomain(entry.slice(1))) allowedDomains.push(entry);
    else if (canonicalEmail(entry)) allowedEmails.push(entry);
    else throw new AccessUnavailable();
  }
  if (!allowedDomains.length && !allowedEmails.length) throw new AccessUnavailable();
  return { allowedDomains, allowedEmails };
}

/** Fails closed like ALLOWED_PRINCIPALS: one malformed entry makes the whole service unavailable. */
export function parseReviewers(raw: string): string[] {
  const reviewers = raw
    .split(",")
    .map((email) => email.trim().toLowerCase())
    .filter(Boolean);
  if (!reviewers.every((email) => canonicalEmail(email))) throw new AccessUnavailable();
  return reviewers;
}

/**
 * SERVICE_OWNERS: `svc:<name>=<email>` pairs, comma-separated. The human who confirms widenings of
 * that service's segments, since a service principal cannot confirm anything on the review host.
 */
export function parseServiceOwners(raw: string): Readonly<Record<string, string>> {
  const owners: Record<string, string> = Object.create(null);
  for (const pair of raw.split(",").map((value) => value.trim().toLowerCase())) {
    if (!pair) continue;
    // At the first "=" only: an email's local part may contain "=".
    const cut = pair.indexOf("=");
    const [service, owner] = [pair.slice(0, cut), pair.slice(cut + 1)];
    if (cut < 0 || !SERVICE_PRINCIPAL.test(service) || !canonicalEmail(owner)) throw new AccessUnavailable();
    owners[service] = owner;
  }
  return Object.freeze(owners);
}

export function allowed(email: string, config: PrincipalRules): boolean {
  if (config.allowedEmails.includes(email)) return true;
  return config.allowedDomains.includes(email.slice(email.lastIndexOf("@")));
}

/**
 * ALLOWED_PRINCIPALS for an OS account's principal, checked again on every session, apply and
 * verifier call so that removing a person from the list also revokes their connected accounts.
 */
export function principalAllowed(env: { ALLOWED_PRINCIPALS: string }, email: string): boolean {
  try {
    return canonicalEmail(email) && allowed(email, parseAllowedPrincipals(env.ALLOWED_PRINCIPALS));
  } catch {
    return false; // malformed or empty list: fail closed
  }
}
