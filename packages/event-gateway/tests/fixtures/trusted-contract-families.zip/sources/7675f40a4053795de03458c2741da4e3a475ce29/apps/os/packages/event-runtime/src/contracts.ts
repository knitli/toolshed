import { z } from "zod";
import type { EventAuthorityServiceV1, EventAttemptStatusResultV1, EventAttemptReservationResultV1 } from "gatekeeper-messaging/src/event-authority-contract";
import type { OwnerRegistry } from "./registry.ts";
import type { AgentCoordinator } from "./coordinator.ts";
import { EventEnvelopeSchema } from "./protocol.ts";

export const uuid = z.uuid().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[47][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
export const agent = z.string().regex(/^[a-z0-9-]{1,32}$/);
export const generation = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);
export const deliveryId = z.string().regex(/^dly_[0-9a-f]{64}$/);
export const CompleteEnrollmentSchema = z.strictObject({ challengeId: uuid, signature: z.string().regex(/^[A-Za-z0-9_-]{86}$/) });
export const RuntimeRequestSchema = z.strictObject({ runtimeId: uuid });
export const ClaimRequestSchema = z.strictObject({ deliveryId, attemptId: uuid });
const budgetSchema = z.strictObject({ used: z.number().int().nonnegative(), remaining: z.number().int().nonnegative(), limit: z.literal(10), windowMs: z.literal(3600000) });
/** Original transport timestamps describe transport only. The distinct permit window
 * governs this single native attempt, including delivery identity and every generation. */
export const DispatchClaimResultSchema = z.union([
  z.strictObject({
    status: z.literal("admitted"), permitId: uuid, nodeId: uuid,
    permitIssuedAt: z.iso.datetime({ precision: 3 }), permitExpiresAt: z.iso.datetime({ precision: 3 }),
    envelope: EventEnvelopeSchema,
  }).refine((value) => Date.parse(value.permitExpiresAt) - Date.parse(value.permitIssuedAt) === 5000),
  z.strictObject({ status: z.literal("over_budget"), budget: budgetSchema }),
]);
export type DispatchClaimResult = z.infer<typeof DispatchClaimResultSchema>;
export const DispatchNoStartRequestSchema = z.strictObject({
  deliveryId, attemptId: uuid, permitId: uuid, nodeGeneration: generation,
  evidence: z.union([
    z.strictObject({ type: z.literal("native_terminal_no_start"), receiptId: uuid }),
    z.strictObject({ type: z.literal("local_not_submitted") }),
  ]),
});
export const DispatchNoStartResultSchema = DispatchNoStartRequestSchema.extend({ nodeId: uuid, status: z.literal("not_started") });
export type DispatchNoStartRequest = z.infer<typeof DispatchNoStartRequestSchema>;
export type DispatchNoStartResult = z.infer<typeof DispatchNoStartResultSchema>;
export const NodeProofSchema = z.strictObject({
  nodeId: uuid, nodeGeneration: generation, issuedAt: z.iso.datetime({ precision: 3 }), nonce: uuid,
  signature: z.string().regex(/^[A-Za-z0-9_-]{86}$/),
});

export type AuthorityEnvironment = { MESSAGE_AUTHORITY: EventAuthorityServiceV1 };
export type EventApiEnvironment = AuthorityEnvironment & {
  EVENT_ENABLED: string;
  EVENT_MANUAL_ENABLED: string;
  EVENT_NATIVE_BINDING_ENABLED?: string;
  EVENT_NATIVE_BINDING_CANARY?: string;
  GITHUB_SOURCE_MAP?: string;
  EVENT_HOST: string;
  ACCESS_ISSUER: string;
  ACCESS_EVENT_AUD: string;
  ACCESS_UI_AUD: string;
  ADMIN_UI_ORIGIN: string;
  ALLOWED_PRINCIPALS: string;
  OWNER_REGISTRY: DurableObjectNamespace<OwnerRegistry>;
  AGENT_COORDINATOR: DurableObjectNamespace<AgentCoordinator>;
};
export function coordinatorName(principal: string, name: string): string {
  return JSON.stringify(["event-agent-v1", principal, name]);
}
export function runtimeConfigured(env: EventApiEnvironment, acknowledgmentOnly = false): boolean {
  try {
    return (env.EVENT_ENABLED === "true" || (acknowledgmentOnly && env.EVENT_ENABLED === "false")) &&
      new URL(`https://${env.EVENT_HOST}`).hostname === env.EVENT_HOST &&
      ![":", "/", "?", "#", "@"].some(character => env.EVENT_HOST.includes(character)) && env.EVENT_HOST.includes(".") &&
      new URL(env.ACCESS_ISSUER).origin === env.ACCESS_ISSUER && env.ACCESS_ISSUER.startsWith("https://") &&
      !!env.ACCESS_EVENT_AUD && !env.ACCESS_EVENT_AUD.includes("<") &&
      env.ACCESS_EVENT_AUD !== env.ACCESS_UI_AUD && !!env.MESSAGE_AUTHORITY &&
      !!env.OWNER_REGISTRY && !!env.AGENT_COORDINATOR;
  } catch { return false; }
}
export class EventApiError extends Error {
  constructor(readonly code: string, readonly status = 400) { super(code); }
}

const authorityBudgetSchema = budgetSchema.refine((value) => value.remaining === Math.max(0, value.limit - value.used));
const authorityFailureSchema = z.strictObject({ status: z.enum(["denied", "unavailable", "invalid"]) });
const authorityAttemptFields = {
  attemptId: uuid,
  reservedAt: generation.nullable(),
  budget: authorityBudgetSchema,
};
const nativeAttemptStatusSchema = z.union([
  z.strictObject({ status: z.enum(["reserved", "unknown"]), ...authorityAttemptFields }),
  authorityFailureSchema,
]);
const nativeAttemptReservationSchema = z.union([
  z.strictObject({ status: z.enum(["reserved", "over_budget"]), ...authorityAttemptFields, idempotent: z.boolean() }),
  authorityFailureSchema,
]);

/** Treat private binding replies as untrusted before they can authorize a permit. */
export function parseNativeAttemptStatus(value: unknown, requestedAttemptId: string): EventAttemptStatusResultV1 {
  const result = nativeAttemptStatusSchema.safeParse(value);
  if (!result.success || ("attemptId" in result.data && result.data.attemptId !== requestedAttemptId))
    throw new EventApiError("authority_unavailable", 503);
  return result.data;
}
export function parseNativeAttemptReservation(value: unknown, requestedAttemptId: string): EventAttemptReservationResultV1 {
  const result = nativeAttemptReservationSchema.safeParse(value);
  if (!result.success || ("attemptId" in result.data && result.data.attemptId !== requestedAttemptId))
    throw new EventApiError("authority_unavailable", 503);
  return result.data;
}

/** All public API JSON is bounded, closed by its route schema, and unambiguous. */
export function parseApiJson(text: string): unknown {
  if (new TextEncoder().encode(text).length > 8192) throw new EventApiError("request_too_large", 413);
  let i = 0;
  const whitespace = () => { while (/\s/.test(text[i] ?? "") && i < text.length) i++; };
  const string = (): string => {
    const start = i++;
    while (i < text.length) {
      if (text[i] === "\\") { i += 2; continue; }
      if (text[i++] === '"') return JSON.parse(text.slice(start, i)) as string;
    }
    throw new EventApiError("invalid_json");
  };
  const value = (depth: number): void => {
    if (depth > 16) throw new EventApiError("invalid_json");
    whitespace();
    if (text[i] === '"') { string(); return; }
    if (text[i] === "{" || text[i] === "[") {
      const object = text[i++] === "{";
      const close = object ? "}" : "]";
      const keys = new Set<string>();
      whitespace();
      if (text[i] === close) { i++; return; }
      while (i < text.length) {
        if (object) {
          whitespace();
          if (text[i] !== '"') throw new EventApiError("invalid_json");
          const key = string();
          if (keys.has(key)) throw new EventApiError("duplicate_json_key");
          keys.add(key); whitespace();
          if (text[i++] !== ":") throw new EventApiError("invalid_json");
        }
        value(depth + 1); whitespace();
        if (text[i] === close) { i++; return; }
        if (text[i++] !== ",") throw new EventApiError("invalid_json");
      }
      throw new EventApiError("invalid_json");
    }
    const start = i;
    while (i < text.length && !/[\s,}\]]/.test(text[i]!)) i++;
    if (start === i) throw new EventApiError("invalid_json");
    JSON.parse(text.slice(start, i));
  };
  try {
    value(0); whitespace();
    if (i !== text.length) throw new EventApiError("invalid_json");
    return JSON.parse(text);
  } catch (error) {
    if (error instanceof EventApiError) throw error;
    throw new EventApiError("invalid_json");
  }
}

export async function readApiBody(request: Request): Promise<string> {
  if (request.headers.get("content-type")?.split(";")[0]?.trim().toLowerCase() !== "application/json")
    throw new EventApiError("content_type", 415);
  if (request.headers.has("content-encoding")) throw new EventApiError("content_encoding", 415);
  const reader = request.body?.getReader();
  if (!reader) throw new EventApiError("invalid_json");
  const decoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });
  let length = 0, result = "";
  let timer: ReturnType<typeof setTimeout> | undefined;
  const deadline = new Promise<never>((_, reject) => {
    timer = setTimeout(() => { reject(new EventApiError("request_timeout", 408)); void reader.cancel(); }, 5000);
  });
  try {
    while (true) {
      const chunk = await Promise.race([reader.read(), deadline]);
      if (chunk.done) break;
      length += chunk.value.length;
      if (length > 8192) { void reader.cancel(); throw new EventApiError("request_too_large", 413); }
      result += decoder.decode(chunk.value, { stream: true });
    }
    return result + decoder.decode();
  } catch (error) {
    if (error instanceof EventApiError) throw error;
    throw new EventApiError("invalid_body");
  } finally { if (timer !== undefined) clearTimeout(timer); reader.releaseLock(); }
}
