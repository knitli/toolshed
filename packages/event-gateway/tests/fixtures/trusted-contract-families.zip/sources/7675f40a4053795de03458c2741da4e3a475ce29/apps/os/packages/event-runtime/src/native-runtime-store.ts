import type { z } from "zod";
import { EventApiError } from "./contracts.ts";
import { EVENT_POLICY_V1 } from "./policy.ts";
import {
  NativeRuntimeAttachResponseSchema, NativeRuntimeRenewResponseSchema, NativeRuntimeTransferResponseSchema,
  NativeRuntimeBindingSchema, NativeRuntimeStatusResponseSchema, type NativeRuntimeStatusResponse,
  type NativeRuntimeBinding, type NativeRuntimeChallengeRequest, type NativeRuntimeWitnessSchema,
  type NativeRuntimeAttachRequest, type NativeRuntimeRenewRequest, type NativeRuntimeTransferRequest,
} from "./native-admission-contract.ts";

export type RuntimeRow = {
  runtime_id: string; runtime_generation: number; node_id: string; node_generation: number;
  attachment_generation: number; lease_until: number; qualified: number;
};
type NativeRuntimeBindingRow = { runtime_id: string; client_id: string; key_thumbprint: string | null; binding_json: string; nonce: number; sequence: number };
export type NativeRuntimeCommitRequest = NativeRuntimeAttachRequest | NativeRuntimeRenewRequest | NativeRuntimeTransferRequest;

function row<T>(sql: SqlStorage, query: string, ...values: SqlStorageValue[]): T | null {
  return (sql.exec<Record<string, SqlStorageValue>>(query, ...values).toArray()[0] as T | undefined) ?? null;
}
function nowIso(now: number): string { return new Date(now).toISOString(); }
function sameNativeBinding(left: NativeRuntimeBinding, right: NativeRuntimeBinding): boolean {
  return left.clientId === right.clientId && left.connectionId === right.connectionId && left.backendPid === right.backendPid
    && left.threadId === right.threadId && left.generation === right.generation
    && left.serverInstanceId === right.serverInstanceId && left.serverGeneration === right.serverGeneration;
}

/** Synchronous native binding mutations run inside the coordinator's existing transaction. */
export class NativeRuntimeStore {
  readonly #sql: SqlStorage;

  constructor(sql: SqlStorage) { this.#sql = sql; }

  runtime(runtimeId: string): RuntimeRow | null {
    return row<RuntimeRow>(this.#sql, "SELECT runtime_id,runtime_generation,node_id,node_generation,attachment_generation,lease_until,qualified FROM runtimes WHERE runtime_id=?", runtimeId);
  }
  /** Historical rows only: readback does not extend a lease or establish live native eligibility. */
  readback(runtimeId: string, keyThumbprint: string, now: number): NativeRuntimeStatusResponse {
    try {
      const runtime = this.runtime(runtimeId);
      const observedAt = nowIso(now);
      if (!runtime) return NativeRuntimeStatusResponseSchema.parse({ status: "missing", runtimeId, observedAt });
      const native = this.binding(runtimeId);
      if (native && native.key_thumbprint !== keyThumbprint) throw new EventApiError("denied", 403);
      const nativeBinding = native ? NativeRuntimeBindingSchema.parse(JSON.parse(native.binding_json)) : null;
      if ((native && native.client_id !== nativeBinding?.clientId) || (runtime.qualified !== 0 && runtime.qualified !== 1))
        throw new EventApiError("registry_unavailable", 503);
      return NativeRuntimeStatusResponseSchema.parse({ status: "present", runtimeId, observedAt,
        runtimeGeneration: runtime.runtime_generation, nodeId: runtime.node_id, nodeGeneration: runtime.node_generation,
        attachmentGeneration: runtime.attachment_generation, leaseUntil: nowIso(runtime.lease_until),
        storedQualified: runtime.qualified === 1, nativeBinding });
    } catch (error) {
      if (error instanceof EventApiError) throw error;
      throw new EventApiError("registry_unavailable", 503);
    }
  }
  prune(now: number): void {
    this.#sql.exec(`DELETE FROM native_runtime_challenges WHERE
      (consumed_at IS NULL AND expires_at<=?) OR (consumed_at IS NOT NULL AND receipt_expires_at<=?)`, now, now);
  }
  challengeMatches(operation: "attach" | "renew" | "transfer", intent: NativeRuntimeChallengeRequest,
    input: NativeRuntimeCommitRequest, binding: NativeRuntimeBinding): boolean {
    if (intent.operation !== operation) return false;
    if (operation === "attach" && intent.operation === "attach" && "runtimeId" in input)
      return input.runtimeId === intent.runtimeId && input.expectedRuntimeGeneration === intent.expectedRuntimeGeneration
        && input.expectedAttachmentGeneration === intent.expectedAttachmentGeneration
        && sameNativeBinding(binding, intent.expectedNativeBinding);
    if (operation === "renew" && intent.operation === "renew" && "runtimeId" in input)
      return input.runtimeId === intent.runtimeId && input.expectedRuntimeGeneration === intent.expectedRuntimeGeneration
        && input.expectedAttachmentGeneration === intent.expectedAttachmentGeneration
        && sameNativeBinding(binding, intent.expectedNativeBinding);
    if (operation === "transfer" && intent.operation === "transfer" && "sourceRuntimeId" in input)
      return input.sourceRuntimeId === intent.sourceRuntimeId
        && input.expectedSourceRuntimeGeneration === intent.expectedSourceRuntimeGeneration
        && input.expectedSourceAttachmentGeneration === intent.expectedSourceAttachmentGeneration
        && input.replacementRuntimeId === intent.replacementRuntimeId
        && input.expectedReplacementRuntimeGeneration === intent.expectedReplacementRuntimeGeneration
        && input.expectedReplacementAttachmentGeneration === intent.expectedReplacementAttachmentGeneration
        && sameNativeBinding(binding, intent.expectedNativeBinding);
    return false;
  }
  binding(runtimeId: string): NativeRuntimeBindingRow | null {
    return row<NativeRuntimeBindingRow>(this.#sql,
      "SELECT runtime_id,client_id,key_thumbprint,binding_json,nonce,sequence FROM native_runtime_bindings WHERE runtime_id=?", runtimeId);
  }
  #nextNativeGeneration(value: number): number {
    if (!Number.isSafeInteger(value) || value < 1 || value >= Number.MAX_SAFE_INTEGER) throw new Error("conflict");
    return value + 1;
  }
  #checkNativeWitnessProgress(previous: NativeRuntimeBindingRow | null, binding: NativeRuntimeBinding,
    witness: z.infer<typeof NativeRuntimeWitnessSchema>): void {
    if (!previous) return;
    let priorBinding: NativeRuntimeBinding;
    try { priorBinding = JSON.parse(previous.binding_json) as NativeRuntimeBinding; }
    catch { throw new EventApiError("native_binding_unqualified", 409); }
    if (sameNativeBinding(priorBinding, binding)
      && (witness.nonce <= previous.nonce || witness.sequence <= previous.sequence)) throw new Error("conflict");
  }
  #assertNativeClientAvailable(clientId: string, now: number, excluded: ReadonlySet<string>): void {
    const active = this.#sql.exec<{ runtime_id: string; client_id: string }>(`SELECT b.runtime_id,b.client_id FROM runtimes r
      JOIN native_runtime_bindings b ON b.runtime_id=r.runtime_id WHERE r.qualified=1 AND r.lease_until>?`, now).toArray();
    if (active.some(item => item.client_id === clientId && !excluded.has(item.runtime_id))) throw new Error("conflict");
  }
  #assertNativeActiveCapacity(now: number, excluded: ReadonlySet<string>): void {
    const active = this.#sql.exec<{ runtime_id: string }>(
      "SELECT runtime_id FROM runtimes WHERE qualified=1 AND lease_until>?", now).toArray();
    const remaining = active.filter(item => !excluded.has(item.runtime_id)).length;
    if (remaining + 1 > EVENT_POLICY_V1.pilotAdmittedSessionsPerAgent) throw new Error("conflict");
  }
  #saveNativeRuntimeBinding(runtimeId: string, binding: NativeRuntimeBinding, keyThumbprint: string,
    witness: z.infer<typeof NativeRuntimeWitnessSchema>): void {
    this.#sql.exec(`INSERT INTO native_runtime_bindings(runtime_id,client_id,key_thumbprint,binding_json,nonce,sequence) VALUES (?,?,?,?,?,?)
      ON CONFLICT(runtime_id) DO UPDATE SET client_id=excluded.client_id,key_thumbprint=excluded.key_thumbprint,binding_json=excluded.binding_json,
      nonce=excluded.nonce,sequence=excluded.sequence`, runtimeId, binding.clientId, keyThumbprint,
      JSON.stringify(binding), witness.nonce, witness.sequence);
  }
  applyCommit(operation: "attach" | "renew" | "transfer", input: NativeRuntimeCommitRequest,
    scope: { nodeId: string; nodeGeneration: number; keyThumbprint: string }, binding: NativeRuntimeBinding,
    witness: z.infer<typeof NativeRuntimeWitnessSchema>, now: number): unknown {
    const leaseUntil = now + EVENT_POLICY_V1.runtimeLeaseMs;
    if (!Number.isSafeInteger(leaseUntil)) throw new Error("conflict");
    if (operation === "attach" && "runtimeId" in input) {
      const current = this.runtime(input.runtimeId);
      const create = input.expectedRuntimeGeneration === null;
      let runtimeGeneration = 1, attachmentGeneration = 1;
      const excluded = new Set<string>();
      if (create) {
        if (current || (row<{ count: number }>(this.#sql, "SELECT count(*) AS count FROM runtimes")?.count ?? 0)
          >= EVENT_POLICY_V1.maxRuntimesPerAgent) throw new Error("conflict");
      } else {
        if (!current || current.runtime_generation !== input.expectedRuntimeGeneration
          || current.attachment_generation !== input.expectedAttachmentGeneration) throw new Error("conflict");
        runtimeGeneration = this.#nextNativeGeneration(current.runtime_generation);
        attachmentGeneration = this.#nextNativeGeneration(current.attachment_generation);
        excluded.add(input.runtimeId);
        this.#checkNativeWitnessProgress(this.binding(input.runtimeId), binding, witness);
      }
      this.#assertNativeActiveCapacity(now, excluded);
      this.#assertNativeClientAvailable(binding.clientId, now, excluded);
      if (create) {
        this.#sql.exec("INSERT INTO runtimes VALUES (?,?,?,?,?,?,1)", input.runtimeId, runtimeGeneration,
          scope.nodeId, scope.nodeGeneration, attachmentGeneration, leaseUntil);
      } else {
        const changed = this.#sql.exec(`UPDATE runtimes SET runtime_generation=?,node_id=?,node_generation=?,
          attachment_generation=?,lease_until=?,qualified=1 WHERE runtime_id=? AND runtime_generation=? AND attachment_generation=?`,
          runtimeGeneration, scope.nodeId, scope.nodeGeneration, attachmentGeneration, leaseUntil, input.runtimeId,
          input.expectedRuntimeGeneration!, input.expectedAttachmentGeneration!).rowsWritten;
        if (changed !== 1) throw new Error("conflict");
      }
      this.#saveNativeRuntimeBinding(input.runtimeId, binding, scope.keyThumbprint, witness);
      return NativeRuntimeAttachResponseSchema.parse({ status: "attached", runtimeId: input.runtimeId,
        runtimeGeneration, nodeId: scope.nodeId, nodeGeneration: scope.nodeGeneration, attachmentGeneration,
        leaseUntil: nowIso(leaseUntil), nativeBinding: binding });
    }
    if (operation === "renew" && "runtimeId" in input) {
      const current = this.runtime(input.runtimeId);
      if (!current || current.runtime_generation !== input.expectedRuntimeGeneration
        || current.attachment_generation !== input.expectedAttachmentGeneration) throw new Error("conflict");
      if (current.qualified !== 1 || current.lease_until <= now) throw new Error("expired");
      if (current.node_id !== scope.nodeId || current.node_generation !== scope.nodeGeneration) throw new Error("conflict");
      const previous = this.binding(input.runtimeId);
      if (!previous || previous.key_thumbprint !== scope.keyThumbprint
        || !sameNativeBinding(JSON.parse(previous.binding_json) as NativeRuntimeBinding, binding))
        throw new EventApiError("native_binding_unqualified", 409);
      this.#checkNativeWitnessProgress(previous, binding, witness);
      this.#assertNativeActiveCapacity(now, new Set([input.runtimeId]));
      this.#assertNativeClientAvailable(binding.clientId, now, new Set([input.runtimeId]));
      const changed = this.#sql.exec(`UPDATE runtimes SET lease_until=? WHERE runtime_id=? AND runtime_generation=?
        AND attachment_generation=? AND node_id=? AND node_generation=? AND qualified=1 AND lease_until>?`, leaseUntil,
        input.runtimeId, input.expectedRuntimeGeneration, input.expectedAttachmentGeneration,
        scope.nodeId, scope.nodeGeneration, now).rowsWritten;
      if (changed !== 1) throw new Error("conflict");
      this.#saveNativeRuntimeBinding(input.runtimeId, binding, scope.keyThumbprint, witness);
      return NativeRuntimeRenewResponseSchema.parse({ status: "renewed", runtimeId: input.runtimeId,
        runtimeGeneration: current.runtime_generation, nodeId: current.node_id, nodeGeneration: current.node_generation,
        attachmentGeneration: current.attachment_generation, leaseUntil: nowIso(leaseUntil), nativeBinding: binding });
    }
    if (operation === "transfer" && "sourceRuntimeId" in input) {
      const source = this.runtime(input.sourceRuntimeId), target = this.runtime(input.replacementRuntimeId);
      if (!source || source.runtime_generation !== input.expectedSourceRuntimeGeneration
        || source.attachment_generation !== input.expectedSourceAttachmentGeneration
        || !target || target.runtime_generation !== input.expectedReplacementRuntimeGeneration
        || target.attachment_generation !== input.expectedReplacementAttachmentGeneration) throw new Error("conflict");
      const sourceNative = this.binding(input.sourceRuntimeId);
      const targetNative = this.binding(input.replacementRuntimeId);
      if (!sourceNative || !targetNative || sourceNative.key_thumbprint !== scope.keyThumbprint
        || targetNative.key_thumbprint !== scope.keyThumbprint)
        throw new EventApiError("native_binding_unqualified", 409);
      if (target.qualified !== 1 || target.lease_until <= now) throw new Error("expired");
      if (target.node_id !== scope.nodeId || target.node_generation !== scope.nodeGeneration
        || !sameNativeBinding(JSON.parse(targetNative.binding_json) as NativeRuntimeBinding, binding)) throw new Error("conflict");
      this.#checkNativeWitnessProgress(targetNative, binding, witness);
      const sourceRuntimeGeneration = this.#nextNativeGeneration(source.runtime_generation);
      const sourceAttachmentGeneration = this.#nextNativeGeneration(source.attachment_generation);
      const attachmentGeneration = this.#nextNativeGeneration(target.attachment_generation);
      const excluded = new Set([input.sourceRuntimeId, input.replacementRuntimeId]);
      this.#assertNativeActiveCapacity(now, excluded);
      this.#assertNativeClientAvailable(binding.clientId, now, excluded);
      const sourceChanged = this.#sql.exec(`UPDATE runtimes SET runtime_generation=?,attachment_generation=?,lease_until=0,qualified=0
        WHERE runtime_id=? AND runtime_generation=? AND attachment_generation=?`,
        sourceRuntimeGeneration, sourceAttachmentGeneration, input.sourceRuntimeId, input.expectedSourceRuntimeGeneration,
        input.expectedSourceAttachmentGeneration).rowsWritten;
      const targetChanged = this.#sql.exec(`UPDATE runtimes SET attachment_generation=?,lease_until=?,qualified=1
        WHERE runtime_id=? AND runtime_generation=? AND attachment_generation=? AND node_id=? AND node_generation=? AND qualified=1 AND lease_until>?`,
        attachmentGeneration, leaseUntil, input.replacementRuntimeId, input.expectedReplacementRuntimeGeneration,
        input.expectedReplacementAttachmentGeneration, scope.nodeId, scope.nodeGeneration, now).rowsWritten;
      if (sourceChanged !== 1 || targetChanged !== 1) throw new Error("conflict");
      this.#saveNativeRuntimeBinding(input.replacementRuntimeId, binding, scope.keyThumbprint, witness);
      return NativeRuntimeTransferResponseSchema.parse({ status: "transferred", sourceRuntimeId: input.sourceRuntimeId,
        sourceRuntimeGeneration, sourceAttachmentGeneration, runtimeId: target.runtime_id,
        runtimeGeneration: target.runtime_generation, nodeId: scope.nodeId, nodeGeneration: scope.nodeGeneration,
        attachmentGeneration, leaseUntil: nowIso(leaseUntil), nativeBinding: binding });
    }
    throw new Error("invalid");
  }
  receiptIsCurrent(operation: "attach" | "renew" | "transfer", value: unknown, now: number, keyThumbprint: string): boolean {
    const result = operation === "attach" ? NativeRuntimeAttachResponseSchema.safeParse(value)
      : operation === "renew" ? NativeRuntimeRenewResponseSchema.safeParse(value)
      : NativeRuntimeTransferResponseSchema.safeParse(value);
    if (!result.success) return false;
    const target = this.runtime(result.data.runtimeId), native = this.binding(result.data.runtimeId);
    if (!target || !native || native.key_thumbprint !== keyThumbprint || target.qualified !== 1 || target.runtime_generation !== result.data.runtimeGeneration
      || target.node_id !== result.data.nodeId || target.node_generation !== result.data.nodeGeneration
      || target.attachment_generation !== result.data.attachmentGeneration || target.lease_until !== Date.parse(result.data.leaseUntil)
      || target.lease_until <= now || !sameNativeBinding(JSON.parse(native.binding_json) as NativeRuntimeBinding, result.data.nativeBinding)) return false;
    if (operation !== "transfer") return true;
    const transfer = result.data as z.infer<typeof NativeRuntimeTransferResponseSchema>;
    const source = this.runtime(transfer.sourceRuntimeId);
    const sourceNative = this.binding(transfer.sourceRuntimeId);
    return !!source && !!sourceNative && sourceNative.key_thumbprint === keyThumbprint
      && source.runtime_generation === transfer.sourceRuntimeGeneration
      && source.attachment_generation === transfer.sourceAttachmentGeneration && source.qualified === 0 && source.lease_until === 0;
  }
}
