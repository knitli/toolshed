import { requireNativeAdmissionCanary } from "./native-admission-gate.ts";
import { z } from "zod";
import { admitCoordinator } from "./coordinator-admission.ts";
import { authenticateAgent, credentialsFromRequest } from "./authority-client.ts";
import { ClaimRequestSchema, CompleteEnrollmentSchema, coordinatorName, DispatchClaimResultSchema, DispatchNoStartRequestSchema, DispatchNoStartResultSchema, EventApiError, NodeProofSchema, parseApiJson, readApiBody, RuntimeRequestSchema, runtimeConfigured, type EventApiEnvironment } from "./contracts.ts";
import { ownerRegistryName } from "./registry.ts";
import { EventProtocolError, parseEventObservationAck } from "./protocol.ts";
import { EventRequestDeadline } from "./request-deadline.ts";
import {
  NativeRuntimeAttachRequestSchema, NativeRuntimeAttachResponseSchema,
  NativeRuntimeChallengeRequestSchema, NativeRuntimeChallengeResponseSchema,
  NativeRuntimeRenewRequestSchema, NativeRuntimeRenewResponseSchema,
  NativeRuntimeTransferRequestSchema, NativeRuntimeTransferResponseSchema,
  NativeRuntimeStatusRequestSchema, NativeRuntimeStatusResponseSchema,
} from "./native-admission-contract.ts";

const routes = new Set(["/v1/nodes/complete", "/v1/runtimes/status", "/v1/runtimes/challenge", "/v1/runtimes/attach", "/v1/runtimes/renew", "/v1/runtimes/transfer", "/v1/dispatch/claim", "/v1/dispatch/settle-no-start", "/v1/ack"]);
const nativeRuntimeCommitPaths = new Set(["/v1/runtimes/attach", "/v1/runtimes/renew", "/v1/runtimes/transfer"]);
const response = (value: unknown, status = 200): Response => Response.json(value, { status, headers: { "cache-control": "no-store" } });

export async function eventFetch(request: Request, env: EventApiEnvironment): Promise<Response> {
  const url = new URL(request.url);
  const acknowledgmentOnly = request.method === "POST" && ["/v1/ack", "/v1/dispatch/settle-no-start"].includes(url.pathname);
  if (!runtimeConfigured(env, acknowledgmentOnly)) return response({ error: "runtime_disabled" }, 503);
  const deadline = new EventRequestDeadline();
  try {
    if (url.protocol !== "https:" || url.host !== env.EVENT_HOST || url.search || !routes.has(url.pathname))
      return response({ error: "not_found" }, 404);
    if (request.method !== "POST") return response({ error: "method_not_allowed" }, 405);
    const credentials = credentialsFromRequest(request);
    const identity = await authenticateAgent(env.MESSAGE_AUTHORITY, credentials, deadline);
    const raw = await readApiBody(request);
    const payload = parseApiJson(raw);
    const registry = env.OWNER_REGISTRY.getByName(ownerRegistryName(identity.principal));

    if (url.pathname === "/v1/nodes/complete") {
      const completion = CompleteEnrollmentSchema.parse(payload);
      const current = await authenticateAgent(env.MESSAGE_AUTHORITY, credentials, deadline);
      if (current.principal !== identity.principal || current.agent !== identity.agent || current.keyThumbprint !== identity.keyThumbprint)
        throw new EventApiError("denied", 403);
      const node = await deadline.run(() => registry.completeEnrollment(completion));
      // The owner-approved challenge and node signature admit the node. This caller's
      // proof additionally selects its owner partition; it cannot change the challenge.
      return response({ nodeId: node.nodeId, generation: node.generation });
    }

    if (url.pathname === "/v1/runtimes/status") {
      const input = NativeRuntimeStatusRequestSchema.parse(payload);
      requireNativeAdmissionCanary(env, identity);
      const proofHeader = request.headers.get("x-event-node-proof");
      if (!proofHeader || proofHeader.length > 2048) throw new EventApiError("node_proof_required", 403);
      const proof = NodeProofSchema.parse(parseApiJson(proofHeader));
      const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)));
      const bodySha256 = [...digest].map((byte) => byte.toString(16).padStart(2, "0")).join("");
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const result = NativeRuntimeStatusResponseSchema.safeParse(await deadline.run<unknown>(() => coordinator.runtimeStatus(raw, {
        principal: identity.principal, agent: identity.agent, keyThumbprint: identity.keyThumbprint,
        proof, proofBinding: { audience: `https://${env.EVENT_HOST}`, method: request.method, path: url.pathname, bodySha256 },
        credentials, bodySha256, nodeId: proof.nodeId, nodeGeneration: proof.nodeGeneration,
      })));
      if (!result.success || result.data.runtimeId !== input.runtimeId) throw new EventApiError("registry_unavailable", 503);
      return response(result.data);
    }

    if (url.pathname === "/v1/runtimes/challenge") {
      const input = NativeRuntimeChallengeRequestSchema.parse(payload);
      requireNativeAdmissionCanary(env, identity);
      const proofHeader = request.headers.get("x-event-node-proof");
      if (!proofHeader || proofHeader.length > 2048) throw new EventApiError("node_proof_required", 403);
      const proof = NodeProofSchema.parse(parseApiJson(proofHeader));
      const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)));
      const bodySha256 = [...digest].map((byte) => byte.toString(16).padStart(2, "0")).join("");
      const nodeAuth = await deadline.run(async () => await registry.authenticateNode(proof, {
        audience: `https://${env.EVENT_HOST}`, method: request.method, path: url.pathname, bodySha256,
      }));
      if (nodeAuth.status !== "authorized" || !nodeAuth.node.agents.includes(identity.agent))
        throw new EventApiError("node_denied", 403);
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const currentNode = await deadline.run(async () => await registry.currentNode({ nodeId: nodeAuth.node.nodeId,
        agent: identity.agent, generation: nodeAuth.node.generation }));
      if (currentNode.status !== "authorized" || currentNode.node.nodeId !== nodeAuth.node.nodeId
        || currentNode.node.generation !== nodeAuth.node.generation || !currentNode.node.agents.includes(identity.agent))
        throw new EventApiError("node_denied", 403);
      const current = await authenticateAgent(env.MESSAGE_AUTHORITY, credentials, deadline);
      if (current.principal !== identity.principal || current.agent !== identity.agent || current.keyThumbprint !== identity.keyThumbprint)
        throw new EventApiError("denied", 403);
      requireNativeAdmissionCanary(env, current);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const result = NativeRuntimeChallengeResponseSchema.safeParse(await deadline.run(() => coordinator.createNativeRuntimeChallenge(input, {
        principal: identity.principal, agent: identity.agent, keyThumbprint: identity.keyThumbprint,
        nodeId: currentNode.node.nodeId, nodeGeneration: currentNode.node.generation,
      })));
      if (!result.success) throw new EventApiError("registry_unavailable", 503);
      return response(result.data);
    }

    if (nativeRuntimeCommitPaths.has(url.pathname)) {
      const operation = url.pathname === "/v1/runtimes/attach" ? "attach"
        : url.pathname === "/v1/runtimes/renew" ? "renew" : "transfer";
      const input = operation === "attach" ? NativeRuntimeAttachRequestSchema.parse(payload)
        : operation === "renew" ? NativeRuntimeRenewRequestSchema.parse(payload)
          : NativeRuntimeTransferRequestSchema.parse(payload);
      requireNativeAdmissionCanary(env, identity);
      const proofHeader = request.headers.get("x-event-node-proof");
      if (!proofHeader || proofHeader.length > 2048) throw new EventApiError("node_proof_required", 403);
      const proof = NodeProofSchema.parse(parseApiJson(proofHeader));
      const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)));
      const bodySha256 = [...digest].map((byte) => byte.toString(16).padStart(2, "0")).join("");
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const value = await deadline.run(() => coordinator.commitNativeRuntime(operation, raw, {
        principal: identity.principal, agent: identity.agent, keyThumbprint: identity.keyThumbprint,
        proof, proofBinding: { audience: `https://${env.EVENT_HOST}`, method: request.method, path: url.pathname, bodySha256 },
        credentials, bodySha256, nodeId: proof.nodeId, nodeGeneration: proof.nodeGeneration,
      }));
      const nativeBinding = input.nativeEvidence.witness && {
        clientId: input.nativeEvidence.witness.clientId, connectionId: input.nativeEvidence.witness.connectionId,
        backendPid: input.nativeEvidence.witness.backendPid, threadId: input.nativeEvidence.witness.threadId,
        generation: input.nativeEvidence.witness.generation, serverInstanceId: input.nativeEvidence.witness.serverInstanceId,
        serverGeneration: input.nativeEvidence.witness.serverGeneration,
      };
      const result = operation === "attach" ? NativeRuntimeAttachResponseSchema.safeParse(value)
        : operation === "renew" ? NativeRuntimeRenewResponseSchema.safeParse(value)
          : NativeRuntimeTransferResponseSchema.safeParse(value);
      const expectedRuntimeId = operation === "transfer" && "replacementRuntimeId" in input
        ? input.replacementRuntimeId : "runtimeId" in input ? input.runtimeId : "";
      if (!result.success || result.data.runtimeId !== expectedRuntimeId || result.data.nodeId !== proof.nodeId
        || result.data.nodeGeneration !== proof.nodeGeneration || JSON.stringify(result.data.nativeBinding) !== JSON.stringify(nativeBinding))
        throw new EventApiError("registry_unavailable", 503);
      if (operation === "transfer" && "sourceRuntimeId" in input
        && (result.data.status !== "transferred" || result.data.sourceRuntimeId !== input.sourceRuntimeId))
        throw new EventApiError("registry_unavailable", 503);
      return response(result.data);
    }

    const proofHeader = request.headers.get("x-event-node-proof");
    if (!proofHeader || proofHeader.length > 2048) throw new EventApiError("node_proof_required", 403);
    const proof = NodeProofSchema.parse(parseApiJson(proofHeader));
    const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)));
    const nodeAuth = await deadline.run(async () => await registry.authenticateNode(proof, {
      audience: `https://${env.EVENT_HOST}`, method: request.method, path: url.pathname,
      bodySha256: [...digest].map((byte) => byte.toString(16).padStart(2, "0")).join(""),
    }));
    if (nodeAuth.status !== "authorized" || !nodeAuth.node.agents.includes(identity.agent))
      throw new EventApiError("node_denied", 403);

    if (url.pathname === "/v1/runtimes/attach" || url.pathname === "/v1/runtimes/renew") {
      RuntimeRequestSchema.parse(payload);
      // A node signature is not evidence of the actual live native client. No public
      // route can mint qualification while that binding protocol remains unproved.
      return response({ error: "native_binding_unqualified" }, 409);
    }
    if (url.pathname === "/v1/dispatch/claim") {
      const input = ClaimRequestSchema.parse(payload);
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const result = DispatchClaimResultSchema.safeParse(await deadline.run(async () => await coordinator.claim(
        { ...input, nodeId: nodeAuth.node.nodeId, nodeGeneration: nodeAuth.node.generation }, credentials,
      )));
      if (!result.success) throw new EventApiError("invalid_dispatch_response", 503);
      if (result.data.status === "admitted") {
        const envelope = result.data.envelope;
        if (result.data.nodeId !== nodeAuth.node.nodeId || envelope.principal !== identity.principal || envelope.agent !== identity.agent ||
          envelope.deliveryId !== input.deliveryId || envelope.attemptId !== input.attemptId ||
          envelope.nodeGeneration !== nodeAuth.node.generation) throw new EventApiError("invalid_dispatch_response", 503);
      }
      return response(result.data);
    }

    if (url.pathname === "/v1/dispatch/settle-no-start") {
      const input = DispatchNoStartRequestSchema.parse(payload);
      if (input.nodeGeneration !== nodeAuth.node.generation) throw new EventApiError("denied", 403);
      const current = await authenticateAgent(env.MESSAGE_AUTHORITY, credentials, deadline);
      if (current.principal !== identity.principal || current.agent !== identity.agent || current.keyThumbprint !== identity.keyThumbprint)
        throw new EventApiError("denied", 403);
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const result = DispatchNoStartResultSchema.safeParse(await deadline.run(() => coordinator.settleNoStart(input,
        { nodeId: nodeAuth.node.nodeId, generation: nodeAuth.node.generation })));
      if (!result.success || result.data.nodeId !== nodeAuth.node.nodeId || result.data.deliveryId !== input.deliveryId ||
        result.data.attemptId !== input.attemptId || result.data.permitId !== input.permitId || result.data.nodeGeneration !== input.nodeGeneration ||
        result.data.evidence.type !== input.evidence.type || (input.evidence.type === "native_terminal_no_start" &&
          (result.data.evidence.type !== "native_terminal_no_start" || result.data.evidence.receiptId !== input.evidence.receiptId)))
        throw new EventApiError("invalid_dispatch_response", 503);
      return response(result.data);
    }

    const acknowledgment = parseEventObservationAck(raw);
    if (acknowledgment.principal !== identity.principal || acknowledgment.agent !== identity.agent || acknowledgment.nodeGeneration !== nodeAuth.node.generation)
      throw new EventApiError("acknowledgment_denied", 403);
    // Authentication preceded node verification; refresh it immediately before handing
    // the ACK to its coordinator. The coordinator rechecks the current node fence.
    const current = await authenticateAgent(env.MESSAGE_AUTHORITY, credentials, deadline);
    if (current.principal !== identity.principal || current.agent !== identity.agent || current.keyThumbprint !== identity.keyThumbprint)
      throw new EventApiError("denied", 403);
    await admitCoordinator(env, identity.principal, identity.agent, deadline);
    const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
    return response(await deadline.run(() => coordinator.acknowledge(acknowledgment,
      { nodeId: nodeAuth.node.nodeId, generation: nodeAuth.node.generation })));
  } catch (error) {
    if (error instanceof EventApiError) return response({ error: error.code }, error.status);
    if (error instanceof z.ZodError || error instanceof EventProtocolError) return response({ error: "invalid_request" }, 400);
    // Durable Object RPC preserves Error.message, not the custom error class or fields.
    if (error instanceof Error && /^(invalid|conflict|denied|node_denied|expired|capacity|not_found|native_binding_unqualified)$/.test(error.message))
      return response({ error: error.message }, ["denied", "node_denied"].includes(error.message) ? 403 : 409);
    if (error instanceof Error && /^(authority_unavailable|registry_unavailable|runtime_disabled)$/.test(error.message))
      return response({ error: error.message }, 503);
    return response({ error: "unavailable" }, 503);
  } finally { deadline.dispose(); }
}
