import { EventApiError, parseApiJson } from "./contracts.ts";
import { NativeAdmissionCanarySchema } from "./native-admission-canary.ts";

export function requireNativeAdmissionCanary(env: {
  EVENT_ENABLED?: string; EVENT_NATIVE_BINDING_ENABLED?: string; EVENT_NATIVE_BINDING_CANARY?: string;
}, identity: { principal: string; agent: string }): void {
  if (env.EVENT_ENABLED === "true" && env.EVENT_NATIVE_BINDING_ENABLED === "true") {
    try {
      const scope = NativeAdmissionCanarySchema.parse(parseApiJson(env.EVENT_NATIVE_BINDING_CANARY ?? ""));
      if (scope.principal === identity.principal && scope.agent === identity.agent) return;
    } catch { /* Invalid deployment scope never grants native admission. */ }
  }
  throw new EventApiError("native_binding_unqualified", 409);
}
