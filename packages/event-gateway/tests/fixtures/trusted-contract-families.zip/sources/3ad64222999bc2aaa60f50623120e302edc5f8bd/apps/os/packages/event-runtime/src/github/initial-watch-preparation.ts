import { z } from 'zod';
import { EVENT_POLICY_V1 } from '../policy';
import { CONVERSION_MANIFEST_LIMITS, GitHubConversionManifestStore, ConversionManifestFenceSchema } from './conversion-manifest-store';
import { InitialReconciliationObligationSchema } from './reconciliation-internal';
import { CreateWatchRequestSchema, SourceOnlyControlTokenSchema, WatchPromotionRequestSchema,
  WatchActivateTokenSchema, WATCH_CONTROL_LIMITS } from './watch-control-internal';

const counter = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER);
const equal = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);
const bytes = (s: string) => new TextEncoder().encode(s).length;
export const INITIAL_WATCH_PREPARATION_LIMITS = Object.freeze({ rows: 64, bytes: 512 * 1024, recordBytes: 8192 });
export const InitialWatchPreparationSchema = z.strictObject({ request: CreateWatchRequestSchema,
  predecessor: SourceOnlyControlTokenSchema, promotion: WatchPromotionRequestSchema,
  fence: ConversionManifestFenceSchema, leaseUntil: counter.positive(), preparationGeneration: counter,
  manifestBytes: z.number().int().positive().max(CONVERSION_MANIFEST_LIMITS.bytes),
}).refine(v => {
  const r = v.request, p = v.predecessor, t = v.promotion.token;
  return v.promotion.initialReconciliation === true && equal(t, v.fence.token) && equal(r.holder, v.fence.holder)
    && v.fence.leaseRevision === 1 && r.operationId === t.operationId && equal(r.subject, t.subject)
    && equal(p.subject, t.subject) && p.principal === t.principal && p.agent === t.agent
    && p.sourceIncarnation === r.expectedSourceIncarnation && p.sourceIncarnation === t.sourceIncarnation
    && p.operationId !== t.operationId && p.obligationId !== t.obligationId && p.lifecycleEpoch <= Number.MAX_SAFE_INTEGER - 2
    && p.lifecycleEpoch === r.expectedLifecycleEpoch && t.lifecycleEpoch === p.lifecycleEpoch + 1
    && t.watchIncarnation === 1 && t.routingRevision === 1 && t.sourceEnableGeneration === p.sourceEnableGeneration
    && equal(v.promotion.predecessor, { operationId: p.operationId, obligationId: p.obligationId, lifecycleEpoch: p.lifecycleEpoch })
    && (['installationId', 'grantRevision', 'mappingRevision', 'policyRevision'] as const).every(k => t[k] === p[k] && t[k] === r.source[k])
    && bytes(JSON.stringify(v)) <= INITIAL_WATCH_PREPARATION_LIMITS.recordBytes;
});
export type InitialWatchPreparation = z.infer<typeof InitialWatchPreparationSchema>;
const identity = { operationId: z.string().uuid(), token: WatchActivateTokenSchema, preparationGeneration: counter,
  manifestBytes: z.number().int().positive().max(CONVERSION_MANIFEST_LIMITS.bytes) };
export const InitialWatchPreparationReceiptSchema = z.discriminatedUnion('status', [
  z.strictObject({ ...identity, status: z.literal('prepared'), obligation: InitialReconciliationObligationSchema, sourceRpcGeneration: counter }),
  z.strictObject({ ...identity, status: z.literal('refused'), nextPreparationGeneration: counter,
    reason: z.enum(['history_unavailable', 'checkpoint_conflict']), effect: z.literal('none') }),
  z.strictObject({ ...identity, status: z.literal('aborted'), nextPreparationGeneration: counter,
    effect: z.enum(['none', 'pinned']), obligation: InitialReconciliationObligationSchema.optional() }),
]).refine(v => v.operationId === v.token.operationId && (v.status === 'prepared'
  ? equal(v.obligation.token, v.token) : v.nextPreparationGeneration > v.preparationGeneration)
  && (v.status !== 'aborted' || (v.effect === 'pinned' ? !!v.obligation && equal(v.obligation.token, v.token) : v.obligation === undefined)));
export type InitialWatchPreparationReceipt = z.infer<typeof InitialWatchPreparationReceiptSchema>;
export type InitialWatchPreparationPhase = 'preparing' | 'aborting' | 'refused_ack' | 'refused' | 'quarantined';
export interface InitialWatchPreparationRow { input: InitialWatchPreparation; phase: InitialWatchPreparationPhase;
  receipt: InitialWatchPreparationReceipt | null; dueAt: number; acknowledgedAt: number | null }
function receiptMatches(input: InitialWatchPreparation, receipt: InitialWatchPreparationReceipt): boolean {
  const obligation = receipt.status === 'prepared' || receipt.status === 'aborted' && receipt.effect === 'pinned' ? receipt.obligation : undefined;
  return receipt.operationId === input.request.operationId && equal(receipt.token, input.promotion.token)
    && receipt.preparationGeneration === input.preparationGeneration && receipt.manifestBytes === input.manifestBytes
    && (!obligation || obligation.toVersion >= input.promotion.expectedSourceVersion && obligation.hostEpoch > input.promotion.expectedHostEpoch);
}
type Stored = { input: string; phase: InitialWatchPreparationPhase; receipt: string | null; due_at: number; acknowledged_at: number | null };

/** No timeout releases custody. Only exact no-effect proof plus host acknowledgment does. */
export class InitialWatchPreparationStore {
  constructor(private readonly storage: DurableObjectStorage) {
    storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_initial_watch_preparations(operation_id TEXT PRIMARY KEY,
      canonical_subject TEXT NOT NULL,input TEXT NOT NULL,phase TEXT NOT NULL,
      receipt TEXT,due_at INTEGER NOT NULL,acknowledged_at INTEGER)`);
  }
  charged(): number { return this.storage.sql.exec<{ n: number }>("SELECT count(*) AS n FROM github_initial_watch_preparations WHERE phase!='refused'").one().n; }
  get(id: string): InitialWatchPreparationRow | null {
    const r = this.storage.sql.exec<Stored>('SELECT * FROM github_initial_watch_preparations WHERE operation_id=?', id).toArray()[0];
    if (!r) return null;
    const raw: unknown = JSON.parse(r.input);
    if (raw && typeof raw === 'object' && !('manifestBytes' in raw)) {
      // Legacy custody remains charged; it cannot acquire or release capacity without a proof.
      if (r.phase !== 'refused') this.storage.sql.exec("UPDATE github_initial_watch_preparations SET phase='quarantined' WHERE operation_id=?", id);
      return null;
    }
    const input = InitialWatchPreparationSchema.parse(raw);
    const rawReceipt: unknown = r.receipt ? JSON.parse(r.receipt) : null;
    if (rawReceipt && typeof rawReceipt === 'object' && !('manifestBytes' in rawReceipt)) {
      if (r.phase !== 'refused') this.storage.sql.exec("UPDATE github_initial_watch_preparations SET phase='quarantined' WHERE operation_id=?", id);
      return null;
    }
    const receipt = rawReceipt ? InitialWatchPreparationReceiptSchema.parse(rawReceipt) : null;
    if (input.request.operationId !== id || !['preparing', 'aborting', 'refused_ack', 'refused', 'quarantined'].includes(r.phase)
      || !Number.isSafeInteger(r.due_at) || r.due_at < 0
      || r.acknowledged_at !== null && (!Number.isSafeInteger(r.acknowledged_at) || r.acknowledged_at < 0)
      || bytes(r.input) + bytes(r.receipt ?? '') > 8192
      || receipt && !receiptMatches(input, receipt)
      || ['refused_ack', 'refused'].includes(r.phase) && (!receipt || receipt.status === 'prepared' || receipt.effect !== 'none')
      || r.phase === 'refused' && r.acknowledged_at === null) throw new Error('github_source_conflict');
    return { input, phase: r.phase, receipt, dueAt: r.due_at, acknowledgedAt: r.acknowledged_at };
  }
  reserve(raw: InitialWatchPreparation, now: number): InitialWatchPreparationRow {
    const input = InitialWatchPreparationSchema.parse(raw), id = input.request.operationId, serialized = JSON.stringify(input);
    // Reserve the largest future proof now; a host pin must never outgrow coordinator custody.
    const maximum = Number.MAX_SAFE_INTEGER, token = input.promotion.token;
    const obligation = { token, cause: 'initial', operationId: id, fromVersion: 1, toVersion: maximum,
      observationEpoch: maximum, hostEpoch: maximum };
    const future = [
      { operationId: id, token, preparationGeneration: input.preparationGeneration, manifestBytes: input.manifestBytes, status: 'prepared', obligation, sourceRpcGeneration: maximum },
      { operationId: id, token, preparationGeneration: input.preparationGeneration, manifestBytes: input.manifestBytes, status: 'aborted', nextPreparationGeneration: maximum, effect: 'pinned', obligation },
    ];
    if (future.some(receipt => bytes(serialized) + bytes(JSON.stringify(receipt)) > INITIAL_WATCH_PREPARATION_LIMITS.recordBytes)) throw new Error('capacity');
    return this.storage.transactionSync(() => {
      this.prune(now);
      const old = this.get(id);
      if (old) { if (!equal(old.input, input)) throw new Error('github_operation_conflict'); return old; }
      if (this.storage.sql.exec('SELECT 1 FROM github_initial_watch_preparations WHERE operation_id=?', id).toArray().length) throw new Error('github_source_conflict');
      const reservation = new GitHubConversionManifestStore(this.storage).reservation(id, input.fence);
      if (!reservation || reservation.preparationGeneration !== input.preparationGeneration || reservation.manifestBytes !== input.manifestBytes) throw new Error('github_source_conflict');
      if (input.leaseUntil <= now || input.leaseUntil > now + input.request.leaseMs) throw new Error('github_source_conflict');
      const subject = JSON.stringify(input.request.subject);
      if (this.storage.sql.exec("SELECT 1 FROM github_initial_watch_preparations WHERE canonical_subject=? AND phase!='refused' AND NOT (phase='quarantined' AND acknowledged_at IS NOT NULL)", subject).toArray().length) throw new Error('github_source_conflict');
      const usage = this.storage.sql.exec<{ n: number; bytes: number }>('SELECT count(*) AS n,coalesce(sum(length(CAST(input AS BLOB))+coalesce(length(CAST(receipt AS BLOB)),0)),0) AS bytes FROM github_initial_watch_preparations').one();
      let charged = this.charged();
      for (const table of ['deliveries', 'github_initial_reconciliations', 'github_initial_activation_intents']) {
        if (this.storage.sql.exec('SELECT 1 FROM sqlite_master WHERE name=?', table).toArray().length)
          charged += this.storage.sql.exec<{ n: number }>(`SELECT count(*) AS n FROM ${table}${table === 'deliveries' ? " WHERE state IN ('pending','submitted','ambiguous')" : ''}`).one().n;
      }
      if (charged >= EVENT_POLICY_V1.maxPendingDeliveriesPerAgent || usage.n >= INITIAL_WATCH_PREPARATION_LIMITS.rows
        || (usage.n + 1) * INITIAL_WATCH_PREPARATION_LIMITS.recordBytes > INITIAL_WATCH_PREPARATION_LIMITS.bytes) throw new Error('capacity');
      if (this.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE name='schema_migrations'").toArray().length)
        this.storage.sql.exec('INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(11,?)', now);
      this.storage.sql.exec("INSERT INTO github_initial_watch_preparations VALUES(?,?,?,'preparing',NULL,?,NULL)", id, subject, serialized, now);
      return this.get(id)!;
    });
  }
  pending(now: number): InitialWatchPreparationRow[] {
    return this.storage.sql.exec<{ operation_id: string }>("SELECT operation_id FROM github_initial_watch_preparations WHERE (phase IN ('preparing','aborting','refused_ack') OR (phase='quarantined' AND acknowledged_at IS NULL)) AND due_at<=? ORDER BY due_at,operation_id", now).toArray().map(r => this.get(r.operation_id)).filter((row): row is InitialWatchPreparationRow => row !== null);
  }
  private receipt(id: string, raw: InitialWatchPreparationReceipt): { row: InitialWatchPreparationRow; receipt: InitialWatchPreparationReceipt } {
    const receipt = InitialWatchPreparationReceiptSchema.parse(raw), row = this.get(id);
    if (!row || !receiptMatches(row.input, receipt) || bytes(JSON.stringify(receipt)) + bytes(JSON.stringify(row.input)) > 8192) throw new Error('github_source_conflict');
    return { row, receipt };
  }
  recordPrepared(id: string, raw: InitialWatchPreparationReceipt, now: number): void {
    const { row, receipt } = this.receipt(id, raw);
    if (receipt.status !== 'prepared' || row.phase !== 'preparing' || row.receipt && !equal(row.receipt, receipt)) throw new Error('github_source_conflict');
    this.storage.sql.exec('UPDATE github_initial_watch_preparations SET receipt=?,due_at=? WHERE operation_id=?', JSON.stringify(receipt), now, id);
  }
  recordRefused(id: string, raw: InitialWatchPreparationReceipt, now: number): void {
    const { row, receipt } = this.receipt(id, raw);
    if (receipt.status === 'prepared' || receipt.effect !== 'none'
      || row.receipt?.status === 'prepared' || row.phase === 'refused'
      || row.receipt && !equal(row.receipt, receipt)) throw new Error('github_source_conflict');
    this.storage.sql.exec("UPDATE github_initial_watch_preparations SET receipt=?,phase='refused_ack',due_at=? WHERE operation_id=?", JSON.stringify(receipt), now, id);
  }
  acknowledgeRefusal(id: string, raw: InitialWatchPreparationReceipt, now: number): void {
    const { row, receipt } = this.receipt(id, raw);
    if (!['refused_ack', 'refused'].includes(row.phase) || receipt.status === 'prepared' || receipt.effect !== 'none' || !equal(row.receipt, receipt)) throw new Error('github_source_conflict');
    if (row.phase === 'refused') return;
    this.prune(now);
    const usage = this.storage.sql.exec<{ n: number; bytes: number }>("SELECT count(*) AS n,coalesce(sum(length(CAST(input AS BLOB))+length(CAST(receipt AS BLOB))),0) AS bytes FROM github_initial_watch_preparations WHERE phase='refused'").one();
    if (usage.n >= WATCH_CONTROL_LIMITS.retainedOperations || usage.bytes + bytes(JSON.stringify(row.input)) + bytes(JSON.stringify(receipt)) > WATCH_CONTROL_LIMITS.retainedBytes) throw new Error('capacity');
    new GitHubConversionManifestStore(this.storage).releaseReservation({ operationId: id, fence: row.input.fence,
      preparationGeneration: row.input.preparationGeneration, manifestBytes: row.input.manifestBytes });
    this.storage.sql.exec("UPDATE github_initial_watch_preparations SET phase='refused',acknowledged_at=? WHERE operation_id=?", now, id);
  }
  beginAbort(id: string, now: number): void {
    this.storage.sql.exec("UPDATE github_initial_watch_preparations SET phase='aborting',due_at=? WHERE operation_id=? AND phase='preparing'", now, id);
  }
  quarantine(id: string, now: number): void {
    this.storage.sql.exec("UPDATE github_initial_watch_preparations SET phase='quarantined',due_at=? WHERE operation_id=? AND phase!='refused'", now, id);
  }
  recordAborted(id: string, raw: InitialWatchPreparationReceipt, now: number): void {
    const { row, receipt } = this.receipt(id, raw);
    if (receipt.status !== 'aborted' || !['aborting', 'quarantined'].includes(row.phase)
      || row.receipt?.status === 'aborted' && !equal(row.receipt, receipt)) throw new Error('github_source_conflict');
    if (receipt.effect === 'none') { this.recordRefused(id, receipt, now); return; }
    if (row.receipt?.status === 'prepared' && !equal(row.receipt.obligation, receipt.obligation)) throw new Error('github_source_conflict');
    this.storage.sql.exec("UPDATE github_initial_watch_preparations SET phase='quarantined',receipt=?,acknowledged_at=?,due_at=? WHERE operation_id=?", JSON.stringify(receipt), now, now, id);
  }
  transfer(id: string, commit: (input: InitialWatchPreparation) => void): void {
    this.storage.transactionSync(() => {
      const row = this.get(id);
      if (!row || row.phase !== 'preparing' || row.receipt?.status !== 'prepared') throw new Error('github_source_conflict');
      this.storage.sql.exec('DELETE FROM github_initial_watch_preparations WHERE operation_id=?', id);
      const result: unknown = commit(row.input);
      if (result !== null && (typeof result === 'object' || typeof result === 'function')
        && typeof (result as { then?: unknown }).then === 'function') throw new Error('github_source_conflict');
      const intent = this.storage.sql.exec<{ promotion: string; fence: string; state: string }>('SELECT promotion,fence,state FROM github_initial_activation_intents WHERE operation_id=?', id).toArray()[0];
      if (!intent || intent.state !== 'reserved' || !equal(JSON.parse(intent.promotion), row.input.promotion)
        || !equal(JSON.parse(intent.fence), row.input.fence)) throw new Error('github_source_conflict');
    });
  }
  retry(id: string, dueAt: number): void { this.storage.sql.exec("UPDATE github_initial_watch_preparations SET due_at=? WHERE operation_id=? AND (phase IN ('preparing','aborting','refused_ack') OR (phase='quarantined' AND acknowledged_at IS NULL))", dueAt, id); }
  nextAt(): number | null {
    if (!this.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE name='github_conversion_manifest_reservations'").toArray().length) return null;
    return this.storage.sql.exec<{ at: number | null }>("SELECT min(due_at) AS at FROM github_initial_watch_preparations WHERE (phase IN ('preparing','aborting','refused_ack') OR (phase='quarantined' AND acknowledged_at IS NULL)) AND operation_id IN (SELECT operation_id FROM github_conversion_manifest_reservations)").one().at; }
  prune(now: number): void { this.storage.sql.exec("DELETE FROM github_initial_watch_preparations WHERE phase='refused' AND acknowledged_at<=?", now - WATCH_CONTROL_LIMITS.terminalRetentionMs); }
}
