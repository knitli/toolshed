import { z } from "zod";
import { THUMBPRINT } from "gatekeeper-messaging/src/agent-token.ts";
import { canonicalEmail } from "openapi-operator/src/access.ts";
import type { EventAuthorityCredentialsV1, EventAuthorityIdentityV1, EventAuthorityServiceV1 } from "gatekeeper-messaging/src/event-authority-contract";
import { agent, EventApiError } from "./contracts.ts";
import { EventRequestDeadline } from "./request-deadline.ts";

const ownerIdentitySchema = z.strictObject({
  principal: z.string().refine(value => canonicalEmail(value) && value === value.toLowerCase()), agent,
});
const authResultSchema = z.union([
  z.strictObject({ status: z.literal("authorized"), identity: ownerIdentitySchema.extend({
    keyThumbprint: z.string().regex(THUMBPRINT),
  }) }),
  z.strictObject({ status: z.enum(["denied", "unavailable", "invalid"]) }),
]);
const ownerResultSchema = z.union([
  z.strictObject({ status: z.literal("authorized"), identity: ownerIdentitySchema }),
  z.strictObject({ status: z.enum(["not_registered", "denied", "unavailable", "invalid"]) }),
]);

/** A private service binding is still a protocol boundary, not an unchecked identity cast. */
export function parseAuthorityAuthResult(value: unknown) {
  const parsed = authResultSchema.safeParse(value);
  if (!parsed.success) throw new EventApiError("authority_unavailable", 503);
  return parsed.data;
}
export function parseOwnerAgentResult(value: unknown) {
  const parsed = ownerResultSchema.safeParse(value);
  if (!parsed.success) throw new EventApiError("authority_unavailable", 503);
  return parsed.data;
}

export function credentialsFromRequest(request: Request): EventAuthorityCredentialsV1 {
  const accessAssertion = request.headers.get("cf-access-jwt-assertion") ?? "";
  const authorization = request.headers.get("authorization") ?? "";
  if (!accessAssertion || accessAssertion.length > 16384 || !/^Bearer [^\s]+$/.test(authorization))
    throw new EventApiError("denied", 403);
  const agentToken = authorization.slice(7);
  if (agentToken.length > 4096) throw new EventApiError("denied", 403);
  return { accessAssertion, agentToken };
}

/** Transient original proofs only; no caller-selected identity and no stored credentials. */
export async function authenticateAgent(
  authority: EventAuthorityServiceV1,
  credentials: EventAuthorityCredentialsV1,
  deadline?: EventRequestDeadline,
): Promise<EventAuthorityIdentityV1> {
  const ownedDeadline = deadline ? undefined : new EventRequestDeadline(5000);
  deadline ??= ownedDeadline!;
  let result;
  try { result = parseAuthorityAuthResult(await deadline.run(() => authority.currentAuth(credentials), 5000)); }
  catch { throw new EventApiError("authority_unavailable", 503); }
  finally { ownedDeadline?.dispose(); }
  if (result.status !== "authorized")
    throw new EventApiError(result.status, result.status === "unavailable" ? 503 : 403);
  return result.identity;
}
