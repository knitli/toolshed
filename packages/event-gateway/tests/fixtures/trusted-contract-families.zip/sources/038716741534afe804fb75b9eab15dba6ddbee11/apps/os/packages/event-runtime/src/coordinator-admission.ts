import { z } from "zod";
import { EventApiError } from "./contracts.ts";
import { ownerRegistryName } from "./registry.ts";
import { EventRequestDeadline } from "./request-deadline.ts";

export interface CoordinatorAdmissionEnvironment {
  OWNER_REGISTRY: {
    getByName(name: string): { admitCoordinator(input: { agent: string }): Promise<{ status: "admitted" | "capacity" | "invalid" }> };
  };
}
const resultSchema = z.strictObject({ status: z.enum(["admitted", "capacity", "invalid"]) });

/** Every coordinator creation path first consumes an idempotent owner-scoped slot. */
export async function admitCoordinator(
  env: CoordinatorAdmissionEnvironment,
  principal: string,
  agent: string,
  deadline?: EventRequestDeadline,
): Promise<void> {
  const ownedDeadline = deadline ? undefined : new EventRequestDeadline(5000);
  deadline ??= ownedDeadline!;
  try {
    const result = resultSchema.safeParse(await deadline.run(
      () => env.OWNER_REGISTRY.getByName(ownerRegistryName(principal)).admitCoordinator({ agent }), 5000,
    ));
    if (!result.success) throw new EventApiError("registry_unavailable", 503);
    if (result.data.status === "capacity") throw new EventApiError("coordinator_capacity", 409);
    if (result.data.status !== "admitted") throw new EventApiError("invalid", 400);
  } catch (error) {
    if (error instanceof EventApiError) throw error;
    throw new EventApiError("registry_unavailable", 503);
  } finally { ownedDeadline?.dispose(); }
}
