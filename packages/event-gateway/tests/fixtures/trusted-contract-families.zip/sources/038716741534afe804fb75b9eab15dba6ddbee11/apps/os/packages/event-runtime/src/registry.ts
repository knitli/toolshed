import { DurableObject } from 'cloudflare:workers';
import { EVENT_POLICY_V1 } from './policy';
import { coordinatorName, uuid, agent as agentName, generation as nodeGeneration } from './contracts';
import { z } from 'zod';
import type { AgentCoordinator } from './coordinator';

export interface CreateChallengeInput {
  nodeId: string;
  publicKey: JsonWebKey;
  meshIp: string;
  meshPort: number;
  agents: string[];
}
export interface NodeView extends CreateChallengeInput {
  generation: number;
  revoked: boolean;
}
export interface NodeProof {
  nodeId: string;
  nodeGeneration: number;
  issuedAt: string;
  nonce: string;
  signature: string;
}
export interface ChallengeView {
  challengeId: string;
  nodeId: string;
  expiresAt: string;
  signingPayload: string;
}
export interface ProofBinding {
  audience: string;
  method: string;
  path: string;
  bodySha256: string;
}
export type NodeAuthorization = { status: 'authorized'; node: NodeView } | { status: 'denied' | 'invalid' };
export interface SlotInput { nodeId: string; agent: string; generation: number; deliveryId: string }
export type SlotResult = { status: 'reserved' | 'capacity' | 'denied' };

export const ownerRegistryName = (principal: string): string => JSON.stringify(['event-owner-v1', principal]);
export function canonicalNodeProof(principal: string, proof: NodeProof, binding: ProofBinding): string {
  return JSON.stringify(['event-node-proof-v1', principal, binding.audience, binding.method,
    binding.path, binding.bodySha256, proof.nodeId, proof.nodeGeneration, proof.issuedAt, proof.nonce]);
}
// These are the only routes that call authenticateNode; enrollment completion uses its challenge signature.
const NODE_PROOF_PATHS = new Set(['/v1/runtimes/challenge', '/v1/runtimes/attach', '/v1/runtimes/renew', '/v1/runtimes/transfer', '/v1/dispatch/claim', '/v1/dispatch/settle-no-start', '/v1/ack']);
function validProofBinding(binding: ProofBinding, hostname: string): boolean {
  if (!hostname || hostname.length > 253 || binding.audience.length > 261
    || binding.method !== 'POST' || binding.path.length > 32 || !NODE_PROOF_PATHS.has(binding.path)
    || binding.audience !== `https://${hostname}` || binding.bodySha256.length !== 64
    || ![...binding.bodySha256].every(character => '0123456789abcdef'.includes(character))) return false;
  try {
    const audience = new URL(binding.audience);
    return audience.protocol === 'https:' && audience.hostname === hostname
      && audience.host === hostname && audience.origin === binding.audience;
  } catch { return false; }
}
const ID = /^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/;
const CHALLENGE_MS = 5 * 60_000;
/** Owner-level implementation ceilings; separate from the frozen per-agent wire policy.
 * Revoked node tombstones count toward this limit to retain their generation fence. */
export const OWNER_REGISTRY_LIMITS = Object.freeze({ nodes: 32, pendingChallenges: 32, coordinators: 128, proofNoncesPerNode: 1024, proofNonces: 8192 });
const CoordinatorAdmissionSchema = z.strictObject({ agent: agentName });
const RevocationConfirmationSchema = z.strictObject({ nodeId: uuid, agent: agentName, revokedGeneration: nodeGeneration.min(2) });
type RevocationJob = { node_id: string; agent: string; revoked_generation: number; next_at: number; attempts: number };
type RegistryEnvironment = { EVENT_HOST: string; AGENT_COORDINATOR?: DurableObjectNamespace<AgentCoordinator> };
function revocationDeadline(work: Promise<void>): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('revocation_unavailable')), EVENT_POLICY_V1.nativeRpcDeadlineMs);
    work.then(() => { clearTimeout(timer); resolve(); }, error => { clearTimeout(timer); reject(error); });
  });
}
function decodeSignature(value: string): Uint8Array<ArrayBuffer> {
  if (!/^[A-Za-z0-9_-]{86}$/.test(value)) throw new Error('invalid');
  return Uint8Array.from(atob(value.replace(/-/g, '+').replace(/_/g, '/') + '=='), c => c.charCodeAt(0));
}
function validMeshIp(value: string): boolean {
  const parts = value.split('.');
  return parts.length === 4 && parts.every(p => /^(0|[1-9][0-9]{0,2})$/.test(p) && Number(p) <= 255)
    && Number(parts[0]) === 100 && Number(parts[1]) >= 64 && Number(parts[1]) <= 127;
}
function normalize(input: CreateChallengeInput): CreateChallengeInput {
  const key = input.publicKey;
  if (!ID.test(input.nodeId) || !validMeshIp(input.meshIp) || !Number.isInteger(input.meshPort)
    || input.meshPort < 1 || input.meshPort > 65535 || !Array.isArray(input.agents)
    || input.agents.length < 1 || input.agents.length > 128 || input.agents.some(a => !ID.test(a))
    || new Set(input.agents).size !== input.agents.length || !key || key.kty !== 'OKP'
    || key.crv !== 'Ed25519' || typeof key.x !== 'string' || !/^[A-Za-z0-9_-]{43}$/.test(key.x)
    || key.d !== undefined) throw new Error('invalid');
  return { nodeId: input.nodeId, publicKey: { kty: 'OKP', crv: 'Ed25519', x: key.x },
    meshIp: input.meshIp, meshPort: input.meshPort, agents: input.agents.toSorted() };
}
async function verify(key: JsonWebKey, signature: string, payload: string): Promise<boolean> {
  try {
    const publicKey = await crypto.subtle.importKey('jwk', key, { name: 'Ed25519' }, false, ['verify']);
    return await crypto.subtle.verify('Ed25519', publicKey, decodeSignature(signature), new TextEncoder().encode(payload));
  } catch { return false; }
}

/** Owner-scoped enrollment authority. No bearer credentials or runtime-presence claims are stored. */
export class OwnerRegistry extends DurableObject<RegistryEnvironment> {
  private readonly principal: string;
  constructor(ctx: DurableObjectState, env: RegistryEnvironment) {
    super(ctx, env);
    const name: unknown = JSON.parse(ctx.id.name ?? 'null');
    if (!Array.isArray(name) || name[0] !== 'event-owner-v1' || typeof name[1] !== 'string' || !name[1]) {
      throw new Error('invalid owner registry identity');
    }
    this.principal = name[1];
    ctx.storage.sql.exec('CREATE TABLE IF NOT EXISTS registry_migrations (version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)');
    ctx.storage.transactionSync(() => {
      const unsupported = ctx.storage.sql.exec('SELECT 1 FROM registry_migrations WHERE version != 1 LIMIT 1').toArray();
      if (unsupported.length) throw new Error('unsupported registry schema');
      const applied = ctx.storage.sql.exec('SELECT 1 FROM registry_migrations WHERE version=1').toArray();
      if (applied.length) return;
      ctx.storage.sql.exec(`CREATE TABLE IF NOT EXISTS nodes (
      node_id TEXT PRIMARY KEY, generation INTEGER NOT NULL CHECK(generation > 0),
      revoked INTEGER NOT NULL CHECK(revoked IN (0,1)), binding TEXT NOT NULL)`);
    ctx.storage.sql.exec(`CREATE TABLE IF NOT EXISTS challenges (
      challenge_id TEXT PRIMARY KEY, node_id TEXT NOT NULL, expires_at INTEGER NOT NULL,
      base_generation INTEGER NOT NULL, payload TEXT NOT NULL, binding TEXT NOT NULL,
      consumed_generation INTEGER CHECK(consumed_generation > 0))`);
    ctx.storage.sql.exec(`CREATE TABLE IF NOT EXISTS proof_nonces (
      node_id TEXT NOT NULL, nonce TEXT NOT NULL, expires_at INTEGER NOT NULL,
      PRIMARY KEY(node_id,nonce))`);
    ctx.storage.sql.exec(`CREATE TABLE IF NOT EXISTS slots (
      node_id TEXT NOT NULL, agent TEXT NOT NULL, delivery_id TEXT NOT NULL,
      generation INTEGER NOT NULL CHECK(generation > 0), PRIMARY KEY(node_id,delivery_id))`);
    ctx.storage.sql.exec(`CREATE TABLE IF NOT EXISTS revocation_outbox (
      node_id TEXT NOT NULL, agent TEXT NOT NULL, revoked_generation INTEGER NOT NULL CHECK(revoked_generation > 1),
      next_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts >= 0),
      PRIMARY KEY(node_id,agent))`);
    ctx.storage.sql.exec('CREATE TABLE IF NOT EXISTS admitted_coordinators (agent TEXT PRIMARY KEY)');
    ctx.storage.sql.exec('CREATE INDEX IF NOT EXISTS revocation_due ON revocation_outbox(next_at)');
    ctx.storage.sql.exec('CREATE INDEX IF NOT EXISTS challenge_expiry ON challenges(expires_at)');
    ctx.storage.sql.exec('CREATE INDEX IF NOT EXISTS nonce_expiry ON proof_nonces(expires_at)');
      ctx.storage.sql.exec('INSERT INTO registry_migrations VALUES (1,?)', Date.now());
    });
  }
  async admitCoordinator(input: { agent: string }): Promise<{ status: 'admitted' | 'capacity' | 'invalid' }> {
    const parsed = CoordinatorAdmissionSchema.safeParse(input);
    if (!parsed.success) return { status: 'invalid' };
    return this.ctx.storage.transactionSync(() => {
      const sql = this.ctx.storage.sql;
      if (sql.exec('SELECT 1 FROM admitted_coordinators WHERE agent=?', parsed.data.agent).toArray().length)
        return { status: 'admitted' };
      if (sql.exec<{ n: number }>('SELECT count(*) AS n FROM admitted_coordinators').one().n >= OWNER_REGISTRY_LIMITS.coordinators)
        return { status: 'capacity' };
      sql.exec('INSERT INTO admitted_coordinators VALUES (?)', parsed.data.agent);
      return { status: 'admitted' };
    });
  }
  private node(nodeId: string): NodeView | undefined {
    const row = this.ctx.storage.sql.exec<{ generation: number; revoked: number; binding: string }>(
      'SELECT generation,revoked,binding FROM nodes WHERE node_id = ?', nodeId).toArray()[0];
    return row ? { ...JSON.parse(row.binding), generation: row.generation, revoked: row.revoked === 1 } : undefined;
  }
  private async arm(at = Date.now() + 30_000): Promise<void> {
    // A fixed early alarm cannot be postponed by a concurrent request.
    await this.ctx.blockConcurrencyWhile(async () => {
      const next = at;
      const existing = await this.ctx.storage.getAlarm();
      if (existing === null || existing > next) await this.ctx.storage.setAlarm(next);
    });
  }
  async createChallenge(input: CreateChallengeInput): Promise<ChallengeView> {
    const binding = normalize(input);
    // Import checks that the approved key is usable before persisting the challenge.
    await crypto.subtle.importKey('jwk', binding.publicKey, 'Ed25519', false, ['verify']);
    await this.arm();
    const challengeId = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + CHALLENGE_MS).toISOString();
    const signingPayload = JSON.stringify(['event-node-enrollment-v1', this.principal, challengeId,
      expiresAt, binding.nodeId, binding.publicKey.x, binding.meshIp, binding.meshPort, binding.agents]);
    this.ctx.storage.transactionSync(() => {
      const current = this.node(binding.nodeId);
      if (current && !current.revoked) throw new Error('conflict');
      const baseGeneration = current?.generation ?? 0;
      const nodes = this.ctx.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM nodes').one().n;
      if (baseGeneration === 0 && nodes >= OWNER_REGISTRY_LIMITS.nodes) throw new Error('capacity');
      this.ctx.storage.sql.exec('DELETE FROM challenges WHERE expires_at <= ?', Date.now());
      const existing = this.ctx.storage.sql.exec('SELECT 1 FROM challenges WHERE node_id=? AND consumed_generation IS NULL', binding.nodeId).toArray().length;
      const pending = this.ctx.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM challenges WHERE consumed_generation IS NULL').one().n;
      if (!existing && pending >= OWNER_REGISTRY_LIMITS.pendingChallenges) throw new Error('capacity');
      this.ctx.storage.sql.exec('DELETE FROM challenges WHERE node_id = ?', binding.nodeId);
      this.ctx.storage.sql.exec('INSERT INTO challenges(challenge_id,node_id,expires_at,base_generation,payload,binding) VALUES (?,?,?,?,?,?)', challengeId, binding.nodeId,
        Date.parse(expiresAt), baseGeneration, signingPayload, JSON.stringify(binding));
    });
    return { challengeId, nodeId: binding.nodeId, expiresAt, signingPayload };
  }
  async completeEnrollment(input: { challengeId: string; signature: string }): Promise<NodeView> {
    const row = this.ctx.storage.sql.exec<{ node_id: string; expires_at: number; base_generation: number; payload: string; binding: string; consumed_generation: number | null }>(
      'SELECT * FROM challenges WHERE challenge_id = ?', input.challengeId).toArray()[0];
    if (!row || row.expires_at <= Date.now()) throw new Error('invalid');
    const binding = JSON.parse(row.binding) as CreateChallengeInput;
    if (!await verify(binding.publicKey, input.signature, row.payload)) throw new Error('invalid');
    return this.ctx.storage.transactionSync(() => {
      const live = this.ctx.storage.sql.exec<{ expires_at: number; consumed_generation: number | null }>('SELECT expires_at,consumed_generation FROM challenges WHERE challenge_id = ?', input.challengeId).toArray()[0];
      if (!live || live.expires_at <= Date.now()) throw new Error('conflict');
      const current = this.node(row.node_id);
      if (live.consumed_generation !== null) {
        if (!current || current.revoked || current.generation !== live.consumed_generation) throw new Error('conflict');
        return current;
      }
      if (current && !current.revoked) throw new Error('conflict');
      if ((current?.generation ?? 0) !== row.base_generation) throw new Error('conflict');
      const nodes = this.ctx.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM nodes').one().n;
      if (row.base_generation === 0 && nodes >= OWNER_REGISTRY_LIMITS.nodes) throw new Error('capacity');
      const generation = row.base_generation + 1;
      this.ctx.storage.sql.exec('INSERT INTO nodes VALUES (?,?,0,?) ON CONFLICT(node_id) DO UPDATE SET generation=excluded.generation,revoked=0,binding=excluded.binding', row.node_id, generation, row.binding);
      this.ctx.storage.sql.exec('UPDATE challenges SET consumed_generation=? WHERE challenge_id=?', generation, input.challengeId);
      return { ...binding, generation, revoked: false };
    });
  }
  async revokeNode(input: { nodeId: string; expectedGeneration: number }): Promise<NodeView> {
    // Arm recovery before the generation fence and fanout become durable together.
    await this.arm(Date.now() + 250);
    return this.ctx.storage.transactionSync(() => {
      const node = this.node(input.nodeId);
      if (!node || node.generation !== input.expectedGeneration) throw new Error('conflict');
      const generation = node.generation + 1;
      // Retained slots name the affected coordinators, including agents removed by re-enrollment.
      // Once their slots are gone, they no longer own pending native work that needs reconciliation.
      this.#pruneRevocations();
      const affected = this.ctx.storage.sql.exec<{ agent: string }>('SELECT DISTINCT agent FROM slots WHERE node_id=? AND generation<?', node.nodeId, generation).toArray();
      for (const { agent } of affected) {
        this.ctx.storage.sql.exec(`INSERT INTO revocation_outbox(node_id,agent,revoked_generation,next_at,attempts) VALUES (?,?,?,?,0)
          ON CONFLICT(node_id,agent) DO UPDATE SET revoked_generation=excluded.revoked_generation,next_at=excluded.next_at,attempts=0`,
          node.nodeId, agent, generation, Date.now());
      }
      this.ctx.storage.sql.exec('UPDATE nodes SET revoked=1,generation=generation+1 WHERE node_id=?', input.nodeId);
      this.ctx.storage.sql.exec('DELETE FROM challenges WHERE node_id=? AND consumed_generation IS NULL', input.nodeId);
      return { ...node, revoked: true, generation: node.generation + 1 };
    });
  }
  async confirmNodeRevocation(input: { nodeId: string; agent: string; revokedGeneration: number }): Promise<boolean> {
    const parsed = RevocationConfirmationSchema.safeParse(input);
    if (!parsed.success) return false;
    const { nodeId, agent, revokedGeneration } = parsed.data;
    return this.ctx.storage.sql.exec(`SELECT 1 FROM revocation_outbox AS job
      WHERE job.node_id=? AND job.agent=? AND job.revoked_generation=?
        AND EXISTS (SELECT 1 FROM slots WHERE slots.node_id=job.node_id
          AND slots.agent=job.agent AND slots.generation<job.revoked_generation) LIMIT 1`,
      nodeId, agent, revokedGeneration).toArray().length === 1;
  }
  async status(): Promise<NodeView[]> {
    const rows = this.ctx.storage.sql.exec<{ node_id: string }>('SELECT node_id FROM nodes ORDER BY node_id LIMIT ?', OWNER_REGISTRY_LIMITS.nodes + 1).toArray();
    if (rows.length > OWNER_REGISTRY_LIMITS.nodes) throw new Error('capacity');
    return rows.map(row => this.node(row.node_id)!);
  }
  async currentNode(input: { nodeId: string; agent: string; generation?: number }): Promise<NodeAuthorization> {
    const node = this.node(input.nodeId);
    return node && !node.revoked && node.agents.includes(input.agent) && (input.generation === undefined || node.generation === input.generation)
      ? { status: 'authorized', node } : { status: 'denied' };
  }
  async authenticateNode(proof: NodeProof, binding: ProofBinding): Promise<NodeAuthorization> {
    const now = Date.now();
    const issued = Date.parse(proof.issuedAt);
    if (!Number.isSafeInteger(proof.nodeGeneration) || proof.nodeGeneration < 1 || !Number.isFinite(issued) || new Date(issued).toISOString() !== proof.issuedAt || proof.nonce.length !== 36 || !uuid.safeParse(proof.nonce).success
      || issued > now + EVENT_POLICY_V1.clockSkewMs || issued < now - EVENT_POLICY_V1.freshnessLifetimeMs
      || !validProofBinding(binding, this.env.EVENT_HOST)) return { status: 'invalid' };
    const node = this.node(proof.nodeId);
    if (!node || node.revoked || node.generation !== proof.nodeGeneration) return { status: 'denied' };
    if (!await verify(node.publicKey, proof.signature, canonicalNodeProof(this.principal, proof, binding))) return { status: 'invalid' };
    await this.arm();
    return this.ctx.storage.transactionSync(() => {
      const current = this.node(proof.nodeId);
      if (!current || current.revoked || current.generation !== node.generation) return { status: 'denied' };
      if (Date.now() > issued + EVENT_POLICY_V1.freshnessLifetimeMs) return { status: 'invalid' };
      const replay = this.ctx.storage.sql.exec('SELECT 1 FROM proof_nonces WHERE node_id=? AND nonce=?', proof.nodeId, proof.nonce).toArray();
      if (replay.length) return { status: 'denied' };
      // Reclaim only expired replay fences; live proofs are never evicted to admit new work.
      this.ctx.storage.sql.exec('DELETE FROM proof_nonces WHERE expires_at <= ?', Date.now());
      const nodeNonces = this.ctx.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM proof_nonces WHERE node_id=?', proof.nodeId).one().n;
      const ownerNonces = this.ctx.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM proof_nonces').one().n;
      if (nodeNonces >= OWNER_REGISTRY_LIMITS.proofNoncesPerNode || ownerNonces >= OWNER_REGISTRY_LIMITS.proofNonces)
        throw new Error('capacity');
      this.ctx.storage.sql.exec('INSERT INTO proof_nonces VALUES (?,?,?)', proof.nodeId, proof.nonce,
        issued + EVENT_POLICY_V1.freshnessLifetimeMs + EVENT_POLICY_V1.clockSkewMs);
      return { status: 'authorized', node: current };
    });
  }
  async reserveSlot(input: SlotInput): Promise<SlotResult> {
    return this.ctx.storage.transactionSync(() => {
      const node = this.node(input.nodeId);
      if (!node || node.revoked || node.generation !== input.generation || !node.agents.includes(input.agent) || !input.deliveryId || input.deliveryId.length > 256) return { status: 'denied' };
      const prior = this.ctx.storage.sql.exec<{ agent: string; generation: number }>('SELECT agent,generation FROM slots WHERE node_id=? AND delivery_id=?', input.nodeId, input.deliveryId).toArray()[0];
      if (prior) return { status: prior.agent === input.agent && prior.generation === input.generation ? 'reserved' : 'denied' };
      const count = this.ctx.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM slots WHERE node_id=?', input.nodeId).one().n;
      if (count >= EVENT_POLICY_V1.maxPendingDeliveriesPerNode) return { status: 'capacity' };
      this.ctx.storage.sql.exec('INSERT INTO slots VALUES (?,?,?,?)', input.nodeId, input.agent, input.deliveryId, input.generation);
      return { status: 'reserved' };
    });
  }
  async releaseSlot(input: { nodeId: string; agent: string; deliveryId: string }): Promise<void> {
    this.ctx.storage.sql.exec('DELETE FROM slots WHERE node_id=? AND agent=? AND delivery_id=?', input.nodeId, input.agent, input.deliveryId);
  }
  async alarm(): Promise<void> {
    const now = Date.now();
    this.ctx.storage.sql.exec('DELETE FROM challenges WHERE expires_at <= ?', now);
    this.ctx.storage.sql.exec('DELETE FROM proof_nonces WHERE expires_at <= ?', now);
    this.#pruneRevocations();
    const jobs = this.ctx.storage.sql.exec<RevocationJob>('SELECT * FROM revocation_outbox WHERE next_at<=? ORDER BY next_at,node_id,agent LIMIT 10', now).toArray();
    // At most ten bounded RPCs run concurrently; no external I/O holds the input gate.
    await Promise.all(jobs.map(job => this.#reconcileRevocation(job)));
    const pending = this.ctx.storage.sql.exec<{ n: number }>('SELECT (SELECT count(*) FROM challenges)+(SELECT count(*) FROM proof_nonces) AS n').one().n;
    const due = this.ctx.storage.sql.exec<{ next_at: number | null }>('SELECT min(next_at) AS next_at FROM revocation_outbox').one().next_at;
    if (pending || due !== null) await this.arm(Math.max(Date.now() + 250, Math.min(pending ? Date.now() + 30_000 : Infinity, due ?? Infinity)));
  }
  #pruneRevocations(): void {
    // Each remaining job is backed by at least one of the node's at most 1,000 retained slots.
    this.ctx.storage.sql.exec(`DELETE FROM revocation_outbox WHERE NOT EXISTS (
      SELECT 1 FROM slots WHERE slots.node_id=revocation_outbox.node_id
        AND slots.agent=revocation_outbox.agent AND slots.generation<revocation_outbox.revoked_generation)`);
  }
  async #reconcileRevocation(job: RevocationJob): Promise<void> {
    const leaseUntil = Date.now() + EVENT_POLICY_V1.nativeRpcDeadlineMs;
    await this.arm(leaseUntil);
    // Lease first so a crash or lost reply retries the same node/generation/agent identity.
    const leased = this.ctx.storage.sql.exec(`UPDATE revocation_outbox SET next_at=?,attempts=attempts+1
      WHERE node_id=? AND agent=? AND revoked_generation=? AND next_at=?`, leaseUntil,
      job.node_id, job.agent, job.revoked_generation, job.next_at).rowsWritten;
    if (!leased) return;
    try {
      if ((await this.admitCoordinator({ agent: job.agent })).status !== 'admitted') throw new Error('capacity');
      const coordinator = this.env.AGENT_COORDINATOR?.getByName(coordinatorName(this.principal, job.agent));
      if (!coordinator) throw new Error('revocation_unavailable');
      await revocationDeadline(coordinator.reconcileNodeRevocation({ nodeId: job.node_id, revokedGeneration: job.revoked_generation }));
      // A delayed older reply must not erase a newer revocation for this agent.
      this.ctx.storage.sql.exec('DELETE FROM revocation_outbox WHERE node_id=? AND agent=? AND revoked_generation=?', job.node_id, job.agent, job.revoked_generation);
    } catch {
      const delay = Math.min(EVENT_POLICY_V1.recoveryBackoffMaxMs, EVENT_POLICY_V1.recoveryBackoffInitialMs * 2 ** Math.min(job.attempts, 10));
      this.ctx.storage.sql.exec('UPDATE revocation_outbox SET next_at=? WHERE node_id=? AND agent=? AND revoked_generation=?',
        Date.now() + delay, job.node_id, job.agent, job.revoked_generation);
    }
  }
}
