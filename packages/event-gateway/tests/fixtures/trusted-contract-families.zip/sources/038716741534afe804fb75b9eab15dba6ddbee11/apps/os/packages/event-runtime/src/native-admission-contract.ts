import { z } from "zod";

const uuid = z.uuid().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[47][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
const safeUnsignedInteger = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER);
const generation = safeUnsignedInteger.min(1);
const timestamp = z.iso.datetime({ precision: 3 });

/** Exact native client/thread/server/selection identity bound by a cloud challenge. */
export const NativeRuntimeBindingSchema = z.strictObject({
  clientId: uuid,
  connectionId: uuid,
  backendPid: safeUnsignedInteger.min(1).max(2 ** 32 - 1),
  threadId: uuid,
  generation: safeUnsignedInteger,
  serverInstanceId: uuid,
  serverGeneration: safeUnsignedInteger,
});
export type NativeRuntimeBinding = z.infer<typeof NativeRuntimeBindingSchema>;

/** Native reader v2 witness. The native process supplies `eligible`; the gateway
 * accepts only true after checking this exact witness against its live bridge. */
export const NativeRuntimeWitnessSchema = z.strictObject({
  version: z.literal(2),
  nonce: safeUnsignedInteger,
  clientId: uuid,
  backendPid: safeUnsignedInteger.min(1).max(2 ** 32 - 1),
  connectionId: uuid,
  threadId: uuid,
  generation: safeUnsignedInteger,
  eligible: z.literal(true),
  sequence: safeUnsignedInteger.min(1),
  cause: z.string().max(128),
  serverInstanceId: uuid,
  serverGeneration: safeUnsignedInteger,
  leaseMs: safeUnsignedInteger.min(1),
});
export type NativeRuntimeWitness = z.infer<typeof NativeRuntimeWitnessSchema>;

/** `observedAt` is captured immediately before the local native challenge call. */
export const NativeRuntimeEvidenceSchema = z.strictObject({
  observedAt: timestamp,
  witness: NativeRuntimeWitnessSchema,
});
export type NativeRuntimeEvidence = z.infer<typeof NativeRuntimeEvidenceSchema>;

const attachChallenge = z.strictObject({
  operation: z.literal("attach"),
  runtimeId: uuid,
  expectedRuntimeGeneration: generation.nullable(),
  expectedAttachmentGeneration: generation.nullable(),
  expectedNativeBinding: NativeRuntimeBindingSchema,
}).refine((value) => (value.expectedRuntimeGeneration === null) === (value.expectedAttachmentGeneration === null));

const renewChallenge = z.strictObject({
  operation: z.literal("renew"),
  runtimeId: uuid,
  expectedRuntimeGeneration: generation,
  expectedAttachmentGeneration: generation,
  expectedNativeBinding: NativeRuntimeBindingSchema,
});

const transferChallenge = z.strictObject({
  operation: z.literal("transfer"),
  sourceRuntimeId: uuid,
  expectedSourceRuntimeGeneration: generation,
  expectedSourceAttachmentGeneration: generation,
  replacementRuntimeId: uuid,
  expectedReplacementRuntimeGeneration: generation,
  expectedReplacementAttachmentGeneration: generation,
  expectedNativeBinding: NativeRuntimeBindingSchema,
}).refine((value) => value.sourceRuntimeId !== value.replacementRuntimeId);

/** Intent is recorded before the gateway obtains its fresh local witness. */
export const NativeRuntimeChallengeRequestSchema = z.discriminatedUnion("operation", [
  attachChallenge,
  renewChallenge,
  transferChallenge,
]);
export type NativeRuntimeChallengeRequest = z.infer<typeof NativeRuntimeChallengeRequestSchema>;

export const NativeRuntimeChallengeResponseSchema = z.strictObject({
  challengeId: uuid,
  issuedAt: timestamp,
  expiresAt: timestamp,
}).refine((value) => Date.parse(value.expiresAt) - Date.parse(value.issuedAt) === 30_000);
export type NativeRuntimeChallengeResponse = z.infer<typeof NativeRuntimeChallengeResponseSchema>;

export const NativeRuntimeAttachRequestSchema = z.strictObject({
  challengeId: uuid,
  runtimeId: uuid,
  expectedRuntimeGeneration: generation.nullable(),
  expectedAttachmentGeneration: generation.nullable(),
  nativeEvidence: NativeRuntimeEvidenceSchema,
}).refine((value) => (value.expectedRuntimeGeneration === null) === (value.expectedAttachmentGeneration === null));
export type NativeRuntimeAttachRequest = z.infer<typeof NativeRuntimeAttachRequestSchema>;

export const NativeRuntimeRenewRequestSchema = z.strictObject({
  challengeId: uuid,
  runtimeId: uuid,
  expectedRuntimeGeneration: generation,
  expectedAttachmentGeneration: generation,
  nativeEvidence: NativeRuntimeEvidenceSchema,
});
export type NativeRuntimeRenewRequest = z.infer<typeof NativeRuntimeRenewRequestSchema>;

export const NativeRuntimeTransferRequestSchema = z.strictObject({
  challengeId: uuid,
  sourceRuntimeId: uuid,
  expectedSourceRuntimeGeneration: generation,
  expectedSourceAttachmentGeneration: generation,
  replacementRuntimeId: uuid,
  expectedReplacementRuntimeGeneration: generation,
  expectedReplacementAttachmentGeneration: generation,
  nativeEvidence: NativeRuntimeEvidenceSchema,
}).refine((value) => value.sourceRuntimeId !== value.replacementRuntimeId);
export type NativeRuntimeTransferRequest = z.infer<typeof NativeRuntimeTransferRequestSchema>;

const attachedFields = {
  runtimeId: uuid,
  runtimeGeneration: generation,
  nodeId: uuid,
  nodeGeneration: generation,
  attachmentGeneration: generation,
  leaseUntil: timestamp,
  nativeBinding: NativeRuntimeBindingSchema,
};

export const NativeRuntimeAttachResponseSchema = z.strictObject({
  status: z.literal("attached"),
  ...attachedFields,
});
export type NativeRuntimeAttachResponse = z.infer<typeof NativeRuntimeAttachResponseSchema>;

export const NativeRuntimeRenewResponseSchema = z.strictObject({
  status: z.literal("renewed"),
  ...attachedFields,
});
export type NativeRuntimeRenewResponse = z.infer<typeof NativeRuntimeRenewResponseSchema>;

export const NativeRuntimeTransferResponseSchema = z.strictObject({
  status: z.literal("transferred"),
  sourceRuntimeId: uuid,
  sourceRuntimeGeneration: generation,
  sourceAttachmentGeneration: generation,
  runtimeId: uuid,
  runtimeGeneration: generation,
  nodeId: uuid,
  nodeGeneration: generation,
  attachmentGeneration: generation,
  leaseUntil: timestamp,
  nativeBinding: NativeRuntimeBindingSchema,
});
export type NativeRuntimeTransferResponse = z.infer<typeof NativeRuntimeTransferResponseSchema>;

export const NativeRuntimeAdmissionErrorSchema = z.strictObject({
  error: z.enum([
    "invalid_request",
    "invalid_json",
    "duplicate_json_key",
    "invalid_body",
    "invalid",
    "denied",
    "node_proof_required",
    "node_denied",
    "conflict",
    "capacity",
    "coordinator_capacity",
    "expired",
    "native_binding_unqualified",
    "request_timeout",
    "request_too_large",
    "content_type",
    "content_encoding",
    "runtime_disabled",
    "authority_unavailable",
    "registry_unavailable",
    "unavailable",
    "not_found",
    "method_not_allowed",
  ]),
});
export type NativeRuntimeAdmissionError = z.infer<typeof NativeRuntimeAdmissionErrorSchema>;

export const NATIVE_RUNTIME_CHALLENGE_TTL_MS = 30_000;
export const NATIVE_RUNTIME_MAX_LIVE_CHALLENGES_PER_AGENT = 32;
export const NATIVE_RUNTIME_MAX_EVIDENCE_AGE_MS = 750;
export const NATIVE_RUNTIME_COMMIT_RECEIPT_TTL_MS = 90_000;
export const NATIVE_RUNTIME_MAX_LIVE_COMMIT_RECEIPTS_PER_AGENT = 64;
