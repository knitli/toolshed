import { manualPublicationResult, requireManualCanary } from "./manual-canary.ts";
import { authenticateReadAuthority, revalidateReadAuthority, type ReadAuthorityScope as NativeRuntimeCommitScope } from "./read-authority.ts";
import { withDeadline } from "./request-deadline.ts";
import { githubHostName, type GitHubAttentionHost } from './github/host';
import { GitHubSourceReadRequestSchema, GitHubSourceReadResultSchema } from './github/readback-contract';
import { NativeRuntimeStore, type RuntimeRow, type NativeRuntimeCommitRequest } from "./native-runtime-store.ts";
import { requireNativeAdmissionCanary } from "./native-admission-gate.ts";
import { DurableObject } from "cloudflare:workers";
import { principalAllowed } from "gatekeeper-memory/src/principals.ts";
import { GitHubGrantStore, type GitHubGrantInput, type GitHubPublicationDisposition, type GitHubPublicationInput, type GitHubPublicationPin } from "./github/grants.ts";
import type { GitHubSubjectV1 } from "./github/state.ts";
import { parseAuthorityAuthResult } from "./authority-client.ts";
import { z } from "zod";
import type { EventAuthorityCredentialsV1, EventAuthorityServiceV1 } from "gatekeeper-messaging/src/event-authority-contract";
import { EVENT_INITIAL_POLICY_REVISION, EVENT_POLICY_V1 } from "./policy.ts";
import { GitHubSourceAdoptionInputSchema, GitHubSourceControlStore, GitHubSourceInitializationInputSchema, GitHubSourceControlTokenSchema, GitHubSourceParkingResultSchema, GitHubSourceRevalidationResultSchema, GITHUB_SOURCE_CONTROL_LIMITS, sourceTokenEquals, type GitHubSourceControlToken, type GitHubSourceFenceStatus } from './github/source-control';
import { acknowledgmentAdvancesCurrentWatermark, acknowledgmentMatchesDelivery, deriveDeliveryId, EventObservationAckSchema, validateEventObservationAck, type EventEnvelopeV1, type EventObservationAckV1 } from "./protocol.ts";
import type { NodeAuthorization, OwnerRegistry } from "./registry.ts";
import { EventApiError, parseApiJson, parseNativeAttemptReservation, parseNativeAttemptStatus, DispatchNoStartRequestSchema, DispatchNoStartResultSchema, type DispatchNoStartRequest, type DispatchNoStartResult, type DispatchClaimResult } from "./contracts.ts";
import type { EventDeliveryCounts, EventDeliveryStatusView } from "./admin-types.ts";
import type { EventJob, TransportClaim } from "./queue.ts";
import type { TransportOutcome } from "./delivery.ts";
import {
  NATIVE_RUNTIME_CHALLENGE_TTL_MS, NATIVE_RUNTIME_MAX_LIVE_CHALLENGES_PER_AGENT,
  NATIVE_RUNTIME_MAX_EVIDENCE_AGE_MS, NATIVE_RUNTIME_COMMIT_RECEIPT_TTL_MS,
  NATIVE_RUNTIME_MAX_LIVE_COMMIT_RECEIPTS_PER_AGENT, NativeRuntimeAttachRequestSchema,
  NativeRuntimeChallengeRequestSchema,
  NativeRuntimeRenewRequestSchema,
  NativeRuntimeTransferRequestSchema,
  NativeRuntimeWitnessSchema, NativeRuntimeStatusRequestSchema,
  type NativeRuntimeBinding, type NativeRuntimeChallengeRequest, type NativeRuntimeStatusResponse,
} from "./native-admission-contract.ts";

const uuid = z.uuid().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[47][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
const agentSchema = z.string().regex(/^[a-z0-9-]{1,32}$/);
const principalSchema = z.email().max(254).refine(value => value === value.toLowerCase());
const subjectSchema = z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/);
const manualInputSchema = z.strictObject({ runtimeId: uuid, subjectId: subjectSchema });
const enabledInputSchema = z.strictObject({ enabled: z.boolean() });
const transferInputSchema = z.strictObject({ runtimeId: uuid, replacementRuntimeId: uuid, expectedAttachmentGeneration: z.number().int().positive().max(Number.MAX_SAFE_INTEGER) });
const claimInputSchema = z.strictObject({ deliveryId: z.string().regex(/^dly_[0-9a-f]{64}$/), attemptId: uuid, nodeId: uuid, nodeGeneration: z.number().int().positive().max(Number.MAX_SAFE_INTEGER) });
const revocationInputSchema = z.strictObject({ nodeId: uuid, revokedGeneration: z.number().int().positive().max(Number.MAX_SAFE_INTEGER) });
const jobSchema = z.strictObject({ principal: principalSchema, agent: agentSchema, deliveryId: z.string().regex(/^dly_[0-9a-f]{64}$/) });

type CoordinatorEnv = {
  EVENT_ENABLED?: string;
  EVENT_MANUAL_ENABLED?: string;
  EVENT_MANUAL_CANARY?: string;
  EVENT_NATIVE_BINDING_ENABLED?: string;
  EVENT_NATIVE_BINDING_CANARY?: string;
  EVENT_GITHUB_ENABLED?: string;
  EVENT_GITHUB_SOURCE_CONTROL_ENABLED?: string;
  EVENT_GITHUB_SOURCE_GATE_EPOCH?: string;
  GITHUB_SOURCE_MAP?: string;
  GITHUB_ATTENTION_HOST?: DurableObjectNamespace<GitHubAttentionHost>;
  ALLOWED_PRINCIPALS?: string;
  MESSAGE_AUTHORITY: EventAuthorityServiceV1;
  OWNER_REGISTRY: DurableObjectNamespace<OwnerRegistry>;
  DELIVERY_QUEUE: Queue<EventJob>;
};
type DeliveryRow = {
  delivery_id: string; event_id: string; subject_id: string; source_state_version: string;
  runtime_id: string; runtime_generation: number; attachment_generation: number;
  node_id: string; node_generation: number; state: string; reason: string | null;
  created_at: number; retry_until: number; transport_state: string; transport_failures: number;
};
type AttemptRow = {
  attempt_id: string; delivery_id: string; envelope_json: string; state: string;
  transport_until: number; permit_id: string | null; permit_until: number | null;
  reservation_state: string; submission_id: string | null; turn_id: string | null; ack_json: string | null;
  native_observed_ack_json: string | null;
  transport_status: string; transport_reason: string | null;
};
type Identity = { principal: string; agent: string };
type NativeClaimRow = { delivery_id: string; attempt_id: string; state: string; permit_id: string | null; permit_issued_at: number | null; permit_until: number | null; envelope_json: string | null; updated_at: number };
type NativeRuntimeChallengeRow = {
  challenge_id: string; operation: "attach" | "renew" | "transfer"; request_json: string;
  principal: string; agent: string; key_thumbprint: string; node_id: string; node_generation: number;
  issued_at: number; expires_at: number; consumed_at: number | null; receipt_expires_at: number | null;
  commit_hash: string | null; result_json: string | null;
};

const nativeKeyThumbprint = z.string().regex(/^[A-Za-z0-9_-]{43}$/);
const nativeProofDigest = z.string().regex(/^[0-9a-f]{64}$/);
function bindingFromWitness(witness: z.infer<typeof NativeRuntimeWitnessSchema>): NativeRuntimeBinding {
  return { clientId: witness.clientId, connectionId: witness.connectionId, backendPid: witness.backendPid,
    threadId: witness.threadId, generation: witness.generation, serverInstanceId: witness.serverInstanceId,
    serverGeneration: witness.serverGeneration };
}
type Status = { enabled: boolean; counts: EventDeliveryCounts; recent: EventDeliveryStatusView[]; recentLimit: 20; recentTruncated: boolean };

const SCHEMA = `
CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS coordinator_state(id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL CHECK(enabled IN (0,1)));
INSERT OR IGNORE INTO coordinator_state(id,enabled) VALUES (1,0);
CREATE TABLE IF NOT EXISTS runtimes(
  runtime_id TEXT PRIMARY KEY, runtime_generation INTEGER NOT NULL CHECK(runtime_generation>0),
  node_id TEXT NOT NULL, node_generation INTEGER NOT NULL CHECK(node_generation>0),
  attachment_generation INTEGER NOT NULL CHECK(attachment_generation>0),
  lease_until INTEGER NOT NULL, qualified INTEGER NOT NULL CHECK(qualified IN (0,1)));
CREATE TABLE IF NOT EXISTS native_runtime_bindings(
  runtime_id TEXT PRIMARY KEY, client_id TEXT NOT NULL, key_thumbprint TEXT, binding_json TEXT NOT NULL,
  nonce INTEGER NOT NULL CHECK(nonce>=0), sequence INTEGER NOT NULL CHECK(sequence>=1));
CREATE TABLE IF NOT EXISTS native_runtime_challenges(
  challenge_id TEXT PRIMARY KEY, operation TEXT NOT NULL CHECK(operation IN ('attach','renew','transfer')),
  request_json TEXT NOT NULL, principal TEXT NOT NULL, agent TEXT NOT NULL, key_thumbprint TEXT NOT NULL,
  node_id TEXT NOT NULL, node_generation INTEGER NOT NULL CHECK(node_generation>0),
  issued_at INTEGER NOT NULL, expires_at INTEGER NOT NULL, consumed_at INTEGER,
  receipt_expires_at INTEGER, commit_hash TEXT, result_json TEXT,
  CHECK((consumed_at IS NULL AND receipt_expires_at IS NULL AND commit_hash IS NULL AND result_json IS NULL)
    OR (consumed_at IS NOT NULL AND receipt_expires_at IS NOT NULL AND commit_hash IS NOT NULL AND result_json IS NOT NULL)));
CREATE INDEX IF NOT EXISTS native_runtime_challenge_expiry ON native_runtime_challenges(expires_at,receipt_expires_at);
CREATE TABLE IF NOT EXISTS manual_sources(
  subject_id TEXT PRIMARY KEY, event_id TEXT NOT NULL UNIQUE, source_state_version TEXT NOT NULL UNIQUE,
  event_reference TEXT NOT NULL, observed_at TEXT NOT NULL, observed_source_state_version TEXT,
  created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS deliveries(
  delivery_id TEXT PRIMARY KEY, event_id TEXT NOT NULL, subject_id TEXT NOT NULL,
  source_state_version TEXT NOT NULL, runtime_id TEXT NOT NULL,
  runtime_generation INTEGER NOT NULL, attachment_generation INTEGER NOT NULL,
  node_id TEXT NOT NULL, node_generation INTEGER NOT NULL,
  state TEXT NOT NULL, reason TEXT, created_at INTEGER NOT NULL, retry_until INTEGER NOT NULL,
  transport_state TEXT NOT NULL DEFAULT 'queued', transport_failures INTEGER NOT NULL DEFAULT 0,
  terminal_at INTEGER);
CREATE INDEX IF NOT EXISTS deliveries_state ON deliveries(state,created_at);
CREATE INDEX IF NOT EXISTS deliveries_terminal ON deliveries(terminal_at,delivery_id)
  WHERE state IN ('observed','expired','failed');
CREATE TABLE IF NOT EXISTS attempts(
  attempt_id TEXT PRIMARY KEY, delivery_id TEXT NOT NULL, envelope_json TEXT NOT NULL,
  state TEXT NOT NULL, transport_until INTEGER NOT NULL, permit_id TEXT, permit_until INTEGER,
  reservation_state TEXT NOT NULL DEFAULT 'none', submission_id TEXT, turn_id TEXT, ack_json TEXT,
  native_observed_ack_json TEXT,
  transport_status TEXT NOT NULL DEFAULT 'pending', transport_reason TEXT);
CREATE INDEX IF NOT EXISTS attempts_delivery ON attempts(delivery_id,transport_until);
CREATE TABLE IF NOT EXISTS native_claims(
  delivery_id TEXT PRIMARY KEY, attempt_id TEXT NOT NULL, state TEXT NOT NULL,
  permit_id TEXT, permit_issued_at INTEGER, permit_until INTEGER, envelope_json TEXT, updated_at INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS no_start_settlements(
  attempt_id TEXT PRIMARY KEY, delivery_id TEXT NOT NULL, result_json TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS no_start_delivery ON no_start_settlements(delivery_id);
CREATE TABLE IF NOT EXISTS native_correlations(
  correlation_id TEXT PRIMARY KEY, delivery_id TEXT NOT NULL, attempt_id TEXT NOT NULL, kind TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS queue_outbox(
  delivery_id TEXT PRIMARY KEY, due_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
  state TEXT NOT NULL DEFAULT 'queued');
CREATE TABLE IF NOT EXISTS slot_intents(
  delivery_id TEXT PRIMARY KEY, node_id TEXT NOT NULL, node_generation INTEGER NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('reserve_pending','reserved','release_pending')),
  updated_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, next_at INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS slot_intents_state ON slot_intents(state,updated_at);
`;

function row<T>(sql: SqlStorage, query: string, ...values: SqlStorageValue[]): T | null {
  return (sql.exec<Record<string, SqlStorageValue>>(query, ...values).toArray()[0] as T | undefined) ?? null;
}
function nowIso(now = Date.now()): string { return new Date(now).toISOString(); }
function githubSourceGateEpoch(value: string | undefined): number | null {
  if (!value || !/^[1-9][0-9]{0,15}$/.test(value)) return null;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) ? parsed : null;
}
function retryDelay(failures: number): number {
  return Math.min(EVENT_POLICY_V1.recoveryBackoffMaxMs, EVENT_POLICY_V1.recoveryBackoffInitialMs * 2 ** Math.min(failures, 10));
}

/** One SQL authority per verified principal and canonical registered agent. */
export class AgentCoordinator extends DurableObject<CoordinatorEnv> {
  readonly #identity: Identity;
  readonly #sql: SqlStorage;
  readonly #nativeStore: NativeRuntimeStore;
  readonly #githubSourceControls: GitHubSourceControlStore;
  readonly #grantStore: GitHubGrantStore;

  constructor(ctx: DurableObjectState, env: CoordinatorEnv) {
    super(ctx, env);
    let name: unknown;
    try { name = JSON.parse(ctx.id.name ?? "null"); } catch { name = null; }
    if (!Array.isArray(name) || name.length !== 3 || name[0] !== "event-agent-v1"
      || typeof name[1] !== "string" || typeof name[2] !== "string"
      || !principalSchema.safeParse(name[1]).success || !agentSchema.safeParse(name[2]).success
      || JSON.stringify(name) !== ctx.id.name) throw new Error("invalid coordinator identity");
    this.#identity = { principal: name[1], agent: name[2] };
    this.#sql = ctx.storage.sql;
    this.#nativeStore = new NativeRuntimeStore(this.#sql);
    this.#githubSourceControls = ctx.storage.transactionSync(() => {
      this.#sql.exec(SCHEMA);
      const version = row<{ version: number }>(this.#sql, "SELECT max(version) AS version FROM schema_migrations");
      // Schema v3 includes native binding state. The v4 source-control marker is
      // written only with the first accepted canonical operation; v5 is written
      // transactionally with first parking/revalidation opt-in. These markers
      // make the immediate predecessor fail closed after each new authority is used.
      if ((version?.version ?? 0) > 5) throw new Error("unsupported coordinator schema");
      const attemptColumns = this.#sql.exec<{ name: string }>("PRAGMA table_info(attempts)").toArray();
      if (!attemptColumns.some(column => column.name === "native_observed_ack_json")) {
        this.#sql.exec("ALTER TABLE attempts ADD COLUMN native_observed_ack_json TEXT");
      }
      const nativeBindingColumns = this.#sql.exec<{ name: string }>("PRAGMA table_info(native_runtime_bindings)").toArray();
      if (!nativeBindingColumns.some(column => column.name === "key_thumbprint"))
        this.#sql.exec("ALTER TABLE native_runtime_bindings ADD COLUMN key_thumbprint TEXT");
      this.#sql.exec("INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES (1,?)", Date.now());
      this.#sql.exec("INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES (2,?)", Date.now());
      this.#sql.exec("INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES (3,?)", Date.now());
      return new GitHubSourceControlStore(this.#sql, this.#identity.principal, this.#identity.agent);
    });
    this.#grantStore = new GitHubGrantStore(this.ctx.storage, this.#identity.principal, this.#identity.agent,
      () => this.env.GITHUB_SOURCE_MAP ?? '[]', () => this.env.EVENT_GITHUB_ENABLED === 'true' && this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED === 'true',
      () => githubSourceGateEpoch(this.env.EVENT_GITHUB_SOURCE_GATE_EPOCH));
    // Re-arm active canonical authority checks when a previously alarmed object
    // is reconstructed. This repairs a lost or pre-upgrade wake on object wake.
    if (this.#githubSourceControls.hasActiveControls()) this.ctx.waitUntil(this.#scheduleGitHubSourceWake());
  }

  // GitHub publication records are held source metadata. They do not reserve a
  // destination slot or enqueue a turn; stage-1 live acceptance still gates that consumer.
  #githubGrants(): GitHubGrantStore {
    if (!principalAllowed({ ALLOWED_PRINCIPALS: this.env.ALLOWED_PRINCIPALS ?? "" }, this.#identity.principal)) throw new Error("denied");
    return this.#grantStore;
  }
  async setGitHubGrant(input: GitHubGrantInput) { return this.#githubGrants().setGrant(input); }
  async githubSourceStatus(subject: GitHubSubjectV1, operationId?: string) {
    const grants = this.#githubGrants(), stored = grants.storedGrant(subject);
    if (!this.env.GITHUB_ATTENTION_HOST) throw new EventApiError("unavailable", 503);
    const identity = { ...this.#identity, subject };
    const source = await this.env.GITHUB_ATTENTION_HOST.getByName(githubHostName(identity)).sourceStatus(identity);
    let gate: ReturnType<GitHubGrantStore['sourceGate']> | null = null;
    try { gate = grants.sourceGate(subject); } catch { /* status remains readable while admission fails closed */ }
    const canonical = this.#githubSourceControls.control(subject), pending = this.#githubSourceControls.pendingFor(subject);
    // Parking is host work even when authority_changed is its trigger. Other
    // phases wait on authority only for the explicit authority retry reasons.
    const pendingReason = pending?.phase !== 'park'
      && (pending?.last_reason === 'authority_changed' || pending?.last_reason === 'authority_unavailable')
      ? 'waiting_for_authority' as const : 'waiting_for_host' as const;
    const control = pending && (pending.phase === 'park' || pending.phase === 'revalidate') ? {
      status: pending.phase === 'park' ? 'parking' as const : 'revalidation_pending' as const,
      sourceIncarnation: canonical?.token.sourceIncarnation ?? 0, watchIncarnation: 0 as const, routingRevision: 0 as const,
      lifecycleEpoch: canonical?.token.lifecycleEpoch ?? 0, operationId: pending.operation_id, hostEpoch: source.hostEpoch,
      pendingReason,
    } : canonical ? {
      status: canonical.state,
      sourceIncarnation: canonical.token.sourceIncarnation, watchIncarnation: 0 as const, routingRevision: 0 as const,
      lifecycleEpoch: canonical.token.lifecycleEpoch, operationId: canonical.operation_id,
      hostEpoch: source.hostEpoch, pendingReason: canonical.state === 'parked'
        ? canonical.token.lifecycleEpoch >= Number.MAX_SAFE_INTEGER || source.hostEpoch >= Number.MAX_SAFE_INTEGER - 2
          ? 'revalidation_exhausted' as const : 'revalidation_required' as const
        : canonical.state === 'active'
        ? this.#sourceTokenCurrent(canonical.token) ? null : 'waiting_for_authority' as const
        : pendingReason,
    } : pending ? {
      status: pending.phase === 'prepare' ? 'initialization_pending' as const : pending.phase === 'quiesce' ? 'migration_pending' as const
        : pending.phase === 'park' ? 'parking' as const : pending.phase === 'revalidate' ? 'revalidation_pending' as const : 'activation_pending' as const,
      sourceIncarnation: 0,
      watchIncarnation: 0 as const, routingRevision: 0 as const,
      lifecycleEpoch: 0,
      operationId: pending.operation_id, hostEpoch: source.hostEpoch, pendingReason,
    } : {
      status: source.hostControl === 'quiesced' ? 'quiesced' as const : source.status === 'absent' ? 'absent' as const : 'legacy' as const,
      sourceIncarnation: 0, watchIncarnation: 0 as const, routingRevision: 0 as const, lifecycleEpoch: 0,
      operationId: null, hostEpoch: source.hostEpoch, pendingReason: null,
    };
    return { ...stored, source, control,
      sourceControlEnabled: gate?.enabled === true && gate.deploymentEpoch !== null,
      operation: this.#githubSourceControls.operationReceipt(subject, operationId) };
  }
  async initializeGitHubSource(input: z.infer<typeof GitHubSourceInitializationInputSchema>) {
    const parsed = GitHubSourceInitializationInputSchema.parse(input), kind = 'initialize';
    const request = { principal: this.#identity.principal, agent: this.#identity.agent, kind, ...parsed };
    const existing = this.#githubSourceControls.exactOperation(parsed.operationId, request, Date.now());
    if (existing) {
      await this.#drainGitHubSourceOutbox();
      return this.githubSourceStatus(parsed.subject, parsed.operationId);
    }
    if (this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED !== 'true') throw new Error('github_source_control_unavailable');
    const grants = this.#githubGrants(), grant = grants.grant(parsed.subject);
    if (!grant || grant.revision !== parsed.expectedRevision) throw new Error("github_grant_conflict");
    if (!this.env.GITHUB_ATTENTION_HOST) throw new EventApiError("unavailable", 503);
    const historicalSubjects = grants.historicalSourceSubjects(parsed.subject), historyJson = JSON.stringify(historicalSubjects);
    const preflights = await Promise.all(historicalSubjects.map(subject => {
      const identity = { ...this.#identity, subject };
      return this.env.GITHUB_ATTENTION_HOST!.getByName(githubHostName(identity)).sourceStatus(identity);
    }));
    const raced = this.#githubSourceControls.exactOperation(parsed.operationId, request, Date.now());
    if (raced) {
      await this.#drainGitHubSourceOutbox();
      return this.githubSourceStatus(parsed.subject, parsed.operationId);
    }
    if (preflights.some(preflight => preflight.status !== 'absent' || preflight.hostControl !== 'absent'))
      throw new Error('github_legacy_adoption_required');
    const gate = grants.sourceGate(parsed.subject);
    if (!gate.enabled || gate.deploymentEpoch === null) throw new Error('github_source_gate_unqualified');
    const token: GitHubSourceControlToken = GitHubSourceControlTokenSchema.parse({
      operationId: parsed.operationId, principal: this.#identity.principal, agent: this.#identity.agent,
      subject: { repositoryId: parsed.subject.repositoryId, prNumber: parsed.subject.prNumber },
      sourceIncarnation: 1, watchIncarnation: 0, routingRevision: 0, lifecycleEpoch: 1,
      obligationId: crypto.randomUUID(), action: 'activate', mode: 'source_only', installationId: parsed.subject.installationId,
      grantRevision: grant.revision, mappingRevision: grant.mappingRevision, policyRevision: grant.policyRevision,
      sourceEnableGeneration: gate.generation,
    });
    const scheduleAt = Date.now();
    await this.ctx.storage.transaction(async () => {
      // Recheck grant, deployment epoch and generation after host readback; operation receipt + protected cleanup reservation + outbox + alarm commit together.
      const current = this.#githubGrants().grant(parsed.subject);
      const currentGate = this.#githubGrants().sourceGateInTransaction(parsed.subject);
      if (JSON.stringify(current) !== JSON.stringify(grant) || !currentGate.enabled || currentGate.generation !== gate.generation
        || currentGate.deploymentEpoch !== gate.deploymentEpoch) throw new Error('github_grant_conflict');
      if (JSON.stringify(this.#githubGrants().historicalSourceSubjects(parsed.subject)) !== historyJson)
        throw new Error('github_source_conflict');
      const reservation = this.#githubSourceControls.reserve({ operationId: parsed.operationId, kind, request, subject: parsed.subject, token, phase: 'prepare', now: scheduleAt });
      if (reservation === 'reserved') this.#markCanonicalSourceControlSchema();
      await this.ctx.storage.setAlarm(scheduleAt);
    });
    await this.#drainGitHubSourceOutbox();
    return this.githubSourceStatus(parsed.subject, parsed.operationId);
  }
  async adoptGitHubSource(input: z.infer<typeof GitHubSourceAdoptionInputSchema>) {
    const parsed = GitHubSourceAdoptionInputSchema.parse(input), kind = 'adopt';
    const request = { principal: this.#identity.principal, agent: this.#identity.agent, kind, ...parsed };
    const existing = this.#githubSourceControls.exactOperation(parsed.operationId, request, Date.now());
    if (existing) {
      await this.#drainGitHubSourceOutbox();
      return this.githubSourceStatus(parsed.subject, parsed.operationId);
    }
    if (this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED !== 'true') throw new Error('github_source_control_unavailable');
    const grants = this.#githubGrants(), grant = grants.grant(parsed.subject);
    if (!grant || grant.revision !== parsed.expectedRevision) throw new Error('github_grant_conflict');
    if (!this.env.GITHUB_ATTENTION_HOST) throw new EventApiError('unavailable', 503);
    const historicalSubjects = grants.historicalSourceSubjects(parsed.subject), historyJson = JSON.stringify(historicalSubjects);
    const preflights = await Promise.all(historicalSubjects.map(subject => {
      const identity = { ...this.#identity, subject };
      return this.env.GITHUB_ATTENTION_HOST!.getByName(githubHostName(identity)).sourceStatus(identity);
    }));
    const raced = this.#githubSourceControls.exactOperation(parsed.operationId, request, Date.now());
    if (raced) {
      await this.#drainGitHubSourceOutbox();
      return this.githubSourceStatus(parsed.subject, parsed.operationId);
    }
    const requestedIndex = historicalSubjects.findIndex(subject => subject.installationId === parsed.subject.installationId);
    const preflight = requestedIndex < 0 ? null : preflights[requestedIndex];
    if (preflights.some((status, index) => index !== requestedIndex && (status.status !== 'absent' || status.hostControl !== 'absent')))
      throw new Error('github_legacy_adoption_required');
    if (parsed.expectedControl) {
      const predecessor = this.#githubSourceControls.control(parsed.subject);
      if (!predecessor || predecessor.state !== 'parked' || predecessor.token.installationId !== parsed.subject.installationId
        || predecessor.token.operationId !== parsed.expectedControl.operationId
        || predecessor.token.sourceIncarnation !== parsed.expectedControl.sourceIncarnation
        || predecessor.token.lifecycleEpoch !== parsed.expectedControl.lifecycleEpoch
        || !preflight || preflight.status === 'absent' || preflight.hostControl !== 'parked'
        || preflight.sourceVersion !== parsed.expectedSourceVersion || preflight.hostEpoch !== parsed.expectedHostEpoch)
        throw new Error('github_source_conflict');
      // The host must reserve three increments for revalidation, activation,
      // and a possible later park. Reject before creating an outbox obligation
      // when the displayed parked checkpoint cannot support that lifecycle.
      if (predecessor.token.lifecycleEpoch >= Number.MAX_SAFE_INTEGER
        || preflight.hostEpoch >= Number.MAX_SAFE_INTEGER - 2) throw new Error('github_source_conflict');
      const gate = grants.sourceGate(parsed.subject);
      if (!gate.enabled || gate.deploymentEpoch === null) throw new Error('github_source_gate_unqualified');
      const token: GitHubSourceControlToken = GitHubSourceControlTokenSchema.parse({
        operationId: parsed.operationId, principal: this.#identity.principal, agent: this.#identity.agent,
        subject: { repositoryId: parsed.subject.repositoryId, prNumber: parsed.subject.prNumber },
        sourceIncarnation: predecessor.token.sourceIncarnation, watchIncarnation: 0, routingRevision: 0,
        lifecycleEpoch: predecessor.token.lifecycleEpoch + 1, obligationId: crypto.randomUUID(), action: 'activate', mode: 'source_only',
        installationId: parsed.subject.installationId, grantRevision: grant.revision, mappingRevision: grant.mappingRevision,
        policyRevision: grant.policyRevision, sourceEnableGeneration: gate.generation,
      });
      const scheduleAt = Date.now();
      await this.ctx.storage.transaction(async () => {
        const currentGrant = this.#githubGrants().grant(parsed.subject);
        const currentGate = this.#githubGrants().sourceGateInTransaction(parsed.subject);
        const currentControl = this.#githubSourceControls.control(parsed.subject);
        if (JSON.stringify(currentGrant) !== JSON.stringify(grant) || !currentGate.enabled || currentGate.generation !== gate.generation
          || currentGate.deploymentEpoch !== gate.deploymentEpoch || !currentControl || currentControl.state !== 'parked'
          || !sourceTokenEquals(currentControl.token, predecessor.token)
          || JSON.stringify(this.#githubGrants().historicalSourceSubjects(parsed.subject)) !== historyJson)
          throw new Error('github_grant_conflict');
        this.#githubSourceControls.reserveRevalidation({ operationId: parsed.operationId, request, subject: parsed.subject,
          predecessor: predecessor.token, token, now: scheduleAt });
        await this.ctx.storage.setAlarm(scheduleAt);
      });
      await this.#drainGitHubSourceOutbox();
      return this.githubSourceStatus(parsed.subject, parsed.operationId);
    }
    if (!preflight || preflight.status === 'absent' || preflight.hostControl !== 'absent'
      || preflight.sourceVersion !== parsed.expectedSourceVersion || preflight.hostEpoch !== parsed.expectedHostEpoch)
      throw new Error('github_source_conflict');
    const gate = grants.sourceGate(parsed.subject);
    if (!gate.enabled || gate.deploymentEpoch === null) throw new Error('github_source_gate_unqualified');
    const token: GitHubSourceControlToken = GitHubSourceControlTokenSchema.parse({
      operationId: parsed.operationId, principal: this.#identity.principal, agent: this.#identity.agent,
      subject: { repositoryId: parsed.subject.repositoryId, prNumber: parsed.subject.prNumber },
      sourceIncarnation: 1, watchIncarnation: 0, routingRevision: 0, lifecycleEpoch: 1,
      obligationId: crypto.randomUUID(), action: 'activate', mode: 'source_only', installationId: parsed.subject.installationId,
      grantRevision: grant.revision, mappingRevision: grant.mappingRevision, policyRevision: grant.policyRevision,
      sourceEnableGeneration: gate.generation,
    });
    const scheduleAt = Date.now();
    await this.ctx.storage.transaction(async () => {
      const current = this.#githubGrants().grant(parsed.subject);
      const currentGate = this.#githubGrants().sourceGateInTransaction(parsed.subject);
      if (JSON.stringify(current) !== JSON.stringify(grant) || !currentGate.enabled || currentGate.generation !== gate.generation
        || currentGate.deploymentEpoch !== gate.deploymentEpoch) throw new Error('github_grant_conflict');
      if (JSON.stringify(this.#githubGrants().historicalSourceSubjects(parsed.subject)) !== historyJson)
        throw new Error('github_source_conflict');
      const reservation = this.#githubSourceControls.reserve({ operationId: parsed.operationId, kind, request, subject: parsed.subject, token, phase: 'quiesce', now: scheduleAt });
      if (reservation === 'reserved') this.#markCanonicalSourceControlSchema();
      await this.ctx.storage.setAlarm(scheduleAt);
    });
    await this.#drainGitHubSourceOutbox();
    return this.githubSourceStatus(parsed.subject, parsed.operationId);
  }
  async currentGitHubSourceControl(subject: GitHubSubjectV1): Promise<{ token: GitHubSourceControlToken; state: 'activation_pending' | 'active'; deploymentEpoch: number } | null> {
    const control = this.#githubSourceControls.control(subject);
    if (!control || control.state === 'parked') return null;
    const grants = this.#githubGrants();
    let gate: ReturnType<GitHubGrantStore['sourceGate']>;
    try { gate = grants.sourceGate(subject); } catch { return null; }
    const grant = grants.grant(subject);
    if (!gate.enabled || gate.deploymentEpoch === null || grant === null || gate.generation !== control.token.sourceEnableGeneration
      || grant.revision !== control.token.grantRevision || grant.mappingRevision !== control.token.mappingRevision
      || grant.policyRevision !== control.token.policyRevision || control.token.installationId !== subject.installationId
      || control.token.principal !== this.#identity.principal || control.token.agent !== this.#identity.agent) return null;
    return { token: control.token, state: control.state, deploymentEpoch: gate.deploymentEpoch };
  }
  async githubSourceFenceStatus(subject: GitHubSubjectV1): Promise<GitHubSourceFenceStatus> {
    const grants = this.#githubGrants();
    let deploymentEpoch: number | null;
    try { deploymentEpoch = grants.sourceGate(subject).deploymentEpoch; }
    catch { deploymentEpoch = null; }
    const pending = this.#githubSourceControls.pendingFor(subject);
    if (pending && (pending.phase === 'park' || pending.phase === 'revalidate')) {
      let token: GitHubSourceControlToken;
      try { token = GitHubSourceControlTokenSchema.parse(JSON.parse(pending.token_json)); } catch { throw new Error('github_source_unavailable'); }
      return { mode: 'pending', operationId: pending.operation_id, phase: pending.phase, token, deploymentEpoch };
    }
    const control = this.#githubSourceControls.control(subject);
    if (control) return { mode: 'controlled', token: control.token, state: control.state, deploymentEpoch };
    if (pending) return { mode: 'pending', operationId: pending.operation_id, phase: pending.phase, deploymentEpoch };
    return { mode: 'legacy', deploymentEpoch };
  }
  #sourceTokenCurrent(token: GitHubSourceControlToken, inTransaction = false): boolean {
    try {
      const subject = { installationId: token.installationId, repositoryId: token.subject.repositoryId, prNumber: token.subject.prNumber };
      const grants = this.#githubGrants();
      const gate = inTransaction ? grants.sourceGateInTransaction(subject) : grants.sourceGate(subject);
      const grant = grants.grant(subject);
      return !!grant && gate.enabled && gate.deploymentEpoch !== null && gate.generation === token.sourceEnableGeneration
        && grant.revision === token.grantRevision && grant.mappingRevision === token.mappingRevision
        && grant.policyRevision === token.policyRevision;
    } catch { return false; }
  }
  #sourceTokenStatus(token: GitHubSourceControlToken, inTransaction = false): 'current' | 'stale' | 'unknown' {
    try {
      const subject = { installationId: token.installationId, repositoryId: token.subject.repositoryId, prNumber: token.subject.prNumber };
      // These explicit configuration and persisted-grant facts are sufficient
      // to revoke even when source-map parsing is temporarily unavailable.
      if (this.env.EVENT_GITHUB_ENABLED !== 'true' || this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED !== 'true') return 'stale';
      const grants = this.#githubGrants();
      const persistedGrant = grants.storedGrantValue(subject);
      if (!persistedGrant || !persistedGrant.enabled || persistedGrant.revision !== token.grantRevision
        || persistedGrant.mappingRevision !== token.mappingRevision || persistedGrant.policyRevision !== token.policyRevision) return 'stale';
      const gate = inTransaction ? grants.sourceGateEvidenceInTransaction(subject) : grants.sourceGateEvidence(subject);
      const stored = grants.storedGrant(subject);
      // Explicit gate disable, grant revocation/revision change, or mapping
      // replacement is affirmative stale evidence even if the deployment epoch
      // is unavailable. The gate generation alone is not sufficient: its
      // fail-closed sync also advances on an epoch read failure.
      if (!gate.configurationEnabled || !stored.grant || !stored.grant.enabled || !stored.mappingCurrent
        || stored.grant.revision !== token.grantRevision || stored.grant.mappingRevision !== token.mappingRevision
        || stored.grant.policyRevision !== token.policyRevision) return 'stale';
      const rawEpoch = githubSourceGateEpoch(this.env.EVENT_GITHUB_SOURCE_GATE_EPOCH);
      // sourceGate() marks epoch_invalid and may bump generation when the raw
      // epoch disappears. That alone is not proof of revocation; retain the
      // active obligation and retry until a valid changed epoch or explicit
      // authority revocation is observed.
      if (rawEpoch === null) return 'unknown';
      if (gate.deploymentEpoch !== rawEpoch) return gate.deploymentEpoch === null ? 'unknown' : 'stale';
      // A valid deployment epoch with a persisted invalid marker proves this
      // gate cannot reauthorize the old token under sourceGate's same-epoch
      // closure rule. Missing raw epoch alone remains unknown above.
      if (gate.epochInvalid) return 'stale';
      if (gate.generation < token.sourceEnableGeneration) return 'unknown';
      if (gate.generation > token.sourceEnableGeneration) return 'stale';
      return gate.enabled ? 'current' : 'unknown';
    } catch { return 'unknown'; }
  }
  #sourcePublicationAllowed(subject: GitHubSubjectV1, token?: GitHubSourceControlToken): boolean {
    try {
      const control = this.#githubSourceControls.control(subject), pending = this.#githubSourceControls.pendingFor(subject);
      if (control) return this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED === 'true' && control.state === 'active' && token !== undefined
        && sourceTokenEquals(control.token, token) && this.#sourceTokenCurrent(token, true);
      if (pending) return false;
      return this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED !== 'true' && token === undefined;
    } catch { return false; }
  }
  #markCanonicalSourceControlSchema(): void {
    this.#sql.exec("INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES (4,?)", Date.now());
  }
  async #auditActiveGitHubSources(parkRetryDelayMs = 0): Promise<void> {
    const due = this.#githubSourceControls.activeControlsDue(Date.now());
    for (const control of due) {
      await this.ctx.storage.transaction(async () => {
        const now = Date.now();
        const current = this.#githubSourceControls.control(control.token.subject);
        if (!current || current.state !== 'active' || current.operation_id !== control.operation_id
          || !sourceTokenEquals(current.token, control.token)) return;
        const authority = this.#sourceTokenStatus(control.token, true);
        const parkRetryAt = now + parkRetryDelayMs;
        if (authority === 'stale' && this.#githubSourceControls.beginActiveParking(control.token, now, parkRetryAt)) {
          const alarm = await this.ctx.storage.getAlarm();
          const nextAlarm = Math.max(now + 250, parkRetryAt);
          if (alarm === null || alarm > nextAlarm) await this.ctx.storage.setAlarm(nextAlarm);
          return;
        }
        // Current and unknown authority both remain monitored. Advancing this
        // timestamp is a heartbeat, not a terminal receipt timestamp.
        if (this.#githubSourceControls.touchActiveControl(control.token, now)) {
          const next = now + GITHUB_SOURCE_CONTROL_LIMITS.activeAuthorityAuditIntervalMs;
          const alarm = await this.ctx.storage.getAlarm();
          if (alarm === null || alarm > next) await this.ctx.storage.setAlarm(next);
        }
      });
    }
  }
  async #drainGitHubSourceOutbox(): Promise<void> {
    const namespace = this.env.GITHUB_ATTENTION_HOST;
    if (!namespace) {
      const now = Date.now(), unavailableRetryAt = now + retryDelay(0);
      await this.#auditActiveGitHubSources(retryDelay(0));
      // Deferral and its wake are one durable transition. Otherwise a crash
      // after advancing a prepare-only outbox row could leave it with no alarm.
      await this.ctx.storage.transaction(async () => {
        this.#githubSourceControls.deferDueOutbox(now, unavailableRetryAt);
        const nextSourceWake = this.#githubSourceControls.nextAt();
        if (nextSourceWake !== null) {
          const due = Math.max(Date.now() + 250, nextSourceWake);
          const alarm = await this.ctx.storage.getAlarm();
          if (alarm === null || alarm > due) await this.ctx.storage.setAlarm(due);
        }
      });
      return;
    }
    // Audit due active controls and persist their next wake before any host
    // RPC. Each outbox claim below separately commits its lease wake, avoiding
    // unrelated queue deadlines being scheduled before their retry is known.
    await this.#auditActiveGitHubSources();
    for (let index = 0; index < 8; index++) {
      const now = Date.now(), claimId = crypto.randomUUID();
      const item = await this.ctx.storage.transaction(async () => {
        const claimed = this.#githubSourceControls.claim(now, claimId);
        if (claimed?.claim_until !== null && claimed?.claim_until !== undefined) {
          const currentAlarm = await this.ctx.storage.getAlarm();
          if (currentAlarm === null || currentAlarm > claimed.claim_until) await this.ctx.storage.setAlarm(claimed.claim_until);
        }
        return claimed;
      });
      if (!item) break;
      let token: GitHubSourceControlToken;
      try { token = GitHubSourceControlTokenSchema.parse(JSON.parse(item.token_json)); }
      catch {
        this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, 'invalid_token', Date.now() + retryDelay(item.attempts), Date.now()));
        continue;
      }
      // Parking after activation is owned by the immutable canonical token and
      // cleanup bundle. Operation/request receipts may have expired already.
      if (item.phase === 'park') {
        const identity = { principal: token.principal, agent: token.agent, subject: { installationId: token.installationId, ...token.subject } };
        try {
          const host = namespace.getByName(githubHostName(identity));
          const raw = await host.parkSourceControlled(identity, item.operation_id, token);
          const parked = GitHubSourceParkingResultSchema.parse(raw);
          const committed = this.ctx.storage.transactionSync(() => this.#githubSourceControls.settleParking(item.operation_id, claimId, parked, Date.now()));
          if (!committed) this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, 'park_settlement_pending', Date.now() + retryDelay(item.attempts), Date.now()));
        } catch (error) {
          const reason = error instanceof Error && /^[a-z0-9_]{1,64}$/.test(error.message) ? error.message : 'host_unavailable';
          this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, reason, Date.now() + retryDelay(item.attempts), Date.now()));
        }
        continue;
      }
      const operation = this.#githubSourceControls.operation(item.operation_id);
      if (!operation) {
        const retryAt = Date.now() + retryDelay(item.attempts);
        this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, 'missing_receipt', retryAt, Date.now()));
        continue;
      }
      let request: { subject: GitHubSubjectV1 & { installationId: number }; expectedSourceVersion?: number; expectedHostEpoch?: number; expectedControl?: { operationId: string; sourceIncarnation: number; lifecycleEpoch: number } };
      try { request = JSON.parse(operation.request_json) as typeof request; }
      catch {
        const retryAt = Date.now() + retryDelay(item.attempts);
        this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, 'invalid_request', retryAt, Date.now()));
        continue;
      }
      const identity = { principal: token.principal, agent: token.agent, subject: { installationId: token.installationId, ...token.subject } };
      const host = namespace.getByName(githubHostName(identity));
      let reason = 'host_unavailable';
      try {
        const authority = this.#sourceTokenStatus(token);
        if (item.phase !== 'prepare' && authority === 'stale') {
          this.ctx.storage.transactionSync(() => this.#githubSourceControls.beginParking(item.operation_id, claimId, Date.now()));
          continue;
        }
        if (authority === 'unknown') {
          this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, 'authority_unavailable', Date.now() + retryDelay(item.attempts), Date.now()));
          continue;
        }
        if (authority === 'stale') {
          // A stale prepare may already have left its exact host marker behind
          // after a lost reply. Refuse only after the host acknowledges that
          // marker is absent or safely cancelled; unknown outcomes stay leased.
          const cancelled = await host.cancelPreparedSourceInitialization(identity, item.operation_id);
          if (cancelled) this.ctx.storage.transactionSync(() => this.#githubSourceControls.failPrepare(item.operation_id, claimId, 'authority_changed', Date.now()));
          else this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, 'authority_changed', Date.now() + retryDelay(item.attempts), Date.now()));
          continue;
        }
        if (item.phase === 'prepare') {
          const prepared = await host.prepareSourceInitialization(identity, item.operation_id);
          if (prepared.status === 'legacy') {
            this.ctx.storage.transactionSync(() => this.#githubSourceControls.failPrepare(item.operation_id, claimId, 'legacy_source_present', Date.now()));
            continue;
          }
          const postPrepareAuthority = this.#sourceTokenStatus(token);
          if (postPrepareAuthority === 'stale') {
            const cancelled = await host.cancelPreparedSourceInitialization(identity, item.operation_id);
            if (cancelled) this.ctx.storage.transactionSync(() => this.#githubSourceControls.failPrepare(item.operation_id, claimId, 'authority_changed', Date.now()));
            else {
              const retryAt = Date.now() + retryDelay(item.attempts);
              this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, 'authority_changed', retryAt, Date.now()));
            }
            continue;
          }
          if (postPrepareAuthority === 'unknown') {
            this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, 'authority_unavailable', Date.now() + retryDelay(item.attempts), Date.now()));
            continue;
          }
          const committed = await this.ctx.storage.transaction(async () => {
            if (!this.#sourceTokenCurrent(token, true)) return false;
            return this.#githubSourceControls.settlePrepare(item.operation_id, claimId, Date.now());
          });
          if (!committed) {
            const afterCommitCheck = this.#sourceTokenStatus(token);
            if (afterCommitCheck === 'stale') this.ctx.storage.transactionSync(() => this.#githubSourceControls.beginParking(item.operation_id, claimId, Date.now()));
            else this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, afterCommitCheck === 'unknown' ? 'authority_unavailable' : 'authority_changed', Date.now() + retryDelay(item.attempts), Date.now()));
          }
          continue;
        }
        if (item.phase === 'revalidate') {
          if (!request.expectedControl) throw new Error('github_source_conflict');
          const raw = await host.revalidateParkedSource(identity, {
            operationId: item.operation_id, token, expectedControl: request.expectedControl,
            expectedSourceVersion: request.expectedSourceVersion ?? -1, expectedHostEpoch: request.expectedHostEpoch ?? -1,
          });
          const revalidated = GitHubSourceRevalidationResultSchema.parse(raw);
          if (revalidated.operationId !== item.operation_id || !sourceTokenEquals(revalidated.token, token)
            || revalidated.sourceVersion !== request.expectedSourceVersion || revalidated.hostEpoch <= (request.expectedHostEpoch ?? Number.MAX_SAFE_INTEGER))
            throw new Error('github_source_conflict');
          const postRevalidationAuthority = this.#sourceTokenStatus(token);
          if (postRevalidationAuthority === 'stale') {
            this.ctx.storage.transactionSync(() => this.#githubSourceControls.beginParking(item.operation_id, claimId, Date.now()));
            continue;
          }
          if (postRevalidationAuthority === 'unknown') {
            this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, 'authority_unavailable', Date.now() + retryDelay(item.attempts), Date.now()));
            continue;
          }
          const committed = await this.ctx.storage.transaction(async () => {
            if (!this.#sourceTokenCurrent(token, true)) return false;
            return this.#githubSourceControls.settleRevalidation(item.operation_id, claimId, Date.now());
          });
          if (!committed) {
            const afterCommitCheck = this.#sourceTokenStatus(token);
            if (afterCommitCheck === 'stale') this.ctx.storage.transactionSync(() => this.#githubSourceControls.beginParking(item.operation_id, claimId, Date.now()));
            else this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId,
              afterCommitCheck === 'unknown' ? 'authority_unavailable' : 'authority_changed', Date.now() + retryDelay(item.attempts), Date.now()));
          }
          continue;
        }
        if (item.phase === 'quiesce') {
          const quiesced = await host.quiesceLegacySource(identity, item.operation_id, request.expectedSourceVersion ?? -1, request.expectedHostEpoch ?? -1);
          if (quiesced.status === 'checkpoint_conflict') {
            if (quiesced.operationId !== item.operation_id || quiesced.hostControl !== 'absent'
              || quiesced.expectedSourceVersion !== request.expectedSourceVersion || quiesced.expectedHostEpoch !== request.expectedHostEpoch)
              throw new Error('github_source_conflict');
            this.ctx.storage.transactionSync(() => this.#githubSourceControls.failQuiesce(item.operation_id, claimId, quiesced.reason === 'host_epoch_exhausted'
              ? 'host_epoch_exhausted' : 'source_checkpoint_changed', Date.now()));
            continue;
          }
          if (quiesced.status !== 'quiesced' || quiesced.operationId !== item.operation_id
            || quiesced.sourceVersion !== request.expectedSourceVersion || quiesced.hostEpoch <= (request.expectedHostEpoch ?? Number.MAX_SAFE_INTEGER))
            throw new Error('github_source_conflict');
          const postQuiesceAuthority = this.#sourceTokenStatus(token);
          if (postQuiesceAuthority === 'stale') {
            this.ctx.storage.transactionSync(() => this.#githubSourceControls.beginParking(item.operation_id, claimId, Date.now()));
            continue;
          }
          if (postQuiesceAuthority === 'unknown') {
            const retryAt = Date.now() + retryDelay(item.attempts);
            this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, 'authority_unavailable', retryAt, Date.now()));
            continue;
          }
          const committed = await this.ctx.storage.transaction(async () => {
            if (!this.#sourceTokenCurrent(token, true)) return false;
            return this.#githubSourceControls.settleQuiesce(item.operation_id, claimId, Date.now());
          });
          if (!committed) {
            const afterCommitCheck = this.#sourceTokenStatus(token);
            if (afterCommitCheck === 'stale') this.ctx.storage.transactionSync(() => this.#githubSourceControls.beginParking(item.operation_id, claimId, Date.now()));
            else this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId,
              afterCommitCheck === 'unknown' ? 'authority_unavailable' : 'authority_changed', Date.now() + retryDelay(item.attempts), Date.now()));
          }
          continue;
        }
        const activated = await host.activateSourceControlled(identity, item.operation_id, token);
        if (activated.hostControl !== 'active') throw new Error('github_source_fenced');
        const postActivationAuthority = this.#sourceTokenStatus(token);
        if (postActivationAuthority === 'stale') {
          this.ctx.storage.transactionSync(() => this.#githubSourceControls.beginParking(item.operation_id, claimId, Date.now()));
          continue;
        }
        if (postActivationAuthority === 'unknown') {
          const retryAt = Date.now() + retryDelay(item.attempts);
          this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, 'authority_unavailable', retryAt, Date.now()));
          continue;
        }
        const committed = await this.ctx.storage.transaction(async () => {
          if (!this.#sourceTokenCurrent(token, true)) return false;
          const settled = this.#githubSourceControls.settleActivation(item.operation_id, claimId, Date.now());
          if (settled) {
            const next = this.#githubSourceControls.nextAt();
            const alarm = await this.ctx.storage.getAlarm();
            if (next !== null && (alarm === null || alarm > next)) await this.ctx.storage.setAlarm(next);
          }
          return settled;
        });
        if (!committed) {
          const afterCommitCheck = this.#sourceTokenStatus(token);
          if (afterCommitCheck === 'stale') this.ctx.storage.transactionSync(() => this.#githubSourceControls.beginParking(item.operation_id, claimId, Date.now()));
          else this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId,
            afterCommitCheck === 'unknown' ? 'authority_unavailable' : 'authority_changed', Date.now() + retryDelay(item.attempts), Date.now()));
        }
      } catch (error) {
        reason = error instanceof Error && /^[a-z0-9_]{1,64}$/.test(error.message) ? error.message : 'host_unavailable';
        const retryAt = Date.now() + retryDelay(item.attempts);
        this.ctx.storage.transactionSync(() => this.#githubSourceControls.retry(item.operation_id, claimId, reason, retryAt, Date.now()));
      }
    }
    await this.#scheduleGitHubSourceWake();
  }
  async #scheduleGitHubSourceWake(): Promise<void> {
    const next = this.#githubSourceControls.nextAt();
    if (next !== null) await this.#arm(Math.max(Date.now() + 250, next));
  }
  async githubGrant(subject: GitHubSubjectV1) { return this.#githubGrants().grant(subject); }
  async githubWatches() {
    if (!principalAllowed({ ALLOWED_PRINCIPALS: this.env.ALLOWED_PRINCIPALS ?? "" }, this.#identity.principal)) return [];
    return this.#githubGrants().watches();
  }
  async githubPublicationReceipt(input: GitHubPublicationInput) { return this.#githubGrants().publicationReceipt(input); }
  async githubPublicationStatus(input: GitHubPublicationInput): Promise<GitHubPublicationDisposition | null> { return this.#githubGrants().publicationDisposition(input); }
  async adoptGitHubPublication(input: GitHubPublicationInput, pin: GitHubPublicationPin): Promise<GitHubPublicationDisposition | null> { return this.#githubGrants().adoptPublication(input, pin); }
  async publishGitHub(input: GitHubPublicationInput, pin: GitHubPublicationPin, sourceToken?: GitHubSourceControlToken) {
    const grants = this.#githubGrants();
    // The grant-store receipt transaction invokes the fence callback immediately
    // before a new durable write. Legacy host calls are accepted only while no
    // canonical operation or migration reservation exists and the release gate
    // remains off; controlled calls must match the exact current token.
    return grants.acceptPublication(input, pin, Date.now(), () => this.#sourcePublicationAllowed(input.event.subject, sourceToken));
  }
  async settleGitHubPublication(input: GitHubPublicationInput): Promise<GitHubPublicationDisposition> { return this.#githubGrants().settlePublication(input); }
  async terminalGitHubPublication(input: GitHubPublicationInput): Promise<GitHubPublicationDisposition> { return this.#githubGrants().terminalPublication(input); }
  async acknowledgeGitHubPublicationRelease(input: GitHubPublicationInput, disposition: 'settled' | 'terminal') {
    return this.#githubGrants().acknowledgePublicationRelease(input, disposition);
  }

  async status(): Promise<Status> {
    const counts: EventDeliveryCounts = { pending: 0, submitted: 0, ambiguous: 0, expired: 0, observed: 0, failed: 0, over_budget: 0, unavailable: 0, revoked: 0 };
    for (const item of this.#sql.exec<{ state: string; count: number }>("SELECT state,count(*) AS count FROM deliveries GROUP BY state")) {
      if (item.state === "pending") counts.pending += item.count;
      else if (item.state in counts) counts[item.state as keyof EventDeliveryCounts] = item.count;
    }
    counts.over_budget = row<{ count: number }>(this.#sql, "SELECT count(*) AS count FROM deliveries WHERE reason='over_budget'")?.count ?? 0;
    counts.unavailable = row<{ count: number }>(this.#sql,
      "SELECT count(*) AS count FROM deliveries WHERE reason IN ('transport_unavailable','authority_unavailable')")?.count ?? 0;
    counts.revoked = row<{ count: number }>(this.#sql, "SELECT count(*) AS count FROM deliveries WHERE reason LIKE '%revoked%'")?.count ?? 0;
    const state = row<{ enabled: number }>(this.#sql, "SELECT enabled FROM coordinator_state WHERE id=1");
    const total = row<{ count: number }>(this.#sql, "SELECT count(*) AS count FROM deliveries")?.count ?? 0;
    const recent = this.#sql.exec<{ delivery_id: string; runtime_id: string; state: string; reason: string | null; created_at: number }>(
      "SELECT delivery_id,runtime_id,state,reason,created_at FROM deliveries ORDER BY created_at DESC,delivery_id DESC LIMIT 20").toArray()
      .map(value => ({ deliveryId: value.delivery_id, runtimeId: value.runtime_id, state: value.state, reason: value.reason, createdAt: value.created_at }));
    return { enabled: state?.enabled === 1, counts, recent, recentLimit: 20, recentTruncated: total > recent.length };
  }

  async setEnabled(input: { enabled: boolean }): Promise<{ enabled: boolean }> {
    const parsed = enabledInputSchema.safeParse(input);
    if (!parsed.success) throw new Error("invalid");
    if (parsed.data.enabled && this.env.EVENT_ENABLED !== "true") throw new EventApiError("runtime_disabled", 503);
    this.ctx.storage.transactionSync(() => {
      this.#sql.exec("UPDATE coordinator_state SET enabled=? WHERE id=1", Number(parsed.data.enabled));
      if (parsed.data.enabled) this.#sql.exec(`UPDATE queue_outbox SET due_at=?,state='queued'
        WHERE delivery_id IN (SELECT delivery_id FROM deliveries WHERE state='pending' AND transport_state!='accepted')`, Date.now());
      else this.#sql.exec("UPDATE queue_outbox SET due_at=?,state='queued' WHERE due_at<?", Date.now() + EVENT_POLICY_V1.recoveryBackoffMaxMs, Date.now());
    });
    await this.#schedule();
    return { enabled: parsed.data.enabled };
  }

  async publishManual(input: { runtimeId: string; subjectId: string }): Promise<{ deliveryId: string }> {
    const parsed = manualInputSchema.safeParse(input);
    if (!parsed.success) throw new Error("invalid");
    requireManualCanary(this.env, this.#identity, parsed.data.subjectId);
    const runtime = this.#runtime(parsed.data.runtimeId);
    if (!this.#enabled() || !this.#runtimeReady(runtime, Date.now())) throw new Error("denied");
    const source = this.#source(parsed.data.subjectId);
    const eventId = source?.event_id ?? crypto.randomUUID();
    const sourceVersion = source?.source_state_version ?? `v1-${crypto.randomUUID()}`;
    const eventReference = source?.event_reference ?? `ref_${crypto.randomUUID()}`;
    const observedAt = source?.observed_at ?? nowIso();
    const deliveryId = await deriveDeliveryId({ eventId, runtimeId: runtime.runtime_id,
      runtimeGeneration: runtime.runtime_generation, nodeGeneration: runtime.node_generation,
      attachmentGeneration: runtime.attachment_generation });
    requireManualCanary(this.env, this.#identity, parsed.data.subjectId);
    const prior = row<{ delivery_id: string }>(this.#sql, "SELECT delivery_id FROM deliveries WHERE delivery_id=?", deliveryId);
    if (prior) return manualPublicationResult(this.#delivery(deliveryId), deliveryId);
    if (source) throw new Error("conflict");

    const now = Date.now();
    await this.#arm(now);
    this.ctx.storage.transactionSync((): void => {
      requireManualCanary(this.env, this.#identity, parsed.data.subjectId);
      const currentSource = this.#source(parsed.data.subjectId);
      if (currentSource) {
        const replay = row<{ delivery_id: string }>(this.#sql, "SELECT delivery_id FROM deliveries WHERE delivery_id=?", deliveryId);
        if (currentSource.event_id === eventId && replay) return;
        throw new Error("conflict");
      }
      const currentTime = Date.now();
      if (!this.#enabled() || !this.#sameRuntime(runtime, parsed.data.runtimeId, currentTime)) throw new Error("conflict");
      const sourceCount = row<{ count: number }>(this.#sql, "SELECT count(*) AS count FROM manual_sources")?.count ?? 0;
      const activeCount = row<{ count: number }>(this.#sql,
        "SELECT count(*) AS count FROM runtimes WHERE qualified=1 AND lease_until>?", currentTime)?.count ?? 0;
      const totalRuntimeCount = row<{ count: number }>(this.#sql, "SELECT count(*) AS count FROM runtimes")?.count ?? 0;
      const pendingCount = row<{ count: number }>(this.#sql,
        "SELECT count(*) AS count FROM deliveries WHERE state IN ('pending','submitted','ambiguous')")?.count ?? 0;
      if (!currentSource && sourceCount >= EVENT_POLICY_V1.maxWatchesPerAgent) throw new Error("capacity");
      if (activeCount > EVENT_POLICY_V1.pilotAdmittedSessionsPerAgent || totalRuntimeCount > EVENT_POLICY_V1.maxRuntimesPerAgent) throw new Error("capacity");
      if (pendingCount >= EVENT_POLICY_V1.maxPendingDeliveriesPerAgent) throw new Error("capacity");
      this.#sql.exec("INSERT OR IGNORE INTO manual_sources(subject_id,event_id,source_state_version,event_reference,observed_at,created_at) VALUES (?,?,?,?,?,?)",
        parsed.data.subjectId, eventId, sourceVersion, eventReference, observedAt, currentTime);
      const already = row<{ delivery_id: string }>(this.#sql, "SELECT delivery_id FROM deliveries WHERE delivery_id=?", deliveryId);
      if (already) return;
      this.#sql.exec(`INSERT OR IGNORE INTO deliveries(delivery_id,event_id,subject_id,source_state_version,runtime_id,runtime_generation,
        attachment_generation,node_id,node_generation,state,reason,created_at,retry_until,transport_state)
        VALUES (?,?,?,?,?,?,?,?,?,'pending',NULL,?,?, 'queued')`, deliveryId, eventId, parsed.data.subjectId, sourceVersion,
        runtime.runtime_id, runtime.runtime_generation, runtime.attachment_generation, runtime.node_id, runtime.node_generation,
        currentTime, currentTime + EVENT_POLICY_V1.deliveryTransportRetryHorizonMs);
      this.#sql.exec("INSERT OR IGNORE INTO slot_intents(delivery_id,node_id,node_generation,state,updated_at) VALUES (?,?,?,'reserve_pending',?)",
        deliveryId, runtime.node_id, runtime.node_generation, currentTime);
    });
    await this.#arm(Date.now() + EVENT_POLICY_V1.recoveryBackoffInitialMs);
    await this.#reserveSlot(deliveryId);
    await this.#schedule();
    return manualPublicationResult(this.#delivery(deliveryId), deliveryId);
  }

  /** Public transfer stays fail closed until a reviewed native binding can qualify it. */
  async transfer(input: { runtimeId: string; replacementRuntimeId: string; expectedAttachmentGeneration: number }): Promise<{ attachmentGeneration: number }> {
    if (!transferInputSchema.safeParse(input).success) throw new Error("invalid");
    throw new Error("native_binding_unqualified");
  }

  async createNativeRuntimeChallenge(input: unknown, scope: {
    principal: string; agent: string; keyThumbprint: string; nodeId: string; nodeGeneration: number;
  }): Promise<{ challengeId: string; issuedAt: string; expiresAt: string }> {
    this.#requireNativeBindingEnabled();
    const parsed = NativeRuntimeChallengeRequestSchema.safeParse(input);
    if (!parsed.success || scope.principal !== this.#identity.principal || scope.agent !== this.#identity.agent
      || !nativeKeyThumbprint.safeParse(scope.keyThumbprint).success || !uuid.safeParse(scope.nodeId).success
      || !Number.isSafeInteger(scope.nodeGeneration) || scope.nodeGeneration < 1) throw new Error("invalid");
    const issuedAt = Date.now(), expiresAt = issuedAt + NATIVE_RUNTIME_CHALLENGE_TTL_MS;
    const challengeId = crypto.randomUUID();
    this.ctx.storage.transactionSync(() => {
      this.#nativeStore.prune(issuedAt);
      const liveChallenges = row<{ count: number }>(this.#sql, `SELECT count(*) AS count FROM native_runtime_challenges
        WHERE consumed_at IS NULL AND expires_at>?`, issuedAt)?.count ?? 0;
      const liveReceipts = row<{ count: number }>(this.#sql, `SELECT count(*) AS count FROM native_runtime_challenges
        WHERE consumed_at IS NOT NULL AND receipt_expires_at>?`, issuedAt)?.count ?? 0;
      if (liveChallenges >= NATIVE_RUNTIME_MAX_LIVE_CHALLENGES_PER_AGENT
        || liveReceipts >= NATIVE_RUNTIME_MAX_LIVE_COMMIT_RECEIPTS_PER_AGENT) throw new Error("conflict");
      this.#sql.exec(`INSERT INTO native_runtime_challenges(challenge_id,operation,request_json,principal,agent,key_thumbprint,
        node_id,node_generation,issued_at,expires_at) VALUES (?,?,?,?,?,?,?,?,?,?)`, challengeId, parsed.data.operation,
        JSON.stringify(parsed.data), scope.principal, scope.agent, scope.keyThumbprint, scope.nodeId, scope.nodeGeneration, issuedAt, expiresAt);
    });
    return { challengeId, issuedAt: nowIso(issuedAt), expiresAt: nowIso(expiresAt) };
  }

  async readGitHubSource(rawBody: string, scope: NativeRuntimeCommitScope) {
    if (this.env.EVENT_ENABLED !== "true") throw new EventApiError("runtime_disabled", 503);
    const input = GitHubSourceReadRequestSchema.parse(parseApiJson(rawBody));
    if (new TextEncoder().encode(rawBody).length > 4096) throw new EventApiError("invalid", 400);
    const credentials = await authenticateReadAuthority(this.env, this.#identity, rawBody, scope, "/v1/github/source/read");
    const grant = this.#githubGrants().grant(input.subject);
    if (!grant) throw new EventApiError("denied", 403);
    if (!this.env.GITHUB_ATTENTION_HOST) throw new EventApiError("unavailable", 503);
    const identity = { ...this.#identity, subject: input.subject };
    const parsed = GitHubSourceReadResultSchema.safeParse(await withDeadline(
      this.env.GITHUB_ATTENTION_HOST.getByName(githubHostName(identity)).readSource(identity, input), 20_000));
    if (!parsed.success) throw new EventApiError("unavailable", 503);
    const result = parsed.data;
    await revalidateReadAuthority(this.env, scope, credentials);
    if (JSON.stringify(this.#githubGrants().grant(input.subject)) !== JSON.stringify(grant)) throw new EventApiError("denied", 403);
    if (result.status === "ok" && (JSON.stringify(result.subject) !== JSON.stringify(input.subject)
      || result.requestedRange.fromVersion !== input.fromVersion || result.requestedRange.toVersion !== input.toVersion)) throw new EventApiError("unavailable", 503);
    return result;
  }

  async runtimeStatus(rawBody: string, scope: NativeRuntimeCommitScope): Promise<NativeRuntimeStatusResponse> {
    this.#requireNativeBindingEnabled();
    const input = NativeRuntimeStatusRequestSchema.parse(parseApiJson(rawBody));
    await authenticateReadAuthority(this.env, this.#identity, rawBody, scope, "/v1/runtimes/status");
    this.#requireNativeBindingEnabled();
    return this.#nativeStore.readback(input.runtimeId, scope.keyThumbprint, Date.now());
  }

  async commitNativeRuntime(operation: "attach" | "renew" | "transfer", rawBody: string,
    scope: NativeRuntimeCommitScope): Promise<unknown> {
    this.#requireNativeBindingEnabled();
    const input = parseApiJson(rawBody);
    let parsed: NativeRuntimeCommitRequest;
    if (operation === "attach") {
      const result = NativeRuntimeAttachRequestSchema.safeParse(input);
      if (!result.success) throw new Error("invalid");
      parsed = result.data;
    } else if (operation === "renew") {
      const result = NativeRuntimeRenewRequestSchema.safeParse(input);
      if (!result.success) throw new Error("invalid");
      parsed = result.data;
    } else {
      const result = NativeRuntimeTransferRequestSchema.safeParse(input);
      if (!result.success) throw new Error("invalid");
      parsed = result.data;
    }
    const expectedPath = `/v1/runtimes/${operation}`;
    const credentials = z.strictObject({ accessAssertion: z.string().min(1).max(16_384), agentToken: z.string().min(1).max(4_096) }).safeParse(scope.credentials);
    if (scope.principal !== this.#identity.principal || scope.agent !== this.#identity.agent
      || !nativeKeyThumbprint.safeParse(scope.keyThumbprint).success || !uuid.safeParse(scope.proof.nodeId).success
      || !Number.isSafeInteger(scope.proof.nodeGeneration) || scope.proof.nodeGeneration < 1
      || scope.nodeId !== scope.proof.nodeId || scope.nodeGeneration !== scope.proof.nodeGeneration
      || !nativeProofDigest.safeParse(scope.bodySha256).success || !credentials.success
      || scope.proofBinding.method !== "POST" || scope.proofBinding.path !== expectedPath
      || scope.proofBinding.bodySha256 !== scope.bodySha256
      || !Number.isFinite(Date.parse(scope.proof.issuedAt)) || new Date(scope.proof.issuedAt).toISOString() !== scope.proof.issuedAt)
      throw new Error("invalid");
    const parsedEvidence = (parsed as NativeRuntimeCommitRequest).nativeEvidence;
    const evidenceWitness = NativeRuntimeWitnessSchema.parse(parsedEvidence.witness);
    const initialChallenge = row<NativeRuntimeChallengeRow>(this.#sql,
      "SELECT consumed_at FROM native_runtime_challenges WHERE challenge_id=?", parsed.challengeId);
    const replayAtEntry = initialChallenge?.consumed_at !== null && initialChallenge !== null;
    const observedAtAtEntry = Date.parse(parsedEvidence.observedAt);
    const evidenceAgeLimit = Math.min(evidenceWitness.leaseMs, NATIVE_RUNTIME_MAX_EVIDENCE_AGE_MS);
    const remainingEvidenceMs = evidenceAgeLimit - (Date.now() - observedAtAtEntry);
    let nativeDeadlineExpired = !replayAtEntry && remainingEvidenceMs <= 0;
    const evidenceTimer = replayAtEntry ? undefined : setTimeout(() => { nativeDeadlineExpired = true; }, Math.max(1, remainingEvidenceMs));
    try {
      const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(rawBody)));
      const actualBodySha256 = [...digest].map((byte) => byte.toString(16).padStart(2, "0")).join("");
      if (actualBodySha256 !== scope.bodySha256 || actualBodySha256 !== scope.proofBinding.bodySha256)
        throw new Error("invalid");
      const registry = this.env.OWNER_REGISTRY.getByName(JSON.stringify(["event-owner-v1", scope.principal]));
      let nodeAuth: NodeAuthorization;
      try { nodeAuth = await withDeadline<NodeAuthorization>(Promise.resolve(registry.authenticateNode(scope.proof, scope.proofBinding)), EVENT_POLICY_V1.nativeRpcDeadlineMs); }
      catch (error) {
        if (error instanceof EventApiError) throw error;
        throw new EventApiError("registry_unavailable", 503);
      }
      if (nodeAuth.status !== "authorized" || !nodeAuth.node.agents.includes(scope.agent)
        || nodeAuth.node.nodeId !== scope.proof.nodeId || nodeAuth.node.generation !== scope.proof.nodeGeneration)
        throw new EventApiError("node_denied", 403);
      let currentNode: NodeAuthorization;
      try { currentNode = await withDeadline<NodeAuthorization>(Promise.resolve(registry.currentNode({ nodeId: scope.proof.nodeId,
        agent: scope.agent, generation: scope.proof.nodeGeneration })), EVENT_POLICY_V1.nativeRpcDeadlineMs); }
      catch { throw new EventApiError("registry_unavailable", 503); }
      if (currentNode.status !== "authorized" || currentNode.node.nodeId !== nodeAuth.node.nodeId
        || currentNode.node.generation !== nodeAuth.node.generation || !currentNode.node.agents.includes(scope.agent))
        throw new EventApiError("node_denied", 403);
      let currentAuth;
      try { currentAuth = parseAuthorityAuthResult(await withDeadline(this.env.MESSAGE_AUTHORITY.currentAuth(credentials.data), EVENT_POLICY_V1.nativeRpcDeadlineMs)); }
      catch { throw new EventApiError("authority_unavailable", 503); }
      if (currentAuth.status === "unavailable") throw new EventApiError("authority_unavailable", 503);
      if (currentAuth.status !== "authorized" || currentAuth.identity.principal !== scope.principal
        || currentAuth.identity.agent !== scope.agent || currentAuth.identity.keyThumbprint !== scope.keyThumbprint)
        throw new EventApiError("denied", 403);
      let finalNode: NodeAuthorization;
      try { finalNode = await withDeadline<NodeAuthorization>(Promise.resolve(registry.currentNode({ nodeId: scope.proof.nodeId,
        agent: scope.agent, generation: scope.proof.nodeGeneration })), EVENT_POLICY_V1.nativeRpcDeadlineMs); }
      catch { throw new EventApiError("registry_unavailable", 503); }
      if (finalNode.status !== "authorized" || finalNode.node.nodeId !== nodeAuth.node.nodeId
        || finalNode.node.generation !== nodeAuth.node.generation || !finalNode.node.agents.includes(scope.agent))
        throw new EventApiError("node_denied", 403);

      return this.ctx.storage.transactionSync(() => {
        this.#requireNativeBindingEnabled();
        const now = Date.now();
        this.#nativeStore.prune(now);
        const challenge = row<NativeRuntimeChallengeRow>(this.#sql,
          "SELECT * FROM native_runtime_challenges WHERE challenge_id=?", parsed.challengeId);
        if (!challenge) throw new Error("expired");
        if (challenge.principal !== scope.principal || challenge.agent !== scope.agent
          || challenge.key_thumbprint !== scope.keyThumbprint || challenge.node_id !== nodeAuth.node.nodeId
          || challenge.node_generation !== nodeAuth.node.generation) throw new Error("denied");

        // A lost HTTP reply can be recovered by the exact same request body and fresh node proof.
        // The saved result is returned only while its complete target tuple is still current.
        if (challenge.consumed_at !== null) {
          if (challenge.receipt_expires_at === null || challenge.receipt_expires_at <= now
            || challenge.commit_hash !== scope.bodySha256 || !challenge.result_json) throw new Error("conflict");
          const saved = JSON.parse(challenge.result_json) as unknown;
          if (!this.#nativeStore.receiptIsCurrent(operation, saved, now, challenge.key_thumbprint)) throw new Error("conflict");
          return saved;
        }
        if (nativeDeadlineExpired) throw new EventApiError("native_binding_unqualified", 409);
        if (challenge.expires_at <= now) throw new Error("expired");
        if (challenge.operation !== operation) throw new Error("conflict");
        const nativeEvidence = parsed.nativeEvidence;
        const witness = NativeRuntimeWitnessSchema.parse(nativeEvidence.witness);
        const binding = bindingFromWitness(witness);
        const intent = JSON.parse(challenge.request_json) as NativeRuntimeChallengeRequest;
        if (!this.#nativeStore.challengeMatches(operation, intent, parsed, binding)) throw new Error("conflict");
        const observedAt = Date.parse(nativeEvidence.observedAt), proofIssuedAt = Date.parse(scope.proof.issuedAt);
        if (!Number.isFinite(observedAt) || new Date(observedAt).toISOString() !== nativeEvidence.observedAt
          || observedAt < challenge.issued_at || observedAt > proofIssuedAt || observedAt > now || now - observedAt < 0
          || now - observedAt > Math.min(witness.leaseMs, NATIVE_RUNTIME_MAX_EVIDENCE_AGE_MS))
          throw new EventApiError("native_binding_unqualified", 409);

        const receipts = row<{ count: number }>(this.#sql, `SELECT count(*) AS count FROM native_runtime_challenges
          WHERE consumed_at IS NOT NULL AND receipt_expires_at>?`, now)?.count ?? 0;
        if (receipts >= NATIVE_RUNTIME_MAX_LIVE_COMMIT_RECEIPTS_PER_AGENT) throw new Error("conflict");

        const result = this.#nativeStore.applyCommit(operation, parsed, { keyThumbprint: scope.keyThumbprint,
          nodeId: nodeAuth.node.nodeId, nodeGeneration: nodeAuth.node.generation }, binding, witness, now);
        const receiptExpiresAt = now + NATIVE_RUNTIME_COMMIT_RECEIPT_TTL_MS;
        const changed = this.#sql.exec(`UPDATE native_runtime_challenges SET consumed_at=?,receipt_expires_at=?,commit_hash=?,result_json=?
          WHERE challenge_id=? AND consumed_at IS NULL AND expires_at>?`, now, receiptExpiresAt, scope.bodySha256,
          JSON.stringify(result), parsed.challengeId, now).rowsWritten;
        if (changed < 1) throw new Error("conflict");
        return result;
      });
    } finally { if (evidenceTimer !== undefined) clearTimeout(evidenceTimer); }
  }

  #requireNativeBindingEnabled(): void {
    requireNativeAdmissionCanary(this.env, this.#identity);
  }

  async claim(input: { deliveryId: string; attemptId: string; nodeId: string; nodeGeneration: number }, credentials: EventAuthorityCredentialsV1): Promise<DispatchClaimResult> {
    if (this.env.EVENT_ENABLED !== "true") throw new Error("denied");
    const parsed = claimInputSchema.safeParse(input);
    const proof = z.strictObject({ accessAssertion: z.string().min(1).max(16_384), agentToken: z.string().min(1).max(4_096) }).safeParse(credentials);
    if (!parsed.success || !proof.success) throw new Error("invalid");
    const delivery = this.#delivery(parsed.data.deliveryId);
    if (!delivery || delivery.node_id !== parsed.data.nodeId || delivery.node_generation !== parsed.data.nodeGeneration) throw new Error("denied");
    let auth;
    try { auth = parseAuthorityAuthResult(await withDeadline(this.env.MESSAGE_AUTHORITY.currentAuth(proof.data), EVENT_POLICY_V1.nativeRpcDeadlineMs)); }
    catch { throw new EventApiError("authority_unavailable", 503); }
    if (auth.status === "unavailable") throw new EventApiError("authority_unavailable", 503);
    if (auth.status !== "authorized" || auth.identity.principal !== this.#identity.principal || auth.identity.agent !== this.#identity.agent) throw new Error("denied");
    const node = await this.#currentNode(delivery);
    if (!node || node.node.nodeId !== parsed.data.nodeId || node.node.generation !== parsed.data.nodeGeneration) throw new Error("denied");

    // Retrieval preserves the original admission even after its start window or
    // runtime lease expires. It grants no new time, budget, or destination authority.
    if (!this.#enabled()) throw new Error("denied");
    const historical = this.#nativeClaim(delivery.delivery_id);
    const historicalAttempt = this.#attempt(parsed.data.attemptId);
    if (historicalAttempt?.state === "not_started") throw new Error("conflict");
    if (historical?.attempt_id === parsed.data.attemptId && ["admitted", "ambiguous"].includes(historical.state)
      && historicalAttempt && ["admitted", "ambiguous"].includes(historicalAttempt.state)
      && !historicalAttempt.submission_id && !historicalAttempt.turn_id && !historicalAttempt.ack_json
      && historical.permit_id && historical.permit_issued_at && historical.permit_until && historical.envelope_json
      && historicalAttempt.delivery_id === delivery.delivery_id && historicalAttempt.permit_id === historical.permit_id
      && historicalAttempt.permit_until === historical.permit_until && historicalAttempt.envelope_json === historical.envelope_json) {
      return { status: "admitted", nodeId: parsed.data.nodeId, permitId: historical.permit_id,
        permitIssuedAt: nowIso(historical.permit_issued_at), permitExpiresAt: nowIso(historical.permit_until),
        envelope: JSON.parse(historical.envelope_json) as EventEnvelopeV1 };
    }
    this.#requireNativeBindingEnabled();
    const admittedBinding = this.#nativeStore.binding(delivery.runtime_id);
    if (!admittedBinding || admittedBinding.key_thumbprint !== auth.identity.keyThumbprint)
      throw new EventApiError("native_binding_unqualified", 409);
    this.#requireDestination(delivery.delivery_id, Date.now());
    const now = Date.now();
    await this.#arm(now + EVENT_POLICY_V1.nativeRpcDeadlineMs);
    const prepared = this.ctx.storage.transactionSync(() => {
      this.#requireNativeBindingEnabled();
      const fresh = this.#requireDestination(delivery.delivery_id, Date.now());
      let claim = this.#nativeClaim(delivery.delivery_id);
      if (claim && claim.attempt_id !== parsed.data.attemptId) {
        if (["reserving", "admitted", "submitted", "observed", "ambiguous", "unknown", "refused"].includes(claim.state)) throw new Error("conflict");
      } else if (claim?.attempt_id === parsed.data.attemptId && claim.state === "admitted") {
        const admittedAttempt = this.#attempt(claim.attempt_id);
        const admittedEnvelope = claim.envelope_json;
        if (!admittedEnvelope || !claim.permit_id || !claim.permit_issued_at || !claim.permit_until
          || !admittedAttempt || admittedAttempt.state !== "admitted" || admittedAttempt.delivery_id !== delivery.delivery_id
          || admittedAttempt.permit_id !== claim.permit_id || admittedAttempt.permit_until !== claim.permit_until
          || admittedAttempt.envelope_json !== admittedEnvelope || admittedAttempt.submission_id
          || admittedAttempt.turn_id || admittedAttempt.ack_json) throw new Error("conflict");
        return { kind: "replay" as const, claim, envelopeJson: admittedEnvelope };
      } else if (claim?.attempt_id === parsed.data.attemptId && ["submitted", "observed", "ambiguous"].includes(claim.state)) {
        throw new Error("conflict");
      }

      let attempt = this.#attempt(parsed.data.attemptId);
      if (attempt?.state === "not_started") throw new Error("conflict");
      if (attempt && ["admitted", "submitted", "observed", "ambiguous"].includes(attempt.state)
        && (!claim || claim.attempt_id !== parsed.data.attemptId)) throw new Error("conflict");
      let envelope: EventEnvelopeV1;
      let envelopeJson: string;
      if (attempt) {
        if (attempt.delivery_id !== fresh.delivery_id) throw new Error("conflict");
        envelope = JSON.parse(attempt.envelope_json) as EventEnvelopeV1;
        if (Date.parse(envelope.expiresAt) <= Date.now()) {
          // Refresh transport freshness for an unadmitted, same-ID retry. A previously
          // admitted claim is handled above and never receives a replacement permit.
          envelope = this.#makeEnvelope(fresh, parsed.data.attemptId, Date.now());
          envelopeJson = JSON.stringify(envelope);
          this.#sql.exec("UPDATE attempts SET envelope_json=? WHERE attempt_id=?", envelopeJson, parsed.data.attemptId);
          attempt = this.#attempt(parsed.data.attemptId);
          if (!attempt) throw new Error("conflict");
        } else envelopeJson = attempt.envelope_json;
      } else {
        envelope = this.#makeEnvelope(fresh, parsed.data.attemptId, Date.now());
        envelopeJson = JSON.stringify(envelope);
        this.#sql.exec(`INSERT INTO attempts(attempt_id,delivery_id,envelope_json,state,transport_until,reservation_state,transport_status)
          VALUES (?,?,?,'reserving',0,'pending','not_started')`, parsed.data.attemptId, fresh.delivery_id, envelopeJson);
        attempt = this.#attempt(parsed.data.attemptId);
      }
      if (envelope.deliveryId !== fresh.delivery_id || envelope.eventId !== fresh.event_id
        || envelope.runtimeId !== fresh.runtime_id || envelope.nodeGeneration !== fresh.node_generation
        || envelope.runtimeGeneration !== fresh.runtime_generation || envelope.attachmentGeneration !== fresh.attachment_generation
        || envelope.sourceStateVersion !== fresh.source_state_version) throw new Error("conflict");
      if (!attempt) throw new Error("conflict");
      if (claim && claim.attempt_id !== parsed.data.attemptId && claim.state === "budget_refused") {
        this.#sql.exec(`DELETE FROM attempts WHERE delivery_id=? AND state='budget_refused'
          AND reservation_state='budget_refused' AND attempt_id<>?`, fresh.delivery_id, parsed.data.attemptId);
      }
      const reservationAt = Math.max(Date.now(), (claim?.updated_at ?? 0) + 1);
      this.#sql.exec("UPDATE attempts SET state='reserving',reservation_state='pending' WHERE attempt_id=? AND state NOT IN ('submitted','observed','ambiguous')", parsed.data.attemptId);
      this.#sql.exec(`INSERT INTO native_claims(delivery_id,attempt_id,state,permit_id,permit_issued_at,permit_until,envelope_json,updated_at)
        VALUES (?,?,'reserving',NULL,NULL,NULL,?,?) ON CONFLICT(delivery_id) DO UPDATE SET attempt_id=excluded.attempt_id,state='reserving',
        permit_id=NULL,permit_issued_at=NULL,permit_until=NULL,envelope_json=excluded.envelope_json,updated_at=excluded.updated_at`,
        fresh.delivery_id, parsed.data.attemptId, envelopeJson!, reservationAt);
      this.#sql.exec("UPDATE deliveries SET transport_state='accepted',reason=NULL WHERE delivery_id=?", fresh.delivery_id);
      this.#sql.exec("DELETE FROM queue_outbox WHERE delivery_id=?", fresh.delivery_id);
      return { kind: "reserve" as const, envelopeJson: envelopeJson!, reservationAt };
    });
    if (prepared.kind === "replay") {
      const claim = prepared.claim;
      const envelope = JSON.parse(prepared.envelopeJson) as EventEnvelopeV1;
      return { status: "admitted", nodeId: parsed.data.nodeId, permitId: claim.permit_id!,
        permitIssuedAt: nowIso(claim.permit_issued_at!), permitExpiresAt: nowIso(claim.permit_until!), envelope };
    }
    await this.#arm(Date.now() + EVENT_POLICY_V1.nativeRpcDeadlineMs);
    const envelope = JSON.parse(prepared.envelopeJson) as EventEnvelopeV1;
    this.#requireCurrent(delivery.delivery_id, envelope, Date.now());
    const nodeBefore = await this.#currentNode(delivery);
    this.#requireCurrent(delivery.delivery_id, envelope, Date.now());
    if (!nodeBefore || nodeBefore.node.generation !== parsed.data.nodeGeneration) throw new Error("denied");

    let reservation;
    try {
      const attemptInput = { ...proof.data, attemptId: parsed.data.attemptId };
      const prior = parseNativeAttemptStatus(
        await withDeadline(this.env.MESSAGE_AUTHORITY.nativeAttemptStatus(attemptInput), EVENT_POLICY_V1.nativeRpcDeadlineMs),
        parsed.data.attemptId);
      this.#requireCurrent(delivery.delivery_id, envelope, Date.now());
      const nodeAfterStatus = await this.#currentNode(delivery);
      this.#requireCurrent(delivery.delivery_id, envelope, Date.now());
      if (!nodeAfterStatus || nodeAfterStatus.node.generation !== parsed.data.nodeGeneration) throw new Error("denied");
      this.#requireNativeBindingEnabled();
      reservation = prior.status === "reserved" ? prior
        : prior.status === "unknown"
          ? parseNativeAttemptReservation(
            await withDeadline(this.env.MESSAGE_AUTHORITY.reserveNativeAttempt(attemptInput), EVENT_POLICY_V1.nativeRpcDeadlineMs),
            parsed.data.attemptId)
          : prior;
      this.#requireCurrent(delivery.delivery_id, envelope, Date.now());
      const nodeAfterReserve = await this.#currentNode(delivery);
      this.#requireCurrent(delivery.delivery_id, envelope, Date.now());
      if (!nodeAfterReserve || nodeAfterReserve.node.generation !== parsed.data.nodeGeneration) throw new Error("denied");
    } catch (error) {
      if (error instanceof Error && ["denied", "conflict", "expired", "not_found", "native_binding_unqualified"].includes(error.message)) throw error;
      throw new EventApiError("authority_unavailable", 503);
    }
    if (reservation.status === "over_budget") {
      this.ctx.storage.transactionSync(() => {
        this.#requireCurrent(delivery.delivery_id, envelope, Date.now());
        const currentClaim = this.#nativeClaim(delivery.delivery_id);
        const currentAttempt = this.#attempt(parsed.data.attemptId);
        if (!currentClaim || currentClaim.attempt_id !== parsed.data.attemptId || currentClaim.state !== "reserving"
          || currentClaim.updated_at !== prepared.reservationAt || !currentAttempt || currentAttempt.state !== "reserving"
          || currentAttempt.reservation_state !== "pending" || currentAttempt.envelope_json !== prepared.envelopeJson) throw new Error("conflict");
        this.#sql.exec("UPDATE native_claims SET state='budget_refused',updated_at=? WHERE delivery_id=? AND attempt_id=? AND state='reserving' AND updated_at=?",
          Date.now(), delivery.delivery_id, parsed.data.attemptId, prepared.reservationAt);
        this.#sql.exec("UPDATE attempts SET state='budget_refused',reservation_state='budget_refused' WHERE attempt_id=?", parsed.data.attemptId);
        this.#sql.exec("UPDATE deliveries SET reason='over_budget' WHERE delivery_id=?", delivery.delivery_id);
      });
      return { status: "over_budget", budget: reservation.budget };
    }
    if (reservation.status === "denied" || reservation.status === "invalid") {
      const refusal = reservation.status;
      this.ctx.storage.transactionSync(() => {
        this.#requireCurrent(delivery.delivery_id, envelope, Date.now());
        const currentClaim = this.#nativeClaim(delivery.delivery_id);
        const currentAttempt = this.#attempt(parsed.data.attemptId);
        if (!currentClaim || currentClaim.attempt_id !== parsed.data.attemptId || currentClaim.state !== "reserving"
          || currentClaim.updated_at !== prepared.reservationAt || currentClaim.envelope_json !== prepared.envelopeJson
          || !currentAttempt || currentAttempt.delivery_id !== delivery.delivery_id || currentAttempt.state !== "reserving"
          || currentAttempt.reservation_state !== "pending" || currentAttempt.envelope_json !== prepared.envelopeJson) throw new Error("conflict");
        const refusedAt = Date.now();
        const claimUpdated = this.#sql.exec(`UPDATE native_claims SET state='refused',updated_at=?
          WHERE delivery_id=? AND attempt_id=? AND state='reserving' AND updated_at=? AND envelope_json=?`,
          refusedAt, delivery.delivery_id, parsed.data.attemptId, prepared.reservationAt, prepared.envelopeJson).rowsWritten;
        const attemptUpdated = this.#sql.exec(`UPDATE attempts SET state='refused',reservation_state='refused'
          WHERE attempt_id=? AND delivery_id=? AND state='reserving' AND reservation_state='pending' AND envelope_json=?`,
          parsed.data.attemptId, delivery.delivery_id, prepared.envelopeJson).rowsWritten;
        const deliveryUpdated = this.#sql.exec(`UPDATE deliveries SET reason=? WHERE delivery_id=? AND state='pending'
          AND EXISTS (SELECT 1 FROM native_claims WHERE delivery_id=? AND attempt_id=? AND state='refused' AND updated_at=?)`,
          refusal === "denied" ? "authority_denied" : "authority_invalid", delivery.delivery_id,
          delivery.delivery_id, parsed.data.attemptId, refusedAt).rowsWritten;
        if (claimUpdated !== 1 || attemptUpdated !== 1 || deliveryUpdated !== 1) throw new Error("conflict");
      });
      throw new EventApiError("denied", 403);
    }
    if (reservation.status !== "reserved") throw new EventApiError(reservation.status === "unavailable" ? "authority_unavailable" : "denied", reservation.status === "unavailable" ? 503 : 403);

    let currentAuth;
    try { currentAuth = parseAuthorityAuthResult(await withDeadline(this.env.MESSAGE_AUTHORITY.currentAuth(proof.data), EVENT_POLICY_V1.nativeRpcDeadlineMs)); }
    catch { throw new EventApiError("authority_unavailable", 503); }
    if (currentAuth.status === "unavailable") throw new EventApiError("authority_unavailable", 503);
    if (currentAuth.status !== "authorized" || currentAuth.identity.principal !== this.#identity.principal
      || currentAuth.identity.agent !== this.#identity.agent || currentAuth.identity.keyThumbprint !== auth.identity.keyThumbprint)
      throw new Error("denied");
    const nodeAtCommit = await this.#currentNode(delivery);
    this.#requireCurrent(delivery.delivery_id, envelope, Date.now());
    if (!nodeAtCommit || nodeAtCommit.node.nodeId !== parsed.data.nodeId || nodeAtCommit.node.generation !== parsed.data.nodeGeneration)
      throw new Error("denied");

    const prospectiveIssuedAt = Date.now();
    const permitId = crypto.randomUUID();
    await this.#arm(prospectiveIssuedAt + EVENT_POLICY_V1.dispatchStartWindowMs + EVENT_POLICY_V1.nativeRpcDeadlineMs);
    return this.ctx.storage.transactionSync((): DispatchClaimResult => {
      const issuedAt = Date.now();
      const expiresAt = issuedAt + EVENT_POLICY_V1.dispatchStartWindowMs;
      const fresh = this.#requireCurrent(delivery.delivery_id, envelope, issuedAt);
      const nativeBinding = this.#nativeStore.binding(fresh.runtime_id);
      this.#requireNativeBindingEnabled();
      if (!nativeBinding
        || nativeBinding.key_thumbprint !== currentAuth.identity?.keyThumbprint)
        throw new EventApiError("native_binding_unqualified", 409);
      const currentClaim = this.#nativeClaim(fresh.delivery_id);
      const currentAttempt = this.#attempt(parsed.data.attemptId);
      if (!currentClaim || currentClaim.attempt_id !== parsed.data.attemptId || currentClaim.state !== "reserving"
        || currentClaim.updated_at !== prepared.reservationAt || !currentAttempt || currentAttempt.state !== "reserving"
        || currentAttempt.reservation_state !== "pending" || currentAttempt.envelope_json !== prepared.envelopeJson) throw new Error("conflict");
      let admissionEnvelope = envelope;
      let admissionEnvelopeJson = prepared.envelopeJson;
      if (Date.parse(admissionEnvelope.expiresAt) < expiresAt) {
        admissionEnvelope = this.#makeEnvelope(fresh, parsed.data.attemptId, issuedAt);
        admissionEnvelopeJson = JSON.stringify(admissionEnvelope);
        if (Date.parse(admissionEnvelope.expiresAt) < expiresAt) throw new Error("conflict");
        const claimEnvelopeUpdated = this.#sql.exec(`UPDATE native_claims SET envelope_json=? WHERE delivery_id=? AND attempt_id=?
          AND state='reserving' AND updated_at=? AND envelope_json=?`, admissionEnvelopeJson, delivery.delivery_id,
          parsed.data.attemptId, prepared.reservationAt, prepared.envelopeJson).rowsWritten;
        const attemptEnvelopeUpdated = this.#sql.exec(`UPDATE attempts SET envelope_json=? WHERE attempt_id=? AND delivery_id=?
          AND state='reserving' AND reservation_state='pending' AND envelope_json=?`, admissionEnvelopeJson,
          parsed.data.attemptId, delivery.delivery_id, prepared.envelopeJson).rowsWritten;
        if (claimEnvelopeUpdated !== 1 || attemptEnvelopeUpdated !== 1) throw new Error("conflict");
      }
      const claimUpdated = this.#sql.exec(`UPDATE native_claims SET state='admitted',permit_id=?,permit_issued_at=?,permit_until=?,updated_at=?
        WHERE delivery_id=? AND attempt_id=? AND state='reserving' AND updated_at=? AND envelope_json=?`,
        permitId, issuedAt, expiresAt, issuedAt, delivery.delivery_id, parsed.data.attemptId, prepared.reservationAt, admissionEnvelopeJson).rowsWritten;
      const attemptUpdated = this.#sql.exec(`UPDATE attempts SET state='admitted',reservation_state='reserved',permit_id=?,permit_until=?,envelope_json=?
        WHERE attempt_id=? AND delivery_id=? AND state='reserving' AND reservation_state='pending' AND envelope_json=?`,
        permitId, expiresAt, admissionEnvelopeJson, parsed.data.attemptId, delivery.delivery_id, admissionEnvelopeJson).rowsWritten;
      if (claimUpdated !== 1 || attemptUpdated !== 1) throw new Error("conflict");
      this.#sql.exec("UPDATE deliveries SET reason=NULL,transport_state=CASE WHEN transport_state='accepted' THEN transport_state ELSE 'admitted' END WHERE delivery_id=?", delivery.delivery_id);
      return { status: "admitted", nodeId: parsed.data.nodeId, permitId, permitIssuedAt: nowIso(issuedAt), permitExpiresAt: nowIso(expiresAt), envelope: admissionEnvelope };
    });
  }

  /** A current enrolled node attests terminal native refusal or durable no-write
   * evidence. Preserve the charge and delivery slot; only a fresh attempt may retry. */
  async settleNoStart(input: DispatchNoStartRequest, node: { nodeId: string; generation: number }): Promise<DispatchNoStartResult> {
    const parsed = DispatchNoStartRequestSchema.safeParse(input);
    if (!parsed.success) throw new Error("invalid");
    const request = parsed.data;
    const delivery = this.#delivery(request.deliveryId);
    if (!delivery || delivery.node_id !== node.nodeId || delivery.node_generation !== node.generation
      || request.nodeGeneration !== node.generation) throw new Error("denied");
    const currentNode = await this.#currentNode(delivery);
    if (!currentNode || currentNode.node.nodeId !== node.nodeId || currentNode.node.generation !== node.generation) throw new Error("denied");
    const result: DispatchNoStartResult = { ...request, nodeId: node.nodeId, status: "not_started" };
    const resultJson = JSON.stringify(result);
    const recorded = row<{ result_json: string }>(this.#sql,
      "SELECT result_json FROM no_start_settlements WHERE attempt_id=?", request.attemptId);
    if (recorded) {
      if (recorded.result_json !== resultJson) throw new Error("conflict");
      return DispatchNoStartResultSchema.parse(JSON.parse(recorded.result_json));
    }
    // Schedule before the transaction: no await may separate its eligibility check
    // from the terminal write, so a positive ACK and settlement cannot both win.
    await this.#arm(Date.now() + EVENT_POLICY_V1.recoveryBackoffInitialMs);
    return this.ctx.storage.transactionSync(() => {
      const previous = row<{ result_json: string }>(this.#sql,
        "SELECT result_json FROM no_start_settlements WHERE attempt_id=?", request.attemptId);
      if (previous) {
        if (previous.result_json !== resultJson) throw new Error("conflict");
        return DispatchNoStartResultSchema.parse(JSON.parse(previous.result_json));
      }
      const attempt = this.#attempt(request.attemptId);
      const claim = this.#nativeClaim(request.deliveryId);
      const fresh = this.#delivery(request.deliveryId);
      if (!attempt || !claim || !fresh || attempt.delivery_id !== request.deliveryId
        || claim.attempt_id !== request.attemptId || attempt.permit_id !== request.permitId || claim.permit_id !== request.permitId
        || attempt.reservation_state !== "reserved" || !["admitted", "ambiguous"].includes(attempt.state)
        || !["admitted", "ambiguous"].includes(claim.state) || attempt.submission_id || attempt.turn_id || attempt.ack_json
        || !["pending", "ambiguous"].includes(fresh.state)
        || (fresh.state === "ambiguous" && fresh.reason !== "native_outcome_unknown")) throw new Error("conflict");
      const envelope = JSON.parse(attempt.envelope_json) as EventEnvelopeV1;
      if (claim.envelope_json !== attempt.envelope_json || envelope.deliveryId !== request.deliveryId
        || envelope.attemptId !== request.attemptId || envelope.nodeGeneration !== request.nodeGeneration
        || envelope.principal !== this.#identity.principal || envelope.agent !== this.#identity.agent) throw new Error("conflict");
      if (request.evidence.type === "native_terminal_no_start") {
        // Rows are bounded by the charged 10/hour attempt budget, 24-hour retry
        // horizon, and terminal-delivery retention cleanup below.
        const reused = row<{ attempt_id: string }>(this.#sql,
          "SELECT attempt_id FROM no_start_settlements WHERE json_extract(result_json,'$.evidence.receiptId')=? LIMIT 1", request.evidence.receiptId);
        if (reused) throw new Error("conflict");
      }
      this.#sql.exec("INSERT INTO no_start_settlements(attempt_id,delivery_id,result_json) VALUES (?,?,?)",
        request.attemptId, request.deliveryId, resultJson);
      this.#sql.exec("UPDATE attempts SET state='not_started' WHERE attempt_id=?", request.attemptId);
      this.#sql.exec("UPDATE native_claims SET state='not_started',updated_at=? WHERE delivery_id=? AND attempt_id=?",
        Date.now(), request.deliveryId, request.attemptId);
      this.#sql.exec("UPDATE deliveries SET state='pending',reason=NULL WHERE delivery_id=?", request.deliveryId);
      return result;
    });
  }

  async acknowledge(ack: EventObservationAckV1, node: { nodeId: string; generation: number }): Promise<{ status: "submitted" | "observed"; current: boolean }> {
    if (!validateEventObservationAck(ack)) throw new Error("invalid");
    const canonicalAck = EventObservationAckSchema.parse(ack);
    if (canonicalAck.status === "observed" && canonicalAck.nativeCorrelation.kind === "turn"
      && canonicalAck.nativeCorrelation.submissionId === canonicalAck.nativeCorrelation.turnId) throw new Error("invalid");
    const attempt = this.#attempt(canonicalAck.attemptId);
    if (!attempt) throw new Error("not_found");
    const delivery = this.#delivery(attempt.delivery_id);
    const nativeClaim = delivery ? this.#nativeClaim(delivery.delivery_id) : null;
    if (!delivery || !nativeClaim || nativeClaim.attempt_id !== canonicalAck.attemptId
      || !["admitted", "submitted", "observed", "ambiguous"].includes(nativeClaim.state)
      || !["admitted", "submitted", "observed", "ambiguous"].includes(attempt.state)
      || canonicalAck.principal !== this.#identity.principal || canonicalAck.agent !== this.#identity.agent
      || node.nodeId !== delivery.node_id || node.generation !== delivery.node_generation) throw new Error("denied");
    const envelope = JSON.parse(attempt.envelope_json) as EventEnvelopeV1;
    if (!acknowledgmentMatchesDelivery(envelope, canonicalAck)) throw new Error("invalid");
    const currentNode = await this.#currentNode(delivery);
    if (!currentNode || currentNode.node.nodeId !== node.nodeId || currentNode.node.generation !== node.generation) throw new Error("denied");
    if (canonicalAck.status === "submitted" && canonicalAck.nativeCorrelation.kind === "native_turn_started") {
      return this.#acknowledgeNativeStart(canonicalAck, node, attempt, delivery, nativeClaim);
    }
    if (canonicalAck.status === "observed" && canonicalAck.nativeCorrelation.kind === "native_input_recorded") {
      return this.#acknowledgeNativeInput(canonicalAck, node, attempt, delivery, nativeClaim);
    }
    // Keep these explicit guards to narrow ACKs to queue correlations below;
    // both native phases have already returned from their dedicated branches above.
    if (canonicalAck.status === "submitted" && canonicalAck.nativeCorrelation.kind === "native_turn_started") throw new Error("conflict");
    if (canonicalAck.status === "observed" && canonicalAck.nativeCorrelation.kind === "native_input_recorded") throw new Error("conflict");
    const now = Date.now();
    if (canonicalAck.status === "observed") {
      await this.#arm(now + EVENT_POLICY_V1.recoveryBackoffInitialMs);
      const freshNode = await this.#currentNode(delivery);
      if (!freshNode || freshNode.node.nodeId !== node.nodeId || freshNode.node.generation !== node.generation) throw new Error("denied");
    }
    const result = this.ctx.storage.transactionSync(() => {
      const freshAttempt = this.#attempt(canonicalAck.attemptId);
      const freshDelivery = this.#delivery(delivery.delivery_id);
      const freshClaim = this.#nativeClaim(delivery.delivery_id);
      if (!freshAttempt || !freshDelivery || !freshClaim || freshAttempt.envelope_json !== attempt.envelope_json
        || freshClaim.attempt_id !== canonicalAck.attemptId || !["admitted", "submitted", "observed", "ambiguous"].includes(freshClaim.state)) throw new Error("conflict");
      if (freshDelivery.reason === "node_revoked") throw new Error("denied");
      const previous = freshAttempt.ack_json ? EventObservationAckSchema.parse(JSON.parse(freshAttempt.ack_json)) : null;
      if (previous?.status === "submitted" && previous.nativeCorrelation.kind === "native_turn_started") throw new Error("conflict");
      const submissionId = canonicalAck.status === "observed"
        ? canonicalAck.nativeCorrelation.kind === "turn" ? canonicalAck.nativeCorrelation.submissionId : null
        : canonicalAck.nativeCorrelation.kind === "queued" ? canonicalAck.nativeCorrelation.submissionId : null;
      if (!submissionId) throw new Error("conflict");
      if (freshClaim.state === "observed") {
        if (canonicalAck.status !== "observed" || !previous || JSON.stringify(previous) !== JSON.stringify(canonicalAck)) throw new Error("conflict");
        return { status: "observed" as const, current: false };
      }
      if (canonicalAck.status === "submitted" && !["admitted", "ambiguous"].includes(freshClaim.state)) {
        if (previous && JSON.stringify(previous) === JSON.stringify(canonicalAck)) return { status: "submitted" as const, current: false };
        throw new Error("conflict");
      }
      if (freshAttempt.submission_id && freshAttempt.submission_id !== submissionId) throw new Error("conflict");
      const ids = [
        { id: submissionId, kind: "submission" },
        ...(canonicalAck.status === "observed" ? [{ id: canonicalAck.nativeCorrelation.turnId, kind: "turn" }] : []),
      ];
      for (const item of ids) {
        const priorId = row<{ delivery_id: string; attempt_id: string; kind: string }>(this.#sql,
          "SELECT delivery_id,attempt_id,kind FROM native_correlations WHERE correlation_id=?", item.id);
        if (priorId && (priorId.delivery_id !== delivery.delivery_id || priorId.attempt_id !== canonicalAck.attemptId || priorId.kind !== item.kind)) throw new Error("conflict");
      }
      for (const item of ids) this.#sql.exec("INSERT OR IGNORE INTO native_correlations(correlation_id,delivery_id,attempt_id,kind) VALUES (?,?,?,?)",
        item.id, delivery.delivery_id, canonicalAck.attemptId, item.kind);
      if (canonicalAck.status === "submitted") {
        if (previous && JSON.stringify(previous) === JSON.stringify(canonicalAck)) return { status: "submitted" as const, current: false };
        this.#sql.exec("UPDATE attempts SET state='submitted',submission_id=?,ack_json=? WHERE attempt_id=?",
          submissionId, JSON.stringify(canonicalAck), canonicalAck.attemptId);
        this.#sql.exec("UPDATE native_claims SET state='submitted',updated_at=? WHERE delivery_id=? AND attempt_id=?", now, delivery.delivery_id, canonicalAck.attemptId);
        this.#sql.exec("UPDATE deliveries SET state='submitted',reason=NULL WHERE delivery_id=? AND state IN ('pending','ambiguous')", delivery.delivery_id);
        return { status: "submitted" as const, current: false };
      }
      if (canonicalAck.nativeCorrelation.kind !== "turn") throw new Error("conflict");
      const current = this.#isCurrentDestination(freshDelivery, Date.now());
      const source = this.#source(delivery.subject_id);
      const advances = current && !!source && acknowledgmentAdvancesCurrentWatermark(envelope, canonicalAck, source.source_state_version);
      this.#sql.exec("UPDATE attempts SET state='observed',submission_id=?,turn_id=?,ack_json=? WHERE attempt_id=?",
        canonicalAck.nativeCorrelation.submissionId, canonicalAck.nativeCorrelation.turnId, JSON.stringify(canonicalAck), canonicalAck.attemptId);
      this.#sql.exec("UPDATE native_claims SET state='observed',updated_at=? WHERE delivery_id=? AND attempt_id=?", now, delivery.delivery_id, canonicalAck.attemptId);
      this.#sql.exec("UPDATE deliveries SET state='observed',reason=NULL,terminal_at=COALESCE(terminal_at,?) WHERE delivery_id=? AND state IN ('pending','submitted','ambiguous')", now, delivery.delivery_id);
      if (advances) this.#sql.exec("UPDATE manual_sources SET observed_source_state_version=? WHERE subject_id=? AND source_state_version=?",
        canonicalAck.deliveredSourceStateVersion, delivery.subject_id, source!.source_state_version);
      this.#releaseSlotLater(delivery.delivery_id, delivery.node_id, delivery.node_generation, now);
      return { status: "observed" as const, current: advances };
    });
    if (canonicalAck.status === "observed") await this.#releaseSlot(delivery.delivery_id);
    await this.#schedule();
    return result;
  }

  async #acknowledgeNativeStart(canonicalAck: Extract<EventObservationAckV1, { status: "submitted" }>, node: { nodeId: string; generation: number }, attempt: AttemptRow, delivery: DeliveryRow, nativeClaim: NativeClaimRow) {
    if (canonicalAck.nativeCorrelation.kind !== "native_turn_started") throw new Error("conflict");
    const correlation = canonicalAck.nativeCorrelation;
    const pending = attempt.state === nativeClaim.state && ["admitted", "ambiguous"].includes(attempt.state)
      && !attempt.submission_id && !attempt.turn_id && !attempt.ack_json;
    const submittedReplay = attempt.state === "submitted" && nativeClaim.state === "submitted" && delivery.state === "submitted";
    const observedReplay = attempt.state === "observed" && nativeClaim.state === "observed" && delivery.state === "observed"
      && attempt.native_observed_ack_json !== null;
    const replay = (submittedReplay || observedReplay) && attempt.submission_id === null
      && attempt.turn_id === correlation.turnId && attempt.ack_json !== null;
    if (attempt.delivery_id !== delivery.delivery_id || attempt.reservation_state !== "reserved"
      || attempt.permit_id !== correlation.permitId || nativeClaim.permit_id !== correlation.permitId
      || attempt.permit_until === null || nativeClaim.permit_issued_at === null || nativeClaim.permit_until === null
      || attempt.permit_until !== nativeClaim.permit_until || nativeClaim.envelope_json !== attempt.envelope_json
      || !pending && !replay) throw new Error("conflict");
    const now = Date.now();
    const result = this.ctx.storage.transactionSync(() => {
      const freshAttempt = this.#attempt(canonicalAck.attemptId);
      const freshDelivery = this.#delivery(delivery.delivery_id);
      const freshClaim = this.#nativeClaim(delivery.delivery_id);
      if (!freshAttempt || !freshDelivery || !freshClaim
        || !this.#nativeAckRowsMatch(canonicalAck, node, attempt, freshAttempt, freshDelivery, freshClaim)
        || freshDelivery.reason === "node_revoked"
        || !acknowledgmentMatchesDelivery(JSON.parse(freshAttempt.envelope_json) as EventEnvelopeV1, canonicalAck)) throw new Error("conflict");
      const previous = freshAttempt.ack_json ? EventObservationAckSchema.parse(JSON.parse(freshAttempt.ack_json)) : null;
      if (previous) {
        const observed = freshAttempt.native_observed_ack_json
          ? EventObservationAckSchema.parse(JSON.parse(freshAttempt.native_observed_ack_json)) : null;
        const observedCorrelationMatches = observed?.status === "observed"
          && observed.nativeCorrelation.kind === "native_input_recorded"
          && observed.nativeCorrelation.permitId === correlation.permitId
          && observed.nativeCorrelation.turnId === correlation.turnId;
        const sameSubmitted = previous.status === "submitted" && previous.nativeCorrelation.kind === "native_turn_started"
          && JSON.stringify(previous) === JSON.stringify(canonicalAck);
        if (freshAttempt.submission_id === null && freshAttempt.turn_id === correlation.turnId && sameSubmitted
          && freshAttempt.state === "submitted" && freshClaim.state === "submitted" && freshDelivery.state === "submitted"
          && freshAttempt.native_observed_ack_json === null) {
          return { status: "submitted" as const, current: false };
        }
        if (freshAttempt.submission_id === null && freshAttempt.turn_id === correlation.turnId && sameSubmitted
          && freshAttempt.state === "observed" && freshClaim.state === "observed" && freshDelivery.state === "observed"
          && observedCorrelationMatches) return { status: "submitted" as const, current: false };
        throw new Error("conflict");
      }
      const admitted = freshAttempt.state === freshClaim.state && ["admitted", "ambiguous"].includes(freshAttempt.state)
        && ["pending", "ambiguous"].includes(freshDelivery.state)
        && !freshAttempt.submission_id && !freshAttempt.turn_id && !freshAttempt.ack_json;
      const settled = row<{ attempt_id: string }>(this.#sql,
        "SELECT attempt_id FROM no_start_settlements WHERE attempt_id=?", canonicalAck.attemptId);
      if (!admitted || settled) throw new Error("conflict");
      const priorTurn = row<{ delivery_id: string; attempt_id: string; kind: string }>(this.#sql,
        "SELECT delivery_id,attempt_id,kind FROM native_correlations WHERE correlation_id=?", correlation.turnId);
      if (priorTurn) throw new Error("conflict");
      this.#sql.exec("INSERT INTO native_correlations(correlation_id,delivery_id,attempt_id,kind) VALUES (?,?,?,'turn')",
        correlation.turnId, freshDelivery.delivery_id, canonicalAck.attemptId);
      const attemptUpdated = this.#sql.exec(`UPDATE attempts SET state='submitted',turn_id=?,ack_json=?
        WHERE attempt_id=? AND delivery_id=? AND state=? AND reservation_state='reserved'
          AND permit_id=? AND permit_until=? AND submission_id IS NULL AND turn_id IS NULL AND ack_json IS NULL`,
        correlation.turnId, JSON.stringify(canonicalAck), canonicalAck.attemptId, freshDelivery.delivery_id,
        freshAttempt.state, correlation.permitId, freshAttempt.permit_until).rowsWritten;
      const claimUpdated = this.#sql.exec(`UPDATE native_claims SET state='submitted',updated_at=?
        WHERE delivery_id=? AND attempt_id=? AND state=? AND permit_id=? AND permit_until=? AND envelope_json=?`,
        now, freshDelivery.delivery_id, canonicalAck.attemptId, freshClaim.state, correlation.permitId,
        freshClaim.permit_until, freshAttempt.envelope_json).rowsWritten;
      const deliveryUpdated = this.#sql.exec(`UPDATE deliveries SET state='submitted',reason=NULL
        WHERE delivery_id=? AND state IN ('pending','ambiguous')`, freshDelivery.delivery_id).rowsWritten;
      if (attemptUpdated < 1 || claimUpdated < 1 || deliveryUpdated < 1) throw new Error("conflict");
      return { status: "submitted" as const, current: false };
    });
    await this.#schedule();
    return result;
  }

  async #acknowledgeNativeInput(canonicalAck: Extract<EventObservationAckV1, { status: "observed" }>, node: { nodeId: string; generation: number }, attempt: AttemptRow, delivery: DeliveryRow, nativeClaim: NativeClaimRow) {
    if (canonicalAck.nativeCorrelation.kind !== "native_input_recorded") throw new Error("conflict");
    const correlation = canonicalAck.nativeCorrelation;
    if (attempt.reservation_state !== "reserved" || attempt.permit_id !== correlation.permitId
      || nativeClaim.permit_id !== correlation.permitId || attempt.permit_until === null
      || nativeClaim.permit_issued_at === null || nativeClaim.permit_until === null
      || attempt.permit_until !== nativeClaim.permit_until || attempt.submission_id !== null
      || attempt.turn_id !== correlation.turnId || !attempt.ack_json) throw new Error("conflict");
    const registration = EventObservationAckSchema.parse(JSON.parse(attempt.ack_json));
    if (registration.status !== "submitted" || registration.nativeCorrelation.kind !== "native_turn_started"
      || registration.nativeCorrelation.permitId !== correlation.permitId || registration.nativeCorrelation.turnId !== correlation.turnId
      || !acknowledgmentMatchesDelivery(JSON.parse(attempt.envelope_json) as EventEnvelopeV1, registration)) throw new Error("conflict");

    const now = Date.now();
    if (attempt.native_observed_ack_json === null) await this.#arm(now + EVENT_POLICY_V1.recoveryBackoffInitialMs);
    const freshNode = await this.#currentNode(delivery);
    if (!freshNode || freshNode.node.nodeId !== node.nodeId || freshNode.node.generation !== node.generation) throw new Error("denied");
    const outcome = this.ctx.storage.transactionSync(() => {
      const freshAttempt = this.#attempt(canonicalAck.attemptId);
      const freshDelivery = this.#delivery(delivery.delivery_id);
      const freshClaim = this.#nativeClaim(delivery.delivery_id);
      if (!freshAttempt || !freshDelivery || !freshClaim) throw new Error("conflict");
      if (freshDelivery.reason === "node_revoked") throw new Error("denied");
      if (!this.#nativeAckRowsMatch(canonicalAck, node, attempt, freshAttempt, freshDelivery, freshClaim)
        || !acknowledgmentMatchesDelivery(JSON.parse(freshAttempt.envelope_json) as EventEnvelopeV1, canonicalAck)) throw new Error("conflict");

      const previousRegistration = freshAttempt.ack_json
        ? EventObservationAckSchema.parse(JSON.parse(freshAttempt.ack_json)) : null;
      if (previousRegistration?.status !== "submitted" || previousRegistration.nativeCorrelation.kind !== "native_turn_started"
        || previousRegistration.nativeCorrelation.permitId !== correlation.permitId
        || previousRegistration.nativeCorrelation.turnId !== correlation.turnId
        || !acknowledgmentMatchesDelivery(JSON.parse(freshAttempt.envelope_json) as EventEnvelopeV1, previousRegistration)) throw new Error("conflict");

      const previousObservation = freshAttempt.native_observed_ack_json
        ? EventObservationAckSchema.parse(JSON.parse(freshAttempt.native_observed_ack_json)) : null;
      if (previousObservation) {
        if (freshAttempt.state === "observed" && freshClaim.state === "observed" && freshDelivery.state === "observed"
          && freshAttempt.submission_id === null && freshAttempt.turn_id === correlation.turnId
          && previousObservation.status === "observed" && previousObservation.nativeCorrelation.kind === "native_input_recorded"
          && previousObservation.nativeCorrelation.permitId === correlation.permitId
          && previousObservation.nativeCorrelation.turnId === correlation.turnId
          && JSON.stringify(previousObservation) === JSON.stringify(canonicalAck)) {
          return { result: { status: "observed" as const, current: false }, newlyObserved: false };
        }
        throw new Error("conflict");
      }

      if (freshAttempt.state !== "submitted" || freshClaim.state !== "submitted" || freshDelivery.state !== "submitted"
        || freshAttempt.submission_id !== null || freshAttempt.turn_id !== correlation.turnId) throw new Error("conflict");
      const settled = row<{ attempt_id: string }>(this.#sql,
        "SELECT attempt_id FROM no_start_settlements WHERE attempt_id=?", canonicalAck.attemptId);
      if (settled) throw new Error("conflict");
      const priorTurn = row<{ delivery_id: string; attempt_id: string; kind: string }>(this.#sql,
        "SELECT delivery_id,attempt_id,kind FROM native_correlations WHERE correlation_id=?", correlation.turnId);
      if (!priorTurn || priorTurn.delivery_id !== freshDelivery.delivery_id || priorTurn.attempt_id !== canonicalAck.attemptId
        || priorTurn.kind !== "turn") throw new Error("conflict");
      if (row(this.#sql, "SELECT correlation_id FROM native_correlations WHERE correlation_id=?", correlation.itemId)) throw new Error("conflict");

      const current = this.#isCurrentDestination(freshDelivery, Date.now());
      const source = this.#source(freshDelivery.subject_id);
      const advances = current && !!source
        && acknowledgmentAdvancesCurrentWatermark(JSON.parse(freshAttempt.envelope_json) as EventEnvelopeV1, canonicalAck, source.source_state_version);
      this.#sql.exec("INSERT INTO native_correlations(correlation_id,delivery_id,attempt_id,kind) VALUES (?,?,?,'input_item')",
        correlation.itemId, freshDelivery.delivery_id, canonicalAck.attemptId);
      const attemptUpdated = this.#sql.exec(`UPDATE attempts SET state='observed',native_observed_ack_json=?
        WHERE attempt_id=? AND delivery_id=? AND state='submitted' AND reservation_state='reserved'
          AND permit_id=? AND permit_until=? AND submission_id IS NULL AND turn_id=? AND ack_json=? AND native_observed_ack_json IS NULL`,
        JSON.stringify(canonicalAck), canonicalAck.attemptId, freshDelivery.delivery_id, correlation.permitId,
        freshAttempt.permit_until, correlation.turnId, freshAttempt.ack_json).rowsWritten;
      const claimUpdated = this.#sql.exec(`UPDATE native_claims SET state='observed',updated_at=?
        WHERE delivery_id=? AND attempt_id=? AND state='submitted' AND permit_id=? AND permit_until=? AND envelope_json=?`,
        now, freshDelivery.delivery_id, canonicalAck.attemptId, correlation.permitId, freshClaim.permit_until,
        freshAttempt.envelope_json).rowsWritten;
      const deliveryUpdated = this.#sql.exec(`UPDATE deliveries SET state='observed',reason=NULL,terminal_at=COALESCE(terminal_at,?)
        WHERE delivery_id=? AND state='submitted' AND node_id=? AND node_generation=?`,
        now, freshDelivery.delivery_id, node.nodeId, node.generation).rowsWritten;
      if (attemptUpdated < 1 || claimUpdated < 1 || deliveryUpdated < 1) throw new Error("conflict");
      if (advances) this.#sql.exec("UPDATE manual_sources SET observed_source_state_version=? WHERE subject_id=? AND source_state_version=?",
        canonicalAck.deliveredSourceStateVersion, freshDelivery.subject_id, source!.source_state_version);
      this.#releaseSlotLater(freshDelivery.delivery_id, freshDelivery.node_id, freshDelivery.node_generation, now);
      return { result: { status: "observed" as const, current: advances }, newlyObserved: true };
    });
    if (outcome.newlyObserved) {
      await this.#releaseSlot(delivery.delivery_id);
      await this.#schedule();
    }
    return outcome.result;
  }

  #nativeAckRowsMatch(ack: EventObservationAckV1, node: { nodeId: string; generation: number }, attempt: AttemptRow,
    freshAttempt: AttemptRow, freshDelivery: DeliveryRow, freshClaim: NativeClaimRow): boolean {
    const correlation = ack.nativeCorrelation;
    return "permitId" in correlation && freshAttempt.envelope_json === attempt.envelope_json
      && freshAttempt.delivery_id === freshDelivery.delivery_id && freshClaim.delivery_id === freshDelivery.delivery_id
      && freshClaim.attempt_id === ack.attemptId && freshClaim.envelope_json === freshAttempt.envelope_json
      && freshAttempt.reservation_state === "reserved" && freshAttempt.permit_id === correlation.permitId
      && freshClaim.permit_id === correlation.permitId && freshAttempt.permit_until !== null
      && freshClaim.permit_issued_at !== null && freshClaim.permit_until !== null
      && freshAttempt.permit_until === freshClaim.permit_until
      && freshDelivery.node_id === node.nodeId && freshDelivery.node_generation === node.generation;
  }

  async claimTransport(job: EventJob): Promise<TransportClaim | null> {
    const parsed = jobSchema.safeParse(job);
    if (!parsed.success || parsed.data.principal !== this.#identity.principal || parsed.data.agent !== this.#identity.agent) return null;
    if (this.env.EVENT_ENABLED !== "true" || !this.#enabled()) return null;
    const delivery = this.#delivery(parsed.data.deliveryId);
    if (!delivery || delivery.state !== "pending") return null;
    if (delivery.transport_state === "accepted") {
      this.#sql.exec("DELETE FROM queue_outbox WHERE delivery_id=?", delivery.delivery_id);
      return null;
    }
    if (delivery.retry_until <= Date.now()) { await this.#expire(delivery, "transport_retry_horizon_elapsed"); return null; }
    const current = this.#runtime(delivery.runtime_id);
    if (!this.#runtimeReady(current, Date.now()) || current!.runtime_generation !== delivery.runtime_generation
      || current!.attachment_generation !== delivery.attachment_generation || current!.node_generation !== delivery.node_generation) {
      this.#sql.exec("UPDATE deliveries SET reason='runtime_expired' WHERE delivery_id=?", delivery.delivery_id);
      return null;
    }
    const node = await this.#currentNode(delivery);
    this.#requireDestination(delivery.delivery_id, Date.now());
    if (!node) {
      this.#sql.exec("UPDATE deliveries SET reason='node_revoked' WHERE delivery_id=?", delivery.delivery_id);
      return null;
    }
    const now = Date.now();
    const attemptId = crypto.randomUUID();
    const envelope = this.#makeEnvelope(delivery, attemptId, now);
    const transportUntil = now + EVENT_POLICY_V1.meshRequestDeadlineMs + 2_000;
    await this.#arm(now + EVENT_POLICY_V1.meshRequestDeadlineMs + 2_000);
    const result = this.ctx.storage.transactionSync(() => {
      const fresh = this.#requireCurrent(delivery.delivery_id, envelope, Date.now());
      if (fresh.transport_state === "accepted") return null;
      const claim = this.#nativeClaim(fresh.delivery_id);
      if (claim) {
        this.#acceptTransport(fresh.delivery_id);
        return null;
      }
      const active = row<{ attempt_id: string; transport_until: number }>(this.#sql,
        "SELECT attempt_id,transport_until FROM attempts WHERE delivery_id=? AND transport_status='sending' ORDER BY transport_until DESC LIMIT 1", delivery.delivery_id);
      if (active && active.transport_until > now) return null;
      if (active) this.#sql.exec("UPDATE attempts SET transport_status='failed',transport_reason='transport_unavailable' WHERE attempt_id=?", active.attempt_id);
      this.#sql.exec(`INSERT INTO attempts(attempt_id,delivery_id,envelope_json,state,transport_until,reservation_state,transport_status)
        VALUES (?,?,?,'created',?,'none','sending')`, envelope.attemptId, delivery.delivery_id, JSON.stringify(envelope), transportUntil);
      this.#sql.exec(`DELETE FROM attempts WHERE delivery_id=? AND attempt_id<>?
        AND state='created' AND reservation_state='none' AND transport_status='failed'
        AND permit_id IS NULL AND submission_id IS NULL AND turn_id IS NULL AND ack_json IS NULL
        AND NOT EXISTS (SELECT 1 FROM native_claims c WHERE c.attempt_id=attempts.attempt_id)
        AND NOT EXISTS (SELECT 1 FROM native_correlations c WHERE c.attempt_id=attempts.attempt_id)`,
        delivery.delivery_id, envelope.attemptId);
      this.#sql.exec("UPDATE deliveries SET transport_state='sending' WHERE delivery_id=?", delivery.delivery_id);
      this.#sql.exec(`INSERT INTO queue_outbox(delivery_id,due_at,attempts,state) VALUES (?,?,0,'claimed')
        ON CONFLICT(delivery_id) DO UPDATE SET due_at=excluded.due_at,state='claimed'`, delivery.delivery_id, transportUntil);
      return true;
    });
    if (!result) { await this.#schedule(); return null; }
    const latest = this.#runtime(delivery.runtime_id);
    if (!this.#runtimeReady(latest, Date.now()) || latest!.attachment_generation !== delivery.attachment_generation) {
      this.#sql.exec("UPDATE deliveries SET reason='runtime_expired' WHERE delivery_id=?", delivery.delivery_id);
      await this.#schedule();
      return null;
    }
    await this.#schedule();
    return { envelope, destination: { nodeId: node.node.nodeId, meshIp: node.node.meshIp, meshPort: node.node.meshPort } };
  }

  async recordTransportOutcome(job: EventJob, attemptId: string, outcome: TransportOutcome): Promise<void> {
    const parsedJob = jobSchema.safeParse(job);
    if (!parsedJob.success || parsedJob.data.principal !== this.#identity.principal || parsedJob.data.agent !== this.#identity.agent) throw new Error("invalid");
    const parsedAttempt = uuid.safeParse(attemptId);
    if (!parsedAttempt.success) throw new Error("invalid");
    const delivery = this.#delivery(parsedJob.data.deliveryId);
    const attempt = this.#attempt(attemptId);
    if (!delivery || !attempt || attempt.delivery_id !== delivery.delivery_id) throw new Error("not_found");
    const normalized = z.discriminatedUnion("status", [
      z.strictObject({ status: z.literal("transport_accepted") }),
      z.strictObject({ status: z.literal("transport_failed"), reason: z.enum(["transport_unavailable", "transport_rejected", "invalid_receipt", "transport_configuration"]) }),
    ]).safeParse(outcome);
    if (!normalized.success) throw new Error("invalid");
    const now = Date.now();
    const retryDue = Math.min(delivery.retry_until, now + retryDelay(delivery.transport_failures));
    if (delivery.state === "pending" && normalized.data.status === "transport_failed" && !this.#nativeClaim(delivery.delivery_id)) await this.#arm(retryDue);
    this.ctx.storage.transactionSync(() => {
      const fresh = this.#attempt(attemptId);
      const current = this.#delivery(delivery.delivery_id);
      if (!fresh || !current || fresh.delivery_id !== current.delivery_id) throw new Error("not_found");
      if (fresh.transport_status === "accepted" && normalized.data.status === "transport_accepted") return;
      if (fresh.transport_status === "failed" && normalized.data.status === "transport_failed" && fresh.transport_reason === normalized.data.reason) return;
      if (current.state !== "pending") {
        this.#sql.exec("UPDATE attempts SET transport_status=?,transport_reason=? WHERE attempt_id=?",
          normalized.data.status === "transport_accepted" ? "accepted" : "failed",
          normalized.data.status === "transport_failed" ? normalized.data.reason : null, attemptId);
        return;
      }
      if (normalized.data.status === "transport_accepted" || this.#nativeClaim(delivery.delivery_id)) {
        this.#sql.exec("UPDATE attempts SET transport_status='accepted',transport_reason=NULL WHERE attempt_id=?", attemptId);
        this.#acceptTransport(delivery.delivery_id);
        return;
      }
      this.#sql.exec("UPDATE attempts SET transport_status='failed',transport_reason=? WHERE attempt_id=?", normalized.data.reason, attemptId);
      this.#sql.exec("UPDATE deliveries SET transport_state='queued',transport_failures=transport_failures+1,reason=? WHERE delivery_id=?", normalized.data.reason, delivery.delivery_id);
      this.#sql.exec(`INSERT INTO queue_outbox(delivery_id,due_at,attempts,state) VALUES (?,?,0,'queued')
        ON CONFLICT(delivery_id) DO UPDATE SET due_at=excluded.due_at,state='queued'`, delivery.delivery_id, retryDue);
    });
    await this.#schedule();
  }

  async reconcileDeadLetter(job: EventJob): Promise<void> {
    const parsed = jobSchema.safeParse(job);
    if (!parsed.success || parsed.data.principal !== this.#identity.principal || parsed.data.agent !== this.#identity.agent) throw new Error("invalid");
    const delivery = this.#delivery(parsed.data.deliveryId);
    if (!delivery) return;
    if (delivery.state !== "pending" || delivery.transport_state === "accepted") {
      this.#sql.exec("DELETE FROM queue_outbox WHERE delivery_id=?", delivery.delivery_id);
      return;
    }
    if (this.#nativeClaim(delivery.delivery_id)) {
      this.#acceptTransport(delivery.delivery_id);
      return;
    }
    const now = Date.now();
    if (delivery.retry_until <= now) { await this.#expire(delivery, "transport_retry_horizon_elapsed"); return; }
    const due = Math.min(delivery.retry_until, now + retryDelay(delivery.transport_failures));
    await this.#arm(due);
    this.ctx.storage.transactionSync(() => {
      const current = this.#delivery(delivery.delivery_id);
      if (!current || current.state !== "pending" || current.transport_state === "accepted") {
        this.#sql.exec("DELETE FROM queue_outbox WHERE delivery_id=?", delivery.delivery_id);
        return;
      }
      if (this.#nativeClaim(current.delivery_id)) {
        this.#acceptTransport(current.delivery_id);
        return;
      }
      this.#sql.exec(`INSERT INTO queue_outbox(delivery_id,due_at,attempts,state) VALUES (?,?,0,'queued')
        ON CONFLICT(delivery_id) DO UPDATE SET due_at=excluded.due_at,state='queued'`,
        current.delivery_id, due);
    });
    await this.#schedule();
  }

  /** Apply an owner-registry revocation only with a fresh, tuple-bound proof from that registry. */
  async reconcileNodeRevocation(input: { nodeId: string; revokedGeneration: number }): Promise<void> {
    const parsed = revocationInputSchema.safeParse(input);
    if (!parsed.success) throw new Error("invalid");
    let confirmed: boolean;
    try {
      confirmed = await withDeadline(this.env.OWNER_REGISTRY.getByName(JSON.stringify(["event-owner-v1", this.#identity.principal]))
        .confirmNodeRevocation({ ...parsed.data, agent: this.#identity.agent }), EVENT_POLICY_V1.nativeRpcDeadlineMs);
    } catch {
      throw new EventApiError("authority_unavailable", 503);
    }
    if (confirmed !== true) throw new Error("denied");

    const now = Date.now();
    await this.#arm(now + EVENT_POLICY_V1.recoveryBackoffInitialMs);
    this.ctx.storage.transactionSync(() => {
      this.#sql.exec("UPDATE runtimes SET qualified=0 WHERE node_id=? AND node_generation<?",
        parsed.data.nodeId, parsed.data.revokedGeneration);
      const deliveries = this.#sql.exec<{ delivery_id: string; state: string }>(`SELECT delivery_id,state FROM deliveries
        WHERE node_id=? AND node_generation<? AND state IN ('pending','submitted','ambiguous')
        ORDER BY created_at,delivery_id LIMIT ?`, parsed.data.nodeId, parsed.data.revokedGeneration,
        EVENT_POLICY_V1.maxPendingDeliveriesPerAgent).toArray();
      for (const delivery of deliveries) {
        const claim = this.#nativeClaim(delivery.delivery_id);
        const attempt = row<{ attempt_id: string }>(this.#sql, `SELECT attempt_id FROM attempts WHERE delivery_id=?
          AND state IN ('admitted','submitted','ambiguous') LIMIT 1`, delivery.delivery_id);
        const accepted = ["admitted", "submitted", "ambiguous"].includes(claim?.state ?? "")
          || !!attempt || delivery.state === "submitted" || delivery.state === "ambiguous";
        if (accepted) {
          this.#sql.exec("UPDATE deliveries SET state='ambiguous',reason='node_revoked' WHERE delivery_id=? AND state IN ('pending','submitted','ambiguous')",
            delivery.delivery_id);
          this.#sql.exec(`UPDATE native_claims SET state='ambiguous',updated_at=? WHERE delivery_id=?
            AND state IN ('admitted','submitted','ambiguous')`, now, delivery.delivery_id);
          this.#sql.exec(`UPDATE attempts SET state='ambiguous' WHERE delivery_id=? AND state IN ('admitted','submitted','ambiguous')`,
            delivery.delivery_id);
          this.#sql.exec("DELETE FROM queue_outbox WHERE delivery_id=?", delivery.delivery_id);
          continue;
        }
        if (delivery.state !== "pending") continue;
        this.#sql.exec(`UPDATE deliveries SET state='failed',reason='node_revoked',terminal_at=COALESCE(terminal_at,?)
          WHERE delivery_id=? AND state='pending'`, now, delivery.delivery_id);
        this.#sql.exec("DELETE FROM queue_outbox WHERE delivery_id=?", delivery.delivery_id);
        const current = this.#delivery(delivery.delivery_id);
        if (current) this.#releaseSlotLater(current.delivery_id, current.node_id, current.node_generation, now);
      }
    });
    await this.#schedule();
  }

  async alarm(): Promise<void> {
    const now = Date.now();
    await this.#drainGitHubSourceOutbox();
    for (const claim of this.#sql.exec<{ delivery_id: string; attempt_id: string; updated_at: number }>(
      "SELECT delivery_id,attempt_id,updated_at FROM native_claims WHERE state='reserving' AND updated_at<=? ORDER BY updated_at LIMIT 10",
      now - EVENT_POLICY_V1.nativeRpcDeadlineMs)) {
      this.ctx.storage.transactionSync(() => {
        const cutoff = now - EVENT_POLICY_V1.nativeRpcDeadlineMs;
        this.#sql.exec(`UPDATE native_claims SET state='unknown',updated_at=?
          WHERE delivery_id=? AND attempt_id=? AND state='reserving' AND updated_at<=?`, now, claim.delivery_id, claim.attempt_id, cutoff);
        this.#sql.exec(`UPDATE attempts SET state='unknown',reservation_state='unknown'
          WHERE attempt_id=? AND delivery_id=? AND state='reserving'`, claim.attempt_id, claim.delivery_id);
        this.#sql.exec("UPDATE deliveries SET reason='authority_unavailable' WHERE delivery_id=? AND state='pending'", claim.delivery_id);
      });
    }
    for (const claim of this.#sql.exec<{ delivery_id: string; attempt_id: string; permit_until: number }>(
      "SELECT delivery_id,attempt_id,permit_until FROM native_claims WHERE state='admitted' AND permit_until+?<=? ORDER BY permit_until LIMIT 10",
      EVENT_POLICY_V1.nativeRpcDeadlineMs, now)) {
      this.ctx.storage.transactionSync(() => {
        const cutoff = now - EVENT_POLICY_V1.nativeRpcDeadlineMs;
        this.#sql.exec(`UPDATE native_claims SET state='ambiguous',updated_at=?
          WHERE delivery_id=? AND attempt_id=? AND state='admitted' AND permit_until<=?`, now, claim.delivery_id, claim.attempt_id, cutoff);
        this.#sql.exec("UPDATE attempts SET state='ambiguous' WHERE attempt_id=? AND delivery_id=? AND state='admitted'",
          claim.attempt_id, claim.delivery_id);
        this.#sql.exec("UPDATE deliveries SET state='ambiguous',reason='native_outcome_unknown' WHERE delivery_id=? AND state='pending'",
          claim.delivery_id);
      });
    }
    const dueUnadmitted = this.#sql.exec<{ delivery_id: string }>(`SELECT d.delivery_id FROM deliveries d
      WHERE d.state='pending' AND d.retry_until<=?
      AND NOT EXISTS (SELECT 1 FROM native_claims c WHERE c.delivery_id=d.delivery_id
        AND c.state IN ('admitted','submitted','observed','ambiguous'))
      AND NOT EXISTS (SELECT 1 FROM attempts a WHERE a.delivery_id=d.delivery_id
        AND a.state IN ('admitted','submitted','observed','ambiguous'))
      ORDER BY d.retry_until,d.delivery_id LIMIT 10`, now).toArray();
    for (const item of dueUnadmitted) {
      const delivery = this.#delivery(item.delivery_id);
      if (delivery) await this.#expire(delivery, "transport_retry_horizon_elapsed");
    }
    for (const intent of this.#sql.exec<{ delivery_id: string; state: string }>(
      "SELECT delivery_id,state FROM slot_intents WHERE state!='reserved' AND next_at<=? ORDER BY next_at LIMIT 10", now)) {
      if (intent.state === "release_pending") await this.#releaseSlot(intent.delivery_id);
      else await this.#reserveSlot(intent.delivery_id);
    }
    if (this.env.EVENT_ENABLED === "true" && this.#enabled()) {
      const due = this.#sql.exec<{ delivery_id: string }>("SELECT delivery_id FROM queue_outbox WHERE due_at<=? ORDER BY due_at LIMIT 10", now).toArray();
      for (const item of due) {
        const delivery = this.#delivery(item.delivery_id);
        if (!delivery || delivery.state !== "pending" || delivery.transport_state === "accepted") {
          this.#sql.exec("DELETE FROM queue_outbox WHERE delivery_id=?", item.delivery_id);
          continue;
        }
        if (delivery.retry_until <= now) { await this.#expire(delivery, "transport_retry_horizon_elapsed"); continue; }
        const outbox = row<{ attempts: number }>(this.#sql, "SELECT attempts FROM queue_outbox WHERE delivery_id=?", delivery.delivery_id);
        const attemptCount = outbox?.attempts ?? 0;
        const nextDue = Math.min(delivery.retry_until, now + retryDelay(attemptCount));
        // Keep the outbox durable until an authenticated Gateway receipt or native claim proves handoff.
        // Advancing the lease before send makes a crash or a slow Queue call recoverable.
        await this.#arm(nextDue);
        const leased = this.ctx.storage.transactionSync(() => this.#sql.exec(
          "UPDATE queue_outbox SET attempts=attempts+1,due_at=?,state='sent' WHERE delivery_id=? AND due_at<=?",
          nextDue, delivery.delivery_id, now).rowsWritten > 0);
        if (!leased) continue;
        try {
          await this.env.DELIVERY_QUEUE.send({ principal: this.#identity.principal, agent: this.#identity.agent, deliveryId: delivery.delivery_id });
        } catch { /* The pre-send lease already records this handoff and its retry deadline. */ }
      }
    } else {
      // Do not let a disabled Worker spin on an already-due durable handoff.
      this.#sql.exec("UPDATE queue_outbox SET due_at=?,state='queued' WHERE due_at<=?", now + EVENT_POLICY_V1.recoveryBackoffMaxMs, now);
    }
    this.#cleanupTerminalDeliveries(now);
    await this.#schedule();
  }

  #enabled(): boolean { return row<{ enabled: number }>(this.#sql, "SELECT enabled FROM coordinator_state WHERE id=1")?.enabled === 1; }
  #acceptTransport(deliveryId: string): void {
    this.#sql.exec(`UPDATE deliveries SET transport_state='accepted',reason=CASE
      WHEN reason IN ('authority_denied','authority_invalid','authority_unavailable','over_budget') THEN reason ELSE NULL END
      WHERE delivery_id=? AND state='pending'`, deliveryId);
    this.#sql.exec("DELETE FROM queue_outbox WHERE delivery_id=?", deliveryId);
  }
  #runtime(runtimeId: string): RuntimeRow | null {
    return this.#nativeStore.runtime(runtimeId);
  }
  #runtimeReady(runtime: RuntimeRow | null, now: number): runtime is RuntimeRow {
    return !!runtime && runtime.qualified === 1 && runtime.lease_until > now;
  }
  #sameRuntime(expected: RuntimeRow | null, runtimeId: string, now: number): boolean {
    const current = this.#runtime(runtimeId);
    return !!expected && this.#runtimeReady(current, now)
      && current.runtime_generation === expected.runtime_generation && current.node_id === expected.node_id
      && current.node_generation === expected.node_generation && current.attachment_generation === expected.attachment_generation;
  }
  #delivery(deliveryId: string): DeliveryRow | null {
    return row<DeliveryRow>(this.#sql, "SELECT delivery_id,event_id,subject_id,source_state_version,runtime_id,runtime_generation,attachment_generation,node_id,node_generation,state,reason,created_at,retry_until,transport_state,transport_failures FROM deliveries WHERE delivery_id=?", deliveryId);
  }
  #attempt(attemptId: string): AttemptRow | null {
    return row<AttemptRow>(this.#sql, "SELECT attempt_id,delivery_id,envelope_json,state,transport_until,permit_id,permit_until,reservation_state,submission_id,turn_id,ack_json,native_observed_ack_json,transport_status,transport_reason FROM attempts WHERE attempt_id=?", attemptId);
  }
  #source(subjectId: string): { event_id: string; source_state_version: string; event_reference: string; observed_at: string } | null {
    return row(this.#sql, "SELECT event_id,source_state_version,event_reference,observed_at FROM manual_sources WHERE subject_id=?", subjectId);
  }
  #nativeClaim(deliveryId: string): NativeClaimRow | null {
    return row(this.#sql, "SELECT delivery_id,attempt_id,state,permit_id,permit_issued_at,permit_until,envelope_json,updated_at FROM native_claims WHERE delivery_id=?", deliveryId);
  }
  #makeEnvelope(delivery: DeliveryRow, attemptId: string, now: number): EventEnvelopeV1 {
    const source = this.#source(delivery.subject_id);
    if (!source || source.event_id !== delivery.event_id || source.source_state_version !== delivery.source_state_version) throw new Error("conflict");
    return {
      schemaVersion: 1, eventId: delivery.event_id, source: "manual",
      canonicalSubject: { kind: "manual", subjectId: delivery.subject_id },
      sourceStateVersion: source.source_state_version, policyRevision: EVENT_INITIAL_POLICY_REVISION,
      observedAt: source.observed_at, principal: this.#identity.principal, agent: this.#identity.agent,
      eventReference: source.event_reference, runtimeId: delivery.runtime_id,
      nodeGeneration: delivery.node_generation, runtimeGeneration: delivery.runtime_generation,
      attachmentGeneration: delivery.attachment_generation, deliveryId: delivery.delivery_id,
      attemptId, issuedAt: nowIso(now), expiresAt: nowIso(now + EVENT_POLICY_V1.freshnessLifetimeMs),
      eventKind: "manual", reasonCode: "owner_canary",
    };
  }
  #requireDestination(deliveryId: string, now: number): DeliveryRow {
    const delivery = this.#delivery(deliveryId);
    if (!delivery) throw new Error("not_found");
    const runtime = this.#runtime(delivery.runtime_id);
    const source = this.#source(delivery.subject_id);
    const slot = row<{ node_id: string; node_generation: number; state: string }>(this.#sql,
      "SELECT node_id,node_generation,state FROM slot_intents WHERE delivery_id=?", deliveryId);
    if (!this.#enabled()) throw new Error("denied");
    if (delivery.state !== "pending" || delivery.retry_until <= now) throw new Error("expired");
    if (!slot || slot.state !== "reserved" || slot.node_id !== delivery.node_id || slot.node_generation !== delivery.node_generation) throw new Error("denied");
    if (!this.#runtimeReady(runtime, now) || runtime.runtime_id !== delivery.runtime_id
      || runtime.runtime_generation !== delivery.runtime_generation || runtime.node_id !== delivery.node_id
      || runtime.node_generation !== delivery.node_generation || runtime.attachment_generation !== delivery.attachment_generation
      || !source || source.event_id !== delivery.event_id || source.source_state_version !== delivery.source_state_version) throw new Error("conflict");
    return delivery;
  }
  #requireCurrent(deliveryId: string, envelope: EventEnvelopeV1, now: number): DeliveryRow {
    const delivery = this.#requireDestination(deliveryId, now);
    if (delivery.runtime_id !== envelope.runtimeId || delivery.runtime_generation !== envelope.runtimeGeneration
      || delivery.node_generation !== envelope.nodeGeneration || delivery.attachment_generation !== envelope.attachmentGeneration
      || delivery.event_id !== envelope.eventId || delivery.source_state_version !== envelope.sourceStateVersion) throw new Error("conflict");
    return delivery;
  }
  #isCurrentDestination(delivery: DeliveryRow, now: number): boolean {
    const runtime = this.#runtime(delivery.runtime_id);
    const source = this.#source(delivery.subject_id);
    return this.#runtimeReady(runtime, now) && runtime.runtime_generation === delivery.runtime_generation
      && runtime.node_id === delivery.node_id && runtime.node_generation === delivery.node_generation
      && runtime.attachment_generation === delivery.attachment_generation
      && !!source && source.event_id === delivery.event_id && source.source_state_version === delivery.source_state_version;
  }
  async #currentNode(delivery: DeliveryRow): Promise<{ node: { nodeId: string; meshIp: string; meshPort: number; generation: number } } | null> {
    let result: NodeAuthorization;
    try {
      result = await withDeadline<NodeAuthorization>(this.env.OWNER_REGISTRY.getByName(JSON.stringify(["event-owner-v1", this.#identity.principal]))
        .currentNode({ nodeId: delivery.node_id, agent: this.#identity.agent, generation: delivery.node_generation }), EVENT_POLICY_V1.nativeRpcDeadlineMs);
    } catch { throw new EventApiError("authority_unavailable", 503); }
    if (result.status === "authorized") return { node: result.node };
    if (result.status === "denied") return null;
    throw new EventApiError("authority_unavailable", 503);
  }
  async #arm(at: number): Promise<void> {
    await this.ctx.blockConcurrencyWhile(async () => {
      const alarm = await this.ctx.storage.getAlarm();
      if (alarm === null || alarm > at) await this.ctx.storage.setAlarm(at);
    });
  }
  async #schedule(): Promise<void> {
    const intent = row<{ next_at: number | null }>(this.#sql, "SELECT min(next_at) AS next_at FROM slot_intents WHERE state!='reserved'")?.next_at ?? null;
    const ownerEnabled = this.#enabled();
    const outboxDue = ownerEnabled
      ? row<{ due_at: number | null }>(this.#sql, `SELECT min(q.due_at) AS due_at FROM queue_outbox q
        JOIN deliveries d ON d.delivery_id=q.delivery_id WHERE d.state='pending' AND d.transport_state!='accepted'`)?.due_at ?? null
      : null;
    const due = outboxDue === null ? null : this.env.EVENT_ENABLED === "true"
      ? outboxDue
      : Math.min(outboxDue, Date.now() + EVENT_POLICY_V1.recoveryBackoffMaxMs);
    const unadmitted = row<{ deadline: number | null }>(this.#sql, `SELECT min(d.retry_until) AS deadline FROM deliveries d
      WHERE d.state='pending'
      AND NOT EXISTS (SELECT 1 FROM native_claims c WHERE c.delivery_id=d.delivery_id
        AND c.state IN ('admitted','submitted','observed','ambiguous'))
      AND NOT EXISTS (SELECT 1 FROM attempts a WHERE a.delivery_id=d.delivery_id
        AND a.state IN ('admitted','submitted','observed','ambiguous'))`)?.deadline ?? null;
    const native = row<{ deadline: number | null }>(this.#sql,
      "SELECT min(updated_at) + ? AS deadline FROM native_claims WHERE state='reserving'", EVENT_POLICY_V1.nativeRpcDeadlineMs)?.deadline ?? null;
    const admission = row<{ deadline: number | null }>(this.#sql,
      "SELECT min(permit_until) + ? AS deadline FROM native_claims WHERE state='admitted'", EVENT_POLICY_V1.nativeRpcDeadlineMs)?.deadline ?? null;
    const retention = row<{ deadline: number | null }>(this.#sql, `SELECT min(d.terminal_at) + ? AS deadline
      FROM deliveries d WHERE d.state IN ('observed','expired','failed') AND d.terminal_at IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM slot_intents s WHERE s.delivery_id=d.delivery_id)`,
      EVENT_POLICY_V1.terminalDeduplicationRetentionMs)?.deadline ?? null;
    const githubSource = this.#githubSourceControls.nextAt();
    const deadlines = [intent, due, unadmitted, native, admission, retention, githubSource].filter((value): value is number => value !== null);
    if (deadlines.length) await this.#arm(Math.max(Date.now() + 250, Math.min(...deadlines)));
  }
  #cleanupTerminalDeliveries(now: number): void {
    const cutoff = now - EVENT_POLICY_V1.terminalDeduplicationRetentionMs;
    this.ctx.storage.transactionSync(() => {
      const candidates = this.#sql.exec<{ delivery_id: string }>(`SELECT d.delivery_id FROM deliveries d
        WHERE d.state IN ('observed','expired','failed') AND d.terminal_at IS NOT NULL AND d.terminal_at<=?
        AND NOT EXISTS (SELECT 1 FROM slot_intents s WHERE s.delivery_id=d.delivery_id)
        ORDER BY d.terminal_at,d.delivery_id LIMIT 10`, cutoff).toArray();
      for (const candidate of candidates) {
        this.#sql.exec("DELETE FROM no_start_settlements WHERE delivery_id=?", candidate.delivery_id);
        this.#sql.exec("DELETE FROM attempts WHERE delivery_id=?", candidate.delivery_id);
        this.#sql.exec("DELETE FROM native_claims WHERE delivery_id=?", candidate.delivery_id);
        this.#sql.exec("DELETE FROM native_correlations WHERE delivery_id=?", candidate.delivery_id);
        this.#sql.exec("DELETE FROM queue_outbox WHERE delivery_id=?", candidate.delivery_id);
        this.#sql.exec(`DELETE FROM deliveries WHERE delivery_id=? AND state IN ('observed','expired','failed')
          AND terminal_at IS NOT NULL AND terminal_at<=?
          AND NOT EXISTS (SELECT 1 FROM slot_intents s WHERE s.delivery_id=deliveries.delivery_id)`,
          candidate.delivery_id, cutoff);
      }
    });
  }
  async #reserveSlot(deliveryId: string): Promise<void> {
    const intent = row<{ node_id: string; node_generation: number; state: string; attempts: number }>(this.#sql,
      "SELECT node_id,node_generation,state,attempts FROM slot_intents WHERE delivery_id=?", deliveryId);
    const delivery = this.#delivery(deliveryId);
    if (!intent || intent.state !== "reserve_pending" || !delivery) return;
    const runtime = this.#runtime(delivery.runtime_id);
    const source = this.#source(delivery.subject_id);
    if (!this.#runtimeReady(runtime, Date.now()) || runtime.node_id !== intent.node_id || runtime.node_generation !== intent.node_generation
      || runtime.runtime_generation !== delivery.runtime_generation || runtime.attachment_generation !== delivery.attachment_generation
      || !source || source.event_id !== delivery.event_id || source.source_state_version !== delivery.source_state_version
      || delivery.retry_until <= Date.now()) {
      await this.#expire(delivery, "destination_expired");
      return;
    }
    const next = Date.now() + (this.#enabled() ? EVENT_POLICY_V1.nativeRpcDeadlineMs + retryDelay(intent.attempts) : EVENT_POLICY_V1.recoveryBackoffMaxMs);
    await this.#arm(next);
    const currentIntent = row<{ state: string }>(this.#sql, "SELECT state FROM slot_intents WHERE delivery_id=?", deliveryId);
    if (currentIntent?.state !== "reserve_pending") return;
    this.#sql.exec("UPDATE slot_intents SET attempts=attempts+1,next_at=?,updated_at=? WHERE delivery_id=? AND state='reserve_pending'", next, Date.now(), deliveryId);
    if (!this.#enabled() || this.env.EVENT_ENABLED !== "true") return;
    let result: { status: "reserved" | "capacity" | "denied" };
    try {
      result = await withDeadline(this.env.OWNER_REGISTRY.getByName(JSON.stringify(["event-owner-v1", this.#identity.principal]))
        .reserveSlot({ nodeId: intent.node_id, agent: this.#identity.agent, generation: intent.node_generation, deliveryId }), EVENT_POLICY_V1.nativeRpcDeadlineMs);
    } catch {
      this.#sql.exec("UPDATE slot_intents SET next_at=? WHERE delivery_id=? AND state='reserve_pending'", Date.now() + retryDelay(intent.attempts), deliveryId);
      await this.#schedule();
      return;
    }
    await this.#arm(Date.now());
    const fresh = this.#delivery(deliveryId);
    const freshSource = fresh ? this.#source(fresh.subject_id) : null;
    if (!fresh || fresh.state !== "pending" || !this.#sameRuntime(runtime, fresh.runtime_id, Date.now())
      || !freshSource || freshSource.event_id !== delivery.event_id || freshSource.source_state_version !== delivery.source_state_version) {
      if (fresh) await this.#expire(fresh, "destination_expired");
      else {
        this.#releaseSlotLater(deliveryId, intent.node_id, intent.node_generation, Date.now());
        await this.#releaseSlot(deliveryId);
      }
      return;
    }
    if (result.status !== "reserved") {
      await this.#expire(fresh, result.status);
      return;
    }
    this.ctx.storage.transactionSync(() => {
      this.#sql.exec("UPDATE slot_intents SET state='reserved',updated_at=? WHERE delivery_id=? AND state='reserve_pending'", Date.now(), deliveryId);
      this.#sql.exec("INSERT INTO queue_outbox(delivery_id,due_at,attempts) VALUES (?,?,0) ON CONFLICT(delivery_id) DO NOTHING", deliveryId,
        Date.now() + (this.#enabled() ? 0 : EVENT_POLICY_V1.recoveryBackoffMaxMs));
    });
    await this.#schedule();
  }
  async #releaseSlot(deliveryId: string): Promise<void> {
    const intent = row<{ node_id: string; node_generation: number; state: string; attempts: number }>(this.#sql,
      "SELECT node_id,node_generation,state,attempts FROM slot_intents WHERE delivery_id=?", deliveryId);
    if (!intent || intent.state !== "release_pending") return;
    const next = Date.now() + EVENT_POLICY_V1.nativeRpcDeadlineMs + retryDelay(intent.attempts);
    await this.#arm(next);
    this.#sql.exec("UPDATE slot_intents SET attempts=attempts+1,next_at=?,updated_at=? WHERE delivery_id=? AND state='release_pending'", next, Date.now(), deliveryId);
    try {
      await withDeadline(this.env.OWNER_REGISTRY.getByName(JSON.stringify(["event-owner-v1", this.#identity.principal]))
        .releaseSlot({ nodeId: intent.node_id, agent: this.#identity.agent, deliveryId }), EVENT_POLICY_V1.nativeRpcDeadlineMs);
      this.#sql.exec("DELETE FROM slot_intents WHERE delivery_id=? AND node_id=? AND node_generation=? AND state='release_pending'", deliveryId, intent.node_id, intent.node_generation);
    } catch {
      this.#sql.exec("UPDATE slot_intents SET next_at=? WHERE delivery_id=? AND state='release_pending'", Date.now() + retryDelay(intent.attempts), deliveryId);
      await this.#schedule();
    }
  }
  #releaseSlotLater(deliveryId: string, nodeId: string, nodeGeneration: number, now: number): void {
    this.#sql.exec("INSERT INTO slot_intents(delivery_id,node_id,node_generation,state,updated_at,next_at) VALUES (?,?,?,'release_pending',?,?) ON CONFLICT(delivery_id) DO UPDATE SET state='release_pending',attempts=0,next_at=excluded.next_at,updated_at=excluded.updated_at",
      deliveryId, nodeId, nodeGeneration, now, now);
  }
  async #expire(delivery: DeliveryRow, reason: string): Promise<void> {
    const now = Date.now();
    await this.#arm(now + EVENT_POLICY_V1.recoveryBackoffInitialMs);
    const expired = this.ctx.storage.transactionSync((): boolean => {
      const claim = this.#nativeClaim(delivery.delivery_id);
      const admittedAttempt = row<{ attempt_id: string }>(this.#sql, `SELECT attempt_id FROM attempts WHERE delivery_id=?
        AND state IN ('admitted','submitted','observed','ambiguous') LIMIT 1`, delivery.delivery_id);
      if ((claim && ["admitted", "submitted", "observed", "ambiguous"].includes(claim.state)) || admittedAttempt) return false;
      const fresh = this.#delivery(delivery.delivery_id);
      if (!fresh || fresh.state !== "pending") return false;
      this.#sql.exec("UPDATE deliveries SET state=?,reason=?,terminal_at=COALESCE(terminal_at,?) WHERE delivery_id=? AND state='pending'",
        reason === "capacity" || reason === "denied" ? "failed" : "expired", reason, now, delivery.delivery_id);
      this.#sql.exec("DELETE FROM queue_outbox WHERE delivery_id=?", delivery.delivery_id);
      this.#releaseSlotLater(fresh.delivery_id, fresh.node_id, fresh.node_generation, now);
      return true;
    });
    if (expired) await this.#releaseSlot(delivery.delivery_id);
    await this.#schedule();
  }
}
