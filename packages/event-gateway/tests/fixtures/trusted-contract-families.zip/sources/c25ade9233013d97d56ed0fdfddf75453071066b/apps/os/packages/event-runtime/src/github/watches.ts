import { z } from 'zod';
import { canonicalEmail } from 'openapi-operator/src/access';
import { agent, generation, uuid } from '../contracts';
import { EVENT_POLICY_V1 } from '../policy';

const subjectSchema = z.strictObject({ repositoryId: generation, prNumber: generation });
const holderSchema = z.strictObject({ runtimeId: uuid, runtimeGeneration: generation, attachmentGeneration: generation, nodeId: uuid, nodeGeneration: generation });
type Subject = z.infer<typeof subjectSchema>;
type Holder = z.infer<typeof holderSchema>;
export interface GitHubDeliveryWatch {
  subject: Subject; revision: number; incarnation: number; lifecycleEpoch: number;
  installationId: number; sourceIncarnation: number;
  state: 'attached' | 'detached' | 'retired'; holder: Holder | null;
}
const expectedRevisionSchema = generation.or(z.literal(0));
function next(value: number): number {
  if (value >= Number.MAX_SAFE_INTEGER) throw new Error('github_watch_conflict');
  return value + 1;
}

/** Disabled persistence only. Callers must authorize before use; no source or dispatch side effects. */
export class GitHubDeliveryWatchStore {
  constructor(private readonly storage: DurableObjectStorage, private readonly principal: string, private readonly agentName: string, private readonly otherWatchCount: () => number) {
    if (!canonicalEmail(principal) || principal !== principal.toLowerCase()) throw new Error('github_denied');
    agent.parse(agentName);
    storage.sql.exec('CREATE TABLE IF NOT EXISTS github_delivery_watches (owner TEXT NOT NULL, subject TEXT NOT NULL, value TEXT NOT NULL, operation TEXT NOT NULL, PRIMARY KEY(owner,subject))');
  }
  private owner() { return JSON.stringify([this.principal, this.agentName]); }
  private key(subject: Subject) { return JSON.stringify([subject.repositoryId, subject.prNumber]); }
  get(input: Subject): GitHubDeliveryWatch | null {
    const subject = subjectSchema.parse(input);
    const row = this.storage.sql.exec<{ value: string }>('SELECT value FROM github_delivery_watches WHERE owner=? AND subject=?', this.owner(), this.key(subject)).toArray().at(0);
    return row ? JSON.parse(row.value) as GitHubDeliveryWatch : null;
  }
  private save(value: GitHubDeliveryWatch, operation: string): GitHubDeliveryWatch {
    this.storage.sql.exec('INSERT OR REPLACE INTO github_delivery_watches(owner,subject,value,operation) VALUES (?,?,?,?)', this.owner(), this.key(value.subject), JSON.stringify(value), operation);
    return value;
  }
  private replay(subject: Subject, operation: string): GitHubDeliveryWatch | null {
    const row = this.storage.sql.exec<{ value: string; operation: string }>('SELECT value,operation FROM github_delivery_watches WHERE owner=? AND subject=?', this.owner(), this.key(subjectSchema.parse(subject))).toArray().at(0);
    return row?.operation === operation ? JSON.parse(row.value) as GitHubDeliveryWatch : null;
  }
  private current(subject: Subject, expectedRevision: number): GitHubDeliveryWatch {
    generation.parse(expectedRevision);
    const prior = this.get(subject);
    if (!prior || prior.revision !== expectedRevision || prior.state === 'retired') throw new Error('github_watch_conflict');
    return prior;
  }
  create(input: Subject, installationId: number, holder: Holder, expectedRevision: number): GitHubDeliveryWatch {
    const subject = subjectSchema.parse(input), target = holderSchema.parse(holder);
    generation.parse(installationId); expectedRevisionSchema.parse(expectedRevision);
    const operation = JSON.stringify(['create', subject, installationId, target, expectedRevision]);
    return this.storage.transactionSync(() => {
      const replay = this.replay(subject, operation);
      if (replay) return replay;
      const prior = this.get(subject);
      if ((prior?.revision ?? 0) !== expectedRevision || (prior && prior.state !== 'retired')) throw new Error('github_watch_conflict');
      const active = this.storage.sql.exec<{ n: number }>("SELECT count(*) AS n FROM github_delivery_watches WHERE owner=? AND json_extract(value,'$.state')!='retired'", this.owner()).one().n;
      // Trusted coordinator supplies its other watch count synchronously in this transaction.
      const other = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER).parse(this.otherWatchCount());
      if (active + other >= EVENT_POLICY_V1.maxWatchesPerAgent) throw new Error('github_capacity');
      // shortcut: retain at most 1000 canonical lifecycle rows per owner/agent; reviewed cleanup is required before reuse beyond this bound.
      if (!prior && this.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_delivery_watches WHERE owner=?', this.owner()).one().n >= 1000) throw new Error('github_capacity');
      return this.save({ subject, revision: next(prior?.revision ?? 0), incarnation: next(prior?.incarnation ?? 0), lifecycleEpoch: next(prior?.lifecycleEpoch ?? 0),
        installationId, sourceIncarnation: next(prior?.sourceIncarnation ?? 0), state: 'attached', holder: target }, operation);
    });
  }
  transfer(subject: Subject, holder: Holder, expectedRevision: number): GitHubDeliveryWatch {
    const target = holderSchema.parse(holder);
    const operation = JSON.stringify(['transfer', subjectSchema.parse(subject), target, expectedRevision]);
    return this.storage.transactionSync(() => {
      const replay = this.replay(subject, operation);
      if (replay) return replay;
      const prior = this.current(subject, expectedRevision);
      return this.save({ ...prior, revision: next(prior.revision), state: 'attached', holder: target }, operation);
    });
  }
  detach(subject: Subject, expectedRevision: number): GitHubDeliveryWatch {
    const operation = JSON.stringify(['detach', subjectSchema.parse(subject), expectedRevision]);
    return this.storage.transactionSync(() => {
      const replay = this.replay(subject, operation);
      if (replay) return replay;
      const prior = this.current(subject, expectedRevision);
      return this.save({ ...prior, revision: next(prior.revision), state: 'detached', holder: null }, operation);
    });
  }
  retire(subject: Subject, expectedRevision: number): GitHubDeliveryWatch {
    const operation = JSON.stringify(['retire', subjectSchema.parse(subject), expectedRevision]);
    return this.storage.transactionSync(() => {
      const replay = this.replay(subject, operation);
      if (replay) return replay;
      const prior = this.current(subject, expectedRevision);
      return this.save({ ...prior, revision: next(prior.revision), lifecycleEpoch: next(prior.lifecycleEpoch), state: 'retired', holder: null }, operation);
    });
  }
}
