import { GitHubSourceReadRequestSchema, type GitHubSourceReadRequest, type GitHubSourceReadResult } from './readback-contract';
import { DurableObject } from 'cloudflare:workers';
import { canonicalEmail } from 'openapi-operator/src/access';
import { z } from 'zod';
import { GitHubAttentionController, GITHUB_SOURCE_STALE_MS, createInitialGitHubSnapshot, type GitHubSource, type GitHubAdmissionV1 } from './controller';
import { GitHubAppClient } from './client';
import { GitHubGrantSubjectSchema, GitHubGrantViewSchema, GitHubSourceStatusSchema, parseGitHubSourceMap, type GitHubGrantView, type GitHubSourceStatus, type GitHubPublicationDisposition, type GitHubPublicationInput, type GitHubPublicationPin, type GitHubPublicationRelease } from './grants';
import { validSubject, type GitHubTriggerV1 } from './ingress';
import { subjectKey, type GitHubSubjectV1 } from './state';
import { agent as agentSchema, coordinatorName } from '../contracts';
import { EventRequestDeadline } from '../request-deadline';
import { EVENT_POLICY_V1 } from '../policy';
import { GitHubSourceControlTokenSchema, GitHubSourceFenceStatusSchema, GitHubSourceParkingResultSchema, GitHubSourceRevalidationResultSchema, sourceTokenEquals,
  type GitHubSourceControlToken, type GitHubSourceFenceStatus, type GitHubSourceParkingResult, type GitHubSourceRevalidationResult } from './source-control';

export interface GitHubHostIdentity { principal: string; agent: string; subject: GitHubSubjectV1 }
export interface GitHubHostCoordinator {
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  githubGrant(subject: GitHubSubjectV1): Promise<GitHubGrantView | null>;
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  currentGitHubSourceControl?(subject: GitHubSubjectV1): Promise<{ token: GitHubSourceControlToken; state: 'activation_pending' | 'active'; deploymentEpoch: number } | null>;
  parkGitHubSource?(subject: GitHubSubjectV1, operationId: string, token: GitHubSourceControlToken): Promise<GitHubSourceParkingResult>;
  revalidateGitHubSource?(input: { subject: GitHubSubjectV1; operationId: string; token: GitHubSourceControlToken; expectedControl: { operationId: string; sourceIncarnation: number; lifecycleEpoch: number }; sourceVersion: number; hostEpoch: number }): Promise<GitHubSourceRevalidationResult>;
  // eslint-disable-next-line no-unused-vars -- This exact readback fences both legacy and controlled hosts.
  githubSourceFenceStatus?(subject: GitHubSubjectV1): Promise<GitHubSourceFenceStatus>;
  githubWatches(): Promise<GitHubSubjectV1[]>;
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  githubPublicationReceipt(input: GitHubPublicationInput): Promise<{ status: 'accepted'; publicationId: string } | null>;
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  githubPublicationStatus(input: GitHubPublicationInput): Promise<GitHubPublicationDisposition | null>;
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  adoptGitHubPublication(input: GitHubPublicationInput, pin: GitHubPublicationPin): Promise<GitHubPublicationDisposition | null>;
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  publishGitHub(input: GitHubPublicationInput, pin: GitHubPublicationPin, sourceToken?: GitHubSourceControlToken): Promise<GitHubPublicationDisposition>;
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  acknowledgeGitHubPublicationRelease(input: GitHubPublicationInput, disposition: 'settled' | 'terminal'): Promise<GitHubPublicationRelease>;
}
export interface GitHubHostEnvironment {
  EVENT_GITHUB_ENABLED?: string; EVENT_GITHUB_SOURCE_CONTROL_ENABLED?: string; EVENT_GITHUB_SOURCE_GATE_EPOCH?: string; EVENT_HOST: string;
  GITHUB_APP_ID?: string; GITHUB_APP_PRIVATE_KEY?: string; GITHUB_WEBHOOK_SECRET?: string; GITHUB_SOURCE_MAP?: string;
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  GITHUB_WEBHOOK_INBOX?: { getByName(name: string): { enqueue(trigger: GitHubTriggerV1): Promise<'accepted' | 'denied'> } };
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  AGENT_COORDINATOR: { getByName(name: string): GitHubHostCoordinator };
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  GITHUB_ATTENTION_HOST: { getByName(name: string): { accept(identity: GitHubHostIdentity, trigger: GitHubTriggerV1): Promise<'accepted' | 'denied'> } };
}
export type GitHubQuiesceResult =
  | { status: 'quiesced'; operationId: string; sourceVersion: number; hostEpoch: number }
  | { status: 'checkpoint_conflict'; operationId: string; reason: 'checkpoint_changed' | 'host_epoch_exhausted'; hostControl: 'absent'; expectedSourceVersion: number; expectedHostEpoch: number; sourceVersion: number; hostEpoch: number };
type GitHubSourceMappingV1 = ReturnType<typeof parseGitHubSourceMap>[number];
type GitHubAdmissionClient = Pick<GitHubAppClient, 'admit' | 'observe'>;
type GitHubSourceRpcFence = { generation: number; operationId: string | null; phase: 'prepare' | 'quiesce' | null };
type GitHubHostAlarmCheckpoint = { localSourceControlJson: string; hasSnapshot: boolean; validRetainedSnapshot: boolean; snapshotValue: string | null; snapshotEpoch: number | null; sourceRpcFence: GitHubSourceRpcFence };
type GitHubSourceAlarmFenceReadback = { fence: GitHubSourceFenceStatus | null; transientFailure: boolean };
export const githubHostName = (identity: GitHubHostIdentity): string => JSON.stringify(['event-github-v1', identity.principal, identity.agent, identity.subject.installationId, identity.subject.repositoryId, identity.subject.prNumber]);
function sourceGateEpoch(value: string | undefined): number | null {
  if (!value || !/^[1-9][0-9]{0,15}$/.test(value)) return null;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) ? parsed : null;
}
export function githubHostConfigured(env: Partial<GitHubHostEnvironment>): boolean {
  try {
    return env.EVENT_GITHUB_ENABLED === 'true' && /^[A-Za-z0-9_]+$/.test(env.GITHUB_APP_ID ?? '') &&
      // nosemgrep: generic.secrets.gitleaks.private-key.private-key -- PEM validation pattern, not credential material.
      /^-----BEGIN (RSA PRIVATE KEY|PRIVATE KEY)-----\s*[A-Za-z0-9+/=\s]+-----END \1-----\s*$/.test(env.GITHUB_APP_PRIVATE_KEY ?? '') &&
      !!env.GITHUB_WEBHOOK_SECRET && !!env.AGENT_COORDINATOR && !!env.GITHUB_ATTENTION_HOST && !!env.GITHUB_WEBHOOK_INBOX &&
      typeof env.EVENT_HOST === 'string' && new URL(`https://${env.EVENT_HOST}`).host === env.EVENT_HOST && !/[/:?#@]/.test(env.EVENT_HOST) && env.EVENT_HOST.includes('.') &&
      parseGitHubSourceMap(env.GITHUB_SOURCE_MAP ?? '').length > 0;
  } catch { return false; }
}
function githubSourceControlConfigured(env: Partial<GitHubHostEnvironment>): boolean {
  return env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED === 'true' && sourceGateEpoch(env.EVENT_GITHUB_SOURCE_GATE_EPOCH) !== null;
}

const READBACK_ADMISSION_LEASE_MS = 15_000;
interface ReadbackAdmissionLease { key: string; expiresAt: number; pending: boolean; deadline: EventRequestDeadline; expired: boolean; proof: Promise<GitHubAdmissionV1 | null> }
const readbackAdmissions = new WeakMap<DurableObjectStorage, ReadbackAdmissionLease>();

/** Production admission binds current grant and map revisions to the bounded GitHub proof. */
export function createProductionGitHubSource(identity: GitHubHostIdentity, mapping: GitHubSourceMappingV1,
  env: Pick<GitHubHostEnvironment, 'GITHUB_SOURCE_MAP'>, coordinator: GitHubHostCoordinator, client: GitHubAdmissionClient,
  options: { readback?: boolean; readbackStorage?: DurableObjectStorage; freshReadback?: boolean; expectedRevision?: number } = {}): GitHubSource {
  const { readback = false, readbackStorage, freshReadback = false, expectedRevision } = options;
  let firstAuthorization = true;
  return {
    authorize: async (subject, deadline) => {
      const cacheStorage = readback ? readbackStorage : undefined;
      const refresh = freshReadback && firstAuthorization;
      firstAuthorization = false;
      let authorized = false;
      let observedLease = cacheStorage ? readbackAdmissions.get(cacheStorage) : undefined;
      try {
        if (subjectKey(subject) !== subjectKey(identity.subject)) return null;
        const readGrant = () => deadline ? deadline.run(() => coordinator.githubGrant(subject), 5000) : coordinator.githubGrant(subject);
        let grantView: GitHubGrantView | null;
        try { grantView = await readGrant(); } catch { if (readback) throw new Error('unavailable'); return null; }
        const current = GitHubGrantViewSchema.safeParse(grantView);
        if (readback && grantView !== null && !current.success) throw new Error('unavailable');
        if (!current.success || (expectedRevision !== undefined && current.data.revision !== expectedRevision) || !current.data.enabled || subjectKey(current.data.subject) !== subjectKey(subject) || current.data.mappingRevision !== mapping.revision) return null;
        const grant = current.data;
        const currentMapping = () => {
          try { return parseGitHubSourceMap(env.GITHUB_SOURCE_MAP!).find(value => value.principal === identity.principal && value.agent === identity.agent && value.installationId === subject.installationId && value.repositoryId === subject.repositoryId); }
          catch { throw new Error('unavailable'); }
        };
        if (cacheStorage && JSON.stringify(currentMapping()) !== JSON.stringify(mapping)) return null;
        const snapshotKey = () => cacheStorage?.sql.exec<{ value: string }>("SELECT json_array(json_extract(value,'$.version'),json_extract(value,'$.epoch'),json_extract(value,'$.observation.epoch')) AS value FROM github_state WHERE id=1").toArray()[0]?.value ?? null;
        const snapshot = snapshotKey();
        const sourceRevision = JSON.stringify([mapping.principal, mapping.agent, mapping.installationId, mapping.repositoryId, mapping.revision, grant.revision, grant.mappingRevision, grant.policyRevision]);
        let lease: ReadbackAdmissionLease | undefined;
        if (cacheStorage) {
          const key = JSON.stringify([identity, subject, mapping, grant, snapshot]);
          lease = readbackAdmissions.get(cacheStorage);
          if (!lease || lease.key !== key || lease.expired || Date.now() >= lease.expiresAt || refresh && !lease.pending) {
            lease?.deadline.dispose();
            const leaseDeadline = new EventRequestDeadline(READBACK_ADMISSION_LEASE_MS);
            lease = { key, expiresAt: Date.now() + READBACK_ADMISSION_LEASE_MS, pending: true, deadline: leaseDeadline, expired: false, proof: leaseDeadline.run(() => client.admit(subject, grant.policyRevision, sourceRevision, deadline, readback)).catch(error => { if (error instanceof Error && error.message === 'request_deadline_exceeded') throw new Error('unavailable'); throw error; }) };
            const pending = lease;
            // The lease timer also spans gaps between calls; it never restarts on a cache hit.
            void leaseDeadline.run(() => new Promise<never>(() => {})).catch(() => {
              pending.expired = true;
              if (readbackAdmissions.get(cacheStorage) === pending) readbackAdmissions.delete(cacheStorage);
            });
            lease.proof = lease.proof.finally(() => { pending.pending = false; });
            readbackAdmissions.set(cacheStorage, lease);
          }
        }
        observedLease = lease;
        const admission = await (lease?.proof ?? client.admit(subject, grant.policyRevision, sourceRevision, deadline, readback));
        if (!admission) return null;
        if (lease && Date.now() >= lease.expiresAt) throw new Error('unavailable');
        let latestGrantView: GitHubGrantView | null;
        try { latestGrantView = await (lease ? lease.deadline.run(readGrant) : readGrant()); } catch { if (readback) throw new Error('unavailable'); return null; }
        const latest = GitHubGrantViewSchema.safeParse(latestGrantView);
        if (readback && latestGrantView !== null && !latest.success) throw new Error('unavailable');
        if (!latest.success || !latest.data.enabled || subjectKey(latest.data.subject) !== subjectKey(subject) || latest.data.revision !== grant.revision ||
          latest.data.mappingRevision !== grant.mappingRevision || latest.data.policyRevision !== grant.policyRevision || latest.data.mappingRevision !== mapping.revision) return null;
        let latestMapping: GitHubSourceMappingV1 | undefined;
        try { latestMapping = parseGitHubSourceMap(env.GITHUB_SOURCE_MAP!).find(value => value.principal === identity.principal && value.agent === identity.agent && value.installationId === subject.installationId && value.repositoryId === subject.repositoryId); } catch { if (readback) throw new Error('unavailable'); return null; }
        if (!latestMapping || latestMapping.revision !== mapping.revision || latestMapping.principal !== mapping.principal || latestMapping.agent !== mapping.agent ||
          latestMapping.installationId !== mapping.installationId || latestMapping.repositoryId !== mapping.repositoryId) return null;
        if (cacheStorage && snapshotKey() !== snapshot) throw new Error('unavailable');
        if (cacheStorage && JSON.stringify(currentMapping()) !== JSON.stringify(mapping)) return null;
        if (lease && (lease.expired || Date.now() >= lease.expiresAt || readbackAdmissions.get(cacheStorage!) !== lease)) throw new Error('unavailable');
        authorized = true;
        return admission;
      } finally {
        if (!authorized && cacheStorage) {
          observedLease?.deadline.dispose();
          if (readbackAdmissions.get(cacheStorage) === observedLease) readbackAdmissions.delete(cacheStorage);
        }
      }
    },
    observe: (subject, policy, epoch) => client.observe(subject, policy, epoch),
  };
}

/** Storage-backed host core. Tests inject source evidence; production never substitutes configuration for queue proof. */
export class GitHubHostRuntime {
  readonly controller: GitHubAttentionController;
  private readonly sourceGuard?: () => Promise<boolean>;
  private readonly sourceToken?: GitHubSourceControlToken;
  // eslint-disable-next-line no-unused-vars -- TypeScript parameter properties are read through this.coordinator.
  constructor(private readonly storage: DurableObjectStorage, private readonly source: GitHubSource, private readonly coordinator: GitHubHostCoordinator,
    private readonly publicationIdentity: Pick<GitHubHostIdentity, 'principal' | 'agent'> = { principal: 'owner@example.com', agent: 'agent' },
    sourceGuard?: () => Promise<boolean>, sourceToken?: GitHubSourceControlToken, sourceGuardLocal?: () => boolean) {
    this.sourceGuard = sourceGuard;
    this.sourceToken = sourceToken;
    this.controller = new GitHubAttentionController(storage, source, undefined, true, sourceGuard, sourceGuardLocal);
    storage.sql.exec('CREATE TABLE IF NOT EXISTS github_publication_archive (id TEXT PRIMARY KEY, value TEXT NOT NULL, archived_at INTEGER NOT NULL)');
    storage.sql.exec('CREATE TABLE IF NOT EXISTS github_archive_stats (id INTEGER PRIMARY KEY CHECK(id=1), truncated INTEGER NOT NULL)');
  }
  async readSource(input: GitHubSourceReadRequest): Promise<GitHubSourceReadResult> {
    const request = GitHubSourceReadRequestSchema.parse(input);
    const deadline = new EventRequestDeadline(20_000);
    try {
      if (this.sourceGuard && !await this.sourceGuard()) throw new Error('denied');
      const admission = await deadline.run(() => this.source.authorize(request.subject, deadline));
      if (admission?.mergeQueue !== 'excluded') throw new Error('denied');
      const page = this.controller.readSource(request, admission);
      const current = await deadline.run(() => this.source.authorize(request.subject, deadline));
      if (current?.mergeQueue !== 'excluded' || current.revision !== admission.revision || current.policyRevision !== admission.policyRevision
        || this.sourceGuard && !await this.sourceGuard()) throw new Error('denied');
      // Authority RPCs yield; discard a page changed by reconciliation or pruning.
      if (JSON.stringify(this.controller.readSource(request, current)) !== JSON.stringify(page)) return { status: 'conflict' };
      return page;
    } finally { deadline.dispose(); }
  }
  recoveryAlarmAt(now: number): number | null {
    const oldest = this.storage.sql.exec<{ oldest: number | null }>('SELECT MIN(archived_at) AS oldest FROM github_publication_archive').one().oldest;
    const journalDue = this.controller.nextJournalCleanupAt();
    const retained = this.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_handoffs WHERE request IS NOT NULL').one().n;
    const due = Math.min(this.controller.pending().length || retained ? now + 60_000 : Infinity,
      oldest === null ? Infinity : oldest + EVENT_POLICY_V1.terminalDeduplicationRetentionMs, journalDue ?? Infinity);
    return Number.isFinite(due) ? due : null;
  }
  archivedPublications(): { publicationId: string; reason: string; archivedAt: number; event: GitHubPublicationInput['event']; request: GitHubPublicationInput | null; provenance: { revision: string; policy_revision: string } | null; createdAt: number }[] {
    return this.storage.sql.exec<{ value: string }>('SELECT value FROM github_publication_archive ORDER BY archived_at,id').toArray().map(row => JSON.parse(row.value));
  }
  archiveTruncationCount(): number {
    return this.storage.sql.exec<{ truncated: number }>('SELECT truncated FROM github_archive_stats WHERE id=1').toArray()[0]?.truncated ?? 0;
  }
  private pruneArchive(now: number): void {
    this.storage.transactionSync(() => {
      this.storage.sql.exec('DELETE FROM github_publication_archive WHERE archived_at <= ?', now - EVENT_POLICY_V1.terminalDeduplicationRetentionMs);
      const excess = this.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_publication_archive').one().n - 1000;
      if (excess > 0) {
        this.storage.sql.exec('INSERT INTO github_archive_stats(id,truncated) VALUES (1,?) ON CONFLICT(id) DO UPDATE SET truncated=truncated+excluded.truncated', excess);
        this.storage.sql.exec('DELETE FROM github_publication_archive WHERE id IN (SELECT id FROM github_publication_archive ORDER BY archived_at,id LIMIT ?)', excess);
      }
    });
  }
  private archive(id: string, now: number): void {
    this.storage.transactionSync(() => {
      const row = this.storage.sql.exec<{ value: string }>('SELECT value FROM github_outbox WHERE id=?', id).toArray().at(0);
      if (!row) return;
      const handoff = this.storage.sql.exec<{ reason: string; state: string }>('SELECT reason,state FROM github_handoffs WHERE id=?', id).toArray().at(0);
      if (handoff && handoff.state !== 'pending') return;
      const event = JSON.parse(row.value) as GitHubPublicationInput['event'];
      const request = this.request(id);
      const createdAt = this.storage.sql.exec<{ created_at: number }>('SELECT created_at FROM github_publication_created WHERE id=?', id).one().created_at;
      const value = { publicationId: id, event, request, provenance: this.controller.publicationAuthority(id), createdAt, archivedAt: now, reason: request ? 'receipt_unconfirmed_expired' : handoff?.reason ?? 'publication_expired' };
      this.storage.sql.exec('INSERT OR REPLACE INTO github_publication_archive(id,value,archived_at) VALUES (?,?,?)', id, JSON.stringify(value), now);
      if (!this.controller.discardUnacceptedPublication(id)) throw new Error('github_publication_conflict');
      this.pruneArchive(now);
    });
  }
  heldPublications(): { publicationId: string; reason: string }[] {
    return this.storage.sql.exec<{ id: string; reason: string }>("SELECT id,reason FROM github_handoffs WHERE state='pending' ORDER BY id").toArray().map(row => ({ publicationId: row.id, reason: row.reason }));
  }
  private hold(id: string, reason: string, now: number): void {
    this.storage.sql.exec("INSERT INTO github_handoffs(id,request,reason,checked_at,state) VALUES (?,NULL,?,?,'pending') ON CONFLICT(id) DO UPDATE SET reason=excluded.reason", id, reason, now);
  }
  private acceptedDisposition(value: unknown, input: GitHubPublicationInput): GitHubPublicationDisposition | null {
    if (!value || typeof value !== 'object') return null;
    const result = value as Partial<GitHubPublicationDisposition>;
    if (result.status !== 'accepted' || result.publicationId !== input.event.publicationId || result.sourceVersion !== input.event.sourceVersion ||
      !['unsettled', 'settled', 'terminal'].includes(result.disposition ?? '') || typeof result.releaseAcknowledged !== 'boolean') return null;
    return result as GitHubPublicationDisposition;
  }
  private acceptedReceipt(value: unknown, input: GitHubPublicationInput): boolean {
    if (!value || typeof value !== 'object') return false;
    const result = value as { status?: unknown; publicationId?: unknown; sourceVersion?: unknown };
    const keys = Object.keys(value);
    return result.status === 'accepted' && result.publicationId === input.event.publicationId &&
      (keys.length === 2 && keys.includes('status') && keys.includes('publicationId') ||
        keys.length === 3 && keys.includes('status') && keys.includes('publicationId') && keys.includes('sourceVersion') &&
          result.sourceVersion === input.event.sourceVersion);
  }
  private exactReleaseAck(value: unknown, input: GitHubPublicationInput, disposition: 'settled' | 'terminal'): value is GitHubPublicationRelease {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
    const result = value as Partial<GitHubPublicationRelease>, keys = Object.keys(value);
    return keys.length === 4 && keys.includes('status') && keys.includes('publicationId') && keys.includes('sourceVersion') && keys.includes('disposition') &&
      (result.status === 'released' || result.status === 'absent') && result.publicationId === input.event.publicationId &&
      result.sourceVersion === input.event.sourceVersion && result.disposition === disposition;
  }
  private async releaseIfTerminal(input: GitHubPublicationInput, disposition: 'settled' | 'terminal', deadline: EventRequestDeadline): Promise<void> {
    if (!this.controller.markPublicationReleasePending(input.event.publicationId, disposition)) throw new Error('github_publication_pin_missing');
    const released: unknown = await deadline.run(() => this.coordinator.acknowledgeGitHubPublicationRelease(input, disposition), 5000);
    if (!this.exactReleaseAck(released, input, disposition)) throw new Error('github_release_mismatch');
    this.controller.releasePublicationPin(input.event.publicationId);
  }
  private async adoptAccepted(input: GitHubPublicationInput, value: unknown, deadline: EventRequestDeadline): Promise<boolean> {
    const accepted = this.acceptedDisposition(value, input);
    if (!accepted) return false;
    this.controller.acknowledgePublication(input.event.publicationId, input.event);
    if (accepted.disposition !== 'unsettled') await this.releaseIfTerminal(input, accepted.disposition, deadline);
    return true;
  }
  private request(id: string): GitHubPublicationInput | null {
    const row = this.storage.sql.exec<{ request: string | null }>('SELECT request FROM github_handoffs WHERE id=?', id).toArray().at(0);
    return row?.request ? JSON.parse(row.request) as GitHubPublicationInput : null;
  }
  private publicationPin(input: GitHubPublicationInput): GitHubPublicationPin {
    return { ...this.publicationIdentity, publicationId: input.event.publicationId, subject: input.event.subject, sourceVersion: input.event.sourceVersion };
  }
  private acquirePublicationPin(id: string, input: GitHubPublicationInput, now: number, capacityReason = 'evidence_capacity'): boolean {
    try { this.controller.acquirePublicationPin(id, input, now); return true; }
    catch (error) {
      if (error instanceof Error && error.message === 'github_capacity') { this.hold(id, capacityReason, now); return false; }
      if (error instanceof Error && error.message === 'github_incomplete') { this.hold(id, 'evidence_unavailable', now); return false; }
      throw error;
    }
  }
  async drain(now = Date.now(), preserveEarlierAlarm = false): Promise<void> {
    // Lease before external work: process loss and lost replies preserve the exact publication.
    await this.controller.retryPublications(now + 30_000, preserveEarlierAlarm);
    const deadline = new EventRequestDeadline(20_000);
    try {
      this.pruneArchive(now);
      // Backfill pre-clock records once; retries and object reconstruction never renew them.
      for (const event of this.controller.pending()) this.storage.sql.exec('INSERT OR IGNORE INTO github_publication_created(id,created_at) VALUES (?,?)', event.publicationId, Math.min(now, event.observedAt));
      const expired = new Set(this.storage.sql.exec<{ id: string }>('SELECT id FROM github_publication_created WHERE created_at <= ?', now - EVENT_POLICY_V1.deliveryTransportRetryHorizonMs).toArray().map(row => row.id));
      // Exact receipt reads may recover accepted work after revocation, but an absent receipt
      // never authorizes a new write. New writes pass through the current source and grant checks below.
      const recovery = this.storage.sql.exec<{ id: string; request: string; state: string }>(
        'SELECT id,request,state FROM github_handoffs WHERE request IS NOT NULL ORDER BY checked_at,id LIMIT 10',
      ).toArray();
      const uncertainReceipts = new Set<string>();
      for (const row of recovery) {
        try {
          this.storage.sql.exec("UPDATE github_handoffs SET reason=CASE WHEN state='pending' THEN ? ELSE reason END,checked_at=? WHERE id=?", 'receipt_unavailable', now, row.id);
          const input = JSON.parse(row.request) as GitHubPublicationInput;
          if (row.state === 'accepted' || row.state === 'release_pending') {
            const value: unknown = await deadline.run(() => this.coordinator.githubPublicationStatus(input), 5000);
            const status = this.acceptedDisposition(value, input);
            if (!status) {
              if (value === null && row.state === 'release_pending') {
                // The coordinator may have pruned a row after ACK. Retry that exact ACK from
                // the disposition persisted locally before its first attempt; null alone is not proof.
                const disposition = this.controller.publicationReleaseDisposition(row.id);
                if (disposition) await this.releaseIfTerminal(input, disposition, deadline);
              } else if (value !== null && row.state === 'accepted') {
                this.storage.sql.exec('UPDATE github_handoffs SET reason=? WHERE id=?', 'status_mismatch', row.id);
              }
              continue;
            }
            if (status.disposition === 'unsettled') continue;
            await this.releaseIfTerminal(input, status.disposition, deadline);
            continue;
          }
          if (!this.acquirePublicationPin(row.id, input, now, 'evidence_unavailable')) continue;
          const receipt: unknown = await deadline.run(() => this.coordinator.githubPublicationReceipt(input), 5000);
          if (receipt === null) {
            if (expired.has(row.id)) {
              if (this.controller.pending().some(event => event.publicationId === row.id)) this.archive(row.id, now);
              else this.controller.discardUnacceptedPublication(row.id);
            }
            continue;
          }
          if (!this.acceptedReceipt(receipt, input)) {
            this.storage.sql.exec('UPDATE github_handoffs SET reason=? WHERE id=?', 'receipt_mismatch', row.id);
            uncertainReceipts.add(row.id);
            continue;
          }
          // The exact duplicate atomically adopts this already-persisted source pin.
          const value: unknown = await deadline.run(() => this.coordinator.adoptGitHubPublication(input, this.publicationPin(input)), 5000);
          if (!await this.adoptAccepted(input, value, deadline)) this.hold(row.id, 'receipt_mismatch', now);
        } catch {
          // A failed recovery probe is not evidence that a pending request was absent.
          // Keep its source pin and skip it in this drain's write batch while other rows proceed.
          uncertainReceipts.add(row.id);
        }
      }
      for (const id of expired) {
        try { if (!this.request(id)) this.archive(id, now); }
        catch { uncertainReceipts.add(id); }
      }
      const events = this.controller.pending().filter(event => !expired.has(event.publicationId) && !uncertainReceipts.has(event.publicationId));
      if (!events.length) return;
      if (this.sourceGuard && !await deadline.run(this.sourceGuard, 5000)) return;
      const admission = await deadline.run(() => this.source.authorize(events[0]!.subject, deadline), 5000);
      let eligible = 0;
      let grant: GitHubGrantView | null | undefined;
      // The local scan is bounded by the controller's 1,000-publication cap. Stale authority
      // records remain visible but never consume the ten-current-publication batch.
      for (const event of events) {
        const provenance = this.controller.publicationAuthority(event.publicationId);
        if (!provenance || admission?.mergeQueue !== 'excluded' || admission.revision !== provenance.revision || admission.policyRevision !== provenance.policy_revision) {
          this.hold(event.publicationId, 'source_authority_changed', now); continue;
        }
        if (grant === undefined) grant = await deadline.run(() => this.coordinator.githubGrant(event.subject), 5000);
        if (this.sourceGuard && !await deadline.run(this.sourceGuard, 5000)) return;
        if (!grant?.enabled || subjectKey(grant.subject) !== subjectKey(event.subject) || grant.policyRevision !== admission.policyRevision) {
          this.hold(event.publicationId, 'grant_denied', now); continue;
        }
        let input = this.request(event.publicationId);
        if (input && (input.grantRevision !== grant.revision || input.mappingRevision !== grant.mappingRevision || input.policyRevision !== grant.policyRevision)) {
          this.hold(event.publicationId, 'grant_changed', now); continue;
        }
        if (eligible >= 10) continue;
        eligible++;
        // Grant lookup yielded: source/queue coverage must still match the committed evidence.
        const current = await deadline.run(() => this.source.authorize(event.subject, deadline), 5000);
        if (current?.mergeQueue !== 'excluded' || current.revision !== provenance.revision || current.policyRevision !== provenance.policy_revision
          || this.sourceGuard && !await deadline.run(this.sourceGuard, 5000)) {
          this.hold(event.publicationId, 'source_authority_changed', now); continue;
        }
        if (!input) {
          const next: GitHubPublicationInput = { event, grantRevision: grant.revision, mappingRevision: grant.mappingRevision, policyRevision: grant.policyRevision };
          if (!this.acquirePublicationPin(event.publicationId, next, now)) continue;
          input = this.request(event.publicationId)!;
          if (input.grantRevision !== grant.revision || input.mappingRevision !== grant.mappingRevision || input.policyRevision !== grant.policyRevision) continue;
        } else if (!this.acquirePublicationPin(event.publicationId, input, now)) continue;
        const createdAt = this.storage.sql.exec<{ created_at: number }>('SELECT created_at FROM github_publication_created WHERE id=?', event.publicationId).one().created_at;
        // External reads can cross the retry boundary; the next drain performs final recovery.
        if (Math.max(now, Date.now()) - Math.min(createdAt, event.observedAt) >= EVENT_POLICY_V1.deliveryTransportRetryHorizonMs) {
          this.hold(event.publicationId, 'publication_expired', now); continue;
        }
        if (this.sourceGuard && !await deadline.run(this.sourceGuard, 5000)) return;
        const disposition: unknown = await deadline.run(() => this.coordinator.publishGitHub(input!, this.publicationPin(input!), this.sourceToken), 5000);
        if (!await this.adoptAccepted(input!, disposition, deadline)) this.hold(event.publicationId, 'receipt_mismatch', now);
      }
    } catch { /* Retain immutable requests, visible held reasons, and the durable retry lease. */ }
    finally {
      deadline.dispose();
      try { this.controller.pruneExpiredJournal(now); }
      finally {
        await this.controller.retryPublications(now + 30_000, preserveEarlierAlarm);
        const due = this.recoveryAlarmAt(now);
        const currentAlarm = await this.storage.getAlarm();
        if (due !== null && (currentAlarm === null || due < currentAlarm)) await this.storage.setAlarm(due);
      }
    }
  }
  async alarm(now = Date.now()): Promise<void> {
    await this.drain(now);
    if ((this.controller.snapshot()?.dueAt ?? Infinity) <= now) await this.controller.reconcile(now);
    await this.drain(now);
  }
}

const hostIdentitySchema = z.strictObject({ principal: z.string().refine(value => canonicalEmail(value) && value === value.toLowerCase()), agent: agentSchema, subject: GitHubGrantSubjectSchema });
export class GitHubAttentionHost extends DurableObject<GitHubHostEnvironment> {
  private ensureSourceControlTable(): void {
    this.ctx.storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_host_source_control(
      id INTEGER PRIMARY KEY CHECK(id=1), operation_id TEXT NOT NULL,
      state TEXT NOT NULL CHECK(state IN ('prepared','quiesced','active')),
      token_json TEXT, host_epoch INTEGER NOT NULL CHECK(host_epoch>=0), source_version INTEGER NOT NULL CHECK(source_version>=0))`);
    this.ctx.storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_host_source_refusals(
      id INTEGER PRIMARY KEY CHECK(id=1), operation_id TEXT NOT NULL, expected_source_version INTEGER NOT NULL,
      expected_host_epoch INTEGER NOT NULL, reason TEXT NOT NULL CHECK(reason IN ('checkpoint_changed','host_epoch_exhausted')),
      source_version INTEGER NOT NULL CHECK(source_version>=0), host_epoch INTEGER NOT NULL CHECK(host_epoch>=0))`);
    this.ctx.storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_host_source_receipts(
      id INTEGER PRIMARY KEY CHECK(id=1), operation_id TEXT NOT NULL, token_json TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('no_effect','parked','revalidated')),
      source_version INTEGER NOT NULL CHECK(source_version>=0), host_epoch INTEGER NOT NULL CHECK(host_epoch>=0), result_json TEXT NOT NULL)`);
    this.ctx.storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_host_source_parked_checkpoint(
      id INTEGER PRIMARY KEY CHECK(id=1), operation_id TEXT NOT NULL, token_json TEXT NOT NULL,
      source_version INTEGER NOT NULL CHECK(source_version>=0), host_epoch INTEGER NOT NULL CHECK(host_epoch>=0))`);
    this.ctx.storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_host_source_rpc_fence(
      id INTEGER PRIMARY KEY CHECK(id=1), generation INTEGER NOT NULL CHECK(generation>=0),
      operation_id TEXT, phase TEXT CHECK(phase IN ('prepare','quiesce') OR phase IS NULL))`);
    this.ctx.storage.sql.exec('INSERT OR IGNORE INTO github_host_source_rpc_fence(id,generation) VALUES (1,0)');
  }
  private sourceRpcFence(): { generation: number; operationId: string | null; phase: 'prepare' | 'quiesce' | null } {
    if (!this.ctx.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE type='table' AND name='github_host_source_rpc_fence'").toArray().length)
      return { generation: 0, operationId: null, phase: null };
    const row = this.ctx.storage.sql.exec<{ generation: number; operation_id: string | null; phase: 'prepare' | 'quiesce' | null }>(
      'SELECT generation,operation_id,phase FROM github_host_source_rpc_fence WHERE id=1').toArray().at(0);
    if (!row) return { generation: 0, operationId: null, phase: null };
    if (!Number.isSafeInteger(row.generation) || row.generation < 0 || row.operation_id !== null && typeof row.operation_id !== 'string'
      || row.phase !== null && row.phase !== 'prepare' && row.phase !== 'quiesce') throw new Error('github_source_unavailable');
    return { generation: row.generation, operationId: row.operation_id, phase: row.phase };
  }
  private advanceSourceRpcFence(operationId: string, phase: 'prepare' | 'quiesce', expectedGeneration: number): boolean {
    const current = this.sourceRpcFence();
    if (current.generation !== expectedGeneration || current.generation >= Number.MAX_SAFE_INTEGER) return false;
    this.ctx.storage.sql.exec('UPDATE github_host_source_rpc_fence SET generation=?,operation_id=?,phase=? WHERE id=1 AND generation=?',
      current.generation + 1, operationId, phase, expectedGeneration);
    const next = this.sourceRpcFence();
    return next.generation === expectedGeneration + 1 && next.operationId === operationId && next.phase === phase;
  }
  private hasSourceSnapshotRow(): boolean {
    return this.ctx.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE type='table' AND name='github_state'").toArray().length > 0
      && this.ctx.storage.sql.exec('SELECT 1 FROM github_state WHERE id=1').toArray().length > 0;
  }
  private sourceSnapshotValue(): string | null {
    if (!this.ctx.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE type='table' AND name='github_state'").toArray().length) return null;
    return this.ctx.storage.sql.exec<{ value: string }>('SELECT value FROM github_state WHERE id=1').toArray().at(0)?.value ?? null;
  }
  private localSourceControl(): { operation_id: string; state: 'prepared' | 'quiesced' | 'active'; token_json: string | null; host_epoch: number; source_version: number } | null {
    if (!this.ctx.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE type='table' AND name='github_host_source_control'").toArray().length) return null;
    return this.ctx.storage.sql.exec<{ operation_id: string; state: 'prepared' | 'quiesced' | 'active'; token_json: string | null; host_epoch: number; source_version: number }>(
      'SELECT operation_id,state,token_json,host_epoch,source_version FROM github_host_source_control WHERE id=1').toArray().at(0) ?? null;
  }
  private snapshot(identity: GitHubHostIdentity) { return this.recoveryRuntime(identity).controller.snapshot(); }
  private snapshotFromStorage(): { epoch: number; version: number; observation: unknown | null; [key: string]: unknown } | null {
    if (!this.ctx.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE type='table' AND name='github_state'").toArray().length) return null;
    const stored = this.ctx.storage.sql.exec<{ value: string }>('SELECT value FROM github_state WHERE id=1').toArray().at(0);
    if (!stored) return null;
    try {
      const snapshot = JSON.parse(stored.value) as { epoch?: unknown; version?: unknown; observation?: unknown } & Record<string, unknown>;
      return typeof snapshot.epoch === 'number' && Number.isSafeInteger(snapshot.epoch) && snapshot.epoch >= 0
        && typeof snapshot.version === 'number' && Number.isSafeInteger(snapshot.version) && snapshot.version >= 0
        ? { ...snapshot, epoch: snapshot.epoch as number, version: snapshot.version, observation: snapshot.observation ?? null }
        : null;
    } catch { return null; }
  }
  private validateIdentity(identity: GitHubHostIdentity): void {
    if (!hostIdentitySchema.safeParse(identity).success || this.ctx.id.name !== githubHostName(identity)) throw new Error('github_denied');
  }
  private localTokenMatches(identity: GitHubHostIdentity, token: GitHubSourceControlToken, state: 'active' = 'active'): boolean {
    try {
      const local = this.localSourceControl();
      return !!local && local.state === state && local.operation_id === token.operationId && !!local.token_json
        && sourceTokenEquals(JSON.parse(local.token_json), token) && token.principal === identity.principal && token.agent === identity.agent
        && token.installationId === identity.subject.installationId && token.subject.repositoryId === identity.subject.repositoryId
        && token.subject.prNumber === identity.subject.prNumber;
    } catch { return false; }
  }
  private async coordinatorFence(identity: GitHubHostIdentity): Promise<GitHubSourceFenceStatus | null> {
    try {
      const coordinator = this.env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      if (!coordinator.githubSourceFenceStatus) return null;
      const parsed = GitHubSourceFenceStatusSchema.safeParse(await coordinator.githubSourceFenceStatus(identity.subject));
      return parsed.success ? parsed.data : null;
    } catch { return null; }
  }
  private async sourceAlarmFenceReadback(identity: GitHubHostIdentity): Promise<GitHubSourceAlarmFenceReadback> {
    let coordinator: GitHubHostCoordinator;
    try { coordinator = this.env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent)); }
    catch { return { fence: null, transientFailure: true }; }
    // A missing or malformed response is not evidence that the authority read
    // merely timed out; in particular, future explicit parked/quiesced states
    // must not be mistaken for a retryable transport failure.
    if (!coordinator.githubSourceFenceStatus) return { fence: null, transientFailure: false };
    let raw: unknown;
    try { raw = await coordinator.githubSourceFenceStatus(identity.subject); }
    catch { return { fence: null, transientFailure: true }; }
    const parsed = GitHubSourceFenceStatusSchema.safeParse(raw);
    return parsed.success ? { fence: parsed.data, transientFailure: false } : { fence: null, transientFailure: false };
  }
  private sourceAlarmCheckpoint(identity: GitHubHostIdentity): GitHubHostAlarmCheckpoint | null {
    try {
      this.validateIdentity(identity);
      const snapshot = this.snapshotFromStorage();
      const snapshotSubject = snapshot?.subject as Partial<GitHubSubjectV1> | undefined;
      const validRetainedSnapshot = !!snapshot && !!snapshotSubject
        && snapshotSubject.installationId === identity.subject.installationId
        && snapshotSubject.repositoryId === identity.subject.repositoryId
        && snapshotSubject.prNumber === identity.subject.prNumber;
      return { localSourceControlJson: JSON.stringify(this.localSourceControl()), hasSnapshot: this.hasSourceSnapshotRow(), validRetainedSnapshot,
        snapshotValue: this.sourceSnapshotValue(), snapshotEpoch: snapshot?.epoch ?? null, sourceRpcFence: this.sourceRpcFence() };
    } catch { return null; }
  }
  private sourceAlarmCheckpointMatches(identity: GitHubHostIdentity, checkpoint: GitHubHostAlarmCheckpoint, requireLegacy = false): boolean {
    try {
      this.validateIdentity(identity);
      const snapshot = this.snapshotFromStorage();
      if (JSON.stringify(this.localSourceControl()) !== checkpoint.localSourceControlJson
        || this.hasSourceSnapshotRow() !== checkpoint.hasSnapshot || this.sourceSnapshotValue() !== checkpoint.snapshotValue
        || (snapshot?.epoch ?? null) !== checkpoint.snapshotEpoch
        || JSON.stringify(this.sourceRpcFence()) !== JSON.stringify(checkpoint.sourceRpcFence)) return false;
      return !requireLegacy || this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED !== 'true' && this.localSourceControl() === null;
    } catch { return false; }
  }
  private legacyAlarmCheckpoint(identity: GitHubHostIdentity, sourceRpcFence: GitHubSourceRpcFence): GitHubHostAlarmCheckpoint | null {
    if (this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED === 'true') return null;
    const checkpoint = this.sourceAlarmCheckpoint(identity);
    return checkpoint && checkpoint.localSourceControlJson === 'null'
      && JSON.stringify(checkpoint.sourceRpcFence) === JSON.stringify(sourceRpcFence) ? checkpoint : null;
  }
  private legacyRetryCheckpoint(identity: GitHubHostIdentity, sourceRpcFence: GitHubSourceRpcFence): GitHubHostAlarmCheckpoint | null {
    const checkpoint = this.legacyAlarmCheckpoint(identity, sourceRpcFence);
    return checkpoint && checkpoint.validRetainedSnapshot && checkpoint.snapshotEpoch !== null ? checkpoint : null;
  }
  private async drainLegacyAlarmRecovery(identity: GitHubHostIdentity, sourceRpcFence: GitHubSourceRpcFence, retryDelayMs?: number): Promise<void> {
    const checkpoint = this.legacyAlarmCheckpoint(identity, sourceRpcFence);
    if (!checkpoint) return;
    await this.drainRecoveryOnly(identity, checkpoint);
    if (retryDelayMs === undefined) return;
    const retryCheckpoint = this.legacyRetryCheckpoint(identity, sourceRpcFence);
    if (retryCheckpoint) await this.armLegacySourceRetry(identity, retryCheckpoint, retryDelayMs);
  }
  private localEpochMatches(deploymentEpoch: number | null): boolean {
    const raw = this.env.EVENT_GITHUB_SOURCE_GATE_EPOCH;
    if (raw !== undefined && sourceGateEpoch(raw) === null) return false;
    return deploymentEpoch === sourceGateEpoch(raw);
  }
  private async sourceOperationReserved(identity: GitHubHostIdentity, operationId: string, phase: 'prepare' | 'quiesce' | 'park' | 'revalidate', token?: GitHubSourceControlToken): Promise<boolean> {
    if (phase !== 'park' && !githubSourceControlConfigured(this.env)) return false;
    const fence = await this.coordinatorFence(identity);
    if (fence?.mode !== 'pending' || fence.operationId !== operationId || fence.phase !== phase
      || token && (!fence.token || !sourceTokenEquals(fence.token, token))) return false;
    if (phase !== 'park' && !this.localEpochMatches(fence.deploymentEpoch)) return false;
    const local = this.localSourceControl();
    if (!local) return true;
    if (phase === 'prepare') return local.operation_id === operationId && local.state === 'prepared';
    if (phase === 'quiesce') return local.operation_id === operationId && local.state === 'quiesced';
    return true;
  }
  private sourceOperationReceipt(operationId: string, token: GitHubSourceControlToken): GitHubSourceParkingResult | GitHubSourceRevalidationResult | null {
    try {
      if (!this.ctx.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE type='table' AND name='github_host_source_receipts'").toArray().length)
        return null;
      const row = this.ctx.storage.sql.exec<{ operation_id: string; token_json: string; result_json: string }>(
        'SELECT operation_id,token_json,result_json FROM github_host_source_receipts WHERE id=1').toArray().at(0);
      if (!row || row.operation_id !== operationId) return null;
      const recordedToken = GitHubSourceControlTokenSchema.safeParse(JSON.parse(row.token_json));
      if (!recordedToken.success || !sourceTokenEquals(recordedToken.data, token)) throw new Error('github_source_unavailable');
      const raw: unknown = JSON.parse(row.result_json);
      const parking = GitHubSourceParkingResultSchema.safeParse(raw);
      if (parking.success) return parking.data;
      const revalidated = GitHubSourceRevalidationResultSchema.safeParse(raw);
      if (revalidated.success) return revalidated.data;
      throw new Error('github_source_unavailable');
    } catch { throw new Error('github_source_unavailable'); }
  }
  private recoveryRuntime(identity: GitHubHostIdentity): GitHubHostRuntime {
    this.validateIdentity(identity);
    return new GitHubHostRuntime(this.ctx.storage, {
      authorize: () => Promise.resolve(null),
      observe: () => Promise.reject(new Error('github_denied')),
    }, {
      // The ordinary coordinator RPC still enforces owner partition/allowlist. This
      // adapter can only inspect or adopt an exact receipt and acknowledge its exact release;
      // it cannot create a publication, grant, observe, or dispatch.
      githubPublicationReceipt: input => this.env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent)).githubPublicationReceipt(input),
      currentGitHubSourceControl: () => Promise.resolve(null),
      githubPublicationStatus: input => this.env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent)).githubPublicationStatus(input),
      adoptGitHubPublication: (input, pin) => this.env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent)).adoptGitHubPublication(input, pin),
      acknowledgeGitHubPublicationRelease: (input, disposition) => this.env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent)).acknowledgeGitHubPublicationRelease(input, disposition),
      githubGrant: () => Promise.resolve(null),
      githubWatches: () => Promise.resolve([]),
      publishGitHub: () => Promise.reject(new Error('github_denied')),
    }, identity);
  }
  private async sourceFence(identity: GitHubHostIdentity, token: GitHubSourceControlToken, allowActivationPending = false,
    onTransientFailure?: (value: GitHubSourceAlarmFenceReadback) => void): Promise<boolean> {
    try {
      if (!githubSourceControlConfigured(this.env) || !this.localTokenMatches(identity, token)) return false;
      const coordinator = this.env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      if (!coordinator.currentGitHubSourceControl || !coordinator.githubSourceFenceStatus) return false;
      const fence = GitHubSourceFenceStatusSchema.safeParse(await coordinator.githubSourceFenceStatus(identity.subject));
      if (!fence.success || fence.data.mode !== 'controlled' || !sourceTokenEquals(fence.data.token, token)
        || fence.data.state !== 'active' && !(allowActivationPending && fence.data.state === 'activation_pending')) return false;
      const configuredEpoch = sourceGateEpoch(this.env.EVENT_GITHUB_SOURCE_GATE_EPOCH);
      if (configuredEpoch === null || fence.data.deploymentEpoch !== configuredEpoch) return false;
      const current = await coordinator.currentGitHubSourceControl(identity.subject);
      return !!current && current.state === fence.data.state && current.deploymentEpoch === configuredEpoch
        && sourceTokenEquals(current.token, token) && this.localTokenMatches(identity, token);
    } catch { onTransientFailure?.({ fence: null, transientFailure: true }); return false; }
  }
  private async legacySourceFence(identity: GitHubHostIdentity, onReadback?: (value: GitHubSourceAlarmFenceReadback) => void): Promise<boolean> {
    try {
      if (this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED === 'true' || this.localSourceControl() !== null) return false;
      const readback = await this.sourceAlarmFenceReadback(identity);
      onReadback?.(readback);
      // Legacy hosts have no source-control epoch to compare. An invalid,
      // removed, or regressed new-control epoch must not disable their existing
      // read/poll path while the new-control release flag remains off.
      return !!readback.fence && readback.fence.mode === 'legacy'
        && this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED !== 'true' && this.localSourceControl() === null;
    } catch { return false; }
  }
  private runtime(identity: GitHubHostIdentity, readback = false, freshReadback = false, expectedRevision?: number, suppliedToken?: GitHubSourceControlToken,
    allowActivationPending = false, onFenceReadback?: (value: GitHubSourceAlarmFenceReadback) => void): GitHubHostRuntime {
    this.validateIdentity(identity);
    if (!githubHostConfigured(this.env) || !validSubject(identity.subject)) throw new Error('github_denied');
    const local = this.localSourceControl();
    let token: GitHubSourceControlToken | undefined;
    if (!local) {
      if (suppliedToken || this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED === 'true') throw new Error('github_source_control_required');
    } else {
      if (local.state !== 'active' || !local.token_json || this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED !== 'true') throw new Error('github_source_control_required');
      token = GitHubSourceControlTokenSchema.parse(JSON.parse(local.token_json));
      if ((suppliedToken && !sourceTokenEquals(token, suppliedToken)) || token.principal !== identity.principal || token.agent !== identity.agent
        || token.installationId !== identity.subject.installationId || token.subject.repositoryId !== identity.subject.repositoryId
        || token.subject.prNumber !== identity.subject.prNumber) throw new Error('github_source_fenced');
    }
    const mapping = parseGitHubSourceMap(this.env.GITHUB_SOURCE_MAP!).find(value => value.principal === identity.principal && value.agent === identity.agent && value.installationId === identity.subject.installationId && value.repositoryId === identity.subject.repositoryId);
    if (!mapping || token && mapping.revision !== token.mappingRevision || token && token.grantRevision !== expectedRevision && expectedRevision !== undefined) throw new Error('github_denied');
    const coordinator = this.env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
    const client = new GitHubAppClient({ appId: this.env.GITHUB_APP_ID!, privateKeyPkcs8: this.env.GITHUB_APP_PRIVATE_KEY! });
    const source = createProductionGitHubSource(identity, mapping, this.env, coordinator, client, { readback, readbackStorage: readback ? this.ctx.storage : undefined, freshReadback, expectedRevision: token?.grantRevision ?? expectedRevision });
    const authority = token ? () => this.sourceFence(identity, token!, allowActivationPending, onFenceReadback)
      : () => this.legacySourceFence(identity, onFenceReadback);
    const localAuthority = token ? () => this.localTokenMatches(identity, token!) : () => this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED !== 'true' && this.localSourceControl() === null;
    return new GitHubHostRuntime(this.ctx.storage, source, coordinator, identity, authority, token, localAuthority);
  }
  async readSource(identity: GitHubHostIdentity, input: GitHubSourceReadRequest): Promise<GitHubSourceReadResult> {
    this.validateIdentity(identity);
    const request = GitHubSourceReadRequestSchema.parse(input);
    if (subjectKey(request.subject) !== subjectKey(identity.subject)) throw new Error('denied');
    const local = this.localSourceControl();
    if (!local) {
      if (this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED === 'true' || !await this.legacySourceFence(identity)) throw new Error('github_source_fenced');
      const result = await this.runtime(identity, true, request.cursor === undefined).readSource(request);
      if (!await this.legacySourceFence(identity)) throw new Error('github_source_fenced');
      return result;
    }
    if (!local.token_json || local.state !== 'active') throw new Error('github_source_control_required');
    const token = GitHubSourceControlTokenSchema.parse(JSON.parse(local.token_json));
    if (!await this.sourceFence(identity, token)) throw new Error('github_source_fenced');
    const result = await this.runtime(identity, true, request.cursor === undefined, token.grantRevision, token).readSource(request);
    if (!await this.sourceFence(identity, token)) throw new Error('github_source_fenced');
    return result;
  }
  sourceStatus(identity: GitHubHostIdentity): GitHubSourceStatus {
    this.validateIdentity(identity);
    const local = this.localSourceControl();
    const hasParkedCheckpoint = this.ctx.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE type='table' AND name='github_host_source_parked_checkpoint'").toArray().length > 0;
    const receipt = hasParkedCheckpoint ? this.ctx.storage.sql.exec<{ operation_id: string; token_json: string; host_epoch: number }>(
      'SELECT operation_id,token_json,host_epoch FROM github_host_source_parked_checkpoint WHERE id=1').toArray().at(0) : undefined;
    let parked = false;
    try {
      parked = !!local && !!receipt && local.operation_id === receipt.operation_id && !!local.token_json
        && sourceTokenEquals(JSON.parse(local.token_json), JSON.parse(receipt.token_json));
    } catch { throw new Error('github_source_unavailable'); }
    const snapshot = this.snapshotFromStorage();
    if (snapshot && (typeof snapshot.dueAt !== 'number' || !Number.isSafeInteger(snapshot.dueAt)
      || typeof snapshot.firstAttachedAt !== 'number' || !Number.isSafeInteger(snapshot.firstAttachedAt)
      || snapshot.lastSuccess !== null && (typeof snapshot.lastSuccess !== 'number' || !Number.isSafeInteger(snapshot.lastSuccess))
      || !['unknown', 'fresh', 'stale', 'denied'].includes(String(snapshot.health)))) throw new Error('github_source_unavailable');
    const health = snapshot && Date.now() - ((snapshot.lastSuccess as number | null) ?? snapshot.firstAttachedAt as number) >= GITHUB_SOURCE_STALE_MS
      && snapshot.health !== 'denied' ? 'stale' : snapshot?.health;
    return snapshot ? { status: snapshot.observation ? 'ready' : 'pending', sourceVersion: snapshot.version,
      health: health as GitHubSourceStatus['health'], failureReason: snapshot.failureReason as GitHubSourceStatus['failureReason'], nextAttemptAt: snapshot.dueAt as number,
      hostEpoch: local?.host_epoch ?? snapshot.epoch, hostControl: parked ? 'parked' : local?.state ?? 'absent' }
      : { status: 'absent', sourceVersion: 0, health: null, failureReason: null, nextAttemptAt: null,
        hostEpoch: local?.host_epoch ?? 0, hostControl: parked ? 'parked' : local?.state ?? 'absent' };
  }
  async initializeSource(identity: GitHubHostIdentity, expectedRevision: number): Promise<GitHubSourceStatus> {
    void expectedRevision;
    this.validateIdentity(identity);
    if (!githubHostConfigured(this.env)) throw new Error('github_denied');
    throw new Error('github_source_control_required');
  }
  async prepareSourceInitialization(identity: GitHubHostIdentity, operationId: string): Promise<{ status: 'prepared' | 'legacy'; sourceVersion: number; hostEpoch: number }> {
    this.validateIdentity(identity);
    if (!z.uuid().safeParse(operationId).success) throw new Error('invalid');
    const attemptFence = this.sourceRpcFence();
    if (!await this.sourceOperationReserved(identity, operationId, 'prepare')) throw new Error('github_source_fenced');
    const snapshot = this.snapshot(identity);
    return this.ctx.storage.transaction(async () => {
      this.ensureSourceControlTable();
      const currentFence = this.sourceRpcFence();
      if (currentFence.generation !== attemptFence.generation
        || currentFence.operationId === operationId) throw new Error('github_source_fenced');
      const existing = this.localSourceControl();
      if (existing) {
        if (existing.operation_id === operationId && existing.state === 'prepared' && !snapshot && !this.snapshotFromStorage())
          return { status: 'prepared' as const, sourceVersion: 0, hostEpoch: existing.host_epoch };
        throw new Error('github_source_conflict');
      }
      const currentSnapshot = this.snapshotFromStorage();
      if (this.hasSourceSnapshotRow() && !currentSnapshot) throw new Error('github_source_unavailable');
      if (currentSnapshot) return { status: 'legacy' as const, sourceVersion: currentSnapshot.version, hostEpoch: currentSnapshot.epoch };
      // A fresh prepare must remain cancelable if its coordinator reservation
      // becomes stale. At exhaustion no cancellation can advance the fence.
      if (currentFence.generation >= Number.MAX_SAFE_INTEGER) throw new Error('github_source_unavailable');
      this.ctx.storage.sql.exec(`INSERT INTO github_host_source_control(id,operation_id,state,token_json,host_epoch,source_version)
        VALUES (1,?,'prepared',NULL,0,0)`, operationId);
      return { status: 'prepared' as const, sourceVersion: 0, hostEpoch: 0 };
    });
  }
  async cancelPreparedSourceInitialization(identity: GitHubHostIdentity, operationId: string): Promise<boolean> {
    this.validateIdentity(identity);
    const attemptFence = this.sourceRpcFence();
    if (attemptFence.operationId === operationId && attemptFence.phase === 'prepare') return true;
    const fence = await this.coordinatorFence(identity);
    if (!fence || fence.mode !== 'pending' || fence.operationId !== operationId || fence.phase !== 'prepare') return false;
    return this.ctx.storage.transaction(async () => {
      this.ensureSourceControlTable();
      const currentFence = this.sourceRpcFence();
      if (currentFence.operationId === operationId && currentFence.phase === 'prepare') return true;
      if (currentFence.generation !== attemptFence.generation || currentFence.generation >= Number.MAX_SAFE_INTEGER) return false;
      const existing = this.localSourceControl();
      if (existing && (existing.operation_id !== operationId || existing.state !== 'prepared')) return false;
      const snapshot = this.snapshotFromStorage();
      const hasSnapshotRow = this.hasSourceSnapshotRow();
      if ((hasSnapshotRow && !snapshot) || (existing && snapshot !== null)) return false;
      if (hasSnapshotRow) {
        try {
          const subject = GitHubGrantSubjectSchema.safeParse(snapshot?.subject);
          if (!subject.success || subjectKey(subject.data) !== subjectKey(identity.subject)
            || !GitHubSourceStatusSchema.safeParse(this.sourceStatus(identity)).success) return false;
        } catch { return false; }
      }
      if (existing) this.ctx.storage.sql.exec("DELETE FROM github_host_source_control WHERE id=1 AND operation_id=? AND state='prepared'", operationId);
      if (!this.advanceSourceRpcFence(operationId, 'prepare', currentFence.generation)) return false;
      return true;
    });
  }
  async quiesceLegacySource(identity: GitHubHostIdentity, operationId: string, expectedSourceVersion: number, expectedHostEpoch: number): Promise<GitHubQuiesceResult> {
    this.validateIdentity(identity);
    if (!z.uuid().safeParse(operationId).success) throw new Error('invalid');
    const attemptFence = this.sourceRpcFence();
    if (!await this.sourceOperationReserved(identity, operationId, 'quiesce')) throw new Error('github_source_fenced');
    return this.ctx.storage.transaction(async () => {
      this.ensureSourceControlTable();
      const existing = this.localSourceControl();
      const priorRefusal = this.ctx.storage.sql.exec<{ operation_id: string; expected_source_version: number; expected_host_epoch: number; reason: 'checkpoint_changed' | 'host_epoch_exhausted'; source_version: number; host_epoch: number }>(
        'SELECT operation_id,expected_source_version,expected_host_epoch,reason,source_version,host_epoch FROM github_host_source_refusals WHERE id=1').toArray().at(0);
      if (priorRefusal?.operation_id === operationId) {
        if (priorRefusal.expected_source_version !== expectedSourceVersion || priorRefusal.expected_host_epoch !== expectedHostEpoch)
          throw new Error('github_source_conflict');
        return { status: 'checkpoint_conflict' as const, operationId, reason: priorRefusal.reason, hostControl: 'absent' as const,
          expectedSourceVersion: priorRefusal.expected_source_version, expectedHostEpoch: priorRefusal.expected_host_epoch,
          sourceVersion: priorRefusal.source_version, hostEpoch: priorRefusal.host_epoch };
      }
      const currentFence = this.sourceRpcFence();
      if (currentFence.generation !== attemptFence.generation || currentFence.operationId === operationId)
        throw new Error('github_source_fenced');
      if (existing?.operation_id === operationId && existing.state === 'quiesced')
        return { status: 'quiesced' as const, operationId, sourceVersion: existing.source_version, hostEpoch: existing.host_epoch };
      if (existing) throw new Error('github_source_conflict');
      const snapshot = this.snapshotFromStorage();
      const hasStateTable = this.ctx.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE type='table' AND name='github_state'").toArray().length > 0;
      const storedState = hasStateTable ? this.ctx.storage.sql.exec<{ value: string }>('SELECT value FROM github_state WHERE id=1').toArray().at(0) : undefined;
      if (storedState && !snapshot) throw new Error('github_source_unavailable');
      const reason = snapshot && snapshot.version === expectedSourceVersion && snapshot.epoch === expectedHostEpoch
        // Quiescence, activation, and a possible stale-authority park each need
        // one monotonic host epoch. Reserve all three before changing legacy state.
        ? snapshot.epoch >= Number.MAX_SAFE_INTEGER - 2 ? 'host_epoch_exhausted' as const : null
        : 'checkpoint_changed' as const;
      if (reason) {
        if (!this.advanceSourceRpcFence(operationId, 'quiesce', currentFence.generation)) throw new Error('github_source_unavailable');
        const observedVersion = snapshot?.version ?? 0, observedEpoch = snapshot?.epoch ?? 0;
        this.ctx.storage.sql.exec(`INSERT OR REPLACE INTO github_host_source_refusals(
          id,operation_id,expected_source_version,expected_host_epoch,reason,source_version,host_epoch)
          VALUES (1,?,?,?,?,?,?)`, operationId, expectedSourceVersion, expectedHostEpoch, reason, observedVersion, observedEpoch);
        return { status: 'checkpoint_conflict' as const, operationId, reason, hostControl: 'absent' as const,
          expectedSourceVersion, expectedHostEpoch, sourceVersion: observedVersion, hostEpoch: observedEpoch };
      }
      if (!snapshot) throw new Error('github_source_conflict');
      // A new exact operation can replace an old no-effect refusal. The local
      // control row written below then fences any delayed request from the old op.
      this.ctx.storage.sql.exec('DELETE FROM github_host_source_refusals WHERE id=1');
      const hostEpoch = Math.max(snapshot.epoch, expectedHostEpoch) + 1;
      const next = { ...snapshot, epoch: hostEpoch };
      this.ctx.storage.sql.exec('UPDATE github_state SET value=? WHERE id=1', JSON.stringify(next));
      this.ctx.storage.sql.exec(`INSERT INTO github_host_source_control(id,operation_id,state,token_json,host_epoch,source_version)
        VALUES (1,?,'quiesced',NULL,?,?)`, operationId, hostEpoch, snapshot.version);
      await this.ctx.storage.deleteAlarm();
      return { status: 'quiesced' as const, operationId, sourceVersion: snapshot.version, hostEpoch };
    });
  }
  async parkSourceControlled(identity: GitHubHostIdentity, operationId: string, tokenInput: GitHubSourceControlToken): Promise<GitHubSourceParkingResult> {
    this.validateIdentity(identity);
    const token = GitHubSourceControlTokenSchema.parse(tokenInput);
    if (token.operationId !== operationId || token.principal !== identity.principal || token.agent !== identity.agent
      || token.installationId !== identity.subject.installationId || token.subject.repositoryId !== identity.subject.repositoryId
      || token.subject.prNumber !== identity.subject.prNumber) throw new Error('github_source_fenced');
    const attemptFence = this.sourceRpcFence();
    const prior = this.sourceOperationReceipt(operationId, token);
    if (prior && 'status' in prior && (prior.status === 'parked' || prior.status === 'no_effect')) return prior;
    if (!await this.sourceOperationReserved(identity, operationId, 'park', token)) throw new Error('github_source_fenced');
    return this.ctx.storage.transaction(async () => {
      this.ensureSourceControlTable();
      const currentFence = this.sourceRpcFence();
      if (currentFence.generation !== attemptFence.generation || currentFence.operationId === operationId)
        throw new Error('github_source_fenced');
      const replay = this.sourceOperationReceipt(operationId, token);
      if (replay && 'status' in replay && (replay.status === 'parked' || replay.status === 'no_effect')) return replay;
      const local = this.localSourceControl(), snapshot = this.snapshotFromStorage(), hasSnapshot = this.hasSourceSnapshotRow();
      if (hasSnapshot && !snapshot) throw new Error('github_source_unavailable');
      if (snapshot) {
        const checked = GitHubSourceStatusSchema.safeParse(this.sourceStatus(identity));
        if (!checked.success || subjectKey(GitHubGrantSubjectSchema.parse(snapshot.subject)) !== subjectKey(identity.subject))
          throw new Error('github_source_unavailable');
      }
      const rowReceipt = this.ctx.storage.sql.exec<{ operation_id: string; token_json: string; status: string }>(
        'SELECT operation_id,token_json,\'parked\' AS status FROM github_host_source_parked_checkpoint WHERE id=1').toArray().at(0);
      let preserveExistingPark = false;
      if (local && local.state === 'quiesced' && rowReceipt?.status === 'parked' && rowReceipt.operation_id === local.operation_id && local.token_json) {
        const predecessor = GitHubSourceControlTokenSchema.safeParse(JSON.parse(local.token_json));
        preserveExistingPark = predecessor.success && predecessor.data.sourceIncarnation === token.sourceIncarnation
          && predecessor.data.lifecycleEpoch + 1 === token.lifecycleEpoch && predecessor.data.installationId === token.installationId
          && predecessor.data.principal === token.principal && predecessor.data.agent === token.agent
          && predecessor.data.subject.repositoryId === token.subject.repositoryId && predecessor.data.subject.prNumber === token.subject.prNumber
          && snapshot !== null && snapshot.version === local.source_version && snapshot.epoch === local.host_epoch;
      }
      const quiescedLegacy = !!local && local.operation_id === operationId && local.state === 'quiesced'
        && local.token_json === null && !!snapshot && snapshot.version === local.source_version && snapshot.epoch === local.host_epoch;
      const localToken = local?.token_json ? (() => {
        try { return GitHubSourceControlTokenSchema.safeParse(JSON.parse(local.token_json)); }
        catch { return null; }
      })() : null;
      // A committed prepare/activation may have no github_state row yet: the
      // first attach is still waiting on GitHub admission. Preserve that
      // canonical lineage by parking a truthful empty baseline, never by
      // reporting no effect or resetting its incarnation.
      const emptyLineage = !snapshot && !hasSnapshot && !!local && local.operation_id === operationId && local.source_version === 0
        && (local.state === 'prepared' && local.token_json === null
          || local.state === 'active' && localToken?.success === true && sourceTokenEquals(localToken.data, token));
      const noEffect = preserveExistingPark || !local && (!hasSnapshot || snapshot !== null);
      if (!noEffect && !emptyLineage && !quiescedLegacy && (!local || local.operation_id !== operationId || !['quiesced', 'active'].includes(local.state)
        || localToken?.success !== true || !sourceTokenEquals(localToken.data, token)
        || !snapshot || snapshot.version < local.source_version || snapshot.epoch < local.host_epoch
          && !(local.state === 'active' && local.host_epoch - snapshot.epoch === 1 && snapshot.version === local.source_version)))
        throw new Error('github_source_conflict');
      const sourceVersion = snapshot?.version ?? local?.source_version ?? 0;
      const currentHostEpoch = local?.host_epoch ?? snapshot?.epoch ?? 0;
      if (!this.advanceSourceRpcFence(operationId, 'quiesce', currentFence.generation)) throw new Error('github_source_unavailable');
      if (noEffect) {
        if (local && !preserveExistingPark) this.ctx.storage.sql.exec("DELETE FROM github_host_source_control WHERE id=1 AND operation_id=? AND state='prepared'", operationId);
        const result = GitHubSourceParkingResultSchema.parse({ status: 'no_effect', operationId, token, sourceVersion, hostEpoch: currentHostEpoch });
        this.ctx.storage.sql.exec(`INSERT OR REPLACE INTO github_host_source_receipts(id,operation_id,token_json,status,source_version,host_epoch,result_json)
          VALUES (1,?,?,?, ?,?,?)`, operationId, JSON.stringify(token), result.status, sourceVersion, currentHostEpoch, JSON.stringify(result));
        return result;
      }
      const observedEpoch = Math.max(currentHostEpoch, snapshot?.epoch ?? currentHostEpoch);
      // At MAX_SAFE_INTEGER, the local phase and independently advanced RPC
      // generation still fence controller commits inside their storage transaction.
      // Preserve the epoch rather than wrap or leave a confirmed-stale source live.
      const hostEpoch = observedEpoch === Number.MAX_SAFE_INTEGER ? observedEpoch : observedEpoch + 1;
      if (!Number.isSafeInteger(hostEpoch)) throw new Error('github_source_unavailable');
      if (emptyLineage) {
        const baseline = createInitialGitHubSnapshot(identity.subject, Date.now(), hostEpoch);
        this.ctx.storage.sql.exec('INSERT INTO github_state(id,value) VALUES (1,?)', JSON.stringify(baseline));
      } else if (hostEpoch !== snapshot!.epoch) {
        this.ctx.storage.sql.exec('UPDATE github_state SET value=? WHERE id=1', JSON.stringify({ ...snapshot!, epoch: hostEpoch }));
      }
      this.ctx.storage.sql.exec(`UPDATE github_host_source_control SET state='quiesced',token_json=?,host_epoch=?,source_version=?
        WHERE id=1 AND operation_id=? AND state IN ('prepared','quiesced','active')`, JSON.stringify(token), hostEpoch, sourceVersion, operationId);
      const result = GitHubSourceParkingResultSchema.parse({ status: 'parked', operationId, token, sourceVersion, hostEpoch });
      this.ctx.storage.sql.exec(`INSERT OR REPLACE INTO github_host_source_receipts(id,operation_id,token_json,status,source_version,host_epoch,result_json)
        VALUES (1,?,?,?, ?,?,?)`, operationId, JSON.stringify(token), result.status, sourceVersion, hostEpoch, JSON.stringify(result));
      this.ctx.storage.sql.exec(`INSERT OR REPLACE INTO github_host_source_parked_checkpoint(id,operation_id,token_json,source_version,host_epoch)
        VALUES (1,?,?,?,?)`, operationId, JSON.stringify(token), sourceVersion, hostEpoch);
      const recovery = this.recoveryRuntime(identity), due = recovery.recoveryAlarmAt(Date.now()), currentAlarm = await this.ctx.storage.getAlarm();
      if (due !== null && (currentAlarm === null || due < currentAlarm)) await this.ctx.storage.setAlarm(due);
      return result;
    });
  }
  async revalidateParkedSource(identity: GitHubHostIdentity, input: {
    operationId: string; token: GitHubSourceControlToken; expectedControl: { operationId: string; sourceIncarnation: number; lifecycleEpoch: number };
    expectedSourceVersion: number; expectedHostEpoch: number;
  }): Promise<GitHubSourceRevalidationResult> {
    this.validateIdentity(identity);
    const token = GitHubSourceControlTokenSchema.parse(input.token);
    if (token.operationId !== input.operationId || token.principal !== identity.principal || token.agent !== identity.agent
      || token.installationId !== identity.subject.installationId || token.subject.repositoryId !== identity.subject.repositoryId
      || token.subject.prNumber !== identity.subject.prNumber || !githubSourceControlConfigured(this.env)) throw new Error('github_source_fenced');
    const attemptFence = this.sourceRpcFence();
    const prior = this.sourceOperationReceipt(input.operationId, token);
    if (prior && 'status' in prior && prior.status === 'revalidated') return prior;
    if (!await this.sourceOperationReserved(identity, input.operationId, 'revalidate', token)) throw new Error('github_source_fenced');
    return this.ctx.storage.transaction(async () => {
      this.ensureSourceControlTable();
      const currentFence = this.sourceRpcFence();
      if (currentFence.generation !== attemptFence.generation || currentFence.operationId === input.operationId)
        throw new Error('github_source_fenced');
      const replay = this.sourceOperationReceipt(input.operationId, token);
      if (replay && 'status' in replay && replay.status === 'revalidated') return replay;
      const local = this.localSourceControl(), snapshot = this.snapshotFromStorage();
      const receipt = this.ctx.storage.sql.exec<{ operation_id: string; token_json: string; status: string; source_version: number; host_epoch: number }>(
        "SELECT operation_id,token_json,'parked' AS status,source_version,host_epoch FROM github_host_source_parked_checkpoint WHERE id=1").toArray().at(0);
      if (!local || local.state !== 'quiesced' || !snapshot || !receipt || receipt.status !== 'parked'
        || local.operation_id !== receipt.operation_id || !local.token_json || !sourceTokenEquals(JSON.parse(local.token_json), JSON.parse(receipt.token_json)))
        throw new Error('github_source_conflict');
      const predecessor = GitHubSourceControlTokenSchema.parse(JSON.parse(local.token_json));
      if (predecessor.operationId !== input.expectedControl.operationId || predecessor.sourceIncarnation !== input.expectedControl.sourceIncarnation
        || predecessor.lifecycleEpoch !== input.expectedControl.lifecycleEpoch || predecessor.installationId !== token.installationId
        || predecessor.sourceIncarnation !== token.sourceIncarnation || predecessor.lifecycleEpoch >= Number.MAX_SAFE_INTEGER
        || token.lifecycleEpoch !== predecessor.lifecycleEpoch + 1 || input.expectedSourceVersion !== snapshot.version
        || input.expectedHostEpoch !== local.host_epoch || snapshot.version !== local.source_version || snapshot.epoch !== local.host_epoch
        || receipt.source_version !== snapshot.version || receipt.host_epoch !== local.host_epoch)
        throw new Error('github_source_conflict');
      // Revalidation, activation, and a later stale-authority park each need one
      // monotonic host increment. Refuse before the first effect unless all three fit.
      if (!Number.isSafeInteger(local.host_epoch) || local.host_epoch < 0 || local.host_epoch >= Number.MAX_SAFE_INTEGER - 2)
        throw new Error('github_source_unavailable');
      const hostEpoch = local.host_epoch + 1;
      // The parked predecessor's ID is the RPC witness. This fences delayed work
      // under the old lifecycle while leaving the replacement's first activation
      // eligible to start with its fresh operation ID.
      if (!this.advanceSourceRpcFence(predecessor.operationId, 'quiesce', currentFence.generation)) throw new Error('github_source_unavailable');
      this.ctx.storage.sql.exec('UPDATE github_state SET value=? WHERE id=1', JSON.stringify({ ...snapshot, epoch: hostEpoch }));
      this.ctx.storage.sql.exec(`UPDATE github_host_source_control SET operation_id=?,state='quiesced',token_json=?,host_epoch=?,source_version=?
        WHERE id=1 AND operation_id=? AND state='quiesced'`, input.operationId, JSON.stringify(token), hostEpoch, snapshot.version, predecessor.operationId);
      const result = GitHubSourceRevalidationResultSchema.parse({ status: 'revalidated', operationId: input.operationId, token, sourceVersion: snapshot.version, hostEpoch });
      this.ctx.storage.sql.exec(`INSERT OR REPLACE INTO github_host_source_receipts(id,operation_id,token_json,status,source_version,host_epoch,result_json)
        VALUES (1,?,?,?, ?,?,?)`, input.operationId, JSON.stringify(token), result.status, snapshot.version, hostEpoch, JSON.stringify(result));
      const currentAlarm = await this.ctx.storage.getAlarm();
      if (currentAlarm === null) await this.ctx.storage.setAlarm(Date.now() + 30_000);
      return result;
    });
  }
  async activateSourceControlled(identity: GitHubHostIdentity, operationId: string, tokenInput: GitHubSourceControlToken): Promise<GitHubSourceStatus> {
    this.validateIdentity(identity);
    const token = GitHubSourceControlTokenSchema.parse(tokenInput);
    if (token.operationId !== operationId || token.principal !== identity.principal || token.agent !== identity.agent
      || token.installationId !== identity.subject.installationId || token.subject.repositoryId !== identity.subject.repositoryId
      || token.subject.prNumber !== identity.subject.prNumber) throw new Error('github_source_fenced');
    const attemptFence = this.sourceRpcFence();
    const coordinator = this.env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
    if (!coordinator.githubSourceFenceStatus || !coordinator.currentGitHubSourceControl) throw new Error('github_source_fenced');
    const fence = GitHubSourceFenceStatusSchema.safeParse(await coordinator.githubSourceFenceStatus(identity.subject));
    const current = await coordinator.currentGitHubSourceControl(identity.subject);
    const configuredEpoch = sourceGateEpoch(this.env.EVENT_GITHUB_SOURCE_GATE_EPOCH);
    if (!githubSourceControlConfigured(this.env) || configuredEpoch === null || !fence.success || fence.data.mode !== 'controlled'
      || fence.data.deploymentEpoch !== configuredEpoch || fence.data.state !== 'activation_pending' && fence.data.state !== 'active'
      || !sourceTokenEquals(fence.data.token, token) || !current || current.deploymentEpoch !== configuredEpoch
      || current.state !== fence.data.state || !sourceTokenEquals(current.token, token)) throw new Error('github_source_fenced');
    await this.ctx.storage.transaction(async () => {
      this.ensureSourceControlTable();
      const currentFence = this.sourceRpcFence();
      if (currentFence.generation !== attemptFence.generation || currentFence.operationId === operationId)
        throw new Error('github_source_fenced');
      const existing = this.localSourceControl(), snapshot = this.snapshotFromStorage();
      if (existing?.state === 'active' && existing.operation_id === operationId && existing.token_json
        && sourceTokenEquals(JSON.parse(existing.token_json), token)) return;
      if (!existing || existing.operation_id !== operationId || !['prepared', 'quiesced'].includes(existing.state)) throw new Error('github_source_control_required');
      if ((existing.state === 'prepared' && snapshot !== null) || (existing.state === 'quiesced' && (!snapshot || snapshot.version !== existing.source_version)))
        throw new Error('github_source_conflict');
      // Refuse corrupt or stale quiesced rows whose final activation increment
      // would exceed the safe-integer epoch domain.
      if (!Number.isSafeInteger(existing.host_epoch) || existing.host_epoch < 0 || existing.host_epoch >= Number.MAX_SAFE_INTEGER)
        throw new Error('github_source_unavailable');
      this.ctx.storage.sql.exec('DELETE FROM github_host_source_refusals WHERE id=1');
      const hostEpoch = existing.host_epoch + 1;
      this.ctx.storage.sql.exec(`UPDATE github_host_source_control SET state='active',token_json=?,host_epoch=?,source_version=?
        WHERE id=1 AND operation_id=? AND state IN ('prepared','quiesced')`, JSON.stringify(token), hostEpoch, snapshot?.version ?? 0, operationId);
    });
    const activationGuard = () => this.sourceFence(identity, token, true);
    if (!await activationGuard()) throw new Error('github_source_fenced');
    // The activation path is the only caller allowed to seed the local source while
    // the coordinator remains activation_pending. Ordinary entrypoints require active.
    const activationRuntime = this.runtime(identity, false, false, token.grantRevision, token, true);
    await activationRuntime.controller.attach(identity.subject, Date.now(), true);
    if (!await activationGuard()) throw new Error('github_source_fenced');
    return this.sourceStatus(identity);
  }
  async attach(identity: GitHubHostIdentity): Promise<void> {
    const runtime = this.runtime(identity);
    await runtime.controller.attach(identity.subject);
  }
  async accept(identity: GitHubHostIdentity, trigger: GitHubTriggerV1): Promise<'accepted' | 'denied'> {
    try { return await this.runtime(identity).controller.accept(trigger); }
    catch (error) {
      if (error instanceof Error && ['github_source_control_required', 'github_source_fenced', 'github_denied'].includes(error.message)) return 'denied';
      throw error;
    }
  }
  private async drainRecoveryOnly(identity: GitHubHostIdentity, expectedCheckpoint?: GitHubHostAlarmCheckpoint): Promise<void> {
    if (expectedCheckpoint && !this.sourceAlarmCheckpointMatches(identity, expectedCheckpoint)) return;
    const checkpoint = expectedCheckpoint ?? this.sourceAlarmCheckpoint(identity);
    const recovery = this.recoveryRuntime(identity);
    try { await recovery.drain(Date.now(), true); }
    finally {
      // Inactive hosts keep exact receipt/pin recovery but never schedule source polling.
      await this.ctx.storage.transaction(async () => {
        // A source-state/RPC-fence change while the receipt drain was yielding
        // owns its alarm. Do not delete or replace it with this older wake-up.
        if (!checkpoint || !this.sourceAlarmCheckpointMatches(identity, checkpoint)) return;
        const due = recovery.recoveryAlarmAt(Date.now());
        if (due !== null) await this.ctx.storage.setAlarm(due);
        else await this.ctx.storage.deleteAlarm();
      });
    }
  }
  private async armLegacySourceRetry(identity: GitHubHostIdentity, checkpoint: GitHubHostAlarmCheckpoint, delayMs: number): Promise<void> {
    if (checkpoint.localSourceControlJson !== 'null' || !checkpoint.validRetainedSnapshot || checkpoint.snapshotEpoch === null
      || this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED === 'true') return;
    const retryAt = Date.now() + delayMs;
    await this.ctx.storage.transaction(async () => {
      // A legacy retry is only an alarm hint. The next invocation still reads
      // fresh authority, and this transaction cannot overwrite a newer host
      // incarnation, source-control transition, or snapshot.
      if (this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED === 'true'
        || !this.sourceAlarmCheckpointMatches(identity, checkpoint, true)) return;
      const earlierAlarm = await this.ctx.storage.getAlarm();
      if (earlierAlarm === null || earlierAlarm > retryAt) await this.ctx.storage.setAlarm(retryAt);
    });
  }
  private async retrySourceAlarm(identity: GitHubHostIdentity, token: GitHubSourceControlToken,
    fence: GitHubSourceFenceStatus | null, allowTransientReadFailure = false): Promise<void> {
    const configured = githubSourceControlConfigured(this.env);
    const currentReadback = !!fence && this.localEpochMatches(fence.deploymentEpoch);
    const matchingPending = configured && currentReadback && fence?.mode === 'pending'
      && fence.phase === 'activate' && fence.operationId === token.operationId;
    const matchingControl = configured && currentReadback && fence?.mode === 'controlled'
      && (fence.state === 'activation_pending' || fence.state === 'active') && sourceTokenEquals(fence.token, token);
    // A transient read retains a wake; every alarm rechecks the full fence before provider work.
    const transientReadFailure = configured && allowTransientReadFailure && fence === null;
    if (!(matchingPending || matchingControl || transientReadFailure) || !this.localTokenMatches(identity, token)) return;
    const retryAt = Date.now() + 30_000;
    await this.ctx.storage.transaction(async () => {
      // A recovery obligation may already have armed an earlier deadline. Keep
      // that deadline and retry only while the exact local authority still holds.
      if (!githubSourceControlConfigured(this.env) || !this.localTokenMatches(identity, token)) return;
      const earlierAlarm = await this.ctx.storage.getAlarm();
      if (earlierAlarm === null || earlierAlarm > retryAt) await this.ctx.storage.setAlarm(retryAt);
    });
  }
  async alarm(): Promise<void> {
    let identity: GitHubHostIdentity;
    try {
      const [kind, principal, agent, installationId, repositoryId, prNumber] = JSON.parse(this.ctx.id.name ?? '') as unknown[];
      if (kind !== 'event-github-v1' || typeof principal !== 'string' || typeof agent !== 'string') return;
      identity = { principal, agent, subject: { installationId, repositoryId, prNumber } as GitHubSubjectV1 };
      if (githubHostName(identity) !== this.ctx.id.name) return;
    } catch { return; }
    const checkpoint = this.sourceAlarmCheckpoint(identity);
    const local = this.localSourceControl();
    if (!local) {
      if (this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED === 'true' || !checkpoint) {
        await this.drainRecoveryOnly(identity, checkpoint ?? undefined);
        return;
      }
      const readback = await this.sourceAlarmFenceReadback(identity);
      // The RPC may yield while a source operation adopts a local token or
      // advances its generation. That newer owner controls the alarm now.
      if (!this.sourceAlarmCheckpointMatches(identity, checkpoint, true)) return;
      if (readback.fence?.mode !== 'legacy') {
        await this.drainLegacyAlarmRecovery(identity, checkpoint.sourceRpcFence,
          readback.transientFailure ? 30_000 : undefined);
        return;
      }

      const runtimeReadback: { value: GitHubSourceAlarmFenceReadback | null; sawTransientFailure: boolean } = { value: null, sawTransientFailure: false };
      try {
        await this.runtime(identity, false, false, undefined, undefined, false, value => {
          runtimeReadback.value = value;
          runtimeReadback.sawTransientFailure ||= value.transientFailure;
        }).alarm();
      } catch {
        // Runtime errors can be authority RPC failures or provider failures.
        // Read the typed fence again before choosing a bounded retry; never
        // overwrite an alarm installed by a competing source transition.
        const failedCheckpoint = this.legacyAlarmCheckpoint(identity, checkpoint.sourceRpcFence);
        if (!failedCheckpoint) return;
        const failureReadback = await this.sourceAlarmFenceReadback(identity);
        if (!this.sourceAlarmCheckpointMatches(identity, failedCheckpoint, true)) return;
        if (failureReadback.transientFailure) {
          await this.drainRecoveryOnly(identity, failedCheckpoint);
          const retryCheckpoint = this.legacyRetryCheckpoint(identity, checkpoint.sourceRpcFence);
          if (retryCheckpoint) await this.armLegacySourceRetry(identity, retryCheckpoint, 30_000);
        } else if (failureReadback.fence?.mode === 'legacy') {
          const retryCheckpoint = this.legacyRetryCheckpoint(identity, checkpoint.sourceRpcFence);
          if (retryCheckpoint) await this.armLegacySourceRetry(identity, retryCheckpoint, 60_000);
        } else {
          await this.drainRecoveryOnly(identity, failedCheckpoint);
        }
        return;
      }
      if (runtimeReadback.sawTransientFailure) {
        // The runtime can observe a transient failure and then a conclusive
        // denial during one alarm pass. Classify one fresh read before choosing
        // a retry so an older transient cannot override that newer authority.
        const classifiedCheckpoint = this.legacyAlarmCheckpoint(identity, checkpoint.sourceRpcFence);
        if (!classifiedCheckpoint) return;
        const classified = await this.sourceAlarmFenceReadback(identity);
        if (!this.sourceAlarmCheckpointMatches(identity, classifiedCheckpoint, true)) return;
        await this.drainLegacyAlarmRecovery(identity, checkpoint.sourceRpcFence,
          classified.transientFailure ? 30_000 : classified.fence?.mode === 'legacy' ? 60_000 : undefined);
      } else if (runtimeReadback.value && runtimeReadback.value.fence?.mode !== 'legacy') {
        await this.drainLegacyAlarmRecovery(identity, checkpoint.sourceRpcFence);
      }
      return;
    }
    if (local.state !== 'active' || !local.token_json) { await this.drainRecoveryOnly(identity, checkpoint ?? undefined); return; }
    let token: GitHubSourceControlToken;
    try { token = GitHubSourceControlTokenSchema.parse(JSON.parse(local.token_json)); }
    catch { await this.drainRecoveryOnly(identity, checkpoint ?? undefined); return; }
    if (!await this.sourceFence(identity, token)) {
      const readback = await this.sourceAlarmFenceReadback(identity);
      if (!checkpoint || !this.sourceAlarmCheckpointMatches(identity, checkpoint)) return;
      await this.drainRecoveryOnly(identity, checkpoint);
      await this.retrySourceAlarm(identity, token, readback.fence, readback.transientFailure);
      return;
    }
    let runtime: GitHubHostRuntime;
    const runtimeReadback: { value: GitHubSourceAlarmFenceReadback | null; transientFailure: boolean } = { value: null, transientFailure: false };
    try { runtime = this.runtime(identity, false, false, token.grantRevision, token, false, value => {
      runtimeReadback.value = value;
      runtimeReadback.transientFailure ||= value.transientFailure;
    }); }
    catch {
      if (!checkpoint || !this.sourceAlarmCheckpointMatches(identity, checkpoint)) return;
      await this.drainRecoveryOnly(identity, checkpoint);
      const readback = await this.sourceAlarmFenceReadback(identity);
      if (!this.sourceAlarmCheckpointMatches(identity, checkpoint)) return;
      await this.retrySourceAlarm(identity, token, readback.fence, readback.transientFailure);
      return;
    }
    try { await runtime.alarm(); }
    catch {
      const failedCheckpoint = this.sourceAlarmCheckpoint(identity);
      if (!checkpoint || !failedCheckpoint || failedCheckpoint.localSourceControlJson !== checkpoint.localSourceControlJson
        || JSON.stringify(failedCheckpoint.sourceRpcFence) !== JSON.stringify(checkpoint.sourceRpcFence)
        || !this.localTokenMatches(identity, token)) return;
      const readback = await this.sourceAlarmFenceReadback(identity);
      if (!this.sourceAlarmCheckpointMatches(identity, failedCheckpoint)) return;
      await this.drainRecoveryOnly(identity, failedCheckpoint);
      await this.retrySourceAlarm(identity, token, readback.fence, readback.transientFailure);
      return;
    }
    if (runtimeReadback.transientFailure) {
      const failedCheckpoint = this.sourceAlarmCheckpoint(identity);
      if (!checkpoint || !failedCheckpoint || failedCheckpoint.localSourceControlJson !== checkpoint.localSourceControlJson
        || JSON.stringify(failedCheckpoint.sourceRpcFence) !== JSON.stringify(checkpoint.sourceRpcFence)
        || !this.localTokenMatches(identity, token)) return;
      const readback = await this.sourceAlarmFenceReadback(identity);
      if (!this.sourceAlarmCheckpointMatches(identity, failedCheckpoint)) return;
      await this.drainRecoveryOnly(identity, failedCheckpoint);
      await this.retrySourceAlarm(identity, token, readback.fence, readback.transientFailure);
    }
  }
}
