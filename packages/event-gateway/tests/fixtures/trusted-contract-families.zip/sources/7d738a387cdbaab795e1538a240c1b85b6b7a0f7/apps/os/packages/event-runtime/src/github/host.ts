import { GitHubSourceReadRequestSchema, type GitHubSourceReadRequest, type GitHubSourceReadResult } from './readback-contract';
import { DurableObject } from 'cloudflare:workers';
import { canonicalEmail } from 'openapi-operator/src/access';
import { z } from 'zod';
import { GitHubAttentionController, type GitHubSource, type GitHubAdmissionV1 } from './controller';
import { GitHubAppClient } from './client';
import { GitHubGrantSubjectSchema, GitHubGrantViewSchema, parseGitHubSourceMap, type GitHubGrantView, type GitHubSourceStatus, type GitHubPublicationInput } from './grants';
import { validSubject, type GitHubTriggerV1 } from './ingress';
import { subjectKey, type GitHubSubjectV1 } from './state';
import { agent as agentSchema, coordinatorName } from '../contracts';
import { EventRequestDeadline } from '../request-deadline';
import { EVENT_POLICY_V1 } from '../policy';

export interface GitHubHostIdentity { principal: string; agent: string; subject: GitHubSubjectV1 }
export interface GitHubHostCoordinator {
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  githubGrant(subject: GitHubSubjectV1): Promise<GitHubGrantView | null>;
  githubWatches(): Promise<GitHubSubjectV1[]>;
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  githubPublicationReceipt(input: GitHubPublicationInput): Promise<{ status: 'accepted'; publicationId: string } | null>;
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  publishGitHub(input: GitHubPublicationInput): Promise<{ status: 'accepted'; publicationId: string }>;
}
export interface GitHubHostEnvironment {
  EVENT_GITHUB_ENABLED?: string; EVENT_HOST: string;
  GITHUB_APP_ID?: string; GITHUB_APP_PRIVATE_KEY?: string; GITHUB_WEBHOOK_SECRET?: string; GITHUB_SOURCE_MAP?: string;
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  GITHUB_WEBHOOK_INBOX?: { getByName(name: string): { enqueue(trigger: GitHubTriggerV1): Promise<'accepted' | 'denied'> } };
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  AGENT_COORDINATOR: { getByName(name: string): GitHubHostCoordinator };
  // eslint-disable-next-line no-unused-vars -- TypeScript interface parameter names document the RPC contract.
  GITHUB_ATTENTION_HOST: { getByName(name: string): { accept(identity: GitHubHostIdentity, trigger: GitHubTriggerV1): Promise<'accepted' | 'denied'> } };
}
type GitHubSourceMappingV1 = ReturnType<typeof parseGitHubSourceMap>[number];
type GitHubAdmissionClient = Pick<GitHubAppClient, 'admit' | 'observe'>;
export const githubHostName = (identity: GitHubHostIdentity): string => JSON.stringify(['event-github-v1', identity.principal, identity.agent, identity.subject.installationId, identity.subject.repositoryId, identity.subject.prNumber]);
export function githubHostConfigured(env: Partial<GitHubHostEnvironment>): boolean {
  try {
    return env.EVENT_GITHUB_ENABLED === 'true' && /^[A-Za-z0-9_]+$/.test(env.GITHUB_APP_ID ?? '') &&
      // nosemgrep: generic.secrets.gitleaks.private-key.private-key -- PEM validation pattern, not credential material.
      /^-----BEGIN (RSA PRIVATE KEY|PRIVATE KEY)-----\s*[A-Za-z0-9+/=\s]+-----END \1-----\s*$/.test(env.GITHUB_APP_PRIVATE_KEY ?? '') &&
      !!env.GITHUB_WEBHOOK_SECRET && !!env.AGENT_COORDINATOR && !!env.GITHUB_ATTENTION_HOST && !!env.GITHUB_WEBHOOK_INBOX &&
      typeof env.EVENT_HOST === 'string' && new URL(`https://${env.EVENT_HOST}`).host === env.EVENT_HOST && !/[/:?#@]/.test(env.EVENT_HOST) && env.EVENT_HOST.includes('.') &&
      parseGitHubSourceMap(env.GITHUB_SOURCE_MAP ?? '').length > 0;
  } catch { return false; }
}

const READBACK_ADMISSION_LEASE_MS = 15_000;
interface ReadbackAdmissionLease { key: string; expiresAt: number; pending: boolean; deadline: EventRequestDeadline; expired: boolean; proof: Promise<GitHubAdmissionV1 | null> }
const readbackAdmissions = new WeakMap<DurableObjectStorage, ReadbackAdmissionLease>();

/** Production admission binds current grant and map revisions to the bounded GitHub proof. */
export function createProductionGitHubSource(identity: GitHubHostIdentity, mapping: GitHubSourceMappingV1,
  env: Pick<GitHubHostEnvironment, 'GITHUB_SOURCE_MAP'>, coordinator: GitHubHostCoordinator, client: GitHubAdmissionClient,
  options: { readback?: boolean; readbackStorage?: DurableObjectStorage; freshReadback?: boolean; expectedRevision?: number } = {}): GitHubSource {
  const { readback = false, readbackStorage, freshReadback = false, expectedRevision } = options;
  let firstAuthorization = true;
  return {
    authorize: async (subject, deadline) => {
      const cacheStorage = readback ? readbackStorage : undefined;
      const refresh = freshReadback && firstAuthorization;
      firstAuthorization = false;
      let authorized = false;
      let observedLease = cacheStorage ? readbackAdmissions.get(cacheStorage) : undefined;
      try {
        if (subjectKey(subject) !== subjectKey(identity.subject)) return null;
        const readGrant = () => deadline ? deadline.run(() => coordinator.githubGrant(subject), 5000) : coordinator.githubGrant(subject);
        let grantView: GitHubGrantView | null;
        try { grantView = await readGrant(); } catch { if (readback) throw new Error('unavailable'); return null; }
        const current = GitHubGrantViewSchema.safeParse(grantView);
        if (readback && grantView !== null && !current.success) throw new Error('unavailable');
        if (!current.success || (expectedRevision !== undefined && current.data.revision !== expectedRevision) || !current.data.enabled || subjectKey(current.data.subject) !== subjectKey(subject) || current.data.mappingRevision !== mapping.revision) return null;
        const grant = current.data;
        const currentMapping = () => {
          try { return parseGitHubSourceMap(env.GITHUB_SOURCE_MAP!).find(value => value.principal === identity.principal && value.agent === identity.agent && value.installationId === subject.installationId && value.repositoryId === subject.repositoryId); }
          catch { throw new Error('unavailable'); }
        };
        if (cacheStorage && JSON.stringify(currentMapping()) !== JSON.stringify(mapping)) return null;
        const snapshotKey = () => cacheStorage?.sql.exec<{ value: string }>("SELECT json_array(json_extract(value,'$.version'),json_extract(value,'$.epoch'),json_extract(value,'$.observation.epoch')) AS value FROM github_state WHERE id=1").toArray()[0]?.value ?? null;
        const snapshot = snapshotKey();
        const sourceRevision = JSON.stringify([mapping.principal, mapping.agent, mapping.installationId, mapping.repositoryId, mapping.revision, grant.revision, grant.mappingRevision, grant.policyRevision]);
        let lease: ReadbackAdmissionLease | undefined;
        if (cacheStorage) {
          const key = JSON.stringify([identity, subject, mapping, grant, snapshot]);
          lease = readbackAdmissions.get(cacheStorage);
          if (!lease || lease.key !== key || lease.expired || Date.now() >= lease.expiresAt || refresh && !lease.pending) {
            lease?.deadline.dispose();
            const leaseDeadline = new EventRequestDeadline(READBACK_ADMISSION_LEASE_MS);
            lease = { key, expiresAt: Date.now() + READBACK_ADMISSION_LEASE_MS, pending: true, deadline: leaseDeadline, expired: false, proof: leaseDeadline.run(() => client.admit(subject, grant.policyRevision, sourceRevision, deadline, readback)).catch(error => { if (error instanceof Error && error.message === 'request_deadline_exceeded') throw new Error('unavailable'); throw error; }) };
            const pending = lease;
            // The lease timer also spans gaps between calls; it never restarts on a cache hit.
            void leaseDeadline.run(() => new Promise<never>(() => {})).catch(() => {
              pending.expired = true;
              if (readbackAdmissions.get(cacheStorage) === pending) readbackAdmissions.delete(cacheStorage);
            });
            lease.proof = lease.proof.finally(() => { pending.pending = false; });
            readbackAdmissions.set(cacheStorage, lease);
          }
        }
        observedLease = lease;
        const admission = await (lease?.proof ?? client.admit(subject, grant.policyRevision, sourceRevision, deadline, readback));
        if (!admission) return null;
        if (lease && Date.now() >= lease.expiresAt) throw new Error('unavailable');
        let latestGrantView: GitHubGrantView | null;
        try { latestGrantView = await (lease ? lease.deadline.run(readGrant) : readGrant()); } catch { if (readback) throw new Error('unavailable'); return null; }
        const latest = GitHubGrantViewSchema.safeParse(latestGrantView);
        if (readback && latestGrantView !== null && !latest.success) throw new Error('unavailable');
        if (!latest.success || !latest.data.enabled || subjectKey(latest.data.subject) !== subjectKey(subject) || latest.data.revision !== grant.revision ||
          latest.data.mappingRevision !== grant.mappingRevision || latest.data.policyRevision !== grant.policyRevision || latest.data.mappingRevision !== mapping.revision) return null;
        let latestMapping: GitHubSourceMappingV1 | undefined;
        try { latestMapping = parseGitHubSourceMap(env.GITHUB_SOURCE_MAP!).find(value => value.principal === identity.principal && value.agent === identity.agent && value.installationId === subject.installationId && value.repositoryId === subject.repositoryId); } catch { if (readback) throw new Error('unavailable'); return null; }
        if (!latestMapping || latestMapping.revision !== mapping.revision || latestMapping.principal !== mapping.principal || latestMapping.agent !== mapping.agent ||
          latestMapping.installationId !== mapping.installationId || latestMapping.repositoryId !== mapping.repositoryId) return null;
        if (cacheStorage && snapshotKey() !== snapshot) throw new Error('unavailable');
        if (cacheStorage && JSON.stringify(currentMapping()) !== JSON.stringify(mapping)) return null;
        if (lease && (lease.expired || Date.now() >= lease.expiresAt || readbackAdmissions.get(cacheStorage!) !== lease)) throw new Error('unavailable');
        authorized = true;
        return admission;
      } finally {
        if (!authorized && cacheStorage) {
          observedLease?.deadline.dispose();
          if (readbackAdmissions.get(cacheStorage) === observedLease) readbackAdmissions.delete(cacheStorage);
        }
      }
    },
    observe: (subject, policy, epoch) => client.observe(subject, policy, epoch),
  };
}

/** Storage-backed host core. Tests inject source evidence; production never substitutes configuration for queue proof. */
export class GitHubHostRuntime {
  readonly controller: GitHubAttentionController;
  // eslint-disable-next-line no-unused-vars -- TypeScript parameter properties are read through this.coordinator.
  constructor(private readonly storage: DurableObjectStorage, private readonly source: GitHubSource, private readonly coordinator: GitHubHostCoordinator) {
    this.controller = new GitHubAttentionController(storage, source, undefined, true);
    storage.sql.exec('CREATE TABLE IF NOT EXISTS github_handoffs (id TEXT PRIMARY KEY, request TEXT, reason TEXT NOT NULL, checked_at INTEGER NOT NULL)');
    storage.sql.exec('CREATE TABLE IF NOT EXISTS github_publication_archive (id TEXT PRIMARY KEY, value TEXT NOT NULL, archived_at INTEGER NOT NULL)');
    storage.sql.exec('CREATE TABLE IF NOT EXISTS github_archive_stats (id INTEGER PRIMARY KEY CHECK(id=1), truncated INTEGER NOT NULL)');
  }
  async readSource(input: GitHubSourceReadRequest): Promise<GitHubSourceReadResult> {
    const request = GitHubSourceReadRequestSchema.parse(input);
    const deadline = new EventRequestDeadline(20_000);
    try {
      const admission = await deadline.run(() => this.source.authorize(request.subject, deadline));
      if (admission?.mergeQueue !== 'excluded') throw new Error('denied');
      const page = this.controller.readSource(request, admission);
      const current = await deadline.run(() => this.source.authorize(request.subject, deadline));
      if (current?.mergeQueue !== 'excluded' || current.revision !== admission.revision || current.policyRevision !== admission.policyRevision) throw new Error('denied');
      // Authority RPCs yield; discard a page changed by reconciliation or pruning.
      if (JSON.stringify(this.controller.readSource(request, current)) !== JSON.stringify(page)) return { status: 'conflict' };
      return page;
    } finally { deadline.dispose(); }
  }
  recoveryAlarmAt(now: number): number | null {
    const oldest = this.storage.sql.exec<{ oldest: number | null }>('SELECT MIN(archived_at) AS oldest FROM github_publication_archive').one().oldest;
    const journalDue = this.controller.nextJournalCleanupAt();
    const due = Math.min(this.controller.pending().length ? now + 60_000 : Infinity, oldest === null ? Infinity : oldest + EVENT_POLICY_V1.terminalDeduplicationRetentionMs, journalDue ?? Infinity);
    return Number.isFinite(due) ? due : null;
  }
  archivedPublications(): { publicationId: string; reason: string; archivedAt: number; event: GitHubPublicationInput['event']; request: GitHubPublicationInput | null; provenance: { revision: string; policy_revision: string } | null; createdAt: number }[] {
    return this.storage.sql.exec<{ value: string }>('SELECT value FROM github_publication_archive ORDER BY archived_at,id').toArray().map(row => JSON.parse(row.value));
  }
  archiveTruncationCount(): number {
    return this.storage.sql.exec<{ truncated: number }>('SELECT truncated FROM github_archive_stats WHERE id=1').toArray()[0]?.truncated ?? 0;
  }
  private pruneArchive(now: number): void {
    this.storage.transactionSync(() => {
      this.storage.sql.exec('DELETE FROM github_publication_archive WHERE archived_at <= ?', now - EVENT_POLICY_V1.terminalDeduplicationRetentionMs);
      const excess = this.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_publication_archive').one().n - 1000;
      if (excess > 0) {
        this.storage.sql.exec('INSERT INTO github_archive_stats(id,truncated) VALUES (1,?) ON CONFLICT(id) DO UPDATE SET truncated=truncated+excluded.truncated', excess);
        this.storage.sql.exec('DELETE FROM github_publication_archive WHERE id IN (SELECT id FROM github_publication_archive ORDER BY archived_at,id LIMIT ?)', excess);
      }
    });
  }
  private archive(id: string, now: number): void {
    this.storage.transactionSync(() => {
      const row = this.storage.sql.exec<{ value: string }>('SELECT value FROM github_outbox WHERE id=?', id).toArray().at(0);
      if (!row) return;
      const event = JSON.parse(row.value) as GitHubPublicationInput['event'];
      const handoff = this.storage.sql.exec<{ reason: string }>('SELECT reason FROM github_handoffs WHERE id=?', id).toArray().at(0);
      const request = this.request(id);
      const createdAt = this.storage.sql.exec<{ created_at: number }>('SELECT created_at FROM github_publication_created WHERE id=?', id).one().created_at;
      const value = { publicationId: id, event, request, provenance: this.controller.publicationAuthority(id), createdAt, archivedAt: now, reason: request ? 'receipt_unconfirmed_expired' : handoff?.reason ?? 'publication_expired' };
      this.storage.sql.exec('INSERT OR REPLACE INTO github_publication_archive(id,value,archived_at) VALUES (?,?,?)', id, JSON.stringify(value), now);
      this.acknowledge(id);
      this.pruneArchive(now);
    });
  }
  heldPublications(): { publicationId: string; reason: string }[] {
    return this.storage.sql.exec<{ id: string; reason: string }>('SELECT id,reason FROM github_handoffs ORDER BY id').toArray().map(row => ({ publicationId: row.id, reason: row.reason }));
  }
  private hold(id: string, reason: string, now: number): void {
    this.storage.sql.exec('INSERT INTO github_handoffs(id,request,reason,checked_at) VALUES (?,NULL,?,?) ON CONFLICT(id) DO UPDATE SET reason=excluded.reason', id, reason, now);
  }
  private acknowledge(id: string): void {
    this.controller.acknowledgePublication(id);
    this.storage.sql.exec('DELETE FROM github_handoffs WHERE id=?', id);
  }
  private request(id: string): GitHubPublicationInput | null {
    const row = this.storage.sql.exec<{ request: string | null }>('SELECT request FROM github_handoffs WHERE id=?', id).toArray().at(0);
    return row?.request ? JSON.parse(row.request) as GitHubPublicationInput : null;
  }
  async drain(now = Date.now()): Promise<void> {
    // Lease before external work: process loss and lost replies preserve the exact publication.
    await this.controller.retryPublications(now + 30_000);
    const deadline = new EventRequestDeadline(20_000);
    try {
      this.storage.sql.exec('DELETE FROM github_handoffs WHERE id NOT IN (SELECT id FROM github_outbox)');
      this.pruneArchive(now);
      // Backfill pre-clock records once; retries and object reconstruction never renew them.
      for (const event of this.controller.pending()) this.storage.sql.exec('INSERT OR IGNORE INTO github_publication_created(id,created_at) VALUES (?,?)', event.publicationId, Math.min(now, event.observedAt));
      const expired = new Set(this.storage.sql.exec<{ id: string }>('SELECT id FROM github_publication_created WHERE created_at <= ?', now - EVENT_POLICY_V1.deliveryTransportRetryHorizonMs).toArray().map(row => row.id));
      // Historical receipts authorize no new write: recover them even after source revocation.
      // Rotate the bounded recovery batch so permanently unaccepted old requests cannot monopolize it.
      const recovery = this.storage.sql.exec<{ id: string; request: string }>('SELECT id,request FROM github_handoffs WHERE request IS NOT NULL ORDER BY checked_at,id LIMIT 10').toArray();
      await Promise.allSettled(recovery.map(async row => {
        // Only a receipt probe advances rotation; reason-only holds must preserve its position.
        this.storage.sql.exec('UPDATE github_handoffs SET reason=?,checked_at=? WHERE id=?', 'receipt_unavailable', now, row.id);
        try {
          const receipt: unknown = await deadline.run(() => this.coordinator.githubPublicationReceipt(JSON.parse(row.request) as GitHubPublicationInput), 5000);
          if (typeof receipt === 'object' && receipt !== null && 'status' in receipt && receipt.status === 'accepted' && 'publicationId' in receipt && receipt.publicationId === row.id) this.acknowledge(row.id);
        } finally { if (expired.has(row.id)) this.archive(row.id, now); }
      }));
      for (const id of expired) if (!this.request(id)) this.archive(id, now);
      const events = this.controller.pending().filter(event => !expired.has(event.publicationId));
      if (!events.length) return;
      const admission = await deadline.run(() => this.source.authorize(events[0]!.subject, deadline), 5000);
      let eligible = 0;
      let grant: GitHubGrantView | null | undefined;
      // The local scan is bounded by the controller's 1,000-publication cap. Stale authority
      // records remain visible but never consume the ten-current-publication batch.
      for (const event of events) {
        const provenance = this.controller.publicationAuthority(event.publicationId);
        if (!provenance || admission?.mergeQueue !== 'excluded' || admission.revision !== provenance.revision || admission.policyRevision !== provenance.policy_revision) {
          this.hold(event.publicationId, 'source_authority_changed', now); continue;
        }
        if (grant === undefined) grant = await deadline.run(() => this.coordinator.githubGrant(event.subject), 5000);
        if (!grant?.enabled || subjectKey(grant.subject) !== subjectKey(event.subject) || grant.policyRevision !== admission.policyRevision) {
          this.hold(event.publicationId, 'grant_denied', now); continue;
        }
        let input = this.request(event.publicationId);
        if (input && (input.grantRevision !== grant.revision || input.mappingRevision !== grant.mappingRevision || input.policyRevision !== grant.policyRevision)) {
          this.hold(event.publicationId, 'grant_changed', now); continue;
        }
        if (eligible >= 10) continue;
        eligible++;
        // Grant lookup yielded: source/queue coverage must still match the committed evidence.
        const current = await deadline.run(() => this.source.authorize(event.subject, deadline), 5000);
        if (current?.mergeQueue !== 'excluded' || current.revision !== provenance.revision || current.policyRevision !== provenance.policy_revision) {
          this.hold(event.publicationId, 'source_authority_changed', now); continue;
        }
        if (!input) {
          const next: GitHubPublicationInput = { event, grantRevision: grant.revision, mappingRevision: grant.mappingRevision, policyRevision: grant.policyRevision };
          this.storage.sql.exec('INSERT INTO github_handoffs(id,request,reason,checked_at) VALUES (?,?,?,?) ON CONFLICT(id) DO UPDATE SET request=COALESCE(github_handoffs.request,excluded.request),reason=excluded.reason', event.publicationId, JSON.stringify(next), 'publication_pending', now);
          input = this.request(event.publicationId)!;
          if (input.grantRevision !== grant.revision || input.mappingRevision !== grant.mappingRevision || input.policyRevision !== grant.policyRevision) continue;
        }
        const createdAt = this.storage.sql.exec<{ created_at: number }>('SELECT created_at FROM github_publication_created WHERE id=?', event.publicationId).one().created_at;
        // External reads can cross the retry boundary; the next drain performs final recovery.
        if (Math.max(now, Date.now()) - Math.min(createdAt, event.observedAt) >= EVENT_POLICY_V1.deliveryTransportRetryHorizonMs) {
          this.hold(event.publicationId, 'publication_expired', now); continue;
        }
        const receipt: unknown = await deadline.run(() => this.coordinator.publishGitHub(input!), 5000);
        if (typeof receipt === 'object' && receipt !== null && 'status' in receipt && receipt.status === 'accepted' && 'publicationId' in receipt && receipt.publicationId === event.publicationId) this.acknowledge(event.publicationId);
        else this.hold(event.publicationId, 'receipt_mismatch', now);
      }
    } catch { /* Retain immutable requests, visible held reasons, and the durable retry lease. */ }
    finally {
      deadline.dispose();
      try { this.controller.pruneExpiredJournal(now); }
      finally { await this.controller.retryPublications(now + 30_000); }
    }
  }
  async alarm(now = Date.now()): Promise<void> {
    await this.drain(now);
    if ((this.controller.snapshot()?.dueAt ?? Infinity) <= now) await this.controller.reconcile(now);
    await this.drain(now);
  }
}

const hostIdentitySchema = z.strictObject({ principal: z.string().refine(value => canonicalEmail(value) && value === value.toLowerCase()), agent: agentSchema, subject: GitHubGrantSubjectSchema });
export class GitHubAttentionHost extends DurableObject<GitHubHostEnvironment> {
  private validateIdentity(identity: GitHubHostIdentity): void {
    if (!hostIdentitySchema.safeParse(identity).success || this.ctx.id.name !== githubHostName(identity)) throw new Error('github_denied');
  }
  private recoveryRuntime(identity: GitHubHostIdentity): GitHubHostRuntime {
    this.validateIdentity(identity);
    return new GitHubHostRuntime(this.ctx.storage, {
      authorize: () => Promise.resolve(null),
      observe: () => Promise.reject(new Error('github_denied')),
    }, {
      // The ordinary coordinator RPC still enforces owner partition/allowlist. This
      // adapter can only read an existing exact receipt; it cannot grant or publish.
      githubPublicationReceipt: input => this.env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent)).githubPublicationReceipt(input),
      githubGrant: () => Promise.resolve(null),
      githubWatches: () => Promise.resolve([]),
      publishGitHub: () => Promise.reject(new Error('github_denied')),
    });
  }
  private runtime(identity: GitHubHostIdentity, readback = false, freshReadback = false, expectedRevision?: number): GitHubHostRuntime {
    this.validateIdentity(identity);
    if (!githubHostConfigured(this.env) || !validSubject(identity.subject)) throw new Error('github_denied');
    const mapping = parseGitHubSourceMap(this.env.GITHUB_SOURCE_MAP!).find(value => value.principal === identity.principal && value.agent === identity.agent && value.installationId === identity.subject.installationId && value.repositoryId === identity.subject.repositoryId);
    if (!mapping) throw new Error('github_denied');
    const coordinator = this.env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
    const client = new GitHubAppClient({ appId: this.env.GITHUB_APP_ID!, privateKeyPkcs8: this.env.GITHUB_APP_PRIVATE_KEY! });
    const source = createProductionGitHubSource(identity, mapping, this.env, coordinator, client, { readback, readbackStorage: readback ? this.ctx.storage : undefined, freshReadback, expectedRevision });
    return new GitHubHostRuntime(this.ctx.storage, source, coordinator);
  }
  async readSource(identity: GitHubHostIdentity, input: GitHubSourceReadRequest): Promise<GitHubSourceReadResult> {
    this.validateIdentity(identity);
    const request = GitHubSourceReadRequestSchema.parse(input);
    if (subjectKey(request.subject) !== subjectKey(identity.subject)) throw new Error('denied');
    return this.runtime(identity, true, request.cursor === undefined).readSource(request);
  }
  sourceStatus(identity: GitHubHostIdentity): GitHubSourceStatus {
    this.validateIdentity(identity);
    if (!this.ctx.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE type='table' AND name='github_state'").toArray().length
      || !this.ctx.storage.sql.exec("SELECT 1 FROM github_state WHERE id=1").toArray().length)
      return { status: 'absent', sourceVersion: 0, health: null, failureReason: null, nextAttemptAt: null };
    const snapshot = this.recoveryRuntime(identity).controller.snapshot();
    return snapshot ? { status: snapshot.observation ? 'ready' : 'pending', sourceVersion: snapshot.version,
      health: snapshot.health, failureReason: snapshot.failureReason, nextAttemptAt: snapshot.dueAt }
      : { status: 'absent', sourceVersion: 0, health: null, failureReason: null, nextAttemptAt: null };
  }
  async initializeSource(identity: GitHubHostIdentity, expectedRevision: number): Promise<GitHubSourceStatus> {
    if (!Number.isSafeInteger(expectedRevision) || expectedRevision < 1) throw new Error('invalid');
    await this.runtime(identity, false, false, expectedRevision).controller.attach(identity.subject, Date.now(), true);
    return this.sourceStatus(identity);
  }
  async attach(identity: GitHubHostIdentity): Promise<void> {
    const runtime = this.runtime(identity);
    await runtime.controller.attach(identity.subject);
  }
  async accept(identity: GitHubHostIdentity, trigger: GitHubTriggerV1): Promise<'accepted' | 'denied'> {
    return await this.runtime(identity).controller.accept(trigger);
  }
  async alarm(): Promise<void> {
    let identity: GitHubHostIdentity;
    try {
      const [kind, principal, agent, installationId, repositoryId, prNumber] = JSON.parse(this.ctx.id.name ?? '') as unknown[];
      if (kind !== 'event-github-v1' || typeof principal !== 'string' || typeof agent !== 'string') return;
      identity = { principal, agent, subject: { installationId, repositoryId, prNumber } as GitHubSubjectV1 };
      if (githubHostName(identity) !== this.ctx.id.name) return;
    } catch { return; }
    let runtime: GitHubHostRuntime;
    try { runtime = this.runtime(identity); }
    catch {
      const recovery = this.recoveryRuntime(identity);
      const epoch = recovery.controller.snapshot()?.epoch;
      try { await recovery.drain(); }
      finally {
        // Inactive hosts wake only for pending receipts or retained metadata cleanup.
        // Preserve an immediate alarm if newer source work arrived during recovery.
        await this.ctx.storage.transaction(async () => {
          if (recovery.controller.snapshot()?.epoch !== epoch) return;
          const due = recovery.recoveryAlarmAt(Date.now());
          if (due !== null) await this.ctx.storage.setAlarm(due);
          else await this.ctx.storage.deleteAlarm();
        });
      }
      return;
    }
    try { await runtime.alarm(); }
    catch { await this.ctx.storage.setAlarm(Date.now() + 60_000); }
  }
}
