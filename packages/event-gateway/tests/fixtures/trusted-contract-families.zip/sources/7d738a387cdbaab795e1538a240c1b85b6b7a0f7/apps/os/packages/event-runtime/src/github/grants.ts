import { z } from 'zod';
import { canonicalEmail } from 'openapi-operator/src/access';
import { agent } from '../contracts';
import { EVENT_POLICY_V1 } from '../policy';
import { subjectKey } from './state';

const positive = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);
const revision = z.string().min(1).max(128);
export const GitHubGrantSubjectSchema = z.strictObject({ installationId: positive, repositoryId: positive, prNumber: positive });
const principalSchema = z.string().refine(value => canonicalEmail(value) && value === value.toLowerCase());
const mappingSchema = z.array(z.strictObject({ principal: principalSchema, agent, installationId: positive, repositoryId: positive, revision })).max(64)
  .refine(values => new Set(values.map(value => JSON.stringify([value.principal, value.agent, value.repositoryId]))).size === values.length);
export function parseGitHubSourceMap(raw: string) {
  if (typeof raw !== 'string' || raw.length > 32768) throw new Error('github_mapping_invalid');
  return mappingSchema.parse(JSON.parse(raw));
}
export const GitHubGrantInputSchema = z.strictObject({ subject: GitHubGrantSubjectSchema, enabled: z.boolean(), expectedRevision: positive.or(z.literal(0)), policyRevision: revision });
const eventSchema = z.strictObject({
  publicationId: z.string().min(1).max(256), subject: GitHubGrantSubjectSchema, sourceVersion: positive,
  candidateGeneration: positive, observedAt: positive, eventKind: z.enum(['attention', 'ci', 'terminal']),
  reasonCode: z.enum(['review_requested', 'review_submitted', 'review_comment', 'check_failed', 'status_failed', 'pull_request_closed', 'pull_request_merged']),
}).refine(event => event.candidateGeneration <= event.sourceVersion && event.publicationId === `${subjectKey(event.subject)}:${event.sourceVersion}:${event.reasonCode}` &&
  event.eventKind === (event.reasonCode.startsWith('pull_request_') ? 'terminal' : event.reasonCode.endsWith('_failed') ? 'ci' : 'attention'));
const publicationSchema = z.strictObject({ event: eventSchema, grantRevision: positive, mappingRevision: revision, policyRevision: revision });
export type GitHubGrantInput = z.infer<typeof GitHubGrantInputSchema>;
export type GitHubPublicationInput = z.infer<typeof publicationSchema>;
export const GitHubGrantViewSchema = z.strictObject({ subject: GitHubGrantSubjectSchema, enabled: z.boolean(), revision: positive, mappingRevision: revision, policyRevision: revision });
export type GitHubGrantView = z.infer<typeof GitHubGrantViewSchema>;

export const GitHubSourceStatusSchema = z.strictObject({
  status: z.enum(['absent', 'pending', 'ready']), sourceVersion: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  health: z.enum(['unknown', 'fresh', 'stale', 'denied']).nullable(),
  failureReason: z.enum(['denied', 'incomplete', 'capacity', 'unavailable']).nullable(),
  nextAttemptAt: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER).nullable(),
});
export const GitHubSourceOwnerViewSchema = z.strictObject({ grant: GitHubGrantViewSchema.nullable(), mappingCurrent: z.boolean(), source: GitHubSourceStatusSchema });
export type GitHubSourceOwnerView = z.infer<typeof GitHubSourceOwnerViewSchema>;
export type GitHubSourceStatus = z.infer<typeof GitHubSourceStatusSchema>;

/** Coordinator-local source authorization only; this does not authorize external dispatch or prove queue exclusion. */
export class GitHubGrantStore {
  // eslint-disable-next-line no-unused-vars -- TypeScript parameter properties are read through this.installationMappingJson.
  constructor(private readonly storage: DurableObjectStorage, private readonly principal: string, private readonly agentName: string, private readonly installationMappingJson: string | (() => string)) {
    principalSchema.parse(principal); agent.parse(agentName);
    this.mappings();
    storage.transactionSync(() => {
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_grants (subject TEXT PRIMARY KEY, value TEXT NOT NULL)');
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_grant_sequence (id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL)');
      storage.sql.exec("INSERT INTO github_grant_sequence(id,revision) SELECT 1,COALESCE(MAX(json_extract(value,'$.revision')),0) FROM github_grants WHERE true ON CONFLICT(id) DO UPDATE SET revision=MAX(revision,excluded.revision)");
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_publications (id TEXT PRIMARY KEY, value TEXT NOT NULL, accepted_at INTEGER NOT NULL)');
      if (!storage.sql.exec<{ name: string }>('PRAGMA table_info(github_publications)').toArray().some(column => column.name === 'accepted_at')) {
        storage.sql.exec('ALTER TABLE github_publications ADD COLUMN accepted_at INTEGER NOT NULL DEFAULT 0');
        // Legacy receipts get a full recovery window; construction never renews it.
        storage.sql.exec('UPDATE github_publications SET accepted_at=?', Date.now());
      }
    });
  }
  private mappings() { return parseGitHubSourceMap(typeof this.installationMappingJson === 'function' ? this.installationMappingJson() : this.installationMappingJson); }
  private mapping(subject: GitHubGrantView['subject']) {
    return this.mappings().find(value => value.principal === this.principal && value.agent === this.agentName && value.installationId === subject.installationId && value.repositoryId === subject.repositoryId);
  }
  private stored(subject: GitHubGrantView['subject']): GitHubGrantView | null {
    const row = this.storage.sql.exec<{ value: string }>('SELECT value FROM github_grants WHERE subject=?', subjectKey(subject)).toArray().at(0);
    return row ? JSON.parse(row.value) as GitHubGrantView : null;
  }
  setGrant(input: GitHubGrantInput): GitHubGrantView {
    const parsed = GitHubGrantInputSchema.parse(input);
    return this.storage.transactionSync(() => {
      const prior = this.stored(parsed.subject), mapping = this.mapping(parsed.subject);
      // Revocation remains possible after the operator removes a mapping.
      if (!mapping && (parsed.enabled || !prior)) throw new Error('github_denied');
      if ((prior?.revision ?? 0) !== parsed.expectedRevision || parsed.expectedRevision === Number.MAX_SAFE_INTEGER) throw new Error('github_grant_conflict');
      if (parsed.enabled && !prior?.enabled && this.storage.sql.exec<{ n: number }>("SELECT count(*) AS n FROM github_grants WHERE json_extract(value,'$.enabled')=1").one().n >= 64) throw new Error('github_capacity');
      const previousRevision = this.storage.sql.exec<{ revision: number }>('SELECT revision FROM github_grant_sequence WHERE id=1').one().revision;
      if (previousRevision >= Number.MAX_SAFE_INTEGER) throw new Error('github_grant_conflict');
      const nextRevision = previousRevision + 1;
      this.storage.sql.exec('UPDATE github_grant_sequence SET revision=? WHERE id=1', nextRevision);
      const value: GitHubGrantView = { subject: parsed.subject, enabled: parsed.enabled, revision: nextRevision, mappingRevision: mapping?.revision ?? prior!.mappingRevision, policyRevision: parsed.policyRevision };
      this.storage.sql.exec('INSERT OR REPLACE INTO github_grants(subject,value) VALUES (?,?)', subjectKey(parsed.subject), JSON.stringify(value));
      // The global revision survives eviction, so an absent subject can never reuse an old grant generation.
      this.storage.sql.exec("DELETE FROM github_grants WHERE subject IN (SELECT subject FROM github_grants WHERE json_extract(value,'$.enabled')=0 ORDER BY json_extract(value,'$.revision') DESC LIMIT -1 OFFSET 64)");
      return value;
    });
  }
  storedGrant(input: GitHubGrantView['subject']) {
    const subject = GitHubGrantSubjectSchema.parse(input), grant = this.stored(subject);
    return { grant, mappingCurrent: !!grant && this.mapping(subject)?.revision === grant.mappingRevision };
  }
  grant(input: GitHubGrantView['subject']): GitHubGrantView | null {
    const subject = GitHubGrantSubjectSchema.parse(input), value = this.stored(subject);
    return value?.enabled && this.mapping(subject)?.revision === value.mappingRevision ? value : null;
  }
  watches(): GitHubGrantView['subject'][] {
    return this.storage.sql.exec<{ value: string }>("SELECT value FROM github_grants WHERE json_extract(value,'$.enabled')=1 ORDER BY subject LIMIT 64").toArray()
      .map(row => JSON.parse(row.value) as GitHubGrantView).filter(value => this.grant(value.subject)).map(value => value.subject);
  }
  /** Recover an already committed outcome without granting any new source or dispatch authority. */
  publicationReceipt(input: GitHubPublicationInput, now = Date.now()): { status: 'accepted'; publicationId: string } | null {
    const parsed = publicationSchema.parse(input);
    const prior = this.storage.sql.exec<{ value: string }>('SELECT value FROM github_publications WHERE id=? AND accepted_at>?', parsed.event.publicationId, now - EVENT_POLICY_V1.terminalDeduplicationRetentionMs).toArray().at(0);
    if (!prior) return null;
    if (prior.value !== JSON.stringify(parsed)) throw new Error('github_publication_conflict');
    return { status: 'accepted', publicationId: parsed.event.publicationId };
  }
  /** Immutable metadata receipt only. No runtime delivery, wake, or stored bearer credentials. */
  acceptPublication(input: GitHubPublicationInput, now = Date.now()): { status: 'accepted'; publicationId: string } {
    const parsed = publicationSchema.parse(input), value = JSON.stringify(parsed);
    return this.storage.transactionSync(() => {
      const grant = this.grant(parsed.event.subject);
      if (!grant || grant.revision !== parsed.grantRevision || grant.mappingRevision !== parsed.mappingRevision || grant.policyRevision !== parsed.policyRevision) throw new Error('github_denied');
      this.storage.sql.exec('DELETE FROM github_publications WHERE accepted_at<=?', now - EVENT_POLICY_V1.terminalDeduplicationRetentionMs);
      const prior = this.storage.sql.exec<{ value: string }>('SELECT value FROM github_publications WHERE id=?', parsed.event.publicationId).toArray().at(0);
      if (prior && prior.value !== value) throw new Error('github_publication_conflict');
      if (!prior) {
        if (parsed.event.observedAt + EVENT_POLICY_V1.deliveryTransportRetryHorizonMs <= now || parsed.event.observedAt > now + EVENT_POLICY_V1.clockSkewMs) throw new Error('github_publication_expired');
        if (this.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_publications').one().n >= 1000) throw new Error('github_capacity');
        this.storage.sql.exec('INSERT INTO github_publications(id,value,accepted_at) VALUES (?,?,?)', parsed.event.publicationId, value, now);
      }
      return { status: 'accepted', publicationId: parsed.event.publicationId };
    });
  }
}
