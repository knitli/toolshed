import { INVENTORY_LIMITS as limits, type InventoryPage, type InventoryRow, type InventoryScope, type InventoryScalar } from './quarantine-inventory-contract.ts';

import { collections, parseInventoryRequest, type Field, type Collection } from './quarantine-inventory-validation.ts';
import type { InventoryRequest as Request } from './quarantine-inventory-contract.ts';
const text: Field = { kind: 'text' };
const optionalText: Field = { kind: 'text', nullable: true };
const integer: Field = { kind: 'integer', min: 0 };
const optionalInteger: Field = { kind: 'integer', min: 0, nullable: true };
// These columns are checked as schema metadata only; none enter the row projection.
const excludedColumns: Record<string, Record<string, Field>> = {
  nodes: { binding: text },
  native_runtime_bindings: { binding_json: text, key_thumbprint: optionalText },
  assigned_stock_runtime_bindings: { key_thumbprint: text, binding_json: text },
  deliveries: { reason: optionalText, source_kind: text, source_json: optionalText },
  attempts: {
    envelope_json: text, ack_json: optionalText, native_observed_ack_json: optionalText, transport_reason: optionalText,
    stock_wake_claim_json: optionalText, source_activation_json: optionalText, message_attempt_claim_json: optionalText,
    message_attempt_reserved_at: optionalInteger, message_command_settlement_pending: integer,
  },
  native_claims: { envelope_json: optionalText },
  no_start_settlements: { result_json: text },
  github_conversion_manifest_reservations: { fence: text, preparation_generation: integer },
  github_initial_reconciliations: {
    obligation: text, fence: text, due_at: integer, claim: optionalText, attempts: integer, digest: optionalText,
  },
};
const columnDefaults: Record<string, Record<string, string>> = {
  revocation_outbox: { attempts: '0' },
  deliveries: { transport_state: "'queued'", transport_failures: '0', source_kind: "'manual'" },
  attempts: { reservation_state: "'none'", transport_status: "'pending'", stock_wake_settlement_pending: '0', message_command_settlement_pending: '0' },
  native_claims: { updated_at: '0' },
  slot_intents: { attempts: '0', next_at: '0' },
  queue_outbox: { attempts: '0', state: "'queued'" },
};
// Constructors may add columns before an opt-in marker is written. Earlier layouts remain readable.
const requiredSince: Record<string, Record<string, number>> = {
  attempts: { native_observed_ack_json: 2, stock_wake_claim_json: 12, stock_wake_reserved_at: 12,
    stock_wake_settlement_pending: 12, source_activation_json: 14, message_attempt_claim_json: 15,
    message_attempt_reserved_at: 15, message_command_settlement_pending: 15 },
  native_runtime_bindings: { key_thumbprint: 3 },
  deliveries: { source_kind: 9, source_json: 9 },
};
type Column = { name: string; type: string; notnull: number; dflt_value: string | null; pk: number; hidden: number };
type ReadSql = Pick<SqlStorage, 'exec'>;
const encoder = new TextEncoder();
const bytes = (value: unknown) => encoder.encode(JSON.stringify(value)).byteLength;
function validKey(value: unknown): value is string {
  return typeof value === 'string' && value.length > 0 && encoder.encode(value).byteLength <= limits.keyBytes;
}
function empty(request: Request | null): InventoryPage {
  return { status: 'page', scopeKind: request?.scopeKind ?? null, collection: request?.collection ?? null,
    rows: [], nextKey: null, pageComplete: false,
    historicalCoverage: 'unknown', clearanceAssessment: 'not_performed', consistency: 'single_page_only' };
}
function unavailable(page: InventoryPage, reason: Extract<InventoryPage, { status: 'unavailable' }>['reason']): InventoryPage {
  return { ...page, status: 'unavailable', reason, pageComplete: false, nextKey: null };
}
function validMigrationHistory(versions: number[], scope: InventoryScope): boolean {
  const expectedMax = scope === 'registry' ? 2 : 16;
  if (!versions.length || versions.length > expectedMax
    || versions.some(version => !Number.isSafeInteger(version) || version < 1 || version > expectedMax)) return false;
  const applied = new Set(versions);
  if (applied.size !== versions.length) return false;
  // Base markers accumulate; feature markers 4–15 are independent opt-ins, not a contiguous chain.
  const requiredBase = Math.min(Math.max(...versions), scope === 'registry' ? 1 : 3);
  for (let version = 1; version <= requiredBase; version++) if (!applied.has(version)) return false;
  return true;
}
function readColumns(sql: ReadSql, table: string, maxColumns: number): Column[] {
  // Bound both metadata row count and text before materialization, including hidden columns.
  return sql.exec<Column>(`SELECT
    CASE WHEN length(CAST(name AS BLOB))<=128 THEN name END AS name,
    CASE WHEN length(CAST(type AS BLOB))<=16 THEN type END AS type,
    "notnull", CASE WHEN dflt_value IS NULL OR length(CAST(dflt_value AS BLOB))<=128
      THEN dflt_value ELSE 'unrecognized_default' END AS dflt_value,
    pk,hidden FROM pragma_table_xinfo(?) LIMIT ?`, table, maxColumns + 1).toArray();
}
function knownColumns(columns: Column[], fields: Record<string, Field>, keys: readonly string[],
  defaults: Record<string, string>, optional: string[] = []): boolean {
  if (columns.length > Object.keys(fields).length || new Set(columns.map(column => column.name)).size !== columns.length) return false;
  for (const [name, field] of Object.entries(fields)) {
    const column = columns.find(item => item.name === name);
    if (!column) {
      if (optional.includes(name)) continue;
      return false;
    }
    const pk = keys.indexOf(name) + 1;
    const notnull = field.nullable || (pk > 0 && keys.length === 1) ? 0 : 1;
    if (column.type !== (field.kind === 'text' ? 'TEXT' : 'INTEGER') || column.notnull !== notnull
      || column.dflt_value !== (defaults[name] ?? null) || column.pk !== pk || column.hidden !== 0) return false;
  }
  return columns.every(column => Object.hasOwn(fields, column.name));
}
function knownSchema(sql: ReadSql, request: Request, collection: Collection): boolean {
  const migration = request.scopeKind === 'registry' ? 'registry_migrations' : 'schema_migrations';
  const objects = sql.exec<{ name: string; type: string }>('SELECT name,type FROM sqlite_schema WHERE name IN (?,?)', migration, request.collection).toArray();
  if (objects.length !== 2 || objects.some(object => object.type !== 'table')) return false;
  if (!knownColumns(readColumns(sql, migration, 2), { version: integer, applied_at: integer }, ['version'], {})) return false;
  // Read one more than the current known coordinator maximum so any future marker is visible.
  const migrations = sql.exec<{ version: number }>(`SELECT version FROM ${migration} ORDER BY version LIMIT 17`).toArray();
  const versions = migrations.map(item => item.version);
  if (!validMigrationHistory(versions, request.scopeKind)) return false;
  const fields = { ...collection.fields, ...excludedColumns[request.collection] };
  const columns = readColumns(sql, request.collection, Object.keys(fields).length);
  const optional = Object.entries(requiredSince[request.collection] ?? {})
    .filter(([, version]) => !versions.includes(version)).map(([name]) => name);
  if (request.collection === 'deliveries'
    && columns.some(column => column.name === 'source_kind') !== columns.some(column => column.name === 'source_json')) return false;
  return knownColumns(columns, fields, collection.keys, columnDefaults[request.collection] ?? {}, optional);
}
function project(raw: Record<string, SqlStorageValue>, collection: Collection): InventoryRow {
  const values: Record<string, InventoryScalar> = {}, issues: string[] = [];
  for (const [name, field] of Object.entries(collection.fields)) {
    const value = raw[name], sqlType = raw[`type_${name}`];
    const valid = sqlType === 'null' ? !!field.nullable
      : field.kind === 'integer' ? sqlType === 'integer' && typeof value === 'number' && Number.isSafeInteger(value) && value >= (field.min ?? 0)
      : sqlType === 'text' && typeof value === 'string' && value.length > 0;
    if (!valid || (value !== null && field.states && !field.states.includes(value as InventoryScalar))) {
      values[name] = null;
      issues.push(`${name}:uninterpretable`);
    } else values[name] = value as InventoryScalar;
  }
  const keyValues = collection.keys.map(name => values[name]);
  const key = keyValues.every(validKey) ? keyValues : null;
  if (!key) issues.push('key:uninterpretable');
  return { key, interpretation: issues.length ? 'uninterpretable' : 'raw', values, issues };
}

function readRows(sql: ReadSql, request: Request, collection: Collection): Record<string, SqlStorageValue>[] {
  // Bound SQLite output before materialization; never SELECT any opaque JSON/body column.
  const fields = Object.keys(collection.fields).flatMap(name => [
    `CASE WHEN typeof(${name})='integer' THEN ${name} WHEN typeof(${name})='text' AND length(CAST(${name} AS BLOB))<=${limits.textBytes} THEN ${name} ELSE NULL END AS ${name}`,
    `typeof(${name}) AS type_${name}`,
  ]).join(',');
  const keys = collection.keys.map(key => `${key} COLLATE BINARY`).join(',');
  const where = request.after ? ` WHERE (${keys}) > (${collection.keys.map(() => '?').join(',')})` : '';
  return sql.exec<Record<string, SqlStorageValue>>(`SELECT ${fields} FROM ${request.collection}${where} ORDER BY ${keys} LIMIT ?`,
    ...(request.after ?? []), request.limit + 1).toArray();
}
function appendRow(page: InventoryPage, projected: InventoryRow, request: Request): InventoryPage | null {
  const candidate: InventoryPage = { ...page, rows: [...page.rows, projected], nextKey: projected.key };
  if (!projected.key) {
    const failed = unavailable(candidate, 'uninterpretable_key');
    return bytes(failed) <= request.maxBytes ? failed : unavailable(empty(request), 'page_budget');
  }
  if (bytes(candidate) > request.maxBytes) return page.rows.length ? page : unavailable(page, 'page_budget');
  page.rows.push(projected);
  page.nextKey = projected.key;
  return null;
}
function projectPage(raw: Record<string, SqlStorageValue>[], collection: Collection, request: Request): InventoryPage {
  const page = empty(request);
  for (const item of raw.slice(0, request.limit)) {
    const stopped = appendRow(page, project(item, collection), request);
    if (stopped) return stopped;
  }
  page.pageComplete = raw.length <= request.limit;
  if (page.pageComplete) page.nextKey = null;
  return page;
}

/** SELECT-only projection over initialized storage. No callers are wired to this kernel. */
export function inventoryPage(sql: ReadSql, input: unknown): InventoryPage {
  const request = parseInventoryRequest(input), page = empty(request);
  if (!request) return unavailable(page, 'invalid_request');
  const collection = collections[request.collection]!;
  try {
    if (!knownSchema(sql, request, collection)) return unavailable(page, 'schema_unknown');
  } catch { return unavailable(page, 'schema_unknown'); }
  try {
    return projectPage(readRows(sql, request, collection), collection, request);
  } catch { return unavailable(empty(request), 'query_failed'); }
}
