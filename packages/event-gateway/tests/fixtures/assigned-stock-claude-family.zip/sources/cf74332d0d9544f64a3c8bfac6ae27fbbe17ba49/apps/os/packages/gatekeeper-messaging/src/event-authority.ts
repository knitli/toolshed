import { parseEventMessagePreparationInput, parseEventMessagePreparationResult, type EventMessagePreparationInputV1, type EventMessagePreparationResultV1 } from "./event-authority-contract.ts";
import { parseEventSourceActivationInputV1, parseEventSourceActivationResultV1, type EventSourceActivationInputV1, type EventSourceActivationResultV1 } from "./event-authority-contract.ts";
import { MessageRouteOwnerProofVerifier } from "./message-route-owner-proof.ts";
import { parseMessageRouteControlInput, parseMessageRouteControlResult, parseMessageRouteOwnerCall, type MessageRouteControlResult } from "./message-route-control-contract.ts";
import { routeControlFailure } from "./message-route-control.ts";
import { WorkerEntrypoint } from "cloudflare:workers";
import { validateRpc } from "capnweb-validate";
import { AccessDenied, AccessUnavailable, canonicalEmail, identifier, verifyJwtClaims, type AccessPorts } from "openapi-operator/src/access.ts";
import { verifyAdminAssertion } from "gatekeeper-memory/src/admin-security";
import { productionPorts } from "gatekeeper-memory/src/auth.ts";
import { parseAllowedPrincipals, principalAllowed } from "gatekeeper-memory/src/principals.ts";
import { audienceShared, oauthHostname } from "./auth.ts";
import { readToken, signatureValid } from "./agent-token.ts";
import { agentName, codeOf, mailboxName } from "./model.ts";
import type {
  EventOwnerAgentResultV1,
  EventAuthorityAttemptV1,
  EventAuthorityAuthResultV1,
  EventAuthorityCredentialsV1,
  EventAuthorityIdentityV1,
  EventMessageAuthorityServiceV1,
  EventMessageAttemptV1,
  EventMessagePublicationV1,
  EventMessagePublicationResultV1,
  EventMessageAttemptResultV1,
  EventMessageCommandSettlementV1,
  EventMessageCommandSettlementResultV1,
  EventMessageCommandSettlementReadResultV1,
  EventMessageCommandSettlementReadV1,
  EventAttemptReservationResultV1,
  EventAttemptStatusResultV1,
  EventStockWakeAuthorityServiceV1,
  StockWakeAttemptV1,
  StockWakeReservationResultV1,
  StockWakeSettlementInputV1,
  StockWakeSettlementResultV1,
} from "./event-authority-contract.ts";
import { parseEventAuthorityInput, parseEventMessageCommandSettlement, parseEventMessageCommandSettlementRead, parseEventMessagePublication, parseEventMessageAttempt, parseStockWakeAttempt, parseStockWakeSettlementInput } from "./event-authority-contract.ts";

type Mailbox = ReturnType<Env["MAILBOX"]["getByName"]>;
type AuthorizedCaller = Readonly<{
  identity: EventAuthorityIdentityV1;
  keyThumbprint: string;
  proofExpiresAt: number;
  mailbox: Mailbox;
}>;
type Authorization = AuthorizedCaller | Readonly<{ status: "denied" | "unavailable" }>;

const HOST_LABEL = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;

function eventHost(value: string | undefined): string | null {
  if (!value || value.length > 253 || value !== value.toLowerCase()) return null;
  const labels = value.split(".");
  if (labels.length < 2 || labels.some((label) => label.length > 63 || !HOST_LABEL.test(label))) return null;
  return value;
}

function accessDeniedOrUnavailable(error: unknown): "denied" | "unavailable" {
  if (error instanceof AccessUnavailable) return "unavailable";
  if (error instanceof AccessDenied) return "denied";
  const code = codeOf(error);
  return code === "forbidden" || code === "suspended" || code === "not_found" ? "denied" : "unavailable";
}

/** Narrow internal authority for Event Runtime. It returns no Mailbox stub or Messaging capability. */
@validateRpc()
export class EventAuthority extends WorkerEntrypoint<Env> implements EventMessageAuthorityServiceV1, EventStockWakeAuthorityServiceV1 {
  readonly #ports: AccessPorts;

  /** Optional Access ports are a test seam; deployed construction uses this Worker's Access issuer. */
  constructor(ctx: ExecutionContext, env: Env, ports?: AccessPorts) {
    super(ctx, env);
    this.#ports = ports ?? productionPorts(env.ACCESS_ISSUER);
  }

  #configuration(): { host: string; accessAudience: string } | null {
    const host = eventHost(this.env.EVENT_HOST);
    const accessAudience = this.env.ACCESS_EVENT_AUD;
    if (!host || !accessAudience || !identifier(accessAudience, 256) || !this.env.ACCESS_ISSUER || !this.env.MESSAGING_NAMESPACE)
      return null;
    let oauthHost: string | null;
    try {
      oauthHost = oauthHostname(this.env);
    } catch {
      return null;
    }
    const otherHosts = [this.env.MESSAGES_HOST, oauthHost].filter(Boolean);
    if (otherHosts.some((other) => other!.toLowerCase() === host) || audienceShared(this.env, "ACCESS_EVENT_AUD")) return null;
    try {
      parseAllowedPrincipals(this.env.ALLOWED_PRINCIPALS);
    } catch {
      return null;
    }
    return { host, accessAudience };
  }

  async #authorize(input: EventAuthorityCredentialsV1): Promise<Authorization> {
    const config = this.#configuration();
    if (!config) return { status: "unavailable" };

    // The person: a verified Event Access assertion, or the Gateway Forward identity Event Runtime's NodeEdge passes on
    // (only events-edge binds NodeEdge, and only after Gateway checked the WARP session and device posture).
    let email: string;
    let accessExpiresAt: number | undefined;
    if ("gatewayIdentity" in input) email = input.gatewayIdentity.email;
    else {
      let accessClaims: Record<string, unknown>;
      try {
        accessClaims = await verifyJwtClaims(input.accessAssertion, "access", {
          issuer: this.env.ACCESS_ISSUER,
          audience: config.accessAudience,
        }, this.#ports);
      } catch (error) {
        return { status: accessDeniedOrUnavailable(error) };
      }

      const audiences = typeof accessClaims.aud === "string" ? [accessClaims.aud] : accessClaims.aud;
      if (!Array.isArray(audiences) || audiences.length !== 1 || audiences[0] !== config.accessAudience ||
        typeof accessClaims.email !== "string" || typeof accessClaims.common_name === "string")
        return { status: "denied" };
      if (typeof accessClaims.exp !== "number" || !Number.isSafeInteger(accessClaims.exp)) return { status: "denied" };
      email = accessClaims.email;
      accessExpiresAt = accessClaims.exp;
    }
    // canonicalEmail on the value as given, before lower-casing: a non-ASCII look-alike (the Kelvin sign lower-cases to "k") is refused.
    if (!canonicalEmail(email)) return { status: "denied" };
    const principal = email.toLowerCase();
    if (!principalAllowed(this.env, principal)) return { status: "denied" };

    const agentAudience = `https://${config.host}`;
    const read = readToken(input.agentToken, {
      audience: agentAudience,
      principal,
      now: Math.floor(this.#ports.now()),
    });
    if ("refused" in read) return { status: "denied" };

    const mailbox = this.env.MAILBOX.getByName(mailboxName(this.env.MESSAGING_NAMESPACE, principal));
    let x: string | null;
    try {
      x = await mailbox.agentKey(read.agent, read.kid);
    } catch {
      return { status: "unavailable" };
    }
    if (x === null) return { status: "denied" };
    try {
      if (!(await signatureValid(read, x))) return { status: "denied" };
    } catch {
      return { status: "denied" };
    }

    // Signature verification and the DO lookups above await. Recheck the signed proof's time claims
    // immediately before the final Mailbox check; that synchronous check is the Messaging admission point.
    const current = readToken(input.agentToken, {
      audience: agentAudience,
      principal,
      now: Math.floor(this.#ports.now()),
    });
    if ("refused" in current || current.agent !== read.agent || current.kid !== read.kid || current.input !== read.input)
      return { status: "denied" };
    // A Gateway identity has no expiry of its own: it bounds the proof to a minute, and every later operation asks again.
    const personExpiresAt = accessExpiresAt === undefined ? Math.floor((this.#ports.now() + 60) * 1000) : accessExpiresAt * 1000;
    const proofExpiresAt = Math.min(personExpiresAt, current.expiresAt * 1000);
    if (!Number.isSafeInteger(proofExpiresAt) || proofExpiresAt <= this.#ports.now() * 1000) return { status: "denied" };

    try {
      await mailbox.assertEventCredential(current.agent, current.kid, proofExpiresAt);
    } catch (error) {
      return { status: accessDeniedOrUnavailable(error) };
    }
    return {
      identity: { principal, agent: current.agent, keyThumbprint: current.kid },
      keyThumbprint: current.kid,
      proofExpiresAt,
      mailbox,
    };
  }

  /** Registration read only: no agent capability, key material, or native qualification. */
  async registeredOwnerAgent(input: unknown): Promise<EventOwnerAgentResultV1> {
    if (!input || typeof input !== "object" || Array.isArray(input) ||
      ![Object.prototype, null].includes(Object.getPrototypeOf(input)) ||
      Object.keys(input).length !== 2 || !Object.hasOwn(input, "accessAssertion") || !Object.hasOwn(input, "agent"))
      return { status: "invalid" };
    const value = input as Record<string, unknown>;
    if (typeof value.accessAssertion !== "string" || !value.accessAssertion || new TextEncoder().encode(value.accessAssertion).length > 16_384)
      return { status: "invalid" };
    let agent: string;
    try { agent = agentName(value.agent); } catch { return { status: "invalid" }; }
    try {
      if (!this.env.MESSAGING_NAMESPACE) return { status: "unavailable" };
      parseAllowedPrincipals(this.env.ALLOWED_PRINCIPALS);
      const who = await verifyAdminAssertion(value.accessAssertion, this.env, this.#ports);
      if (!principalAllowed(this.env, who.principal)) return { status: "denied" };
      const mailbox = this.env.MAILBOX.getByName(mailboxName(this.env.MESSAGING_NAMESPACE, who.principal));
      if (!(await mailbox.hasAgent(agent))) return { status: "not_registered" };
      return { status: "authorized", identity: { principal: who.principal, agent } };
    } catch (error) {
      return { status: accessDeniedOrUnavailable(error) };
    }
  }

  async messageRouteControl(originalCall: unknown, originalInput: unknown): Promise<MessageRouteControlResult> {
    const call = parseMessageRouteOwnerCall(originalCall), input = parseMessageRouteControlInput(originalInput);
    if (!call || !input) return { status: "invalid" };
    const namespace = this.env.MESSAGING_NAMESPACE, mailboxes = this.env.MAILBOX;
    try {
      const who = await verifyAdminAssertion(call.token, this.env, this.#ports);
      if (!namespace || this.env.MESSAGING_NAMESPACE !== namespace || mailboxes !== this.env.MAILBOX || !principalAllowed(this.env, who.principal)) return { status: "denied" };
      const verifier = new MessageRouteOwnerProofVerifier(this.env, this.#ports);
      const proof = await verifier.requireOwner(call, { namespace, principal: who.principal, agent: input.agent }, input.request.operation);
      if (this.env.MESSAGING_NAMESPACE !== namespace || mailboxes !== this.env.MAILBOX) return { status: "denied" };
      const result = await mailboxes.getByName(mailboxName(namespace, who.principal)).messageRouteControl(call, input);
      verifier.assertCurrent(proof);
      if (this.env.MESSAGING_NAMESPACE !== namespace || mailboxes !== this.env.MAILBOX || !principalAllowed(this.env, who.principal)) return { status: "denied" };
      return parseMessageRouteControlResult(result, input) ?? { status: "unavailable" };
    } catch (error) { return routeControlFailure(error); }
  }

  async currentAuth(input: EventAuthorityCredentialsV1): Promise<EventAuthorityAuthResultV1> {
    const parsed = parseEventAuthorityInput(input, false);
    if (!parsed) return { status: "invalid" };
    const caller = await this.#authorize(parsed);
    return "status" in caller ? caller : { status: "authorized", identity: caller.identity };
  }

  /** Service-binding-only source read. Identity and source metadata come from Event's trusted coordinator. */
  async prepareSourceActivation(input: EventSourceActivationInputV1): Promise<EventSourceActivationResultV1> {
    const parsed = parseEventSourceActivationInputV1(input);
    if (!parsed) return { status: "invalid" };
    const namespace = this.env.MESSAGING_NAMESPACE, mailboxes = this.env.MAILBOX;
    if (!namespace) return { status: "unavailable" };
    if (parsed.namespace !== namespace || !canonicalEmail(parsed.principal) || parsed.principal !== parsed.principal.toLowerCase() ||
      !principalAllowed(this.env, parsed.principal)) return { status: "denied" };
    try {
      const result = await mailboxes.getByName(mailboxName(namespace, parsed.principal)).prepareEventSourceActivation(parsed);
      if (this.env.MESSAGING_NAMESPACE !== namespace || this.env.MAILBOX !== mailboxes || !principalAllowed(this.env, parsed.principal)) return { status: "denied" };
      const checked = parseEventSourceActivationResultV1(result);
      if (!checked) return { status: "unavailable" };
      return checked.status === "eligible" && (checked.claim.principal !== parsed.principal || checked.claim.agent !== parsed.agent ||
        JSON.stringify(checked.claim.source) !== JSON.stringify(parsed.source) ||
        (parsed.expectedSnapshot !== undefined && checked.claim.snapshotDigest !== parsed.expectedSnapshot))
        ? { status: "unavailable" } : checked;
    } catch (error) { return { status: accessDeniedOrUnavailable(error) }; }
  }

  async reserveNativeAttempt(input: EventAuthorityAttemptV1): Promise<EventAttemptReservationResultV1> {
    const parsed = parseEventAuthorityInput(input, true);
    if (!parsed) return { status: "invalid" };
    const caller = await this.#authorize(parsed);
    if ("status" in caller) return caller;
    try {
      return await caller.mailbox.reserveEventNativeAttempt(
        caller.identity.agent,
        caller.keyThumbprint,
        parsed.attemptId,
        caller.proofExpiresAt,
        parsed.activation,
      );
    } catch (error) {
      return { status: accessDeniedOrUnavailable(error) };
    }
  }

  async reserveStockWakeAttempt(input: StockWakeAttemptV1): Promise<StockWakeReservationResultV1> {
    const parsed = parseStockWakeAttempt(input);
    if (!parsed) return { status: "invalid" };
    const caller = await this.#authorize(parsed);
    if ("status" in caller) return caller;
    try {
      return await caller.mailbox.reserveEventStockWakeAttempt(caller.identity.agent, caller.keyThumbprint,
        parsed.attemptId, this.#stockClaim(parsed), caller.proofExpiresAt);
    } catch (error) { return { status: accessDeniedOrUnavailable(error) }; }
  }

  async stockWakeAttemptStatus(input: StockWakeAttemptV1): Promise<EventAttemptStatusResultV1> {
    const parsed = parseStockWakeAttempt(input);
    if (!parsed) return { status: "invalid" };
    const caller = await this.#authorize(parsed);
    if ("status" in caller) return caller;
    try {
      return await caller.mailbox.eventStockWakeAttemptStatus(caller.identity.agent, caller.keyThumbprint, parsed.attemptId,
        this.#stockClaim(parsed), caller.proofExpiresAt);
    } catch (error) { return { status: accessDeniedOrUnavailable(error) }; }
  }

  async settleStockWakeAttempt(input: StockWakeSettlementInputV1): Promise<StockWakeSettlementResultV1> {
    const parsed = parseStockWakeSettlementInput(input);
    if (!parsed) return { status: "invalid" };
    const caller = await this.#authorize(parsed);
    if ("status" in caller) return caller;
    try {
      return await caller.mailbox.settleEventStockWakeAttempt(caller.identity.agent, caller.keyThumbprint, parsed.attemptId,
        this.#stockClaim(parsed), parsed.reservedAt, caller.proofExpiresAt);
    } catch (error) { return { status: accessDeniedOrUnavailable(error) }; }
  }

  #stockClaim(input: StockWakeAttemptV1): string {
    return JSON.stringify({ deliveryId: input.deliveryId, consumer: input.consumer, conversationId: input.conversationId,
      ...("activation" in input ? { activation: input.activation } : {}) });
  }

  async readMessagePreparation(input: EventMessagePreparationInputV1): Promise<EventMessagePreparationResultV1> {
    const parsed = parseEventMessagePreparationInput(input);
    if (!parsed) return { status: "invalid" };
    const namespace = this.env.MESSAGING_NAMESPACE, mailboxes = this.env.MAILBOX;
    if (!namespace) return { status: "unavailable" };
    const principal = parsed.publication.principal;
    if (parsed.publication.namespace !== namespace || !canonicalEmail(principal) || principal !== principal.toLowerCase() || !principalAllowed(this.env, principal)) return { status: "denied" };
    try {
      const result = await mailboxes.getByName(mailboxName(namespace, principal)).readEventMessagePreparation(parsed);
      if (this.env.MESSAGING_NAMESPACE !== namespace || this.env.MAILBOX !== mailboxes || !principalAllowed(this.env, principal)) return { status: "denied" };
      const checked = parseEventMessagePreparationResult(result);
      if (!checked || (checked.status === "eligible" && JSON.stringify(checked.publication) !== JSON.stringify(parsed.publication))) return { status: "unavailable" };
      return checked;
    } catch (error) { return { status: accessDeniedOrUnavailable(error) }; }
  }

  /** Service-binding-only source attestation. It grants no consumer or wake authority. */
  async validateMessagePublication(input: EventMessagePublicationV1): Promise<EventMessagePublicationResultV1> {
    const parsed = parseEventMessagePublication(input);
    if (!parsed) return { status: "invalid" };
    const namespace = this.env.MESSAGING_NAMESPACE;
    if (!namespace) return { status: "unavailable" };
    if (parsed.namespace !== namespace || !canonicalEmail(parsed.principal) || parsed.principal !== parsed.principal.toLowerCase())
      return { status: "denied" };
    try {
      if (!principalAllowed(this.env, parsed.principal)) return { status: "denied" };
      const result = await this.env.MAILBOX.getByName(mailboxName(namespace, parsed.principal)).validateEventMessagePublication(parsed);
      if (this.env.MESSAGING_NAMESPACE !== namespace || !principalAllowed(this.env, parsed.principal)) return { status: "denied" };
      return result;
    } catch (error) {
      return { status: accessDeniedOrUnavailable(error) };
    }
  }

  async reserveMessageAttempt(input: EventMessageAttemptV1): Promise<EventMessageAttemptResultV1> {
    return this.#messageAttempt(input, true);
  }

  async messageAttemptStatus(input: EventMessageAttemptV1): Promise<EventMessageAttemptResultV1> {
    return this.#messageAttempt(input, false);
  }

  /** Private Event service-binding settlement; the coordinator calls only after exact committed-ACK readback. */
  async settleMessageCommandAccepted(input: EventMessageCommandSettlementV1): Promise<EventMessageCommandSettlementResultV1> {
    const parsed = parseEventMessageCommandSettlement(input);
    if (!parsed) return { status: "invalid" };
    const caller = await this.#authorize(parsed);
    if ("status" in caller) return caller;
    try {
      return await caller.mailbox.settleEventMessageCommandAttempt(caller.identity.agent, caller.keyThumbprint,
        caller.proofExpiresAt, parsed);
    } catch (error) { return { status: accessDeniedOrUnavailable(error) }; }
  }

  /** Read-only recovery proof; it never settles an attempt or changes the shared wake budget. */
  async readMessageCommandSettlement(input: EventMessageCommandSettlementReadV1): Promise<EventMessageCommandSettlementReadResultV1> {
    const parsed = parseEventMessageCommandSettlementRead(input);
    if (!parsed) return { status: "invalid" };
    const principal = parsed.activation.principal;
    if (!this.env.MESSAGING_NAMESPACE || parsed.activation.agent.length === 0 || !principalAllowed(this.env, principal)) return { status: "denied" };
    try {
      return await this.env.MAILBOX.getByName(mailboxName(this.env.MESSAGING_NAMESPACE, principal)).readEventMessageCommandSettlement(parsed);
    } catch { return { status: "unavailable" }; }
  }

  async #messageAttempt(input: EventMessageAttemptV1, reserve: boolean): Promise<EventMessageAttemptResultV1> {
    const parsed = parseEventMessageAttempt(input);
    if (!parsed) return { status: "invalid" };
    const caller = await this.#authorize(parsed);
    if ("status" in caller) return caller;
    const claim = { attemptId: parsed.attemptId, messageId: parsed.messageId, routingGeneration: parsed.routingGeneration, consumer: parsed.consumer,
      ...("activation" in parsed ? { activation: parsed.activation } : {}),
      ...("runtimeProfile" in parsed ? { runtimeProfile: parsed.runtimeProfile, conversationId: parsed.conversationId } : {}) };
    try {
      return reserve
        ? await caller.mailbox.reserveEventMessageAttempt(caller.identity.agent, caller.keyThumbprint, caller.proofExpiresAt, claim)
        : await caller.mailbox.eventMessageAttemptStatus(caller.identity.agent, caller.keyThumbprint, caller.proofExpiresAt, claim);
    } catch (error) {
      return { status: accessDeniedOrUnavailable(error) };
    }
  }

  async nativeAttemptStatus(input: EventAuthorityAttemptV1): Promise<EventAttemptStatusResultV1> {
    const parsed = parseEventAuthorityInput(input, true);
    if (!parsed) return { status: "invalid" };
    const caller = await this.#authorize(parsed);
    if ("status" in caller) return caller;
    try {
      return await caller.mailbox.eventNativeAttemptStatus(
        caller.identity.agent,
        caller.keyThumbprint,
        parsed.attemptId,
        caller.proofExpiresAt,
        parsed.activation,
      );
    } catch (error) {
      return { status: accessDeniedOrUnavailable(error) };
    }
  }
}
