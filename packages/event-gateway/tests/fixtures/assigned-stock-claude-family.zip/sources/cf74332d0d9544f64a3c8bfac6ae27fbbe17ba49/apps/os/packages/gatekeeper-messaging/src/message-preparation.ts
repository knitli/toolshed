import { canonicalMessageActivation, messageRoute, type BridgeOwner } from "./event-bridge.ts";
import { createHash } from "node:crypto";
import { policyOf } from "./activation.ts";
import { credentialActive } from "./registry.ts";
import { partyAddress, checkedType, type Stored } from "./model.ts";
import { messageActivationClaim } from "./source-preparation.ts";
import {
  parseEventMessageConsumer,
  parseEventMessagePreparationInput,
  type EventMessagePreparationInputV1,
  type EventMessagePreparationResultV1,
  type EventMessagePublicationV1,
} from "./event-authority-contract.ts";
import { parseMessageRouteControlInput } from "./message-route-control-contract.ts";

const MAX_ROWS = 128,
  MAX_BYTES = 65_536;
const bytes = (value: string) => new TextEncoder().encode(value).byteLength;
const hashSync = (value: string): string => createHash("sha256").update(value).digest("hex");
export const messagePreparationSnapshotDigest = (snapshot: string): string => hashSync(JSON.stringify(["message-preparation-v1", snapshot]));
export const messagePreparationPolicyFingerprint = (policy: string): string => hashSync(JSON.stringify(["message-policy-v1", policy]));
export const messagePreparationSourceStateVersion = (publication: EventMessagePublicationV1): string =>
  `msg:${hashSync(JSON.stringify(["message-source-v1", publication]))}`;
const exact = (v: unknown, keys: string[]): v is Record<string, unknown> =>
  v !== null &&
  typeof v === "object" &&
  !Array.isArray(v) &&
  Object.keys(v).length === keys.length &&
  keys.every((k) => Object.hasOwn(v, k));
async function hash(value: string): Promise<string> {
  return Array.from(
    new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value))),
    (b) => b.toString(16).padStart(2, "0"),
  ).join("");
}

/** One synchronous canonical read shared by preparation and the reservation-time recheck. */
export function readMessagePreparationSnapshot(
  sql: SqlStorage,
  owner: BridgeOwner,
  wanted: EventMessagePublicationV1,
  now: () => number = Date.now,
) {
  if (owner.namespace !== wanted.namespace || owner.principal !== wanted.principal) return null;
  const at = now();
  if (!owner.admitted(owner.principal)) return null;
  // Bound content before parsing, and grant rows before canonical eligibility's grant evaluation.
  const row = sql
    .exec<{ row: string; status: string; expires_at: number | null }>(
      "SELECT row,status,expires_at FROM messages WHERE box='in' AND id=? AND length(CAST(row AS BLOB))<=?",
      wanted.messageId,
      MAX_BYTES,
    )
    .toArray()[0];
  if (!row) return null;
  const message = JSON.parse(row.row) as Stored,
    sender = partyAddress(message.sender);
  const local = sender.principal === owner.principal;
  const grantWhere = "WHERE direction=? AND agent=? AND peer_principal=? AND peer_agent=?";
  const grantBindings = [
    local ? "out" : "in",
    local ? sender.agent : wanted.agent,
    local ? owner.principal : sender.principal,
    local ? wanted.agent : sender.agent,
    MAX_ROWS + 1,
  ];
  const grantSizes =
    message.kind === "reply"
      ? []
      : sql
          .exec<{ size: number }>(
            `SELECT length(CAST(id AS BLOB))+coalesce(length(CAST(task_types AS BLOB)),0)+512 AS size FROM grants
     ${grantWhere} LIMIT ?`,
            ...grantBindings,
          )
          .toArray();
  if (grantSizes.length > MAX_ROWS || grantSizes.reduce((n, row) => n + row.size, 0) > MAX_BYTES)
    return null;
  const grants =
    message.kind === "reply"
      ? []
      : sql
          .exec(
            `SELECT * FROM grants ${grantWhere} ORDER BY id LIMIT ?`,
            ...grantBindings,
          )
          .toArray();
  if (grants.length > MAX_ROWS || bytes(JSON.stringify(grants)) > MAX_BYTES) return null;
  const policySize = sql
    .exec<{ size: number }>(
      "SELECT coalesce(length(CAST(activation_senders AS BLOB)),0)+coalesce(length(CAST(activation_transports AS BLOB)),0) AS size FROM agents WHERE name=?",
      wanted.agent,
    )
    .one().size;
  if (policySize > MAX_BYTES) return null;
  const activation = canonicalMessageActivation(
    sql,
    owner,
    wanted.agent,
    wanted.messageId,
    at,
  );
  if (activation === null || JSON.stringify(activation.publication) !== JSON.stringify(wanted)) return null;
  const { publication, verdict } = activation;
  const incarnation = sql
    .exec<{ created_at: number }>("SELECT created_at FROM agents WHERE name=?", wanted.agent)
    .one().created_at;
  if (
    !sql
      .exec(
        "SELECT 1 FROM message_wake_routes WHERE agent=? AND length(CAST(consumer AS BLOB))<=4096",
        wanted.agent,
      )
      .toArray().length
  )
    return null;
  const route = messageRoute(sql, wanted.agent),
    consumer = parseEventMessageConsumer(route.consumer);
  if (
    route.owner !== "event" ||
    !Number.isSafeInteger(route.generation) ||
    route.generation < 1 ||
    !consumer ||
    consumer.consumerGeneration !== consumer.attachmentGeneration
  )
    return null;
  const operations = sql
    .exec<{ operation_id: string; request_json: string; result_json: string }>(
      `SELECT operation_id,request_json,result_json FROM message_route_operations WHERE agent=? AND agent_created_at=?
     AND length(CAST(request_json AS BLOB))+length(CAST(result_json AS BLOB))<=8192
     AND json_extract(result_json,'$.route.generation')=? LIMIT 2`,
      wanted.agent,
      incarnation,
      route.generation,
    )
    .toArray();
  if (operations.length !== 1 || bytes(JSON.stringify(operations)) > 8192) return null;
  const request: unknown = JSON.parse(operations[0]!.request_json),
    result: unknown = JSON.parse(operations[0]!.result_json);
  const requestKeys = ["operationId", "namespace", "principal", "agent", "agentCreatedAt", "expectedGeneration", "owner", "consumer", "keyThumbprint"];
  const stockRequestKeys = [...requestKeys, "runtimeProfile"];
  if (!exact(request, requestKeys) && !exact(request, stockRequestKeys)) return null;
  const requestRecord = request as Record<string, unknown>;
  const parsedRequest = parseMessageRouteControlInput({ agent: wanted.agent, request: { operation: "transfer", operationId: requestRecord.operationId,
    agentCreatedAt: requestRecord.agentCreatedAt, expectedGeneration: requestRecord.expectedGeneration, owner: requestRecord.owner,
    consumer: requestRecord.consumer, keyThumbprint: requestRecord.keyThumbprint,
    ...(Object.hasOwn(requestRecord, "runtimeProfile") ? { runtimeProfile: requestRecord.runtimeProfile } : {}) } });
  if (!parsedRequest || parsedRequest.request.operation !== "transfer") return null;
  const runtimeProfile = parsedRequest.request.runtimeProfile;
  if (
    !exact(result, runtimeProfile ? ["previous", "route", "runtimeProfile"] : ["previous", "route"]) ||
    !exact(result.previous, ["owner", "generation", "consumer"]) ||
    !["os", "event"].includes(result.previous.owner as string) ||
    result.previous.generation !== route.generation - 1 ||
    (result.previous.owner === "os"
      ? result.previous.consumer !== null
      : !parseEventMessageConsumer(result.previous.consumer)) ||
    JSON.stringify(result.route) !== JSON.stringify(route) ||
    (runtimeProfile && JSON.stringify(result.runtimeProfile) !== JSON.stringify(runtimeProfile)) ||
    requestRecord.namespace !== owner.namespace ||
    requestRecord.principal !== owner.principal ||
    requestRecord.agent !== wanted.agent ||
    requestRecord.agentCreatedAt !== incarnation ||
    requestRecord.owner !== "event" ||
    requestRecord.expectedGeneration !== route.generation - 1 ||
    JSON.stringify(requestRecord.consumer) !== JSON.stringify(consumer) ||
    requestRecord.operationId !== operations[0]!.operation_id ||
    typeof requestRecord.operationId !== "string" ||
    !/^[A-Za-z0-9_-]{1,128}$/.test(requestRecord.operationId) ||
    typeof requestRecord.keyThumbprint !== "string" ||
    !/^[A-Za-z0-9_-]{43}$/.test(requestRecord.keyThumbprint) ||
    !credentialActive(sql, wanted.agent, requestRecord.keyThumbprint)
  )
    return null;
  const key = sql
    .exec(
      "SELECT thumbprint,agent,x,created_at,state FROM agent_keys WHERE thumbprint=? AND agent=? AND length(CAST(x AS BLOB))<=4096",
      requestRecord.keyThumbprint,
      wanted.agent,
    )
    .one();
  if (bytes(JSON.stringify(key)) > 4096) return null;
  const policy = JSON.stringify(policyOf(sql, wanted.agent));
  const source = {
    status: row.status,
    expiresAt: row.expires_at,
    sender: message.sender,
    recipient: message.recipient,
    flags: message.flags,
    kind: message.kind,
    expires: message.expiresAt,
    type: checkedType(message),
  };
  const snapshot = JSON.stringify({
    publication,
    verdict,
    incarnation,
    policy,
    source,
    grants,
    route,
    key,
    receipt: operations[0],
  });
  if (bytes(snapshot) > MAX_BYTES * 2) return null;
  return {
    publication,
    incarnation,
    route: { generation: route.generation, consumer },
    keyThumbprint: requestRecord.keyThumbprint,
    key: JSON.stringify(key),
    policy,
    verdict,
    snapshot,
  };
}

/** Rebuilds the message claim synchronously from the same canonical read used by preparation. */
export function currentMessageActivationClaim(
  sql: SqlStorage,
  owner: BridgeOwner,
  publication: EventMessagePublicationV1,
  now: () => number = Date.now,
) {
  const snapshot = readMessagePreparationSnapshot(sql, owner, publication, now);
  if (!snapshot) return null;
  const policyFingerprint = messagePreparationPolicyFingerprint(snapshot.policy);
  const snapshotDigest = messagePreparationSnapshotDigest(snapshot.snapshot);
  const sourceStateVersion = messagePreparationSourceStateVersion(publication);
  return messageActivationClaim({ publication, sourceStateVersion, agentIncarnation: snapshot.incarnation,
    routeGeneration: snapshot.route.generation, consumer: snapshot.route.consumer, policyFingerprint, snapshotDigest, verdict: snapshot.verdict });
}

/** Canonical reads only. No budget, route, source, or coordinator mutation is permitted here. */
export async function readMessagePreparation(
  sql: SqlStorage,
  owner: BridgeOwner,
  input: EventMessagePreparationInputV1,
  now: () => number = Date.now,
): Promise<EventMessagePreparationResultV1> {
  const parsed = parseEventMessagePreparationInput(input);
  if (!parsed) return { status: "invalid" };
  const wanted = parsed.publication;
  if (owner.namespace !== wanted.namespace || owner.principal !== wanted.principal)
    return { status: "denied" };
  const read = () => readMessagePreparationSnapshot(sql, owner, wanted, now);
  try {
    const before = read();
    if (!before) return { status: "denied" };
    const [sourceHash, policyFingerprint, keyFingerprint, snapshotDigest] = await Promise.all([
      hash(JSON.stringify(["message-source-v1", before.publication])),
      hash(JSON.stringify(["message-policy-v1", before.policy])),
      hash(JSON.stringify(["message-key-v1", before.key])),
      hash(JSON.stringify(["message-preparation-v1", before.snapshot])),
    ]);
    const after = read();
    if (!after || after.snapshot !== before.snapshot) return { status: "changed" };
    if (parsed.expectedSnapshot !== undefined && parsed.expectedSnapshot !== snapshotDigest)
      return { status: "changed" };
    const activation = messageActivationClaim({ publication: before.publication, sourceStateVersion: `msg:${sourceHash}`, agentIncarnation: before.incarnation,
      routeGeneration: before.route.generation, consumer: before.route.consumer, policyFingerprint, snapshotDigest, verdict: before.verdict });
    if (!activation) return { status: "denied" };
    return {
      status: "eligible",
      publication: before.publication,
      canonicalSubject: {
        kind: "message",
        namespace: owner.namespace,
        messageId: wanted.messageId,
        agentIncarnation: before.incarnation,
      },
      sourceStateVersion: `msg:${sourceHash}`,
      policyFingerprint,
      route: before.route,
      keyThumbprint: before.keyThumbprint,
      keyFingerprint,
      snapshotDigest,
      checkedAt: new Date(now()).toISOString(),
      activation,
    };
  } catch {
    return { status: "unavailable" };
  }
}
