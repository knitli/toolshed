import { z } from 'zod';
import { parseEventMessageConsumer, type EventMessageConsumerV1 } from 'gatekeeper-messaging/src/event-authority-contract';
import { agent, generation, uuid } from '../contracts';
import { requireNativeAdmissionCanary } from '../native-admission-gate';
import { requireAssignedStockProfile } from '../native-admission-gate';
import { NativeRuntimeBindingSchema } from '../native-admission-contract';
import { AssignedStockRuntimeBindingSchema } from '../assigned-stock-contract';
import { AssignedStockRuntimeProfileSchema } from '../protocol';
import type { NativeRuntimeStore } from '../native-runtime-store';
import { EVENT_POLICY_V1 } from '../policy';
import { withDeadline } from '../request-deadline';

const consumer = z.unknown().transform((value, context) => {
  const parsed = parseEventMessageConsumer(value);
  if (parsed) return parsed;
  context.addIssue({ code: 'custom', message: 'invalid message consumer' });
  return z.NEVER;
});
export const MessageConsumerQuerySchema = z.strictObject({
  principal: z.email().max(254).refine(value => value === value.toLowerCase()),
  agent,
  keyThumbprint: z.string().regex(/^[A-Za-z0-9_-]{43}$/),
  consumer,
  runtimeProfile: AssignedStockRuntimeProfileSchema.optional(),
});
export const MessageConsumerSnapshotSchema = z.union([
  z.strictObject({ status: z.literal('current'), consumer,
    leaseUntil: z.iso.datetime({ precision: 3 }), checkedAt: z.iso.datetime({ precision: 3 }) })
    .refine(value => Date.parse(value.leaseUntil) > Date.parse(value.checkedAt)),
  z.strictObject({ status: z.enum(['denied', 'invalid', 'unavailable']) }),
]);
export type MessageConsumerSnapshot = z.infer<typeof MessageConsumerSnapshotSchema>;

// Validate the authority-bearing subset; the existing registry also returns public
// transport metadata, which this query neither trusts nor exposes.
const registryResult = z.union([
  z.strictObject({ status: z.literal('authorized'), node: z.object({
    nodeId: uuid, generation, revoked: z.boolean(), agents: z.array(agent).max(128),
  }).passthrough() }),
  z.strictObject({ status: z.enum(['denied', 'invalid']) }),
]);
export type MessageConsumerRegistry = {
  currentAdmissionNode(input: { nodeId: string; agent: string; generation: number }): Promise<unknown>;
};

type Identity = Readonly<{ principal: string; agent: string }>;
/** A point-in-time query only: no consent, reservation, renewable token or wake permission. */
export async function verifyMessageConsumerSnapshot(
  store: NativeRuntimeStore, identity: Identity, input: unknown,
  environment: Parameters<typeof requireNativeAdmissionCanary>[0], registry: () => MessageConsumerRegistry,
): Promise<MessageConsumerSnapshot> {
  const parsed = MessageConsumerQuerySchema.safeParse(input);
  if (!parsed.success) return { status: 'invalid' };
  const query = parsed.data;
  if (query.principal !== identity.principal || query.agent !== identity.agent) return { status: 'denied' };
  const profileGateOpen = (): boolean => {
    try {
      if (query.runtimeProfile) requireAssignedStockProfile(environment, identity);
      else requireNativeAdmissionCanary(environment, identity);
      return true;
    }
    catch { return false; }
  };
  if (!profileGateOpen()) return { status: 'denied' };
  const selected = query.consumer;
  if (selected.consumerGeneration !== selected.attachmentGeneration) return { status: 'denied' };

  const snapshot = (now: number): { fingerprint: string; leaseUntil: number } | null => {
    const runtime = store.runtime(selected.runtimeId), binding = store.binding(selected.runtimeId);
    const stock = query.runtimeProfile ? store.assignedStockBinding(selected.runtimeId) : null;
    if (!runtime || (query.runtimeProfile
      ? !stock || stock.row.key_thumbprint !== query.keyThumbprint || runtime.qualified !== 0
        || JSON.stringify(stock.binding) !== JSON.stringify(query.runtimeProfile)
      : !binding || binding.key_thumbprint !== query.keyThumbprint || runtime.qualified !== 1)) return null;
    if (!Number.isSafeInteger(runtime.lease_until) || runtime.lease_until <= now) return null;
    if (runtime.runtime_id !== selected.runtimeId || runtime.node_id !== selected.nodeId
      || runtime.node_generation !== selected.nodeGeneration || runtime.runtime_generation !== selected.runtimeGeneration
      || runtime.attachment_generation !== selected.attachmentGeneration) return null;
    if (!query.runtimeProfile) {
      const native = NativeRuntimeBindingSchema.parse(JSON.parse(binding!.binding_json));
      if (binding!.runtime_id !== selected.runtimeId || binding!.client_id !== native.clientId
        || !Number.isSafeInteger(binding!.nonce) || binding!.nonce < 0
        || !Number.isSafeInteger(binding!.sequence) || binding!.sequence < 1) throw new Error('invalid native binding');
    } else if (AssignedStockRuntimeBindingSchema.safeParse(stock?.binding).success !== true) throw new Error('invalid assigned stock binding');
    // A replacement, renewal or key rotation during registry I/O invalidates this
    // observation. Re-querying may observe the new lease, but cannot refresh this one.
    return { fingerprint: JSON.stringify([runtime, binding, stock?.row ?? null]), leaseUntil: runtime.lease_until };
  };
  try {
    const before = snapshot(Date.now());
    if (!before) return { status: 'denied' };
    const response = await withDeadline(registry().currentAdmissionNode({
      nodeId: selected.nodeId, agent: identity.agent, generation: selected.nodeGeneration,
    }), EVENT_POLICY_V1.nativeRpcDeadlineMs);
    if (!profileGateOpen()) return { status: 'denied' };
    const checkedAt = Date.now();
    const after = snapshot(checkedAt);
    if (!after || after.fingerprint !== before.fingerprint) return { status: 'denied' };
    const result = registryResult.safeParse(response);
    if (!result.success) return { status: 'unavailable' };
    if (result.data.status !== 'authorized' || result.data.node.revoked
      || result.data.node.nodeId !== selected.nodeId || result.data.node.generation !== selected.nodeGeneration
      || !result.data.node.agents.includes(identity.agent)) return { status: 'denied' };
    return MessageConsumerSnapshotSchema.parse({ status: 'current', consumer: selected satisfies EventMessageConsumerV1,
      leaseUntil: new Date(after.leaseUntil).toISOString(), checkedAt: new Date(checkedAt).toISOString() });
  } catch {
    return { status: 'unavailable' };
  }
}
