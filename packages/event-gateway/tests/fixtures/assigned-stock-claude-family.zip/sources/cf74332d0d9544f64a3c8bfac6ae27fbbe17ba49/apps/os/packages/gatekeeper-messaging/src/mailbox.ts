import { readMessagePreparation } from "./message-preparation.ts";
import { parseEventMessagePreparationInput, type EventMessagePreparationInputV1, type EventMessagePreparationResultV1 } from "./event-authority-contract.ts";
import type { AccessPorts } from "openapi-operator/src/access.ts";
import { MessageRouteOwnerProofVerifier } from "./message-route-owner-proof.ts";
import { controlMessageRoute, type MessageRouteControlEnvironment } from "./message-route-control.ts";
// The broker (spec "Broker invariants"): one SQLite Durable Object per (namespace, principal),
// holding that principal's inbox and outbox rows (each an agent's, or the default inbox's), their
// idempotency keys, and the principal's agent registry and grants (registry.ts). It is the only signer:
// issue() writes the outbox row and signs its receipt exactly once per message id, and deliver()
// stores that same receipt in the recipient's inbox, idempotently. A crash between the two is
// completed by the host replaying the action, and never yields a second receipt. Reached only by
// this Worker's gatekeeper facet; it has no fetch handler and trusts its caller for authorization.

import { ProtocolError } from "@modelcontextprotocol/server";
import { DurableObject } from "cloudflare:workers";
import type { HookInitiator } from "@gadgets/workshop-shared/gatekeeper";
import {
  LIMITS, NO_FLAGS, OAUTH_LEASE_MS, statusAt, addressOf, agentAddressOf, checkedType, agentName, codeOf, audienceId, beforeOf, bindingChanged, cancelled, fail, keyChanged, intersect, mailboxName, messageBytes, noGrant, notInAudience, orFlags, partyAddress, restrictedTaint, sameAddress, suspended, tooDeep, truncate, viewOf, wireOf, notRetriable, messageIdOf,
  type AgentCredential, type Code, type OAuthBinding, type Address, type Applied, type Flags, type Kind, type Stored,
} from "./model.ts";
import { principalAllowed } from "gatekeeper-memory/src/principals.ts";
import { printTerm, type Term } from "authority/src/scope.ts";
import type { TaskDeclaration } from "authority/src/task.ts";
import type { MessagingHookTarget } from "./hooks.ts";
import { publicJwk } from "./agent-token.ts";
import { keyRing, receiptPayload, signReceipt, type Verdict } from "./receipts.ts";
import { verifyChainOnline } from "./order-verify.ts";
import * as origin from "./origin.ts";
import * as registry from "./registry.ts";
import type { Agent, AgentKind, Grant, GrantMode } from "./registry.ts";
import type { Message, MessageParty, MessageStatus } from "./types.js";
import { EVENTS_SCHEMA, claimDeliveryAttempt as claimAttempt, drainEvents, eventsEnabled, eventStatus, hasEventSubscribers, prepareSubscription, queueEvents, recordDeliveryAttempt as recordAttempt, recordPoisonAttempt as recordPoison, removeEvents, resumeEvents, saveSubscription, scheduleNextAlarm, unsubscribe, type EventOwner, type RelayResult, type SignedDelivery, type SubscriptionInput } from "./events.ts";
import { EVENT_ATTEMPT_RETENTION_MS, eventAttemptStatus, reserveEventAttempt, type EventWakeBudget, type StockWakeAttemptRecord } from "./event-wake-budget.ts";
import * as enrollment from "./enrollment-store.ts";
import * as keys from "./keys.ts";
import { enrollAllowed } from "./auth.ts";
import type { Gate } from "./stepup.ts";
import type { StartingGrant } from "./enrollment-store.ts";
import { AUTHORITY_LOG_SCHEMA, appendLog, logPage, verifyLog } from "./authority-log.ts";
import { REFUSALS_SCHEMA, listRefusals, migrateRefusals, recordRefusal } from "./refusals.ts";
import { refusalOf, type RecipientFacts, type Refusal, type SenderFacts } from "./explain.ts";
import { projectGrant } from "./project.ts";
import * as activation from "./activation.ts";
import * as orders from "./orders.ts";
import { draftStillMay } from "./order-acts.ts";
import * as scopes from "./scopes.ts";
import * as tasks from "./tasks.ts";
import type { AgentDescription, AuthorityLogView, WakeInventoryRow } from "./admin-types.ts";
import type { ActivationClaimV1, ActivationSourceV1, EventAttemptReservationResultV1, EventAttemptStatusResultV1, EventMessageAttemptResultV1, EventMessageClaimV1, EventMessageCommandSettlementV1, EventMessageCommandSettlementReadV1, EventMessageCommandSettlementReadResultV1, EventMessageCommandSettlementResultV1, EventMessagePublicationV1, EventMessagePublicationResultV1, StockWakeReservationResultV1, StockWakeSettlementResultV1 } from "./event-authority-contract.ts";
import type { ReportRunInputV1, RunOriginInputV1, VerifyOriginInputV1 } from "./authority-contract.ts";
import { parseEventMessageClaim, parseEventMessagePublication, parseEventSourceActivationInputV1, parseStockWakeClaimV1 } from "./event-authority-contract.ts";
import { PRESENCE_SCHEMA } from "./credentials.ts";
import * as presence from "./presence-host.ts";
import { authorityFlags, presenceConfig, presenceVarsOf, type Mode } from "./presence.ts";
import { queueNotice, sessionNotice, nextRetry, noticeConfig } from "./notify.ts";
import { drainMessagePublications, messagePublisherAgent, messagePublisherEnabled, scheduleMessagePublications, type MessagePublisherVars } from "./message-publisher.ts";
import { BRIDGE_SCHEMA, MESSAGE_ATTEMPT_CAPACITY, canonicalMessagePublication, messageRoute, migrateMessageSources, stageMessageEvent, type MessageRoutingAuthority } from "./event-bridge.ts";
import { createMessageConsumerAdmission } from "./message-consumer-admission.ts";
import { MESSAGE_SETTLEMENT_BYTE_CAPACITY, MESSAGE_SETTLEMENT_CAPACITY } from "./message-attempt-settlement.ts";
import { prepareSourceActivation, sameActivationSnapshot } from "./source-preparation.ts";
import { currentMessageActivationClaim } from "./message-preparation.ts";

/** Plain values preserve protocol fields across Durable Object RPC error serialization. */
export type SubscriptionResult =
  | { ok: true; result: ReturnType<typeof saveSubscription> }
  | { ok: false; error: { code: -32601 | -32602 | -32001; message: string } }
  | { ok: false; error: { code: -32015; message: string; data: { reason: "timeout" | "endpoint_error" | "challenge_failed" } } };

export type Box = "in" | "out";
/** `storedAt`: when this Mailbox stored the row; for an inbox row, when it was delivered. */
/** `cursor`: where a listing continues after this row (list()'s `before`), in its newest-first order. */
/** `reason`: on an out row, why its recipient refused it (undeliverable()), else null. */
export type Found = { message: Stored; status: string; storedAt: string; cursor: string; reason: string | null };
export type IssueInput = {
  id: string;
  kind: Kind;
  parentId: string | null;
  sender: MessageParty;
  /** "principal" or "principal/agent" (the wire form). */
  recipient: string;
  subject: string;
  body: string;
  taskType: string | null;
  expiresAt: string | null;
  idempotencyKey: string | null;
  requestDigest: string;
  /** The sending workspace's attested audience, sorted. */
  attested: string[];
  attestedFlags: Flags;
  /** Nothing issues "send-self" (v1 only) or "mcp-granted" (bearer keys, retired) any more; old receipts and stored rows still carry them. */
  applied: Exclude<Applied, "send-self" | "mcp-granted" | "human-ordered">;
  /**
   * For an OS send: the attested workspace that sender.agent (or its absence) was resolved from. issue()
   * refuses unless the registry still binds it to that agent, or to none, when the outbox row is written
   * and on every replay. MCP sends have no workspace, so nothing to check.
   */
  workspace?: string;
  /**
   * For an MCP send: the registered key or leased OAuth binding the caller signed in with. issue()
   * refuses unless it still resolves to the sending agent when the outbox row is written, and on every replay.
   */
  credential?: AgentCredential;
};

/**
 * An agent's wake (spec "Storage"), in the Mailbox's kv under wakeKey(agent): the host's initiator (a
 * Fetcher, which structured-clones into kv but not into SQL), the attested workspace it was enabled for,
 * and the host's display target. `nonce` is minted by each setHook(): turning a hook off and on reuses
 * its hookId, so only the nonce tells a firing's hook from the one enabled since (absent on a hook stored
 * before it existed).
 */
export type WakeHook = {
  hookId: string;
  nonce?: string;
  initiator: Fetcher<HookInitiator<MessagingHookTarget>>;
  workspace: string;
  target: string;
};
/**
 * An agent's wake budget (spec "The wake budget"), under its own key so that it outlives the hook:
 * turning the hook off and on, or another chat's hook replacing it, does not start a fresh hour.
 */
export type WakeBudget = EventWakeBudget & { pendingToken?: string | null };
const wakeKey = (agent: string): string => `wake:${agent}`;
const budgetKey = (agent: string): string => `wake-budget:${agent}`;
const STOCK_WAKE_ATTEMPT_CAPACITY = LIMITS.wake.perHour * (EVENT_ATTEMPT_RETENTION_MS / LIMITS.wake.windowMs);
/** An agent's last wake outcome, kept after its hook is dropped so the owner can see why wakes stopped. */
export type WakeStatus = { outcome: WakeOutcome; at: number };
/** What wakeStatus() reports per agent. */
export type WakeState = { enabled: boolean; last: WakeStatus | null };
const statusKey = (agent: string): string => `wake-status:${agent}`;
export type WakeOutcome = "none" | "not_allowed" | "unbound" | "suspended" | "pending" | "over_budget" | "woken" | "failed";
/** What a send says of the wake it started, to a sender of the same person: only what the gates already decided (`not_ordered` and `off` arrive with enforcement, P5b). */
export type SendWake = "woken" | "pending" | "over_budget";

type Row = { row: string; status: string; expires_at: number | null; created_at: number; rowid: number; reason: string | null };

const SCHEMA = `
CREATE TABLE IF NOT EXISTS messages (
  box TEXT NOT NULL CHECK (box IN ('in', 'out')),
  id TEXT NOT NULL,
  row TEXT NOT NULL,
  counterpart TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER,
  status TEXT NOT NULL,
  PRIMARY KEY (box, id)
);
CREATE INDEX IF NOT EXISTS messages_by_box ON messages (box, created_at);
CREATE TABLE IF NOT EXISTS idempotency (
  key TEXT PRIMARY KEY,
  digest TEXT NOT NULL,
  message_id TEXT NOT NULL,
  created_at INTEGER NOT NULL
);`;

/** An idempotency key's slot: per agent, and the raw key for a person-level sender (so MVP reservations still match). */
const slot = (agent: string | null, key: string): string => (agent === null ? key : JSON.stringify([agent, key]));

/**
 * Adds the agent column to a Mailbox made before agents (spec "Migration"): its rows read NULL, the
 * person's default inbox. Then the undelivered reason and the thread id (budgets spec), and the agents'
 * suspension flag (#596). Then grants' task types (#597): rows from before read NULL, any type. Then clears every
 * bearer key hash: bearer keys are retired, so none may authorize anything again. That needs the registry
 * tables, so it makes them first: a Mailbox from before agents has none. Idempotent; runs on every construction.
 */
export function migrate(sql: SqlStorage): void {
  sql.exec(registry.REGISTRY_SCHEMA);
  const columns = new Set(sql.exec<{ name: string }>("PRAGMA table_info(messages)").toArray().map((column) => column.name));
  if (!columns.has("agent")) sql.exec("ALTER TABLE messages ADD COLUMN agent TEXT");
  // Why a message went undelivered, on an out row (spec "Failed messages").
  if (!columns.has("reason")) sql.exec("ALTER TABLE messages ADD COLUMN reason TEXT");
  if (!columns.has("thread_id")) {
    // The thread budget counts by thread; rows from before it get theirs from the stored message, once.
    sql.exec("ALTER TABLE messages ADD COLUMN thread_id TEXT");
    sql.exec("UPDATE messages SET thread_id = json_extract(row, '$.threadId')");
  }
  // The owner's suspension flag (#596): agents from before it read NULL, not suspended.
  if (!sql.exec<{ name: string }>("PRAGMA table_info(agents)").toArray().some((column) => column.name === "suspended_at"))
    sql.exec("ALTER TABLE agents ADD COLUMN suspended_at INTEGER");
  if (!sql.exec<{ name: string }>("PRAGMA table_info(grants)").toArray().some((column) => column.name === "task_types"))
    sql.exec("ALTER TABLE grants ADD COLUMN task_types TEXT");
  // R4 P5c-b (F5): a signed grant may carry the right to wake the receiving agent. Only a grant act sets it; every grant that exists reads 0.
  if (!sql.exec<{ name: string }>("PRAGMA table_info(grants)").toArray().some((column) => column.name === "wake"))
    sql.exec("ALTER TABLE grants ADD COLUMN wake INTEGER NOT NULL DEFAULT 0 CHECK (wake IN (0, 1))");
  sql.exec("CREATE INDEX IF NOT EXISTS messages_by_agent ON messages (box, agent, created_at)");
  sql.exec("CREATE INDEX IF NOT EXISTS messages_by_thread ON messages (thread_id)");
  // ponytail: the agents.key_hash column stays, always NULL now; drop it in a later schema cleanup.
  sql.exec("UPDATE agents SET key_hash = NULL WHERE key_hash IS NOT NULL");
  // Agent enrollments (R4 P2b): their tables, and agent_keys' label and last_seen.
  enrollment.migrateEnrollments(sql);
  // R4 P5c-a: the state of each key (provisional or active). Every key that exists reads active.
  keys.migrateKeys(sql);
  // R4 P3b: the refusals ring and the authority log. Additive, and here so that whatever deletes an agent can clear its ring.
  sql.exec(REFUSALS_SCHEMA);
  migrateRefusals(sql);
  sql.exec(AUTHORITY_LOG_SCHEMA);
  // R4 P4a: scope rows, declared tasks, the activation policy and the restricted-read taint. Additive; rows from before read as they did.
  sql.exec(scopes.SCOPES_SCHEMA);
  sql.exec(tasks.TASKS_SCHEMA);
  const agentColumns = new Set(sql.exec<{ name: string }>("PRAGMA table_info(agents)").toArray().map((column) => column.name));
  // Every agent that exists now keeps waking as it did (plan 5.5): `granted`, marked legacy. A new agent is inserted `order-only` (registry.registerAgent).
  // Each column is guarded on its own, so a run cut off between the two ALTERs finishes on the next one. The legacy mark is the column's DEFAULT,
  // set in the same statement that adds it, so no UPDATE is left to interrupt; registerAgent writes 0 for a new agent.
  if (!agentColumns.has("activation_mode"))
    sql.exec("ALTER TABLE agents ADD COLUMN activation_mode TEXT NOT NULL DEFAULT 'granted' CHECK (activation_mode IN ('order-only', 'granted', 'off'))");
  if (!agentColumns.has("activation_legacy")) sql.exec("ALTER TABLE agents ADD COLUMN activation_legacy INTEGER NOT NULL DEFAULT 1");
  for (const column of ["activation_senders TEXT", "activation_transports TEXT", "restricted_until INTEGER"])
    if (!agentColumns.has(column.split(" ")[0]!)) sql.exec(`ALTER TABLE agents ADD COLUMN ${column}`);
  // R4 P5a-2: the credential registry, the act host, liveness, enforcement latches and the notice outbox. New tables only, each CREATE IF NOT EXISTS: a live Mailbox gains them empty.
  sql.exec(PRESENCE_SCHEMA);
  // R4 P5b: the orders a signed act issued. A new table: a live Mailbox gains it empty.
  sql.exec(orders.ORDERS_SCHEMA);
  // A column added to a presence table after it first shipped: guarded, because CREATE IF NOT EXISTS leaves an existing table as it is (credentials.ts).
  if (!sql.exec<{ name: string }>("PRAGMA table_info(human_credentials)").toArray().some((column) => column.name === "window_until"))
    sql.exec("ALTER TABLE human_credentials ADD COLUMN window_until INTEGER");
  if (!sql.exec<{ name: string }>("PRAGMA table_info(pin_epoch)").toArray().some((column) => column.name === "pins"))
    sql.exec("ALTER TABLE pin_epoch ADD COLUMN pins TEXT");
  if (!sql.exec<{ name: string }>("PRAGMA table_info(notices)").toArray().some((column) => column.name === "credential_thumbprint"))
    sql.exec("ALTER TABLE notices ADD COLUMN credential_thumbprint TEXT");
}

/**
 * Refuses a new message from `agent` (null: the default inbox's sends) to `to` (wire form) in
 * `threadId` (null: a new request) past any budget (spec "Budgets"). Synchronous, so issue() runs it in
 * the transaction that writes the outbox row. The outbox rows are the counter.
 */
export function assertBudget(sql: SqlStorage, agent: string | null, to: string, threadId: string | null, now: number): void {
  const { agentPerHour, pairPerHour, thread, windowMs } = LIMITS.budget;
  const since = now - windowMs;
  const who = agent === null ? "this sender" : "this agent";
  const count = (query: string, ...args: SqlStorageValue[]): number => sql.exec<{ n: number }>(query, ...args).one().n;
  if (count("SELECT count(*) AS n FROM messages WHERE box = 'out' AND agent IS ? AND created_at > ?", agent, since) >= agentPerHour)
    throw fail("over_budget", `${who} sent ${agentPerHour} messages in the last hour, its limit; try again later`);
  if (count("SELECT count(*) AS n FROM messages WHERE box = 'out' AND agent IS ? AND counterpart = ? AND created_at > ?", agent, to, since) >= pairPerHour)
    throw fail("over_budget", `${who} sent ${pairPerHour} messages to ${to} in the last hour, its limit for one recipient; try again later`);
  if (threadId !== null && count("SELECT count(DISTINCT id) AS n FROM messages WHERE thread_id = ?", threadId) >= thread)
    throw fail("over_budget", `this thread has ${thread} messages, its limit; start a new request instead`);
}

/**
 * A refusal a predicate Explain asks is expected to raise, as Explain reports it. An error with no code is a failure and no verdict: it
 * propagates, so the admin API answers `unavailable` and none of its words reach the page.
 */
function verdictOf(error: unknown): Refusal {
  const code = codeOf(error);
  if (code === undefined) throw error;
  return refusalOf(code, error);
}

/** Why a pasted JWK was refused (agent-token.ts publicJwk's reasons), as the owner reads it. */
const JWK_REFUSALS: Record<string, string> = {
  not_json: "a key is a public JWK, as agent-key.ts keygen prints it",
  not_ed25519: 'a key is an Ed25519 public JWK: kty "OKP", crv "Ed25519"',
  private: "that is a private key: keep it on the agent's machine, and since it was pasted here, generate a new one",
  bad_x: "that key's x is not a 32-byte Ed25519 public key in base64url",
};

/** Orders the Orders page lists (newest first). */
const ORDERS_LISTED = 50;
const COLUMNS = "row, status, expires_at, created_at, rowid, reason";
// Expiry is lazy (spec "Data model"): a row past its expiresAt reads as expired, whatever it stored.

const foundOf = (row: Row, now: number): Found => ({
  message: JSON.parse(row.row) as Stored,
  status: statusAt(row, now),
  storedAt: new Date(row.created_at).toISOString(),
  cursor: `${row.created_at}.${row.rowid}`,
  reason: row.reason,
});

/**
 * A tainted agent's MCP send carries `containsRestrictedData` in place of no flags (plan 9.5 item 2), so the flag machinery that already keeps a
 * restricted message from an MCP reader keeps this one too. Only an MCP send (a credential names it) is flagged here: an OS send carries its
 * workspace's attested flags, which the host latches.
 */
const taintedFlags = (flags: Flags, tainted: boolean): Flags => (tainted ? orFlags(flags, { ...NO_FLAGS, containsRestrictedData: true }) : flags);

export class Mailbox extends DurableObject<Env & MessagePublisherVars & MessageRouteControlEnvironment> {
  readonly #messageRoutingAuthority?: MessageRoutingAuthority;
  readonly #messageConsumerAdmission: ReturnType<typeof createMessageConsumerAdmission>;
  readonly #routeOwnerVerifier: MessageRouteOwnerProofVerifier;
  constructor(ctx: DurableObjectState, env: Env & MessagePublisherVars & MessageRouteControlEnvironment, messageRoutingAuthority?: MessageRoutingAuthority, ownerProofPorts?: AccessPorts) {
    super(ctx, env);
    this.#messageRoutingAuthority = messageRoutingAuthority;
    this.#messageConsumerAdmission = createMessageConsumerAdmission(ctx.storage, ctx.id.name, env);
    this.#routeOwnerVerifier = new MessageRouteOwnerProofVerifier(env, ownerProofPorts);
    ctx.storage.sql.exec(SCHEMA);
    migrate(ctx.storage.sql);
    ctx.storage.sql.exec(EVENTS_SCHEMA);
    ctx.storage.sql.exec(BRIDGE_SCHEMA);
    migrateMessageSources(ctx.storage.sql);
    ctx.storage.sql.exec(origin.ORIGIN_SCHEMA);
    if (messagePublisherEnabled(env)) {
      // Persist recovery for already-staged work before the first RPC or alarm.
      const [, principal] = JSON.parse(ctx.id.name ?? "[]") as [string?, string?];
      ctx.blockConcurrencyWhile(() => scheduleMessagePublications(ctx, env, principal ?? ""));
    }
  }

  messageRouteControl(call: unknown, input: unknown) {
    return controlMessageRoute(this.ctx.storage, this.ctx.id.name, this.env, this.#routeOwnerVerifier, call, input);
  }

  #eventOwner(agent: string, credential: AgentCredential): EventOwner {
    if (credential.kind !== "oauth") throw fail("forbidden", "Events require an OAuth connection");
    this.assertBound(agent, { credential });
    const [, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
    if (!principal || !principalAllowed(this.env, principal)) throw fail("forbidden", "this account is no longer allowed");
    return { principal, agent, profile: credential.profile, generation: credential.generation, expiresAt: credential.expiresAt };
  }
  async eventSubscribe(agent: string, credential: AgentCredential, input: SubscriptionInput): Promise<SubscriptionResult> {
    const owner = this.#eventOwner(agent, credential);
    try {
      const prepared = await prepareSubscription(this.ctx.storage.sql, this.env, owner, input);
      // Callback verification and encryption may interleave with owner revocation/rebinding.
      this.#eventOwner(agent, credential);
      return { ok: true, result: saveSubscription(this.ctx.storage.sql, prepared) };
    } catch (error) {
      if (error instanceof ProtocolError) {
        const { code, message } = error;
        if (code === -32601 || code === -32602 || code === -32001)
          return { ok: false, error: { code, message } };
        const reason = (error.data as { reason?: unknown } | undefined)?.reason;
        if (code === -32015 && (reason === "timeout" || reason === "endpoint_error" || reason === "challenge_failed"))
          return { ok: false, error: { code, message, data: { reason } } };
      }
      throw error;
    }
  }
  eventUnsubscribe(agent: string, credential: AgentCredential, url: string): void {
    const owner = this.#eventOwner(agent, credential);
    this.ctx.storage.transactionSync(() => unsubscribe(this.ctx.storage.sql, owner, url));
  }
  eventStatus() { return eventStatus(this.ctx.storage.sql); }
  async resumeEvents(id: string): Promise<void> {
    // Persist recovery before making terminally paused jobs eligible again.
    const due = Date.now() + 100, scheduled = await this.ctx.storage.getAlarm();
    if (scheduled === null || scheduled > due) await this.ctx.storage.setAlarm(due);
    const row = this.ctx.storage.sql.exec<{ agent: string; profile: string; generation: string; expires_at: number }>("SELECT agent,profile,generation,expires_at FROM event_subscriptions WHERE id=?", id).toArray()[0];
    if (row) this.#eventOwner(row.agent, { kind: "oauth", profile: row.profile, generation: row.generation, expiresAt: row.expires_at });
    resumeEvents(this.ctx.storage.sql, id);
  }
  removeEvents(id: string): void { this.ctx.storage.transactionSync(() => removeEvents(this.ctx.storage.sql, id)); }

  #eventAuthorized(owner: EventOwner, id: string): boolean {
    try {
      this.#eventOwner(owner.agent, { kind: "oauth", profile: owner.profile, generation: owner.generation, expiresAt: owner.expiresAt });
      const found = this.#get("in", id, Date.now());
      return !!found && found.message.recipient === `${owner.principal}/${owner.agent}` && found.status !== "expired" && found.status !== "cancelled" && !found.message.flags.containsRestrictedData && !found.message.flags.sharingProhibited;
    } catch { return false; }
  }

  async alarm(): Promise<void> {
    try {
      try {
        if (eventsEnabled(this.env)) await drainEvents(this.ctx, this.env, (owner, id) => this.#eventAuthorized(owner, id));
      } finally {
        await presence.flush(this.#presenceHost());
      }
    } finally {
      try {
        const [namespace, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
        await drainMessagePublications(this.ctx, this.env, {
          namespace: namespace ?? "", principal: principal ?? "",
          admitted: who => namespace === this.env.MESSAGING_NAMESPACE && principalAllowed(this.env, who),
          publicationAgent: messagePublisherAgent(this.env, principal ?? ""),
          live: this.#orderFacts().live,
        });
      } finally {
        await this.#rescheduleAlarm();
      }
    }
  }

  /** Every lane is re-armed even if another drain or scheduler throws. Earlier deadlines win. */
  async #rescheduleAlarm(): Promise<void> {
    try {
      if (eventsEnabled(this.env)) await scheduleNextAlarm(this.ctx);
    } finally {
      try {
        if (noticeConfig(this.env) !== null) {
          const next = nextRetry(this.ctx.storage.sql);
          if (next !== null) await this.#scheduleEarlier(Math.max(Date.now() + 100, next));
        }
      } finally {
        const [, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
        await scheduleMessagePublications(this.ctx, this.env, principal ?? "");
      }
    }
  }

  async #scheduleEarlier(at: number): Promise<void> {
    const scheduled = await this.ctx.storage.getAlarm();
    if (scheduled === null || scheduled > at) await this.ctx.storage.setAlarm(at);
  }

  /**
   * Queue consumer callbacks (see src/queue-delivery.ts). Claim re-resolves the job
   * and signs fresh; record applies the attempt outcome; poison consumes one attempt
   * for messages whose claim itself kept failing. Every record path reschedules the
   * alarm exactly as drain's tail would, so callbacks never strand a due row.
   */
  async claimDeliveryAttempt(subscriptionId: string, jobId: string, secretHash: string): Promise<{ ok: true; delivery: SignedDelivery; messageId: string } | { ok: false }> {
    return claimAttempt(this.ctx.storage.sql, this.env, (owner, id) => this.#eventAuthorized(owner, id), subscriptionId, jobId, secretHash);
  }
  async recordDeliveryAttempt(subscriptionId: string, jobId: string, messageId: string, secretHash: string, result: RelayResult | null): Promise<"resolved" | "dropped"> {
    const outcome = await recordAttempt(this.ctx.storage.sql, subscriptionId, jobId, messageId, secretHash, result);
    await scheduleNextAlarm(this.ctx);
    return outcome;
  }
  async recordPoisonAttempt(subscriptionId: string, jobId: string, secretHash: string): Promise<"resolved" | "dropped"> {
    const outcome = await recordPoison(this.ctx.storage.sql, subscriptionId, jobId, secretHash);
    await scheduleNextAlarm(this.ctx);
    return outcome;
  }

  /**
   * Whether issue() would answer `input` as a replay: post() then skips its early refusals, which would fail a delivered replay. `type` is the
   * stored row's, the one a forward was issued under: a replay's input carries none, and a refusal of it is noted under this.
   */
  replayOf(input: IssueInput): { type: string | null } | null {
    const replay = this.#replayed(input, Date.now());
    return replay ? { type: checkedType(replay) } : null;
  }
  async issue(input: IssueInput): Promise<Stored> {
    const now = Date.now();
    const sql = this.ctx.storage.sql;
    const from = partyAddress(input.sender);
    // A replay answers what was stored, before the new message's own checks (spec "Agents only"). A
    // message stored before #561 to a person's default inbox was sent under no grant: its replay is
    // answered without one, and deliver() then completes it only where its default-inbox row exists.
    const replay = this.#replayed(input, now);
    if (replay) {
      const stored = addressOf(replay.recipient, "recipient");
      const type = checkedType(replay); // the stored, signed row's, never the caller's (#597)
      const cover = (messageId: string, at: number): void => {
        // The stored row's kind, never the caller's: a replay claiming to be a reply skips nothing.
        if (stored.agent === null || replay.kind === "reply") return;
        if (from.agent === null) throw noGrant();
        if (!registry.coversReplay(sql, from.agent, stored, messageId, at, type))
          throw registry.grantRefusal(sql, from.agent, stored, messageId, at, type, { replay: true, forward: replay.kind === "forward" });
      };
      return this.#replay(replay, from.agent, input, now, cover);
    }
    // A reply may answer an order's root, whose sender is a person with no agent: it goes to that person's order view (plan 6.6), the one recipient
    // that is not an agent, and only when its parent is a human-ordered root (checked below, once the parent is read).
    const to: Address = input.kind === "reply" ? addressOf(input.recipient, "recipient") : agentAddressOf(input.recipient, "recipient");
    // The sender's binding, final and on every replay (#stillBound): a replay of a row already written
    // but not yet delivered is refused too, so the row stays undelivered: a binding change takes effect immediately.
    const stillBound = (): void => this.#stillBound(from.agent, input);
    // Agents only (#561): a person's default inbox neither sends nor receives new mail.
    if (from.agent === null) throw fail("forbidden", "only an agent sends Knitli messages; bind this workspace to one");
    if (registry.isSuspended(sql, from.agent)) throw suspended(from.agent); // fail early; again in the transaction
    // Only a replay may carry a past expiresAt: a new message would arrive already expired.
    if (input.expiresAt !== null && Date.parse(input.expiresAt) <= now) throw fail("expired", "this message expired before it could be sent");
    // The parent first: a forward's grant is checked under its task type (#597).
    let parent: Stored | null = null;
    let depth = 0;
    if (input.kind !== "request") ({ parent, depth } = this.#follow(input.kind, input.parentId, from, to, now));
    if (to.agent === null && parent?.applied !== "human-ordered") agentAddressOf(input.recipient, "recipient"); // refuses, as for any other person
    this.#assertNotTainted(from.agent, to, now); // fail early; again in the transaction
    // The type the grant checks (#597): a request's own; a forward's, its root's (never its caller's); a reply's,
    // its parent's checked type, which it records so that forwarding the reply keeps it.
    const type = parent ? checkedType(parent) : input.taskType;
    // A request or forward to an agent needs a grant (spec "Grants"); a reply answers its parent's sender and needs none.
    const granted = input.kind !== "reply";
    const forward = input.kind === "forward";
    const authorize = (messageId: string, at: number): void => {
      if (granted && !registry.outboundMode(sql, from.agent!, to, at, type, messageId)) throw registry.grantRefusal(sql, from.agent!, to, messageId, at, type, { forward });
    };
    // A replay consumes nothing: a standing grant or the `once` it spent must still cover it, and a
    // grant revoked or expired since refuses it. Another unused `once` never covers it.
    const authorizeReplay = (messageId: string, at: number): void => {
      if (granted && !registry.coversReplay(sql, from.agent!, to, messageId, at, type))
        throw registry.grantRefusal(sql, from.agent!, to, messageId, at, type, { replay: true, forward });
    };
    authorize(input.id, now); // fail early, before signing
    assertBudget(sql, from.agent, wireOf(to), parent?.threadId ?? null, now); // fail early, before signing
    const audience = parent ? intersect(input.attested, parent.audience) : input.attested;
    if (!audience.includes(to.principal)) throw notInAudience();
    audienceId(audience); // refuses (too_large) an audience observer tracking could not store
    // Orders (plan 7.4, 5.4): a hop of an ordered thread stays inside its order's envelope, and a consequential type needs an ordered thread. Both are
    // checked here, before signing, and again in the transaction. The thread is ordered when its root receipt is (the message, never a local row, VS-07).
    const claim = parent ? orders.claimOf(parent) : null;
    // The order's end as the signed claim states it (the act's limits.expiresAt, which its row also holds): the gate below checks the order itself.
    const orderEnd = claim ? Date.parse(claim.expiresAt) : Number.POSITIVE_INFINITY;
    // A request or forward without a deadline gets the default one (#590), set here by the signer: the
    // idempotency digest covers expiresAt as the agent sent it, so a same-key retry still matches. Inside an order, no hop outlives it (AT-16):
    // the default is the order's end when that is sooner, and a reply, which has none elsewhere, gets the order's end.
    const fallback = Math.min(input.kind === "reply" ? Number.POSITIVE_INFINITY : now + LIMITS.defaultTtlMs, orderEnd);
    // A deadline the sender gives that is after the order's end is the order's end: the person who signed the order set it.
    const given = input.expiresAt !== null && Date.parse(input.expiresAt) > orderEnd ? new Date(orderEnd).toISOString() : input.expiresAt;
    const expiresAt = given ?? (Number.isFinite(fallback) ? new Date(fallback).toISOString() : null);
    const facts = this.#orderFacts();
    const envelope = (at: number): void => {
      if (claim) orders.gate(sql, claim, { id: input.id, kind: input.kind, threadId: parent!.threadId, from, to, type, depth, expiresAt }, facts.owner, facts.live, at);
      // The recipient's declaration is read here only when it is in this Mailbox (the same person); deliver() checks every recipient.
      if (to.principal === from.principal) orders.consequence(sql, facts.rule, { kind: input.kind, recipient: wireOf(to), type, ordered: claim !== null, id: input.id });
    };
    envelope(now); // fail early, before signing
    const message: Message = {
      id: input.id,
      threadId: parent ? parent.threadId : input.id,
      kind: input.kind,
      parents: parent ? [parent.id] : [],
      sender: input.sender,
      recipient: wireOf(to),
      subject: input.subject,
      body: input.body,
      // A forward's own is always null (checkedType reads its root's), so nothing shows a type it was not checked
      // under; a reply records `type`, and a request's own already equals it.
      taskType: input.kind === "forward" ? null : type,
      ...(input.kind === "forward" && parent ? { quoted: { message: viewOf(parent), receipt: parent.receipt } } : {}),
      issuedAt: new Date(now).toISOString(),
      expiresAt,
      depth,
    };
    if (messageBytes(message) > LIMITS.message) throw fail("too_large", "a message, with anything it quotes, is at most 64 KB");
    // A hop of an ordered thread carries its root's order claim, as every hop of it does (receipts v3, plan 6.8); every other thread stays v2.
    const receipt = await signReceipt(await keyRing(this.env), await receiptPayload(message, parent?.receipt ?? null, input.applied, claim && { ...claim, root: false }));
    // No await from here on: one transaction spends the grant and writes the outbox row, or does neither.
    return this.ctx.storage.transactionSync(() => {
      // A replay that raced this call past the check above gets its row.
      const raced = this.#replayed(input, now);
      if (raced) return this.#replay(raced, from.agent, input, now, authorizeReplay);
      // Signing awaited: the message, or its parent, may have expired meanwhile.
      const signedAt = Date.now();
      if (input.expiresAt !== null && Date.parse(input.expiresAt) <= signedAt) throw fail("expired", "this message expired before it could be sent");
      if (parent) {
        const again = this.#get("in", parent.id, signedAt);
        if (!again) throw fail("not_found", "no such message in your inbox");
        if (again.status === "expired") throw fail("expired", "that message has expired");
        if (again.status === "cancelled") throw cancelled();
      }
      stillBound();
      if (registry.isSuspended(sql, from.agent!)) throw suspended(from.agent!);
      // Authoritative, as the suspension above: a restricted read may have landed while this one signed.
      this.#assertNotTainted(from.agent, to, signedAt);
      // Authoritative: a racing send may have taken the last slot while this one signed. A throw
      // rolls back the transaction, so no grant is spent and no row is written.
      assertBudget(sql, from.agent, wireOf(to), parent?.threadId ?? null, signedAt);
      envelope(signedAt); // authoritative, before a `once` grant is spent
      if (granted) registry.consumeGrant(sql, from.agent!, to, input.id, signedAt, type, forward);
      const stored: Stored = {
        ...message,
        audience,
        flags: taintedFlags(parent ? orFlags(input.attestedFlags, parent.flags) : input.attestedFlags, input.credential !== undefined && scopes.isRestricted(sql, from.agent!, signedAt)),
        applied: input.applied,
        receipt,
        chain: parent ? [...parent.chain, parent.receipt] : [],
        requestDigest: input.requestDigest,
      };
      this.#insert("out", stored, wireOf(to), "sent", now, from.agent);
      if (input.idempotencyKey)
        sql.exec(
          // The key is normally reserved already (reserve(), for this same id): keep that row.
          "INSERT INTO idempotency (key, digest, message_id, created_at) VALUES (?, ?, ?, ?) ON CONFLICT(key) DO NOTHING",
          slot(from.agent, input.idempotencyKey), input.requestDigest, stored.id, now,
        );
      return stored;
    });
  }

  /**
   * What a reply or a forward follows, in the order issue() refuses it: the message it answers or hands on (from the sender's own
   * inbox, #parent), for a reply that `to` is that message's sender, and that one more hop is within the depth limit. `to` absent:
   * Explain, asking where a reply would go. Synchronous, so issue() runs it in the step that reads.
   */
  #follow(kind: "reply" | "forward", parentId: string | null, from: Address, to: Address | undefined, now: number): { parent: Stored; depth: number } {
    const parent = this.#parent(parentId, from, now).message;
    if (kind === "reply" && to !== undefined && !sameAddress(to, partyAddress(parent.sender))) throw fail("forbidden", "a reply goes to the sender of the message it answers");
    const depth = parent.depth + 1;
    if (depth > LIMITS.depth) throw tooDeep();
    return { parent, depth };
  }

  /**
   * The taint rule (plan 9.5 item 3): an agent that read restricted memory in the last day sends nothing to another person. Same-owner mail is
   * untouched, and so is a replay, which is answered before any of this. Synchronous, so issue() runs it in the step that writes.
   */
  #assertNotTainted(agent: string | null, to: Address, now: number): void {
    const [, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
    if (agent !== null && to.principal !== principal && scopes.isRestricted(this.ctx.storage.sql, agent, now)) throw restrictedTaint();
  }

  /** The message `parentId` names, a reply's or a forward's parent, from the sender's own inbox, refused as issue() refuses it. */
  #parent(parentId: string | null, from: Address, now: number): Found {
    const found = this.#get("in", parentId ?? "", now);
    if (!found) throw fail("not_found", "no such message in your inbox");
    if (!sameAddress(addressOf(found.message.recipient, "recipient"), from)) throw fail("forbidden", "only a message's recipient can reply to it or forward it");
    if (found.status === "expired") throw fail("expired", "that message has expired");
    if (found.status === "cancelled") throw cancelled();
    return found;
  }

  /**
   * The task type `input` is checked under, before issue() (#597): a request's own; a forward's from the
   * parent stored in this sender's inbox, never from the caller. A parent it cannot read refuses as
   * issue() would. post() skips its early checks for a replay, and issue() takes a replay's type from its stored row.
   */
  resolveType(input: IssueInput): string | null {
    if (input.kind === "request") return input.taskType;
    return checkedType(this.#parent(input.parentId, partyAddress(input.sender), Date.now()).message);
  }

  /**
   * The sender's binding (spec "Identity"): a workspace unbound, rebound or newly bound since the caller
   * looked it up sends and cancels nothing, and the same for an MCP sender whose registered key was
   * removed since the front door checked it. Synchronous: callers run it in the step that writes.
   */
  #stillBound(agent: string | null, who: { workspace?: string; credential?: AgentCredential }): void {
    const sql = this.ctx.storage.sql;
    if (who.workspace !== undefined && registry.agentForWorkspace(sql, who.workspace) !== agent) throw bindingChanged();
    if (who.credential !== undefined && (agent === null || registry.agentForCredential(sql, who.credential) !== agent)) throw keyChanged();
  }

  /**
   * #stillBound for a caller that answers without writing (withdraw()'s refusals): the last check before
   * it answers. An agent caller (a workspace or a key names it) suspended meanwhile learns nothing either, as in cancel().
   */
  assertBound(agent: string | null, who: { workspace?: string; credential?: AgentCredential }): void {
    this.#stillBound(agent, who);
    const agentCalling = who.workspace !== undefined || who.credential !== undefined;
    if (agentCalling && agent !== null && registry.isSuspended(this.ctx.storage.sql, agent)) throw suspended(agent);
  }

  /** A replay's answer: still bound, its agent not suspended, not cancelled since, and still covered by its grant (see authorizeReplay). */
  #replay(stored: Stored, agent: string | null, input: IssueInput, now: number, authorizeReplay: (id: string, at: number) => void): Stored {
    this.#stillBound(agent, input);
    // As the binding: a suspended agent's replay is refused, so a row written but not yet delivered stays undelivered.
    if (agent !== null && registry.isSuspended(this.ctx.storage.sql, agent)) throw suspended(agent);
    // A delivery lost in transport, then cancelled, is never completed by the host's replay.
    if (this.#get("out", stored.id, now)?.status === "cancelled") throw cancelled();
    authorizeReplay(stored.id, now);
    return stored;
  }

  /**
   * The sender's side of a cancel (spec "Cancellation"), in one synchronous step: the same binding or
   * key check as issue(), then the caller agent's own request or forward is marked cancelled.
   * Idempotent. withdraw() then updates the recipient's copy.
   */
  async cancel(id: string, who: { agent: string | null; workspace?: string; credential?: AgentCredential }): Promise<Stored> {
    this.#stillBound(who.agent, who);
    // An agent's own cancel (a workspace or a key names it) is refused once it is suspended (#596), in this
    // step, so a suspension landing during withdraw()'s lookups still refuses it. The owner's is not.
    const agentCalling = who.workspace !== undefined || who.credential !== undefined;
    if (agentCalling && who.agent !== null && registry.isSuspended(this.ctx.storage.sql, who.agent)) throw suspended(who.agent);
    const row = this.ctx.storage.sql.exec<Row>(`SELECT ${COLUMNS} FROM messages WHERE box = 'out' AND id = ? AND agent IS ?`, id, who.agent).toArray()[0];
    if (!row) throw fail("not_found", "no such message in your outbox");
    const found = foundOf(row, Date.now());
    if (found.message.kind === "reply") throw fail("invalid", "a reply cannot be cancelled");
    if (found.status === "expired") throw fail("expired", "that message has expired");
    // A run bound to it, or to a forward of it at any depth, may have started (origin.ts; same-owner only, so the
    // binding is in this Mailbox): too late, as when answered.
    if (origin.startedFrom(this.ctx.storage.sql, id)) throw fail("conflict", "a run has already started from that message");
    this.ctx.storage.sql.exec("UPDATE messages SET status = 'cancelled' WHERE box = 'out' AND id = ?", id);
    return found.message;
  }

  /** The recipient's side: its copy of exactly this message, while unread or read, becomes cancelled. Its status after, or null without one. */
  async withdraw(message: Stored): Promise<MessageStatus | null> {
    const found = this.#get("in", message.id, Date.now());
    if (!found) return null;
    if (found.message.receipt !== message.receipt) throw fail("conflict", "a different receipt was delivered for this message");
    this.ctx.storage.sql.exec("UPDATE messages SET status = 'cancelled' WHERE box = 'in' AND id = ? AND status IN ('unread', 'read')", message.id);
    return this.#get("in", message.id, Date.now())!.status as MessageStatus;
  }

  /** Notes why the recipient refused an outbox row, for the owner page (spec "Failed messages"). */
  async undeliverable(id: string, reason: string): Promise<void> {
    this.ctx.storage.sql.exec("UPDATE messages SET reason = ? WHERE box = 'out' AND id = ?", truncate(reason, 300), id);
  }

  /**
   * An outbox row the owner may deliver again, exactly as signed (spec "Retry"): not cancelled or
   * expired, its sending agent not suspended, still covered by its grant as a replay is, and never a
   * workspace's message to another person, whose audience only that workspace can attest.
   */
  async redeliverable(id: string, agent: string | null): Promise<Stored> {
    const now = Date.now();
    const row = this.ctx.storage.sql.exec<Row>(`SELECT ${COLUMNS} FROM messages WHERE box = 'out' AND id = ? AND agent IS ?`, id, agent).toArray()[0];
    if (!row) throw fail("not_found", "no such message in this outbox");
    const { message, status } = foundOf(row, now);
    if (status === "cancelled") throw cancelled();
    if (status === "expired") throw fail("expired", "that message has expired");
    const to = addressOf(message.recipient, "recipient");
    const blocked = notRetriable(message);
    if (blocked) throw fail("forbidden", blocked.refusal);
    if (agent !== null && registry.isSuspended(this.ctx.storage.sql, agent)) throw suspended(agent);
    if (to.agent !== null && message.kind !== "reply") {
      if (agent === null) throw noGrant();
      const type = checkedType(message); // the stored, signed message's (#597)
      if (!registry.coversReplay(this.ctx.storage.sql, agent, to, id, now, type)) throw registry.grantRefusal(this.ctx.storage.sql, agent, to, id, now, type, { replay: true, forward: message.kind === "forward" });
    }
    return message;
  }

  /**
   * Files `message` in the recipient's inbox, once. `wake` is what the wake of the recipient's chat will do, but only when the sender is this same
   * person (plan 7.5: another person's sender learns "delivered" and nothing about a wake), and only the synchronous part of it: `woken` says a
   * wake was started, not that the host accepted it.
   */
  async deliver(message: Stored): Promise<{ wake: SendWake | null }> {
    await this.#armInbound(message);
    const now = Date.now();
    const sql = this.ctx.storage.sql;
    const existing = this.#get("in", message.id, now)?.message;
    if (existing) {
      if (existing.receipt !== message.receipt) throw fail("conflict", "a different receipt was already delivered for this message");
      const [, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
      this.ctx.storage.transactionSync(() => stageMessageEvent(sql, existing, now, messagePublisherEnabled(this.env), messagePublisherAgent(this.env, principal ?? "")));
      return { wake: null };
    }
    const to = addressOf(message.recipient, "recipient");
    // Agents only (#561): an existing default-inbox row still answers above; a new one is refused, but for a reply to an order's root, which goes
    // to its person's order view (plan 6.6), the second and last place the rule bends.
    if (to.agent === null) {
      if (!orders.toOrderView(sql, message)) throw fail("forbidden", "a person's default inbox takes no new mail");
      return this.#fileOrderView(message, now);
    }
    if (!registry.hasAgent(sql, to.agent)) throw fail("not_found", `no agent named ${to.agent}`);
    const from = partyAddress(message.sender);
    // Nor from a person: a pre-#561 person-level message (an owner Retry, a late replay) is not delivered
    // anew. Its replay into a row that exists is answered above.
    if (from.agent === null) throw fail("forbidden", "only an agent sends Knitli messages; a message from a person is not delivered");
    // A person removed from ALLOWED_PRINCIPALS neither receives nor sends (spec 2026-09-28 "Broker
    // invariants": refused at delivery). post() and redeliver() check the recipient upstream, and each front
    // door (session, MCP, owner page) the sender, but this Mailbox may run another Worker version than its
    // caller while a deploy rolls out, so it checks both again where the row is filed.
    if (!principalAllowed(this.env, to.principal)) throw fail("forbidden", "the recipient is not allowed to use Knitli Messaging");
    if (!principalAllowed(this.env, from.principal)) throw fail("forbidden", "the sender is no longer allowed to use Knitli Messaging");
    // Suspension (#596): a suspended agent receives nothing, so nothing is filed and nothing wakes it. The
    // sender's flag lives in its owner's Mailbox: here when that is this one, else issue() checks it.
    if (registry.isSuspended(sql, to.agent)) throw suspended(to.agent);
    if (from.principal === to.principal && registry.isSuspended(sql, from.agent)) throw suspended(from.agent);
    // The checks issue() made, again before delivery (#596), in the step that inserts. A host replay or a
    // Retry may arrive after the deadline: an expired message is never filed, so it never wakes anyone.
    if (message.expiresAt !== null && Date.parse(message.expiresAt) <= now) throw fail("expired", "this message expired before it could be delivered");
    if (!message.audience.includes(to.principal)) throw notInAudience();
    // Grants (spec "Grants"); a reply answers what this agent sent and needs none. One owner's grant lives
    // in this same Mailbox, so it is re-checked here, atomically with the insert: a standing grant, or the
    // `once` this message spent. Another person's outbound grant lives in the sender's Mailbox and is
    // re-checked on every replay (issue()) and Retry (redeliverable()); here, its owner's acceptance.
    if (message.kind !== "reply") {
      const type = checkedType(message); // read from the signed message itself, quoted chain included (#597)
      if (from.principal === to.principal) {
        if (!registry.coversReplay(sql, from.agent, to, message.id, now, type)) throw registry.grantRefusal(sql, from.agent, to, message.id, now, type, { replay: true, forward: message.kind === "forward" });
      } else if (!registry.accepts(sql, to.agent, from, now, type)) throw registry.acceptRefusal(sql, to.agent, from, now);
      // A type its recipient declares fields for takes only the body those fields describe (plan 5.4 item 1): the authoritative check, after
      // post()'s early one. Only a sender that passed the checks above learns which field is wrong. A reply is a result, not a task.
      const declared = type === null ? null : tasks.declaredType(sql, to.agent, type);
      const problem = declared === null ? null : tasks.bodyProblem(declared, message.body);
      if (problem !== null) throw fail("invalid", tasks.bodyRefusal(to.agent, type!, problem));
    }
    // Orders (plan 7.4, 5.4), authoritatively, in this Mailbox: an ordered thread's envelope again, and a consequential type only inside one.
    const noted = orders.atDelivery(sql, message, this.#orderFacts(), now);
    // Opportunistic cleanup: inbox rows that expired over a week ago, a bounded batch per delivery.
    sql.exec(
      "DELETE FROM messages WHERE box = 'in' AND id IN (SELECT id FROM messages WHERE box = 'in' AND expires_at <= ? LIMIT 50)",
      now - LIMITS.expiredRetentionMs,
    );
    origin.sweep(sql);
    if (orders.inboxFull(sql, now, to.agent)) throw fail("inbox_full", "the recipient's inbox is full");
    this.ctx.storage.transactionSync(() => {
      this.#insert("in", message, wireOf(from), "unread", now, to.agent);
      noted();
      this.#stageInbound(message, now);
    });
    // Wake the agent (spec "Firing"): after the row exists, never awaited, never failing delivery. The sender's own answer is looked up first, in
    // the same synchronous step as the wake's gates (no await between), so it is what the wake is about to decide.
    const wake = from.principal === to.principal ? this.#wakeHint(to.agent, Date.now()) : null;
    this.ctx.waitUntil(this.wake(to.agent, { id: message.id, from: wireOf(from) }));
    return { wake };
  }

  /**
   * Before an inbox row is committed: persist the alarm that publishes and notifies it. A crash can leave an empty alarm, but can never commit a
   * notification job without its recovery alarm already scheduled. deliver() and an order's root (acts.ts, through the presence host) both run it.
   */
  async #armInbound(message: Stored): Promise<void> {
    if (messagePublisherEnabled(this.env) || (eventsEnabled(this.env) && hasEventSubscribers(this.ctx.storage.sql, message, Date.now()))) {
      const due = Date.now() + 1000;
      const scheduled = await this.ctx.storage.getAlarm();
      if (scheduled === null || scheduled > due) await this.ctx.storage.setAlarm(due);
    }
  }

  /** In the transaction that files an inbox row: its Event publication obligation and its OAuth-webhook jobs. deliver() and an order's root both run it. */
  #stageInbound(message: Stored, now: number): void {
    const [, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
    stageMessageEvent(this.ctx.storage.sql, message, now, messagePublisherEnabled(this.env), messagePublisherAgent(this.env, principal ?? ""));
    if (eventsEnabled(this.env)) queueEvents(this.ctx.storage.sql, message, now);
  }

  /**
   * Files a reply to an order's root in its person's order view (plan 6.6): an inbox row with no agent, which the admin's Orders page reads and MCP never
   * lists. The checks deliver() makes of any reply, then the order's envelope; nothing wakes.
   */
  #fileOrderView(message: Stored, now: number): { wake: null } {
    const sql = this.ctx.storage.sql;
    const from = partyAddress(message.sender);
    const to = addressOf(message.recipient, "recipient");
    // As deliver() checks any recipient, here and not only through the order's same-owner rule: this Mailbox may run another Worker version than its caller.
    if (!principalAllowed(this.env, to.principal)) throw fail("forbidden", "the recipient is not allowed to use Knitli Messaging");
    if (from.agent === null || !principalAllowed(this.env, from.principal)) throw fail("forbidden", "only an agent sends Knitli messages");
    if (registry.isSuspended(sql, from.agent)) throw suspended(from.agent);
    if (message.expiresAt !== null && Date.parse(message.expiresAt) <= now) throw fail("expired", "this message expired before it could be delivered");
    if (!message.audience.includes(to.principal)) throw notInAudience();
    orders.atDelivery(sql, message, this.#orderFacts(), now);
    if (orders.inboxFull(sql, now)) throw fail("inbox_full", "the recipient's inbox is full");
    this.ctx.storage.transactionSync(() => this.#insert("in", message, wireOf(from), "unread", now, null));
    return { wake: null };
  }

  /**
   * Starts a turn for `agent`'s subscribed chat, if its owner turned the hook on (spec "Firing"). The
   * checks and the budget are synchronous, before any await; the firing then carries the envelope only.
   * Never throws: deliver() does not wait for it.
   */
  async wake(agent: string, envelope: { id: string; from: string }, order: activation.LiveOrder | null = null): Promise<WakeOutcome> {
    const hook = this.ctx.storage.kv.get<WakeHook>(wakeKey(agent));
    if (!hook) return "none";
    const outcome = await this.#fire(agent, hook, envelope, order);
    // Only while this enable is still the stored one: a replacement's outcome is not this one's, and an
    // unbind or disable meanwhile already recorded (or cleared) the status. A firing that dropped its own
    // hook (the two cases in #fire) recorded that there, in its synchronous step.
    if (this.#current(agent, hook)) this.#noteWake(agent, outcome);
    console.log(JSON.stringify({ event: "messaging_wake", agent, outcome }));
    return outcome;
  }

  #budget(agent: string): WakeBudget {
    return this.ctx.storage.kv.get<WakeBudget>(budgetKey(agent)) ?? { pendingSince: null, wakes: [] };
  }

  /**
   * The synchronous gates of a wake, in the order #fire meets them: "go" when none refuses, else the outcome. No effect of its own: #fire applies
   * the ones that have effects (forgetting an unbound hook, spending the budget), and #wakeHint asks it without applying anything.
   */
  #wakeGate(agent: string, hook: WakeHook, now: number): WakeOutcome | "go" {
    const { perHour, pendingMs } = LIMITS.wake;
    if (messageRoute(this.ctx.storage.sql, agent).owner !== "os") return "not_allowed";
    // A person removed from ALLOWED_PRINCIPALS starts no turns; the hook stays, for if they return.
    const [, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
    if (!principal || !principalAllowed(this.env, principal)) return "not_allowed";
    // The race rule: the binding, in the same synchronous step as the budget, before any await.
    if (registry.agentForWorkspace(this.ctx.storage.sql, hook.workspace) !== agent) return "unbound";
    // A suspended agent is never woken (#596): checked here, and again once the turn's host answers.
    if (registry.isSuspended(this.ctx.storage.sql, agent)) return "suspended";
    const budget = this.#budget(agent);
    if (budget.pendingToken?.startsWith("event:") || (budget.pendingSince !== null && now - budget.pendingSince < pendingMs)) return "pending";
    if ((budget.stockWakeAttempts ?? []).some((attempt) => attempt.settledAt === null)) return "pending";
    if (budget.wakes.filter((at) => at > now - LIMITS.wake.windowMs).length >= perHour) return "over_budget";
    return "go";
  }

  /** What a same-owner sender is told of the wake a delivery is about to start, or null when it will start none (no hook, or one that will be dropped). */
  #wakeHint(agent: string, now: number): SendWake | null {
    const hook = this.ctx.storage.kv.get<WakeHook>(wakeKey(agent));
    if (!hook) return null;
    const gate = this.#wakeGate(agent, hook, now);
    return gate === "go" ? "woken" : gate === "pending" || gate === "over_budget" ? gate : null;
  }

  /**
   * What the activation policy would have decided for this wake, counted for the owner (plan 8.2, OBSERVE: nothing it says changes the wake). It
   * sees a wake the gates let through or the budget or a suspension stopped, not one that was never going to start (an unbound hook, an account
   * no longer allowed). Best effort: a count that cannot be kept changes no wake.
   */
  #observeActivation(agent: string, from: string, gate: WakeOutcome | "go", now: number, order: activation.LiveOrder | null): void {
    if (gate === "not_allowed" || gate === "unbound") return;
    try {
      const policy = activation.policyOf(this.ctx.storage.sql, agent);
      if (policy === null) return;
      // `order`: an order's root, filed by its act (5b-2a); every other wake passes null until 5b-2b looks up the live order. The transport is the OS
      // hook, the only one that reaches this code.
      const verdict = activation.wakeAllowed(policy, { sender: from, transport: "os-hook", order, suspended: gate === "suspended", overBudget: gate === "pending" || gate === "over_budget" });
      activation.observe(this.ctx.storage.kv, agent, verdict, now);
    } catch {
      // The wake is what matters; the count is a convenience.
    }
  }

  async #fire(agent: string, hook: WakeHook, envelope: { id: string; from: string }, order: activation.LiveOrder | null = null): Promise<WakeOutcome> {
    const kv = this.ctx.storage.kv;
    const now = Date.now();
    const gate = this.#wakeGate(agent, hook, now);
    if (gate === "unbound") this.#forgetWake(agent);
    this.#observeActivation(agent, envelope.from, gate, now, order);
    if (gate !== "go") return gate;
    const route = messageRoute(this.ctx.storage.sql, agent);
    const pendingToken = `os:${crypto.randomUUID()}`;
    const budget = this.#budget(agent);
    const wakes = budget.wakes.filter((at) => at > now - LIMITS.wake.windowMs);
    kv.put<WakeBudget>(budgetKey(agent), { ...budget, pendingSince: now, pendingToken, wakes: [...wakes, now] });
    // A firing that starts no turn frees its pending slot; its timestamp stays, so a failing host costs at most perHour tries.
    const release = (): void => {
      const after = this.#budget(agent);
      if (after.pendingToken === pendingToken) kv.put<WakeBudget>(budgetKey(agent), { ...after, pendingSince: null, pendingToken: null });
    };
    try {
      using started = await hook.initiator.startHook();
      if (messageRoute(this.ctx.storage.sql, agent).generation !== route.generation) {
        release();
        return "not_allowed";
      }
      // A suspension that landed while the host started the turn: nothing reaches the agent.
      if (registry.isSuspended(this.ctx.storage.sql, agent)) {
        release();
        return "suspended";
      }
      // Straight to the queue, not through an ObservationGate: the fields are the envelope only, the
      // same baseline inbox() lists, and a baseline gate resolves nothing (gatekeeper-kit observers.ts).
      await started.approvalQueue.authorizeObservation({
        title: "A Knitli message arrived",
        description: "A Knitli message arrived for this workspace's agent: who sent it and its id, without its subject or content.",
        fields: [
          { label: "From", kind: "inline", value: envelope.from },
          { label: "Message", kind: "inline", value: envelope.id },
        ],
      });
      // Routing transfer fences an old hook even if ownership returned to OS while it awaited.
      if (messageRoute(this.ctx.storage.sql, agent).generation !== route.generation) {
        release();
        return "not_allowed";
      }
      // And once more after the observation, which can wait on a person: the last await before the agent hears of it.
      if (registry.isSuspended(this.ctx.storage.sql, agent)) {
        release();
        return "suspended";
      }
      await started.callback.messageArrived(envelope);
      return "woken";
    } catch (error) {
      release();
      // Re-read: the hook may have been replaced or cleared while this firing awaited.
      const dead = (error instanceof Error ? error.message : String(error)).includes("Hook has been deleted or disabled.");
      if (dead && this.#current(agent, hook)) {
        kv.delete(wakeKey(agent));
        this.#noteWake(agent, "failed");
      }
      return "failed";
    }
  }

  /** Whether `hook`, as a firing read it, is still what `agent` has stored: this enable, not a later one under the same hookId. */
  #current(agent: string, hook: WakeHook): boolean {
    const stored = this.ctx.storage.kv.get<WakeHook>(wakeKey(agent));
    return stored !== undefined && stored.nonce === hook.nonce;
  }

  /** The agent looked at its mail: its next message may wake it again (spec "The wake budget"). */
  #settle(agent: string): void {
    const budget = this.ctx.storage.kv.get<WakeBudget>(budgetKey(agent));
    // An unknown Event outcome stays pending until verified receiver settlement, never an inbox read or timeout.
    if (budget?.pendingSince != null && !budget.pendingToken?.startsWith("event:"))
      this.ctx.storage.kv.put<WakeBudget>(budgetKey(agent), { ...budget, pendingSince: null, pendingToken: null });
  }

  /** A row of `agent`'s mailbox (null: the default inbox), never another agent's (spec "Read rule"). */
  async get(box: Box, id: string, agent: string | null = null): Promise<Found | null> {
    return this.#getOwn(box, id, agent, Date.now());
  }
  #getOwn(box: Box, id: string, agent: string | null, now: number): Found | null {
    const row = this.ctx.storage.sql.exec<Row>(`SELECT ${COLUMNS} FROM messages WHERE box = ? AND id = ? AND agent IS ?`, box, id, agent).toArray()[0];
    return row ? foundOf(row, now) : null;
  }

  /**
   * Newest first; `before` (a row's `cursor`) continues after that row. `settle`: the agent itself is
   * looking (inbox() over a session), so its pending wake is cleared; the owner page's and MCP's views are not.
   */
  async list(box: Box, options: { agent?: string | null; status?: MessageStatus; limit: number; before?: string; settle?: boolean }): Promise<Found[]> {
    const now = Date.now();
    const sql = this.ctx.storage.sql;
    const agent = options.agent ?? null;
    let page = "";
    let after: number[] = [];
    if (options.before !== undefined) {
      const [at, rowid] = beforeOf(options.before)!.split(".").map(Number) as [number, number];
      page = "AND (created_at < ? OR (created_at = ? AND rowid < ?))";
      after = [at, at, rowid];
    }
    const order = "ORDER BY created_at DESC, rowid DESC LIMIT ?";
    const rows =
      options.status === "expired"
        ? sql.exec<Row>(`SELECT ${COLUMNS} FROM messages WHERE box = ? AND agent IS ? AND expires_at IS NOT NULL AND expires_at <= ? ${page} ${order}`, box, agent, now, ...after, options.limit)
        : options.status
          ? sql.exec<Row>(`SELECT ${COLUMNS} FROM messages WHERE box = ? AND agent IS ? AND status = ? AND (expires_at IS NULL OR expires_at > ?) ${page} ${order}`, box, agent, options.status, now, ...after, options.limit)
          : sql.exec<Row>(`SELECT ${COLUMNS} FROM messages WHERE box = ? AND agent IS ? ${page} ${order}`, box, agent, ...after, options.limit);
    if (options.settle && box === "in" && agent !== null) this.#settle(agent);
    return rows.toArray().map((row) => foundOf(row, now));
  }

  /** Unread, unexpired inbox rows per mailbox (agent null: the default inbox); mailboxes with none are left out. */
  async unreadCounts(): Promise<{ agent: string | null; n: number }[]> {
    return this.ctx.storage.sql
      .exec<{ agent: string | null; n: number }>(
        "SELECT agent, count(*) AS n FROM messages WHERE box = 'in' AND status = 'unread' AND (expires_at IS NULL OR expires_at > ?) GROUP BY agent",
        Date.now(),
      )
      .toArray()
      .map(({ agent, n }) => ({ agent, n }));
  }

  /** Inbox status by id, for the senders' outbox listings; ids not in this inbox are left out. */
  async statuses(ids: string[]): Promise<Record<string, MessageStatus>> {
    const now = Date.now();
    const out: Record<string, MessageStatus> = {};
    for (const id of ids) {
      const found = this.#get("in", id, now);
      if (found) out[id] = found.status as MessageStatus;
    }
    return out;
  }

  /**
   * Marks an unread inbox message read, and returns its status after that (expiry is read lazily), in one
   * synchronous step: another workspace of this principal may have answered it, or it may have
   * expired, since the caller last looked. Null when there is no such inbox row. `reader`: the agent
   * reading (its key's thumbprint too, over MCP); the owner's Dismiss passes none.
   */
  async markRead(id: string, reader?: { agent: string; credential?: AgentCredential }): Promise<MessageStatus | null> {
    const now = Date.now();
    // An MCP reader's credential, and any reader's suspension (#596), checked in this same synchronous
    // step: a key removed, or the agent suspended, during the read leaves the message unread and returns nothing.
    if (reader?.credential !== undefined && registry.agentForCredential(this.ctx.storage.sql, reader.credential) !== reader.agent) throw keyChanged();
    if (reader && registry.isSuspended(this.ctx.storage.sql, reader.agent)) throw suspended(reader.agent);
    this.ctx.storage.sql.exec(
      "UPDATE messages SET status = 'read' WHERE box = 'in' AND id = ? AND status = 'unread'",
      id,
    );
    const owner = this.ctx.storage.sql.exec<{ agent: string | null }>("SELECT agent FROM messages WHERE box = 'in' AND id = ?", id).toArray()[0]?.agent;
    if (owner) this.#settle(owner);
    return (this.#get("in", id, now)?.status as MessageStatus | undefined) ?? null;
  }

  /**
   * The first reply moves the parent to answered; later ones change nothing. Nor does a late one, delivered
   * after the parent expired (#590): an expired row keeps what it stored, whatever reads it.
   */
  async markAnswered(id: string): Promise<void> {
    this.ctx.storage.sql.exec(
      "UPDATE messages SET status = 'answered' WHERE box = 'in' AND id = ? AND status IN ('unread', 'read') AND (expires_at IS NULL OR expires_at > ?)",
      id, Date.now(),
    );
  }

  /**
   * The message id for an idempotency key: the one already reserved or sent under it, or `id`, now
   * reserved. Keys are per agent (`slot`), and a person-level sender's are shared by all their unbound
   * workspaces. Synchronous in this one Mailbox, so concurrent retries get the same id. A different
   * digest is a conflict.
   */
  async reserve(key: string, digest: string, id: string, agent: string | null = null): Promise<string> {
    const now = Date.now();
    const hit = this.#reservation(slot(agent, key), digest, now);
    if (hit) return hit;
    this.ctx.storage.sql.exec("INSERT INTO idempotency (key, digest, message_id, created_at) VALUES (?, ?, ?, ?)", slot(agent, key), digest, id, now);
    return id;
  }

  /** The message id reserved or sent under `key`, without reserving it: for a retry that may not send. */
  async reserved(key: string, digest: string, agent: string | null = null): Promise<string | null> {
    return this.#reservation(slot(agent, key), digest, Date.now());
  }

  /** The stored answer to a replay of `input` (the same id, or the same idempotency key), or null. */
  #replayed(input: IssueInput, now: number): Stored | null {
    const same = this.#get("out", input.id, now)?.message;
    if (same) {
      if (same.requestDigest !== input.requestDigest) throw fail("conflict", "this message id was already sent with different content");
      return same;
    }
    if (!input.idempotencyKey) return null;
    const hit = this.#reservation(slot(input.sender.agent ?? null, input.idempotencyKey), input.requestDigest, now);
    if (!hit) return null;
    const stored = this.#get("out", hit, now)?.message;
    if (stored) return stored;
    // Reserved but not yet sent: only the reserved id may be issued under this key.
    if (hit !== input.id) throw fail("conflict", "this idempotencyKey is reserved for another message");
    return null;
  }

  /** The message id reserved or sent under `key` in the last 7 days, or null. */
  #reservation(key: string, digest: string, now: number): string | null {
    const sql = this.ctx.storage.sql;
    sql.exec("DELETE FROM idempotency WHERE created_at <= ?", now - LIMITS.idempotencyMs);
    const hit = sql.exec<{ digest: string; message_id: string }>("SELECT digest, message_id FROM idempotency WHERE key = ?", key).toArray()[0];
    if (!hit) return null;
    if (hit.digest !== digest) throw fail("conflict", "this idempotencyKey was already used for a different message");
    return hit.message_id;
  }

  #get(box: Box, id: string, now: number): Found | null {
    const row = this.ctx.storage.sql.exec<Row>(`SELECT ${COLUMNS} FROM messages WHERE box = ? AND id = ?`, box, id).toArray()[0];
    return row ? foundOf(row, now) : null;
  }

  /** Another principal's Mailbox in this one's namespace (its name is JSON [namespace, principal]: mailboxName). */
  #peer(principal: string) {
    const name = this.ctx.id.name;
    if (!name) throw fail("unavailable", "this Mailbox was not reached by name");
    const [namespace] = JSON.parse(name) as [string, string];
    return this.env.MAILBOX.getByName(mailboxName(namespace, principal));
  }

  #insert(box: Box, message: Stored, counterpart: string, status: string, now: number, agent: string | null): void {
    orders.insertMessage(this.ctx.storage.sql, box, message, counterpart, status, now, agent);
  }

  // The registry (spec "Identity", "Grants"). Callers authorize: the owner page writes it for its
  // signed-in owner only, and sessions and MCP only read it.

  registerAgent(name: string, kind: AgentKind): Agent {
    return registry.registerAgent(this.ctx.storage.sql, agentName(name), kind, Date.now());
  }
  /**
   * The named agents, whether each exists (with its keys) and whether it holds nothing, so may start with permissions
   * (enrollment-store whichHoldNothing): everything a page needs to decide about a few names, in one read.
   */
  agentsNamed(names: string[]): { name: string; agent: registry.Agent | null; holdsNothing: boolean; atKeyLimit: boolean }[] {
    const sql = this.ctx.storage.sql;
    const found = registry.agentsNamed(sql, names);
    const nothing = new Set(enrollment.whichHoldNothing(sql, names));
    return names.map((name, i) => ({ name, agent: found[i]!, holdsNothing: found[i] !== null && nothing.has(name), atKeyLimit: (found[i]?.keys.length ?? 0) >= registry.MAX_AGENT_KEYS }));
  }
  agentPage(cursor?: string | null) {
    const page = registry.agentPage(this.ctx.storage.sql, cursor);
    const wake: Record<string, WakeState> = {};
    for (const agent of page.agents) {
      const state = this.#wakeOf(agent.name);
      if (state !== null) wake[agent.name] = state;
    }
    return { ...page, wake, liveOrders: orders.liveCount(this.ctx.storage.sql, Date.now()) };
  }
  /** `agent`'s wake as the owner page shows it: null when it never had one. */
  #wakeOf(agent: string): WakeState | null {
    const kv = this.ctx.storage.kv;
    const enabled = kv.get<WakeHook>(wakeKey(agent)) !== undefined;
    const last = kv.get<WakeStatus>(statusKey(agent)) ?? null;
    return enabled || last !== null ? { enabled, last } : null;
  }
  agents(): Agent[] {
    return registry.listAgents(this.ctx.storage.sql);
  }
  /**
   * The step-up gate for the widening calls below (stepup.ts). Made before the call's transaction, which cannot await: the gate then reads its facts inside it.
   * The Mailbox is where the rule is asked, so the admin API and the legacy owner host meet it alike (plan 5.11, 13.3 step 1).
   */
  #stepUp(): Promise<Gate> {
    return presence.stepUp(this.#presenceHost());
  }
  async bindWorkspace(name: string, workspaceId: string): Promise<void> {
    const gate = await this.#stepUp();
    this.ctx.storage.transactionSync(() => {
      const before = this.agents().find((a) => a.name === name)?.workspaceId ?? null;
      if (before === workspaceId) return; // binding the same workspace again changes nothing
      // Whoever can speak as an agent is the agent's authority, held or not yet: a session binding on one that holds nothing would inherit what it is given later (#805), so the
      // binding is a signed bind-existing act for every agent. Refusing reuses the draft path the forms already take; a binding is never stored inert.
      gate.require("bind-existing", `Binding a workspace to ${name}`);
      registry.bindWorkspace(this.ctx.storage.sql, name, workspaceId);
      // The race rule: a wake follows its workspace, never the agent to a new one.
      this.#forgetWake(name);
    });
  }
  unbind(name: string): void {
    registry.unbind(this.ctx.storage.sql, name);
    this.#forgetWake(name);
  }
  /**
   * Drops `agent`'s wake with its binding. The host still shows the hook on and calls enable() only when
   * it is switched on again, so the drop is recorded for the owner (wakeStatus()).
   */
  #forgetWake(agent: string): void {
    if (this.ctx.storage.kv.get(wakeKey(agent)) === undefined) return;
    this.ctx.storage.kv.delete(wakeKey(agent));
    this.#noteWake(agent, "unbound");
  }
  #noteWake(agent: string, outcome: WakeOutcome): void {
    this.ctx.storage.kv.put<WakeStatus>(statusKey(agent), { outcome, at: Date.now() });
  }

  /**
   * Stores `agent`'s wake (spec "Storage"), replacing any other: the last hook enabled wins. Refused
   * unless `workspace` (the attested workspace subscribe() pinned in the controller's props) is bound to
   * `agent` now. `target` is the host's display id, never checked.
   */
  setHook(agent: string, workspace: string, hookId: string, initiator: WakeHook["initiator"], target: string): void {
    if (registry.agentForWorkspace(this.ctx.storage.sql, workspace) !== agent)
      throw fail("forbidden", `this workspace is no longer bound to ${agent}; subscribe again from the workspace`);
    this.ctx.storage.kv.put<WakeHook>(wakeKey(agent), { hookId, nonce: crypto.randomUUID(), initiator, workspace, target });
    this.ctx.storage.kv.delete(statusKey(agent));
  }
  /** The host's disable(): forgets `agent`'s wake if it is still this hook. Never refuses. */
  clearHook(agent: string, hookId: string): void {
    if (this.ctx.storage.kv.get<WakeHook>(wakeKey(agent))?.hookId !== hookId) return;
    this.ctx.storage.kv.delete(wakeKey(agent));
    this.ctx.storage.kv.delete(statusKey(agent));
  }
  /** The agents with a stored wake. Test-only: the owner page reads wakeStatus(). */
  wakeHooks(): string[] {
    return [...this.ctx.storage.kv.list<WakeHook>({ prefix: "wake:" })].map(([key]) => key.slice("wake:".length));
  }
  /**
   * Per agent that had a wake, whether one is stored now and its last outcome (null before its first).
   * An agent with `enabled: false` and `last.outcome` "unbound" or "failed" had a wake the host still
   * shows on: its owner turns the hook off and on again in Connections.
   */
  wakeStatus(): Record<string, WakeState> {
    const kv = this.ctx.storage.kv;
    const out: Record<string, WakeState> = {};
    for (const agent of this.wakeHooks()) out[agent] = { enabled: true, last: kv.get<WakeStatus>(statusKey(agent)) ?? null };
    for (const [key, last] of kv.list<WakeStatus>({ prefix: "wake-status:" })) {
      const agent = key.slice("wake-status:".length);
      // hasOwn, not `??=`: an agent named "constructor" would find Object's own.
      if (!Object.hasOwn(out, agent)) out[agent] = { enabled: false, last };
    }
    return out;
  }
  agentForWorkspace(workspaceId: string): string | null {
    return registry.agentForWorkspace(this.ctx.storage.sql, workspaceId);
  }
  /** The owner page's Suspend and Unsuspend (#596). The wake hook stays, so unsuspending restores it too. */
  suspend(name: string): void {
    // The agent's waiting order requests go with it: they stay cancelled when it is restored.
    this.ctx.storage.transactionSync(() => {
      registry.setSuspended(this.ctx.storage.sql, agentName(name), Date.now());
      orders.voidDrafts(this.ctx.storage.sql, agentName(name));
    });
  }
  /** Restores an agent's keys, bindings, permissions and wake authority at once, so once `activation` is enforced it is the signed `activation` act (op unsuspend). */
  async unsuspend(name: string): Promise<void> {
    const gate = await this.#stepUp();
    this.ctx.storage.transactionSync(() => {
      gate.require("activation", `Restoring ${name}`);
      registry.setSuspended(this.ctx.storage.sql, agentName(name), null);
    });
  }
  /**
   * Stop everything (R4 plan 12.5), for this person's Mailbox alone: suspends every agent not yet suspended, and denies every enrollment still waiting
   * (an unused code, a computer awaiting confirmation). Each is the owner page's own call for one agent or one code (suspend(), denyEnrollment()), so
   * the effects are the same ones; they all run here, in one call, so a press of the button is one invocation however many agents there are. One that
   * fails is named and the rest still run. Keys, grants, bindings, wake hooks and credentials are not touched. The caller burns the denied codes.
   */
  stopAll(actor: string): { suspended: string[]; alreadySuspended: number; codes: string[]; computers: string[]; ordersRevoked: number; failed: { kind: "agent" | "enrollment" | "orders"; name: string; code: Code }[] } {
    this.#owner(actor);
    // Live orders first (R4 P5b): an order's next hop and wake are refused from here on, whatever happens to the agents.
    const out: ReturnType<Mailbox["stopAll"]> = { suspended: [], alreadySuspended: 0, codes: [], computers: [], ordersRevoked: 0, failed: [] };
    // Isolated: a failure here is named, and never keeps the agents below from being suspended (which also stops their orders' hops).
    try {
      out.ordersRevoked = this.ctx.storage.transactionSync(() => {
        const n = orders.revokeLive(this.ctx.storage.sql, Date.now());
        if (n > 0) appendLog(this.ctx.storage.sql, { kind: "order.revoked", actor, detail: { stopEverything: true, count: n } }, Date.now());
        return n;
      });
    } catch (error) {
      out.failed.push({ kind: "orders", name: "live orders", code: codeOf(error) ?? "unavailable" });
    }
    for (const agent of this.agents()) {
      if (agent.suspendedAt) {
        out.alreadySuspended += 1;
        continue;
      }
      try {
        this.suspend(agent.name);
        out.suspended.push(agent.name);
      } catch (error) {
        out.failed.push({ kind: "agent", name: agent.name, code: codeOf(error) ?? "unavailable" });
      }
    }
    // An unused code and a computer waiting to be confirmed are different things to cancel, and the owner is told which.
    for (const { id, state } of enrollment.waiting(this.ctx.storage.sql, Date.now())) {
      try {
        this.denyEnrollment(actor, id);
        (state === "pending" ? out.computers : out.codes).push(id);
      } catch (error) {
        out.failed.push({ kind: "enrollment", name: id, code: codeOf(error) ?? "unavailable" });
      }
    }
    return out;
  }
  /** Revokes one order (R4 P5b, plan 7.4 item 1): narrowing, so the owner's session may. Its next hop and its next wake are refused. */
  revokeOrder(actor: string, digest: string): { revoked: boolean } {
    this.#owner(actor);
    return this.ctx.storage.transactionSync(() => {
      const revoked = orders.revoke(this.ctx.storage.sql, digest, Date.now());
      if (revoked) appendLog(this.ctx.storage.sql, { kind: "order.revoked", actor, detail: { actDigest: digest } }, Date.now());
      // Revoking is idempotent: an order already revoked (a double click, a stale list) answers as revoked, logs nothing, and an unknown id stays false.
      return { revoked: revoked || orders.orderOf(this.ctx.storage.sql, digest)?.revoked_at != null };
    });
  }
  /** The person's orders, newest first, and whether orders can be drafted at all (authority.orderEmission): the Orders page lists existing rows either way. */
  orderList(actor: string): { emission: boolean; orders: orders.OrderView[]; cut: boolean; limit: number; waiting: orders.WaitingOrderView[] } {
    this.#owner(actor);
    const now = Date.now();
    // `waiting`: the orders agents asked for (Flow B) that no one has signed; the page links each to the sign hand-off.
    return { emission: authorityFlags(this.env).orderEmission, ...orders.listOrders(this.ctx.storage.sql, ORDERS_LISTED, this.#orderFacts().live, now), limit: ORDERS_LISTED, waiting: orders.waitingDrafts(this.ctx.storage.sql, now, (drafter, subject, extra) => draftStillMay(this.ctx.storage.sql, drafter, subject, extra.scope, extra)) };
  }
  /** One order with every hop of its thread, or null when this Mailbox holds no such order. */
  orderTrace(actor: string, digest: string): orders.OrderTraceView | null {
    this.#owner(actor);
    return orders.traceOrder(this.ctx.storage.sql, digest, this.#orderFacts().live, Date.now());
  }
  // Flow B (R4 P5b 5b-2c): an agent asks for an order. Each is the agent's own call, so each first checks the binding it called with (a key or a workspace still its agent's, and
  // not suspended), as a send does in issue().
  /** An agent's request for an order: an inert draft the person signs. Returns its id and where to sign it. */
  async requestOrder(agent: string, who: { workspace?: string; credential?: AgentCredential }, input: unknown) {
    const name = agentName(agent);
    this.assertBound(name, who);
    return presence.requestOrder(this.#presenceHost(), name, who.credential?.kind === "key" ? who.credential.thumbprint : null, input, () => this.assertBound(name, who));
  }
  /** Where an agent's own request stands. A draft that agent did not make is `not_found`. */
  orderStatus(agent: string, who: { workspace?: string; credential?: AgentCredential }, draftId: string): orders.DraftStatus {
    const name = agentName(agent);
    this.assertBound(name, who);
    const status = orders.draftStatus(this.ctx.storage.sql, `agent:${wireOf({ principal: this.#who().owner, agent: name })}`, draftId, this.#orderFacts().live, Date.now());
    if (!status) throw fail("not_found", "no order request of yours has that id");
    return status;
  }
  /** The live orders an agent is inside. */
  agentOrders(agent: string, who: { workspace?: string; credential?: AgentCredential }): { orders: orders.AgentOrderView[]; truncated: boolean } {
    const name = agentName(agent);
    this.assertBound(name, who);
    return orders.agentOrders(this.ctx.storage.sql, name, this.#orderFacts().live, Date.now());
  }
  /** The order the message `id` in `agent`'s inbox belongs to, or null when it belongs to none. */
  messageOrder(agent: string, id: string): orders.OrderBrief | null {
    const found = this.#getOwn("in", id, agentName(agent), Date.now());
    if (!found) throw fail("not_found", "no such message in your inbox");
    return orders.orderBrief(this.ctx.storage.sql, found.message, this.#orderFacts().live, Date.now());
  }
  /**
   * The wake inventory (R4 P5b, D7 B): every agent's hook, activation policy and observed counts, and the agents holding a live permission to message it
   * (a same-owner sender's grant to it, or another owner's offer it accepted). What the owner approves as allowed senders before every agent is order-only.
   */
  wakeInventory(): WakeInventoryRow[] {
    const sql = this.ctx.storage.sql;
    const owner = this.#who().owner;
    const wake = this.wakeStatus();
    const live = registry.listGrants(sql, Date.now()).filter((g) => g.revokedAt === null && (g.expiresAt === null || Date.parse(g.expiresAt) > Date.now()) && !(g.mode === "once" && g.usedAt !== null));
    return this.agents().map((agent) => {
      const policy = activation.policyOf(sql, agent.name)!;
      const observed = activation.observedOf(this.ctx.storage.kv, agent.name);
      const address = wireOf({ principal: owner, agent: agent.name });
      const permitted = [...new Set(live.flatMap((g) =>
        g.direction === "out" && g.peer === address ? [wireOf({ principal: owner, agent: g.agent })] : g.direction === "in" && g.agent === agent.name && g.acceptedAt !== null ? [g.peer] : []))].toSorted();
      return {
        agent: agent.name, kind: agent.kind, suspended: agent.suspendedAt !== null, hookOn: wake[agent.name]?.enabled === true,
        mode: policy.mode, senders: policy.senders, transports: policy.transports,
        observed: observed && { since: new Date(observed.since).toISOString(), total: observed.total, suppressed: observed.suppressed }, permitted,
      };
    });
  }
  /** Refuses (`suspended`) unless `name` is active: the front doors' check before an agent's own operations. */
  assertActive(name: string): void {
    if (registry.isSuspended(this.ctx.storage.sql, name)) throw suspended(name);
  }
  /** Registers a public JWK (an object or its JSON text) an external agent signs its tokens with; returns its thumbprint. Only x is kept. */
  async addAgentKey(name: string, jwk: unknown): Promise<string> {
    const key = await publicJwk(jwk);
    if ("refused" in key) throw fail("invalid", JWK_REFUSALS[key.refused]!);
    const gate = await this.#stepUp();
    return this.ctx.storage.transactionSync(() => {
      const now = Date.now();
      // A key on an agent that holds authority is a computer enrolled with a signed act; on one that holds nothing a session may add it, and it is inert until an act lists it (INV14).
      if (keys.holdsAuthority(this.ctx.storage.sql, agentName(name), now)) gate.require("bind-existing", `Adding a key to ${name}`);
      registry.addAgentKey(this.ctx.storage.sql, name, key.x, key.thumbprint, now, gate.provisional("bind-existing") ? "provisional" : "active");
      return key.thumbprint;
    });
  }
  removeAgentKey(name: string, thumbprint: string): boolean {
    return this.ctx.storage.transactionSync(() => {
      enrollment.forgetDevice(this.ctx.storage.sql, name, thumbprint);
      return registry.removeAgentKey(this.ctx.storage.sql, name, thumbprint);
    });
  }
  agentKey(name: string, thumbprint: string): string | null {
    return registry.agentKey(this.ctx.storage.sql, name, thumbprint);
  }
  /**
   * Refuses (`key_provisional`) a key no act has listed (INV14). A door asks it AFTER the signature verified, so a forged token for a provisional thumbprint is
   * answered as any other bad token; Memory's and Event's last looks (credentialActive) refuse a provisional key themselves.
   */
  assertKeyActive(name: string, thumbprint: string): void {
    if (registry.agentKey(this.ctx.storage.sql, name, thumbprint) !== null) registry.assertActiveKey(this.ctx.storage.sql, thumbprint);
  }
  /** Final current-authority check used by the Event entrypoint after signature verification. */
  assertEventCredential(name: string, thumbprint: string, proofExpiresAt: number): void {
    const [, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
    if (!Number.isSafeInteger(proofExpiresAt) || proofExpiresAt <= Date.now() || !principal || !principalAllowed(this.env, principal) ||
      !registry.credentialActive(this.ctx.storage.sql, name, thumbprint))
      throw fail("forbidden", "this Event agent credential is no longer authorized");
  }
  #genericAdmissionBlocked(name: string, attemptId: string, budget: WakeBudget): boolean {
    return messageRoute(this.ctx.storage.sql, name).owner === "event" || !!budget.pendingToken?.startsWith("event:") ||
      this.ctx.storage.sql.exec("SELECT attempt_id FROM message_wake_attempts WHERE attempt_id=?", attemptId).toArray().length > 0 ||
      this.ctx.storage.sql.exec("SELECT attempt_id FROM message_attempt_settlements WHERE attempt_id=?", attemptId).toArray().length > 0 ||
      (budget.stockWakeAttempts ?? []).some(row => row.settledAt === null || row.attemptId === attemptId);
  }
  /** Idempotently charges a native attempt against this agent's existing Messaging wake allowance. */
  reserveEventNativeAttempt(name: string, thumbprint: string, attemptId: string, proofExpiresAt: number, activation?: ActivationClaimV1): EventAttemptReservationResultV1 {
    return this.ctx.storage.transactionSync(() => {
      this.assertEventCredential(name, thumbprint, proofExpiresAt);
      const now = Date.now(), budget = this.#budget(name);
      if (this.#genericAdmissionBlocked(name, attemptId, budget)) return { status: "denied" };
      const prior = eventAttemptStatus(budget, attemptId, now);
      if (prior.status === "reserved") {
        // Retained identity-free rows only recover through their exact legacy shape. Bound rows
        // require the same source claim and cannot be downgraded to the old three-field DTO.
        if (!!prior.activation !== !!activation || (prior.activation && activation && !sameActivationSnapshot(prior.activation, activation)))
          return { status: "denied" };
        return { status: "reserved", attemptId, reservedAt: prior.reservedAt, idempotent: true, budget: prior.budget };
      }
      if (!activation) return { status: "denied" };
      const [namespace, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
      if (!namespace || !principal || activation.principal !== principal || activation.agent !== name || activation.source.kind === "message")
        return { status: "denied" };
      const currentActivation = prepareSourceActivation(this.ctx.storage.sql, { principal, agent: name, live: this.#orderFacts().live }, activation.source, now);
      if (currentActivation.status !== "eligible" || !sameActivationSnapshot(activation, currentActivation.claim)) return { status: "denied" };
      const result = reserveEventAttempt(budget, attemptId, now, activation);
      // A legacy native outcome has no trusted settlement here. Preserve its barrier across
      // budget retention and route transfer without changing legacy native retry behavior.
      if (result.result.status === "reserved") this.ctx.storage.kv.put(`event-native-unsettled:${name}`, true);
      this.ctx.storage.kv.put<WakeBudget>(budgetKey(name), result.budget);
      return {
        status: result.result.status,
        attemptId,
        reservedAt: result.result.reservedAt,
        idempotent: result.result.idempotent,
        budget: result.result.budget,
      };
    });
  }
  /** Stock command reservation is separately settleable; it never changes legacy uncertainty. */
  reserveEventStockWakeAttempt(name: string, thumbprint: string, attemptId: string, claim: string, proofExpiresAt: number): StockWakeReservationResultV1 {
    return this.ctx.storage.transactionSync(() => {
      this.assertEventCredential(name, thumbprint, proofExpiresAt);
      const now = Date.now(), budget = this.#budget(name);
      const retained = (budget.stockWakeAttempts ?? []).filter(row => row.settledAt === null || row.recordedAt > now - EVENT_ATTEMPT_RETENTION_MS);
      const prior = retained.find(row => row.attemptId === attemptId);
      if (prior) {
        if (prior.thumbprint !== thumbprint || prior.claim !== claim) return { status: "conflict" };
        if (prior.settledAt !== null) return { status: "conflict" };
        // Exact status/retry recovery for reservations created before source-bound claims.
        return { status: "reserved", attemptId, reservedAt: prior.reservedAt, idempotent: true,
          budget: { used: budget.wakes.filter(at => at > now - LIMITS.wake.windowMs).length,
            remaining: Math.max(0, LIMITS.wake.perHour - budget.wakes.filter(at => at > now - LIMITS.wake.windowMs).length),
            limit: LIMITS.wake.perHour, windowMs: LIMITS.wake.windowMs } };
      }
      if (messageRoute(this.ctx.storage.sql, name).owner === "event" || !!budget.pendingToken?.startsWith("event:") ||
        this.ctx.storage.sql.exec("SELECT attempt_id FROM message_wake_attempts WHERE attempt_id=?", attemptId).toArray().length > 0 ||
        this.ctx.storage.sql.exec("SELECT attempt_id FROM message_attempt_settlements WHERE attempt_id=?", attemptId).toArray().length > 0) return { status: "denied" };
      let parsedClaim: unknown;
      try { parsedClaim = JSON.parse(claim); } catch { return { status: "denied" }; }
      const checkedClaim = parseStockWakeClaimV1(parsedClaim), activation = checkedClaim && "activation" in checkedClaim ? checkedClaim.activation : null;
      if (!checkedClaim || !activation || JSON.stringify(checkedClaim) !== claim) return { status: "denied" };
      const [namespace, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
      if (!namespace || !principal || activation.principal !== principal || activation.agent !== name || activation.source.kind === "message") return { status: "denied" };
      const currentActivation = prepareSourceActivation(this.ctx.storage.sql, { principal, agent: name, live: this.#orderFacts().live }, activation.source, now);
      if (currentActivation.status !== "eligible" || !sameActivationSnapshot(activation, currentActivation.claim)) return { status: "denied" };
      const wakes = budget.wakes.filter(at => at > now - LIMITS.wake.windowMs);
      const used = wakes.length;
      const snapshot = { used, remaining: Math.max(0, LIMITS.wake.perHour - used), limit: LIMITS.wake.perHour as 10, windowMs: LIMITS.wake.windowMs as 3_600_000 };
      const genericAttempts = budget.eventAttempts ?? [];
      if (genericAttempts.some(row => row.attemptId === attemptId)) return { status: "conflict" };
      if (this.ctx.storage.kv.get(`event-native-unsettled:${name}`) || retained.some(row => row.settledAt === null) ||
        genericAttempts.some(row => !this.ctx.storage.sql.exec("SELECT attempt_id FROM message_wake_attempts WHERE attempt_id=? AND agent=?", row.attemptId, name).toArray().length))
        return { status: "pending" };
      if (budget.pendingSince !== null && now - budget.pendingSince < LIMITS.wake.pendingMs) return { status: "pending" };
      if (wakes.length >= LIMITS.wake.perHour) return { status: "over_budget", attemptId, reservedAt: null, idempotent: false, budget: snapshot };
      if (retained.length >= STOCK_WAKE_ATTEMPT_CAPACITY) return { status: "unavailable" };
      const reservedAt = now, nextWakes = [...wakes, reservedAt];
      const record: StockWakeAttemptRecord = { attemptId, recordedAt: now, reservedAt, thumbprint, claim, settledAt: null };
      this.ctx.storage.kv.put<WakeBudget>(budgetKey(name), { ...budget, wakes: nextWakes, stockWakeAttempts: [...retained, record] });
      return { status: "reserved", attemptId, reservedAt, idempotent: false,
        budget: { used: nextWakes.length, remaining: Math.max(0, LIMITS.wake.perHour - nextWakes.length), limit: LIMITS.wake.perHour, windowMs: LIMITS.wake.windowMs } };
    });
  }
  eventStockWakeAttemptStatus(name: string, thumbprint: string, attemptId: string, claim: string, proofExpiresAt: number): EventAttemptStatusResultV1 {
    return this.ctx.storage.transactionSync(() => {
      this.assertEventCredential(name, thumbprint, proofExpiresAt);
      const budget = this.#budget(name), row = (budget.stockWakeAttempts ?? []).find(item => item.attemptId === attemptId);
      const wakes = budget.wakes.filter(at => at > Date.now() - LIMITS.wake.windowMs);
      if (row && (row.thumbprint !== thumbprint || row.claim !== claim)) return { status: "denied" };
      if (row?.settledAt !== null && row?.settledAt !== undefined) return { status: "unknown", attemptId, reservedAt: null,
        budget: { used: wakes.length, remaining: Math.max(0, LIMITS.wake.perHour - wakes.length), limit: LIMITS.wake.perHour, windowMs: LIMITS.wake.windowMs } };
      return { status: row ? "reserved" : "unknown", attemptId, reservedAt: row?.reservedAt ?? null,
        budget: { used: wakes.length, remaining: Math.max(0, LIMITS.wake.perHour - wakes.length), limit: LIMITS.wake.perHour, windowMs: LIMITS.wake.windowMs } };
    });
  }
  settleEventStockWakeAttempt(name: string, thumbprint: string, attemptId: string, claim: string, reservedAt: number, proofExpiresAt: number): StockWakeSettlementResultV1 {
    return this.ctx.storage.transactionSync(() => {
      this.assertEventCredential(name, thumbprint, proofExpiresAt);
      const budget = this.#budget(name), rows = budget.stockWakeAttempts ?? [], index = rows.findIndex(row => row.attemptId === attemptId);
      if (index < 0) return { status: "unknown" };
      const row = rows[index];
      if (row.thumbprint !== thumbprint || row.claim !== claim || row.reservedAt !== reservedAt) return { status: "conflict" };
      if (row.settledAt !== null) return { status: "settled", attemptId, settledAt: row.settledAt, idempotent: true };
      const settledAt = Date.now();
      const next = rows.slice(); next[index] = { ...row, settledAt };
      this.ctx.storage.kv.put<WakeBudget>(budgetKey(name), { ...budget, stockWakeAttempts: next });
      return { status: "settled", attemptId, settledAt, idempotent: false };
    });
  }
  async readEventMessagePreparation(input: EventMessagePreparationInputV1): Promise<EventMessagePreparationResultV1> {
    const parsed = parseEventMessagePreparationInput(input);
    if (!parsed) return { status: "invalid" };
    const [namespace, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
    if (!namespace || !principal) return { status: "denied" };
    return readMessagePreparation(this.ctx.storage.sql, { namespace, principal,
      admitted: who => this.env.MESSAGING_NAMESPACE === namespace && principalAllowed(this.env, who),
      live: this.#orderFacts().live }, parsed);
  }
  /** Private source-only read; the Mailbox id supplies namespace and owner identity. */
  prepareEventSourceActivation(input: { namespace: string; principal: string; agent: string; source: Exclude<ActivationSourceV1, { kind: "message" }>; expectedSnapshot?: string }) {
    const [namespace, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
    const parsed = parseEventSourceActivationInputV1(input);
    if (!parsed) return { status: "invalid" as const };
    if (!namespace || !principal || parsed.namespace !== namespace || parsed.principal !== principal || !principalAllowed(this.env, principal)) return { status: "denied" as const };
    return prepareSourceActivation(this.ctx.storage.sql, { principal, agent: parsed.agent, live: this.#orderFacts().live }, parsed.source, Date.now(), parsed.expectedSnapshot);
  }
  /** Private service metadata read. Mailbox identity, never the request, supplies source ownership. */
  validateEventMessagePublication(input: EventMessagePublicationV1): EventMessagePublicationResultV1 {
    const parsed = parseEventMessagePublication(input);
    if (!parsed) return { status: "invalid" };
    const [namespace, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
    if (!namespace || !principal || parsed.namespace !== namespace || parsed.principal !== principal) return { status: "denied" };
    const publication = canonicalMessagePublication(this.ctx.storage.sql,
      { namespace, principal, admitted: who => principalAllowed(this.env, who), live: this.#orderFacts().live }, parsed.agent, parsed.messageId, Date.now());
    return publication && JSON.stringify(publication) === JSON.stringify(parsed)
      ? { status: "eligible", publication } : { status: "denied" };
  }
  /** Message-specific authority stays disabled without a trusted coordinator verifier. */
  reserveEventMessageAttempt(name: string, thumbprint: string, proofExpiresAt: number, input: EventMessageClaimV1): Promise<EventMessageAttemptResultV1> {
    return this.#messageAttempt(name, thumbprint, proofExpiresAt, input, true);
  }
  eventMessageAttemptStatus(name: string, thumbprint: string, proofExpiresAt: number, input: EventMessageClaimV1): Promise<EventMessageAttemptResultV1> {
    return this.#messageAttempt(name, thumbprint, proofExpiresAt, input, false);
  }
  async #messageAttempt(name: string, thumbprint: string, proofExpiresAt: number, input: EventMessageClaimV1, reserve: boolean): Promise<EventMessageAttemptResultV1> {
    const parsed = parseEventMessageClaim(input);
    if (!parsed) return { status: "invalid" };
    if (!this.#messageRoutingAuthority && !this.env.EVENT_MESSAGE_CONSUMER) return { status: "denied" };
    const sql = this.ctx.storage.sql;
    const { owner: principal } = this.#who();
    const [namespace] = JSON.parse(this.ctx.id.name ?? "[]") as [string?];
    if (!namespace) return { status: "denied" };
    const sourceOwner = { namespace, principal, admitted: (who: string) => principalAllowed(this.env, who), live: (thumbprint: string) => this.#orderFacts().live(thumbprint) };
    const current = (): string | null => {
      this.assertEventCredential(name, thumbprint, proofExpiresAt);
      const route = messageRoute(sql, name);
      if (route.owner !== "event" || route.generation !== parsed.routingGeneration || JSON.stringify(route.consumer) !== JSON.stringify(parsed.consumer)) return null;
      const publication = canonicalMessagePublication(sql, sourceOwner, name, parsed.messageId, Date.now());
      if (!publication) return null;
      if (!("activation" in parsed)) return publication.publicationId;
      const activation = currentMessageActivationClaim(sql, sourceOwner, publication, Date.now);
      return activation && sameActivationSnapshot(parsed.activation, activation) ? publication.publicationId : null;
    };
    const publication = current();
    if (publication === null) return { status: "denied" };
    const consumerQuery = { principal, agent: name, keyThumbprint: thumbprint, consumer: structuredClone(parsed.consumer),
      ...("runtimeProfile" in parsed ? { runtimeProfile: parsed.runtimeProfile } : {}) };
    // Explicit test ports retain their behavior; the default service path owns a per-call commit fence.
    const consumerCurrent = this.#messageRoutingAuthority
      ? await this.#messageRoutingAuthority.currentConsumer(consumerQuery) ? () => true : null
      : await this.#messageConsumerAdmission(consumerQuery);
    if (consumerCurrent === "unavailable") return { status: "unavailable" };
    if (!consumerCurrent) return { status: "denied" };
    return this.ctx.storage.transactionSync(() => {
      const consumerStatus = consumerCurrent();
      if (consumerStatus === "unavailable") return { status: "unavailable" };
      if (!consumerStatus || current() !== publication) return { status: "denied" };
      // A terminal attempt is historical only, even if its pending token is restored or
      // reservation retention expires. Never turn a terminal replay into another permit.
      if (sql.exec("SELECT attempt_id FROM message_attempt_settlements WHERE attempt_id=?", parsed.attemptId).toArray().length)
        return { status: "conflict" };
      const now = Date.now();
      const identity = "runtimeProfile" in parsed
        ? JSON.stringify([publication, name, thumbprint, parsed.routingGeneration, parsed.consumer, parsed.runtimeProfile, parsed.conversationId])
        : JSON.stringify([publication, name, thumbprint, parsed.routingGeneration, parsed.consumer]);
      const activationJson = "activation" in parsed ? JSON.stringify(parsed.activation) : null;
      const prior = sql.exec<{ identity: string; reserved_at: number; activation_json: string | null }>("SELECT identity,reserved_at,activation_json FROM message_wake_attempts WHERE attempt_id=?", parsed.attemptId).toArray()[0];
      const budget = this.#budget(name);
      if (prior) {
        if (prior.identity !== identity || prior.activation_json !== activationJson) return { status: "conflict" };
        const held = eventAttemptStatus(budget, parsed.attemptId, now);
        if (held.status !== "reserved" || prior.reserved_at <= now - EVENT_ATTEMPT_RETENTION_MS ||
          budget.pendingToken !== `event:${parsed.attemptId}` || budget.pendingSince === null)
          return { status: "unknown" };
        return { status: "reserved", attemptId: parsed.attemptId, reservedAt: prior.reserved_at, idempotent: true, routingGeneration: parsed.routingGeneration, budget: held.budget };
      }
      if (!reserve) return { status: "unknown" };
      if (!("activation" in parsed)) return { status: "denied" };
      // Never reinterpret a generic native reservation as a message-bound admission.
      if (eventAttemptStatus(budget, parsed.attemptId, now).status === "reserved") return { status: "conflict" };
      if (budget.pendingToken?.startsWith("event:") || (budget.pendingSince !== null && now - budget.pendingSince < LIMITS.wake.pendingMs)) return { status: "pending" };
      if (this.ctx.storage.kv.get(`event-native-unsettled:${name}`) || (budget.eventAttempts ?? []).some(row =>
        !sql.exec("SELECT attempt_id FROM message_wake_attempts WHERE attempt_id=? AND agent=?", row.attemptId, name).toArray().length) ||
        (budget.stockWakeAttempts ?? []).some(row => row.settledAt === null)) return { status: "pending" };
      if (sql.exec<{ n: number }>("SELECT count(*) AS n FROM message_wake_attempts").one().n >= MESSAGE_ATTEMPT_CAPACITY)
        return { status: "unavailable" };
      const charged = reserveEventAttempt(budget, parsed.attemptId, now);
      if (charged.result.status === "over_budget") return { status: "over_budget", budget: charged.result.budget };
      sql.exec("INSERT INTO message_wake_attempts(attempt_id,agent,identity,reserved_at,activation_json) VALUES (?,?,?,?,?)", parsed.attemptId, name, identity, now, activationJson);
      this.ctx.storage.kv.put<WakeBudget>(budgetKey(name), { ...charged.budget, pendingSince: now, pendingToken: `event:${parsed.attemptId}` });
      return { status: "reserved", attemptId: parsed.attemptId, reservedAt: now, idempotent: false, routingGeneration: parsed.routingGeneration, budget: charged.result.budget };
    });
  }

  /** Private Event service-binding transition; the coordinator verifies its committed command ACK before this call. */
  settleEventMessageCommandAttempt(name: string, thumbprint: string, proofExpiresAt: number,
    input: EventMessageCommandSettlementV1): EventMessageCommandSettlementResultV1 {
    return this.ctx.storage.transactionSync(() => {
      this.assertEventCredential(name, thumbprint, proofExpiresAt);
      const { attemptId, messageId, routingGeneration, consumer, runtimeProfile, conversationId, reservedAt, deliveryId, permitId, acknowledgmentDigest } = input;
      const [namespace, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
      const source = input.activation.source;
      if (!namespace || !principal || input.activation.principal !== principal || input.activation.agent !== name || source.kind !== "message" ||
        source.namespace !== namespace || source.messageId !== messageId || source.routeGeneration !== routingGeneration ||
        source.agentIncarnation !== input.activation.agentIncarnation || JSON.stringify(source.consumer) !== JSON.stringify(consumer))
        return { status: "denied" };
      const claim = parseEventMessageClaim({ attemptId, messageId, routingGeneration, consumer,
        activation: input.activation, runtimeProfile, conversationId });
      if (!claim || !("runtimeProfile" in claim) || !/^dly_[0-9a-f]{64}$/.test(deliveryId) ||
        !/^[0-9a-f]{64}$/.test(acknowledgmentDigest) || !/^[0-9a-f-]{36}$/.test(permitId) ||
        !Number.isSafeInteger(reservedAt) || reservedAt <= 0) return { status: "invalid" };
      const publication = JSON.stringify([namespace, principal, name, input.activation.agentIncarnation, messageId]);
      const identity = JSON.stringify([publication, name, thumbprint, routingGeneration, consumer, runtimeProfile, conversationId]);
      const row = this.ctx.storage.sql.exec<{ agent: string; identity: string; reserved_at: number; activation_json: string | null }>(
        "SELECT agent,identity,reserved_at,activation_json FROM message_wake_attempts WHERE attempt_id=?", attemptId).toArray()[0];
      if (!row || row.agent !== name || row.reserved_at !== reservedAt || !row.activation_json || row.identity !== identity) return { status: "conflict" };
      let activation: unknown;
      try { activation = JSON.parse(row.activation_json); } catch { return { status: "conflict" }; }
      if (JSON.stringify(activation) !== JSON.stringify(input.activation)) return { status: "conflict" };
      const expectedIdentity = JSON.parse(row.identity) as unknown[];
      if (!Array.isArray(expectedIdentity) || expectedIdentity.length !== 7 || expectedIdentity[0] !== publication ||
        expectedIdentity[1] !== name || expectedIdentity[2] !== thumbprint || expectedIdentity[3] !== routingGeneration ||
        JSON.stringify(expectedIdentity[4]) !== JSON.stringify(consumer) ||
        JSON.stringify(expectedIdentity[5]) !== JSON.stringify(runtimeProfile) || expectedIdentity[6] !== conversationId)
        return { status: "conflict" };
      const fact = JSON.stringify({ kind: "stock_command_accepted", attemptId, messageId, routingGeneration, consumer,
        runtimeProfile, conversationId, reservedAt, deliveryId, permitId, acknowledgmentDigest });
      const prior = this.ctx.storage.sql.exec<{ fact_json: string }>("SELECT fact_json FROM message_attempt_settlements WHERE attempt_id=?", attemptId).toArray()[0];
      if (prior) return prior.fact_json === fact ? { status: "settled", attemptId, idempotent: true } : { status: "conflict" };
      const usage = this.ctx.storage.sql.exec<{ count: number; bytes: number }>(`SELECT count(*) AS count,
        coalesce(sum(length(CAST(attempt_id AS BLOB))+length(CAST(receipt_id AS BLOB))+length(CAST(fact_json AS BLOB))+8),0) AS bytes
        FROM message_attempt_settlements`).one();
      const bytes = new TextEncoder().encode(attemptId + attemptId + fact).byteLength + 8;
      if (usage.count >= MESSAGE_SETTLEMENT_CAPACITY || usage.bytes + bytes > MESSAGE_SETTLEMENT_BYTE_CAPACITY)
        return { status: "unavailable" };
      const budgetKey = `wake-budget:${name}`, budget = this.ctx.storage.kv.get<WakeBudget>(budgetKey);
      if (!budget || budget.pendingToken !== `event:${attemptId}`) return { status: "conflict" };
      this.ctx.storage.sql.exec("INSERT INTO message_attempt_settlements(attempt_id,receipt_id,fact_json,settled_at) VALUES (?,?,?,?)",
        attemptId, attemptId, fact, Date.now());
      this.ctx.storage.kv.put<WakeBudget>(budgetKey, { ...budget, pendingSince: null, pendingToken: null });
      return { status: "settled", attemptId, idempotent: false };
    });
  }

  /** Exact, read-only proof of a prior command settlement. This cannot create a fact or clear a budget token. */
  readEventMessageCommandSettlement(input: EventMessageCommandSettlementReadV1): EventMessageCommandSettlementReadResultV1 {
    return this.ctx.storage.transactionSync(() => {
      const { attemptId, messageId, routingGeneration, consumer, runtimeProfile, conversationId, reservedAt, deliveryId, permitId, acknowledgmentDigest } = input;
      const [namespace, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
      const source = input.activation.source;
      if (!namespace || !principal || input.activation.principal !== principal || source.kind !== "message" ||
        source.namespace !== namespace || source.messageId !== messageId || source.routeGeneration !== routingGeneration ||
        source.agentIncarnation !== input.activation.agentIncarnation || JSON.stringify(source.consumer) !== JSON.stringify(consumer))
        return { status: "denied" };
      const claim = parseEventMessageClaim({ attemptId, messageId, routingGeneration, consumer,
        activation: input.activation, runtimeProfile, conversationId });
      if (!claim || !("runtimeProfile" in claim) || !/^dly_[0-9a-f]{64}$/.test(deliveryId) ||
        !/^[0-9a-f]{64}$/.test(acknowledgmentDigest) || !/^[0-9a-f-]{36}$/.test(permitId) ||
        !Number.isSafeInteger(reservedAt) || reservedAt <= 0) return { status: "invalid" };
      const publication = JSON.stringify([namespace, principal, input.activation.agent, input.activation.agentIncarnation, messageId]);
      const row = this.ctx.storage.sql.exec<{ agent: string; identity: string; reserved_at: number; activation_json: string | null }>(
        "SELECT agent,identity,reserved_at,activation_json FROM message_wake_attempts WHERE attempt_id=?", attemptId).toArray()[0];
      if (!row) return { status: "missing" };
      if (row.agent !== input.activation.agent || row.reserved_at !== reservedAt || !row.activation_json) return { status: "mismatch" };
      let activation: unknown;
      try { activation = JSON.parse(row.activation_json); } catch { return { status: "mismatch" }; }
      if (JSON.stringify(activation) !== JSON.stringify(input.activation)) return { status: "mismatch" };
      const expectedIdentity = JSON.parse(row.identity) as unknown[];
      if (!Array.isArray(expectedIdentity) || expectedIdentity.length !== 7 || expectedIdentity[0] !== publication ||
        expectedIdentity[1] !== input.activation.agent || typeof expectedIdentity[2] !== "string" || expectedIdentity[3] !== routingGeneration ||
        JSON.stringify(expectedIdentity[4]) !== JSON.stringify(consumer) ||
        JSON.stringify(expectedIdentity[5]) !== JSON.stringify(runtimeProfile) || expectedIdentity[6] !== conversationId)
        return { status: "mismatch" };
      const fact = JSON.stringify({ kind: "stock_command_accepted", attemptId, messageId, routingGeneration, consumer,
        runtimeProfile, conversationId, reservedAt, deliveryId, permitId, acknowledgmentDigest });
      const prior = this.ctx.storage.sql.exec<{ fact_json: string }>("SELECT fact_json FROM message_attempt_settlements WHERE attempt_id=?", attemptId).toArray()[0];
      if (!prior) return { status: "missing" };
      return prior.fact_json === fact ? { status: "settled", attemptId } : { status: "mismatch" };
    });
  }

  /** Reports a previously reserved/denied attempt; it never changes the shared budget. */
  eventNativeAttemptStatus(name: string, thumbprint: string, attemptId: string, proofExpiresAt: number, activation?: ActivationClaimV1): EventAttemptStatusResultV1 {
    return this.ctx.storage.transactionSync(() => {
      this.assertEventCredential(name, thumbprint, proofExpiresAt);
      const budget = this.#budget(name);
      // Status is admission-bearing: Event may skip reserve when it sees "reserved".
      if (this.#genericAdmissionBlocked(name, attemptId, budget))
        return { status: "denied" };
      const result = eventAttemptStatus(budget, attemptId, Date.now());
      if (result.status === "reserved" && (!!result.activation !== !!activation ||
        (result.activation && activation && !sameActivationSnapshot(result.activation, activation)))) return { status: "denied" };
      return { status: result.status, attemptId, reservedAt: result.reservedAt, budget: result.budget };
    });
  }

  // Agent enrollment (spec 2026-10-07-r4-agent-enrollment.md). The SQL is enrollment-store.ts; these only
  // authorize and make each mutation one transaction. The first group is the owner page's: `actor` is the
  // verified principal, and this Mailbox is that principal's. The second is the code Durable Object's,
  // after it checked the code, the proof of possession and the strikes.

  /** The principal this Mailbox belongs to, from its name; refuses another's. Defense in depth: the admin API already opens only the caller's own. */
  #owner(actor: string): void {
    const [, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
    if (!principal || typeof actor !== "string" || actor.toLowerCase() !== principal.toLowerCase()) throw fail("forbidden", "that enrollment belongs to another account");
  }
  /** Returns the id of the open enrollment a retry (same `mintId`) replaced, or null. */
  beginEnrollment(actor: string, input: { id: string; agent: string; grants: StartingGrant[]; expiresAt: number; mintId?: string; create?: boolean }): string | null {
    this.#owner(actor);
    return this.ctx.storage.transactionSync(() => enrollment.begin(this.ctx.storage.sql, { ...input, principal: actor.toLowerCase() }, Date.now()));
  }
  enrollment(actor: string, id: string): enrollment.EnrollmentView {
    this.#owner(actor);
    return enrollment.one(this.ctx.storage.sql, id, Date.now());
  }
  enrollments(actor: string): enrollment.EnrollmentView[] {
    this.#owner(actor);
    return enrollment.list(this.ctx.storage.sql, Date.now());
  }
  async confirmEnrollment(actor: string, id: string, typed: string) {
    this.#owner(actor);
    const gate = await this.#stepUp();
    return this.ctx.storage.transactionSync(() => {
      const now = Date.now();
      return enrollment.confirm(this.ctx.storage.sql, id, typed, now, (agent, startsWith) => {
        // Activation is where authority starts (plan 5.11): an agent that holds some, or an enrollment that starts it with permissions, is a signed `agent-enroll` act.
        // Otherwise the session confirms, and the key is inert until an act lists it.
        if (startsWith || keys.holdsAuthority(this.ctx.storage.sql, agent, now)) {
          gate.require("agent-enroll", `Confirming a computer for ${agent}`);
        }
        // Whichever branch: with enforce requested (met or not) a session-confirmed key is inert until an act lists it.
        return gate.provisional("agent-enroll") ? "provisional" : "active";
      });
    });
  }
  denyEnrollment(actor: string, id: string): void {
    this.#owner(actor);
    enrollment.deny(this.ctx.storage.sql, id);
  }
  discardEnrollment(actor: string, id: string): void {
    this.#owner(actor);
    this.ctx.storage.transactionSync(() => {
      const gone = enrollment.discard(this.ctx.storage.sql, actor.toLowerCase(), id);
      // What activation observing counted for the agent lives in kv, not in a table: it goes with the agent.
      if (gone !== null) this.ctx.storage.kv.delete(activation.observedKey(gone));
    });
  }
  redeemEnrollment(input: Parameters<typeof enrollment.redeem>[1]): void {
    enrollment.redeem(this.ctx.storage.sql, input, Date.now());
  }
  flagEnrollmentConflict(id: string): void {
    enrollment.flagConflict(this.ctx.storage.sql, id);
  }
  enrollmentOutcome(id: string) {
    return enrollment.outcome(this.ctx.storage.sql, id, Date.now());
  }

  // MESSAGING.createAgent (plan 10.7): the session counts a request per workspace when it stages the card,
  // and creates the agent, bound to the workspace the host attested, only when the owner approves it.

  reserveAgentCreation(workspaceId: string): void {
    enrollment.reserveCreation(this.ctx.storage.kv, workspaceId, Date.now());
  }
  /**
   * Creates the agent and binds it, atomically. Idempotent: a replay of an apply whose reply was lost finds the exact
   * pairing it made (an agent of this name, bound to this workspace) and succeeds without changing anything. Any other
   * existing agent or binding is a conflict, as before.
   */
  createWorkspaceAgent(name: string, workspaceId: string): void {
    this.ctx.storage.transactionSync(() => {
      const sql = this.ctx.storage.sql;
      // Only an os agent has a workspace, so a match on the workspace is a match on the kind too.
      const existing = sql.exec<{ workspace_id: string | null }>("SELECT workspace_id FROM agents WHERE name = ?", agentName(name)).toArray()[0];
      if (existing?.workspace_id === workspaceId) return;
      registry.registerAgent(sql, name, "os", Date.now());
      registry.bindWorkspace(sql, name, workspaceId);
    });
  }

  oauthBinding(profile: string): OAuthBinding | null { return registry.oauthBinding(this.ctx.storage.sql, profile); }
  oauthBindings(): OAuthBinding[] { return registry.oauthBindings(this.ctx.storage.sql); }
  async bindOAuth(profile: string, agent: string): Promise<OAuthBinding> {
    const gate = await this.#stepUp();
    return this.ctx.storage.transactionSync(() => {
      gate.require("bind-existing", `Binding the OAuth connection to ${agent}`); // for every agent, as bindWorkspace (#805)
      return registry.bindOAuth(this.ctx.storage.sql, profile, agentName(agent));
    });
  }
  revokeOAuth(profile: string, generation: string): boolean { return registry.revokeOAuth(this.ctx.storage.sql, profile, generation); }
  resolveOAuth(profile: string, expiresAt: number): { agent: string; credential: Extract<AgentCredential, { kind: "oauth" }> } {
    const binding = registry.authorizeOAuth(this.ctx.storage.sql, profile, expiresAt);
    return { agent: binding.agent, credential: { kind: "oauth", profile, generation: binding.generation,
      expiresAt: Math.min(expiresAt, Date.now() + OAUTH_LEASE_MS) } };
  }
  authorizeOAuth(profile: string, authenticatedUntil: number): OAuthBinding {
    return registry.authorizeOAuth(this.ctx.storage.sql, profile, authenticatedUntil);
  }
  agentForCredential(credential: AgentCredential): string | null {
    return registry.agentForCredential(this.ctx.storage.sql, credential);
  }
  /** `taskTypes` (#597): parsed by the caller (taskTypesOf); absent or null covers any type. */
  async grant(input: { agent: string; to: string; mode: GrantMode; expiresAt: number | null; taskTypes?: string[] | null }): Promise<Grant> {
    const gate = await this.#stepUp();
    return this.ctx.storage.transactionSync(() => {
      const to = addressOf(input.to);
      // Every new permission widens (P5c-b, plan 5.11); revoking one does not.
      gate.require("grant", `Letting ${input.agent} send to ${input.to}`);
      scopes.assertMayGrant(this.ctx.storage.sql, input.agent, to, this.#who().owner); // the taint rule (plan 9.5 item 4), in the step that creates it
      return registry.createGrant(this.ctx.storage.sql, { agent: input.agent, to, mode: input.mode, expiresAt: input.expiresAt, taskTypes: input.taskTypes ?? null }, Date.now()); // fields named, never `...input`: a session never mints `wake`
    });
  }
  /** Refuses (`restricted_taint`) a permission from `agent` to `to` that grant() would refuse: the owner page asks before it makes an offer to the other person. */
  async assertMayGrant(agent: string, to: string): Promise<void> {
    const gate = await this.#stepUp();
    this.ctx.storage.transactionSync(() => {
      // Asked first, before the offer is filed at the other owner's Mailbox: a refused session call leaves nothing there. grant() asks again and does the logging.
      gate.require("grant", `Letting ${agent} send to ${to}`, true);
      scopes.assertMayGrant(this.ctx.storage.sql, agentName(agent), addressOf(to), this.#who().owner);
    });
  }
  /** Refuses (`restricted_taint`) a message from `agent` to `to` that issue() would refuse: the OS session asks before it stages a card that could only fail at apply. */
  assertNotRestricted(agent: string, to: string): void {
    this.#assertNotTainted(agentName(agent), addressOf(to), Date.now());
  }
  /**
   * Records another owner's grant to one of this principal's agents as an offer awaiting acceptance,
   * once the offering agent is confirmed in its owner's registry, so no one can fill this page with
   * made-up agent names. Returns nothing: the offerer never learns whether it was accepted.
   */
  async offer(input: { agent: string; from: string; expiresAt: number | null }): Promise<void> {
    const from = addressOf(input.from, "from");
    if (from.agent === null) throw fail("invalid", "a grant comes from an agent");
    if (!(await this.#peer(from.principal).hasAgent(from.agent))) throw fail("not_found", `no agent named ${from.agent} is registered by its owner`);
    registry.offer(this.ctx.storage.sql, { agent: input.agent, from, expiresAt: input.expiresAt }, Date.now());
  }
  hasAgent(name: string): boolean {
    return registry.hasAgent(this.ctx.storage.sql, name);
  }
  async acceptOffer(id: string, expiresAt: number | null, taskTypes: string[] | null = null): Promise<Grant> {
    const gate = await this.#stepUp();
    return this.ctx.storage.transactionSync(() => {
      gate.require("grant", "Accepting a permission");
      return registry.acceptOffer(this.ctx.storage.sql, id, expiresAt, taskTypes, Date.now());
    });
  }
  revokeGrant(id: string): Grant {
    return registry.revokeGrant(this.ctx.storage.sql, id, Date.now());
  }
  /** Revoke and inspect the remaining pair in one synchronous storage turn, without listing grants. */
  revokeGrantForAdmin(id: string): { grant: Grant; hasActiveGrant: boolean } {
    return this.ctx.storage.transactionSync(() => {
      const sql = this.ctx.storage.sql;
      const now = Date.now();
      const grant = registry.revokeGrant(sql, id, now);
      const peer = addressOf(grant.peer);
      const hasActiveGrant = grant.direction === "out" && registry.hasActiveOutGrant(sql, grant.agent, peer, now, grant.id);
      return { grant, hasActiveGrant };
    });
  }
  hasActiveOutGrant(agent: string, to: string): boolean {
    return registry.hasActiveOutGrant(this.ctx.storage.sql, agent, addressOf(to, "to"), Date.now());
  }
  withdrawOffer(agent: string, from: string): void {
    registry.withdrawOffer(this.ctx.storage.sql, agent, addressOf(from, "from"), Date.now());
  }
  permissionPage(cursor?: string | null): { grants: Grant[]; nextCursor: string | null } {
    return registry.permissionPage(this.ctx.storage.sql, Date.now(), cursor);
  }
  grants(): Grant[] {
    return registry.listGrants(this.ctx.storage.sql, Date.now());
  }
  /**
   * The mode a send of `type` from `agent` to `to` would use now: a check before staging, never the
   * authority. Refuses (no_grant) without one, naming the type when a grant for the pair exists (#597).
   * `forward`: `type` is the forwarded request's, for the refusal's wording.
   */
  outboundMode(agent: string, to: string, type: string | null, forward = false): GrantMode {
    const sql = this.ctx.storage.sql;
    const address = addressOf(to);
    const now = Date.now();
    const mode = registry.outboundMode(sql, agent, address, now, type);
    if (!mode) throw registry.grantRefusal(sql, agent, address, null, now, type, { forward });
    return mode;
  }
  accepts(agent: string, from: string, type: string | null): boolean {
    return registry.accepts(this.ctx.storage.sql, agent, addressOf(from, "from"), Date.now(), type);
  }
  recipients(agent: string): string[] {
    return registry.grantTargets(this.ctx.storage.sql, agent, Date.now());
  }
  /** The budget check before staging (session submit): never the authority, issue() is. */
  checkBudget(agent: string | null, to: string, threadId: string | null): void {
    assertBudget(this.ctx.storage.sql, agent, wireOf(addressOf(to)), threadId, Date.now());
  }

  // R4 origin binding (origin.ts): which inbox message started which Execution run. Each is one synchronous step.

  originVerify(input: VerifyOriginInputV1) { return origin.verify(this.ctx.storage.sql, this.#who(), input); }
  originBind(input: RunOriginInputV1) { return origin.bind(this.ctx.storage.sql, this.#who(), input); }
  originRelease(input: RunOriginInputV1) { return origin.release(this.ctx.storage.sql, this.#who(), input); }
  originReport(input: ReportRunInputV1) { return origin.report(this.ctx.storage.sql, this.#who(), input); }
  /** The inbox row for `id`, whichever of this owner's agents it is for: admin-api's verifyDigest, which never shows its content. */
  inboxMessage(id: string): Found | null { return this.#get("in", id, Date.now()); }
  /** verifyChain for a message in this person's mailbox; a thread rooted at an order is judged against the order act stored here (order-verify.ts). */
  verifyChain(chain: string[], message?: Message): Promise<Verdict> {
    const sql = this.ctx.storage.sql;
    return keyRing(this.env).then((ring) => verifyChainOnline(sql, presenceConfig(presenceVarsOf(this.env)), this.#who().owner, chain, ring.publicKeys, message));
  }
  /** What the order checks read of this deployment (R4 P5b): this Mailbox's person, whether a key is an active signer under the deployed pins, and the consequence rule. */
  #orderFacts(): { owner: string; live: orders.CredentialLive; rule: Mode } {
    const owner = this.#who().owner;
    // Lazy: the presence configuration is parsed only when an ordered hop asks about its signing key.
    const live: orders.CredentialLive = (thumbprint) => orders.credentialLive(this.ctx.storage.sql, presenceConfig(presenceVarsOf(this.env)), owner, Date.now())(thumbprint);
    return { owner, live, rule: authorityFlags(this.env).consequenceRule };
  }
  #who(): origin.Who {
    const [, owner] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
    return { owner: owner ?? "", admitted: !!owner && principalAllowed(this.env, owner), now: Date.now() };
  }

  // R4 P3b: the reads behind the admin's Agent page and Explain, and the refusals ring. Each read is one synchronous step over the
  // predicates enforcement calls, so what it says is one moment's state. None of them changes a grant, a key, a message or a wake.

  /**
   * Notes a refusal in `agent`'s ring. Called by whoever ran the failing check (post(), the OS session) once it failed, never by a
   * check, so a refusal rolled back with its transaction is still noted and Explain, which runs the checks, writes nothing.
   * False when it was not noted (no such agent, or a check or code outside the closed lists).
   */
  recordRefusal(agent: string, entry: { check: unknown; code: unknown; peer?: unknown; taskType?: unknown; messageId?: unknown; kind?: unknown; parentId?: unknown }): boolean {
    const sql = this.ctx.storage.sql;
    return registry.hasAgent(sql, agent) && recordRefusal(sql, agent, entry, Date.now());
  }
  /** `agent`'s ring, newest first; null: every agent's newest 100. */
  refusals(agent: string | null) {
    return listRefusals(this.ctx.storage.sql, agent === null ? null : agentName(agent), 100);
  }
  /** One agent as its page shows it, or null when there is none by that name. The wire address and `stop` are the admin's to add. */
  agentFacts(name: string, oauthProfile: string | null): Omit<AgentDescription, "agent" | "stop"> | null {
    const sql = this.ctx.storage.sql;
    const now = Date.now();
    const agent = registry.agentsNamed(sql, [agentName(name)])[0];
    if (!agent) return null;
    const { grants, truncated } = registry.agentGrants(sql, agent.name, now);
    const permissions = grants.map((grant) => projectGrant(grant, now));
    return {
      kind: agent.kind,
      workspaceId: agent.workspaceId,
      createdAt: agent.createdAt,
      suspendedAt: agent.suspendedAt,
      callable: registry.callable(sql, agent.name, oauthProfile),
      computers: registry.agentComputers(sql, agent.name),
      wake: this.#wakeOf(agent.name),
      permissions,
      permissionsTruncated: truncated,
      inventory: { live: permissions.filter((p) => p.state === "active").length, noExpiry: permissions.filter((p) => p.noExpiry).length },
      refusals: listRefusals(sql, agent.name, 20).map(({ agent: _agent, ...entry }) => entry),
      restrictedUntil: ((until) => (until === null ? null : new Date(until).toISOString()))(scopes.restrictedUntil(sql, agent.name, now)),
      scope: scopes.liveRows(sql, agent.name).map((row) => ({ term: row.text, preset: row.preset, createdAt: row.createdAt })),
      tasks: tasks.declarationsOf(sql, agent.name),
      activation: { policy: activation.policyOf(sql, agent.name)!, observed: activation.observedOf(this.ctx.storage.kv, agent.name) },
    };
  }
  /**
   * Explain's questions of the sender's own Mailbox: the answers of the predicates a send from `agent` meets (post()'s, issue()'s and the
   * door's). A reply or a forward is resolved through its parent in the agent's own inbox, as issue() does (#follow), and the effect's
   * recipient, type and thread are the parent's, never the caller's: nothing about the recipient is looked at before that resolves.
   */
  senderFacts(input: { agent: string; kind: "send" | "forward" | "reply"; to: string | null; type: string | null; parentId: string | null; oauthProfile: string | null }): SenderFacts {
    const sql = this.ctx.storage.sql;
    const now = Date.now();
    const agent = registry.agentsNamed(sql, [agentName(input.agent)])[0];
    const nothing: SenderFacts = { exists: false, kind: null, callable: false, suspended: false, tainted: false, parent: null, target: null, type: null, threadId: null, grant: null, pair: [], pairTruncated: false, budget: null };
    if (!agent) return nothing;
    const [, principal] = JSON.parse(this.ctx.id.name ?? "[]") as [string?, string?];
    const self: Address = { principal: principal ?? "", agent: agent.name };
    const asked = input.to === null ? undefined : agentAddressOf(input.to);
    const facts: SenderFacts = {
      ...nothing,
      exists: true,
      kind: agent.kind,
      callable: registry.callable(sql, agent.name, input.oauthProfile),
      suspended: registry.isSuspended(sql, agent.name),
      tainted: scopes.isRestricted(sql, agent.name, now),
      target: asked ? wireOf(asked) : null,
      type: input.kind === "send" ? input.type : null,
    };
    let to: Address | undefined = asked;
    if (input.kind !== "send") {
      // The door finds the message in THIS agent's inbox (another agent's is no such message); issue() then refuses it as it does a send.
      let parent: Stored | null = null;
      try {
        const found = this.#getOwn("in", messageIdOf(input.parentId), agent.name, now);
        if (!found) throw fail("not_found", "no such message in your inbox");
        const restricted = found.message.flags.containsRestrictedData || found.message.flags.sharingProhibited;
        try {
          parent = this.#follow(input.kind, found.message.id, self, input.kind === "reply" ? asked : undefined, now).parent;
          facts.parent = { found: true, restricted, refusal: null };
        } catch (error) {
          facts.parent = { found: true, restricted, refusal: verdictOf(error) };
        }
      } catch (error) {
        facts.parent = { found: false, refusal: verdictOf(error) };
      }
      if (parent === null) return facts;
      facts.threadId = parent.threadId;
      if (input.kind === "reply") {
        const back = partyAddress(parent.sender);
        to = back.agent === null ? undefined : back;
        facts.target = to ? wireOf(to) : null;
      } else {
        facts.type = checkedType(parent);
      }
    }
    if (!to) return facts;
    if (input.kind !== "reply") {
      const mode = registry.outboundMode(sql, agent.name, to, now, facts.type);
      facts.grant = mode !== null ? { mode } : refusalOf("no_grant", registry.grantRefusal(sql, agent.name, to, null, now, facts.type, { forward: input.kind === "forward" }));
    }
    try {
      assertBudget(sql, agent.name, wireOf(to), facts.threadId, now);
    } catch (error) {
      if (codeOf(error) !== "over_budget") throw error; // a failing query is not a budget
      facts.budget = refusalOf("over_budget", error);
    }
    const pair = registry.pairGrantIds(sql, agent.name, to, now);
    facts.pair = pair.ids;
    facts.pairTruncated = pair.truncated;
    return facts;
  }
  /** Explain's questions of the recipient's Mailbox: deliver()'s and post()'s predicates for a message to `agent`. `from` is asked about only when `checkAcceptance`. */
  recipientFacts(input: { agent: string; from: string | null; type: string | null; checkAcceptance: boolean }): RecipientFacts {
    const sql = this.ctx.storage.sql;
    const now = Date.now();
    const agent = agentName(input.agent);
    return {
      exists: registry.hasAgent(sql, agent),
      suspended: registry.isSuspended(sql, agent),
      accepts: input.checkAcceptance ? registry.accepts(sql, agent, addressOf(input.from, "from"), now, input.type) : null,
      inboxFull: orders.inboxFull(sql, now, agent),
    };
  }
  // R4 P4a: scope rows (scopes.ts), declared tasks (tasks.ts), the activation policy (activation.ts) and the restricted-read taint. These
  // authorize nothing: the admin API (the owner's session) and AuthorityMemory (Memory's private door) do. Each mutation is one transaction.

  agentScope(agent: string): scopes.ScopeRow[] {
    return scopes.liveRows(this.ctx.storage.sql, agentName(agent));
  }
  async setAgentScope(agent: string, terms: Term[], was?: Term[]): Promise<scopes.ScopeChange & { rows: scopes.ScopeRow[] }> {
    const name = agentName(agent);
    const gate = await this.#stepUp();
    return this.ctx.storage.transactionSync(() => {
      // Compare-and-set: a caller that drew its form from `was` replaces the rows only if they are still exactly those, in this one transaction.
      if (was !== undefined) {
        const held = new Set(scopes.liveRows(this.ctx.storage.sql, name).map((row) => row.text));
        const drawn = new Set(was.map(printTerm));
        if (held.size !== drawn.size || [...held].some((text) => !drawn.has(text))) throw fail("conflict", `the Memory rows of ${name} changed after the form you saved was drawn; nothing was changed`);
      }
      const change = scopes.setScope(this.ctx.storage.sql, name, terms, this.#who().owner, Date.now());
      // Only a change that adds a row widens (P5c-b); a refusal here throws inside the transaction, which rolls the rows back.
      if (change.added.length > 0) gate.require("agent-scope", `Widening what ${name} may do`);
      return { ...change, rows: scopes.liveRows(this.ctx.storage.sql, name) };
    });
  }
  async applyScopePreset(agent: string, preset: scopes.PresetId): Promise<scopes.PresetDiff & { rows: scopes.ScopeRow[] }> {
    const name = agentName(agent);
    const gate = await this.#stepUp();
    return this.ctx.storage.transactionSync(() => {
      const diff = scopes.applyPreset(this.ctx.storage.sql, name, preset, this.#who().owner, Date.now());
      if (diff.added.length > 0) gate.require("agent-scope", `Giving ${name} the ${preset} rows`);
      return { ...diff, rows: scopes.liveRows(this.ctx.storage.sql, name) };
    });
  }
  async declareTask(agent: string, declaration: TaskDeclaration): Promise<void> {
    const gate = await this.#stepUp();
    this.ctx.storage.transactionSync(() => {
      const name = agentName(agent);
      tasks.refuseManaged(this.ctx.storage.sql, name, declaration);
      // Tightening a declaration is the session's; anything that is not an attenuation is a signed `declare-task` act (VS-11).
      if (tasks.declarationWidens(tasks.declaredType(this.ctx.storage.sql, name, declaration.type), declaration)) gate.require("declare-task", `Declaring ${declaration.type} for ${name}`);
      tasks.declare(this.ctx.storage.sql, name, declaration, Date.now());
    });
  }
  /** Why `body` does not fit what `agent` declares for `type`, as the sender is told, or null: post()'s early check, run in the recipient's own Mailbox. */
  /**
   * post()'s look at the consequence rule for a message from another person to `agent` (plan 5.4): refuses `order_required` under `enforce` when `agent`
   * declares `type` consequential. Such a message is never inside an order (an ordered thread is same-owner at every hop).
   */
  assertNoOrderNeeded(agent: string, type: string): void {
    orders.consequence(this.ctx.storage.sql, authorityFlags(this.env).consequenceRule, { kind: "request", recipient: wireOf({ principal: this.#who().owner, agent: agentName(agent) }), type, ordered: false, id: "" });
  }
  bodyProblem(agent: string, type: string, body: string): string | null {
    const name = agentName(agent);
    const declared = tasks.declaredType(this.ctx.storage.sql, name, type);
    const problem = declared === null ? null : tasks.bodyProblem(declared, body);
    return problem === null ? null : tasks.bodyRefusal(name, type, problem);
  }
  taskDeclarations(agent: string): TaskDeclaration[] {
    return tasks.declarationsOf(this.ctx.storage.sql, agentName(agent));
  }
  /**
   * What each of `agents` declares, for a sender's `recipients` listing (decision D19 A): by agent name. Another person's agent shows a declared type
   * only if its owner accepts `from` for it, so a sender is shown no more than a send would get through.
   */
  declaredFor(agents: string[], from: string): Record<string, tasks.DeclaredTask[]> {
    const sql = this.ctx.storage.sql;
    const sender = addressOf(from, "from");
    const now = Date.now();
    const owner = this.#who().owner;
    const out: Record<string, tasks.DeclaredTask[]> = {};
    if (agents.length > tasks.DECLARED_BATCH) throw fail("invalid", `declaredFor names at most ${tasks.DECLARED_BATCH} agents`);
    for (const raw of agents) {
      const name = agentName(raw);
      if (!registry.hasAgent(sql, name)) continue;
      const visible = tasks.declarationsOf(sql, name).filter((decl) => sender.principal === owner || registry.accepts(sql, name, sender, now, decl.type));
      if (visible.length > 0) out[name] = visible.map(tasks.declaredTask);
    }
    return out;
  }
  /** An agent's activation policy and what observing it has counted so far. */
  activationOf(agent: string): { policy: activation.ActivationPolicy; observed: activation.Observed | null } {
    const name = agentName(agent);
    const policy = activation.policyOf(this.ctx.storage.sql, name);
    if (!policy) throw fail("not_found", `no agent named ${name}`);
    return { policy, observed: activation.observedOf(this.ctx.storage.kv, name) };
  }
  async setActivation(agent: string, input: unknown): Promise<activation.ActivationPolicy> {
    const policy = activation.parseActivation(input);
    const gate = await this.#stepUp();
    return this.ctx.storage.transactionSync(() => {
      const name = agentName(agent);
      const current = activation.policyOf(this.ctx.storage.sql, name);
      // `granted`, another transport or a longer sender list lets more start a turn (plan 5.11); the opposite is the session's.
      if (current !== null && activation.activationWidens(current, policy)) gate.require("activation", `Changing how ${name} is woken`);
      return activation.setPolicy(this.ctx.storage.sql, name, policy);
    });
  }
  /** Taints `agent` (plan 9.5): Memory reports a read of restricted memory. False when this person has no such agent. */
  markRestricted(agent: string): boolean {
    return scopes.markRestricted(this.ctx.storage.sql, agentName(agent), Date.now());
  }
  /**
   * Memory's last look at a token it verified (AuthorityMemory.resolveAgent): the credential still names an active external agent of an admitted
   * person, and what the agent's ceiling and taint are now. Refuses otherwise (`forbidden`).
   */
  memoryAuthority(name: string, thumbprint: string, proofExpiresAt: number): { terms: Term[]; restricted: boolean; memoryScoped: boolean } {
    const sql = this.ctx.storage.sql;
    const now = Date.now();
    if (!Number.isSafeInteger(proofExpiresAt) || proofExpiresAt <= now || !this.#who().admitted || !registry.credentialActive(sql, name, thumbprint))
      throw fail("forbidden", "this agent credential is no longer authorized");
    return { terms: scopes.memoryTerms(sql, name), restricted: scopes.isRestricted(sql, name, now), memoryScoped: scopes.everHeldMemoryRow(sql, name) };
  }
  /** The agent a host-attested workspace is bound to, for Memory's OS facet, and whether it is suspended. */
  workspaceAgent(workspaceId: string): { agent: string | null; suspended: boolean } {
    const agent = registry.agentForWorkspace(this.ctx.storage.sql, workspaceId);
    return { agent, suspended: agent !== null && registry.isSuspended(this.ctx.storage.sql, agent) };
  }
  /**
   * What stays session-tier is told to the owner (plan 9.2 item 8, VS-05): recorded in the authority log and queued as an out-of-band notice (notify.ts),
   * both labelled as not hardware-proven.
   */
  recordNotice(kind: string, ref: string): void {
    const { owner } = this.#who();
    const now = Date.now();
    // The log entry and the notice row are one step; the push goes after the reply (and the alarm retries it).
    this.ctx.storage.transactionSync(() => {
      appendLog(this.ctx.storage.sql, { kind: `notice.${kind}`, actor: owner, detail: { ref, label: "not hardware-proven" } }, now);
      queueNotice(this.ctx.storage.sql, sessionNotice(kind, ref), now);
    });
    presence.pushAfter(this.#presenceHost());
  }

  // Human presence (R4 P5a-2). Thin on purpose: the SQL and the rules are credentials.ts, register.ts, acts.ts, liveness.ts, enforcement.ts and notify.ts, run by
  // presence-host.ts. The trust root (pins, floors, windows, flags) is read from this Mailbox's own deployed env and from nowhere a caller can reach: no method takes it as an argument. Nothing here changes a grant, a key, a message or a wake.
  beginCredential(intent: unknown, windowSecret: unknown) { return presence.beginCredential(this.#presenceHost(), intent, windowSecret); }
  registerCredential(challengeId: unknown, response: unknown, windowSecret: unknown) { return presence.registerCredential(this.#presenceHost(), challengeId, response, windowSecret); }
  openAct(actId: unknown) { return presence.openAct(this.#presenceHost(), actId); }
  completeAct(actId: unknown, response: unknown, second: unknown) { return presence.completeAct(this.#presenceHost(), actId, response, second); }
  liveness() { return presence.liveness(this.#presenceHost()); }
  finishLiveness(actId: unknown, response: unknown) { return presence.finishLiveness(this.#presenceHost(), actId, response); }
  draftAct(input: unknown, returnOrigins: unknown) { return presence.draftAct(this.#presenceHost(), input, returnOrigins); }
  cancelAct(actId: unknown) { return presence.cancelAct(this.#presenceHost(), actId); }
  credentials() { return presence.credentials(this.#presenceHost()); }
  revokeCredential(thumbprint: unknown) { return presence.revokeCredential(this.#presenceHost(), thumbprint); }
  enforcement() { return presence.enforcement(this.#presenceHost()); }
  notices() { return presence.notices(this.#presenceHost()); }
  notice(id: unknown) { return presence.notice(this.#presenceHost(), id); }
  /** Sends the notices that are due. Also run after every change that queues one and by the alarm, which a failed push asks for; idempotent, and a notice is claimed before it is sent. */
  flushNotices(): Promise<void> { return presence.flush(this.#presenceHost()); }

  #presenceHost(): presence.PresenceHost {
    const who = this.#who();
    return {
      sql: this.ctx.storage.sql, tx: (work) => this.ctx.storage.transactionSync(work), now: () => Date.now(), principal: who.owner, admitted: who.admitted, env: this.env,
      after: (work) => this.ctx.waitUntil(work),
      forgetWake: (agent) => this.#forgetWake(agent),
      enrollAllowed: (principal) => enrollAllowed(this.env, principal),
      // Orders (P5b): the knob, the key a root is signed with, and the wake of the agent it was filed for.
      orderEmission: () => authorityFlags(this.env).orderEmission,
      receiptKeys: () => keyRing(this.env),
      rootFiled: (agent, envelope, order) => this.ctx.waitUntil(this.wake(agent, envelope, order)),
      // A root is an inbox row like any delivery: the same alarm before its transaction and the same Event and webhook obligations inside it.
      inbound: { arm: (message) => this.#armInbound(message), stage: (message, now) => this.#stageInbound(message, now) },
      // One alarm serves the events drain and the notice retries: set it only if none is due sooner.
      schedule: async (at) => {
        const scheduled = await this.ctx.storage.getAlarm();
        if (scheduled === null || scheduled > at) await this.ctx.storage.setAlarm(at);
      },
    };
  }

  grantTotals(): { live: number; noExpiry: number } {
    return registry.grantTotals(this.ctx.storage.sql, Date.now());
  }
  /** Newest first, 100 at most; `verify` also walks every retained link. */
  authorityLog(before: number | null, verify: boolean): AuthorityLogView {
    const sql = this.ctx.storage.sql;
    return { entries: logPage(sql, before), verified: verify ? verifyLog(sql) : null, limit: 100 };
  }
}
