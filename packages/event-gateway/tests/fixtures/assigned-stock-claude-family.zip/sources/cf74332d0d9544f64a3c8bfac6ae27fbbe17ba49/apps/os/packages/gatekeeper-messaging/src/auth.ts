// Access for the agent host, on Knitli Memory's verifier (gatekeeper-memory/src/auth.ts, itself on
// openapi-operator's verifyJwtClaims): it requires this app's AUD. Only the config differs.

import type { AuthConfig } from "gatekeeper-memory/src/auth.ts";
import { allowed, parseAllowedPrincipals, parseServiceTokens } from "gatekeeper-memory/src/principals.ts";
import { AccessDenied, AccessUnavailable, canonicalEmail, verifyJwtClaims, type AccessPorts } from "openapi-operator/src/access.ts";
import { ACCESS_DEVICE } from "./enrollment-contract.ts";
import { principalAllowed } from "gatekeeper-memory/src/principals.ts";
import { audienceShared, type AccessAudienceVar } from "./access-audiences.ts";

export type MessagingAuthVars = {
  ACCESS_ISSUER: string;
  ACCESS_AUD: string;
  ALLOWED_PRINCIPALS: string;
  MESSAGING_SERVICE_TOKENS: string;
};

/** A plain-text answer, errors included: never cached, never sniffed into something else, never framed or given a script's powers. */
export const text = (status: number, body: string): Response =>
  new Response(body, {
    status,
    headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff", "content-security-policy": "default-src 'none'; frame-ancestors 'none'; base-uri 'none'" },
  });

export function authConfig(env: MessagingAuthVars): AuthConfig {
  const { ACCESS_ISSUER: issuer, ACCESS_AUD: audience } = env;
  if (!issuer || !audience) throw new AccessUnavailable();
  try {
    return {
      issuer,
      audience,
      reviewers: [],
      ...parseAllowedPrincipals(env.ALLOWED_PRINCIPALS),
      serviceTokens: parseServiceTokens(env.MESSAGING_SERVICE_TOKENS),
    };
  } catch {
    throw new AccessUnavailable();
  }
}

export type OAuthAuthVars = MessagingAuthVars & {
  MESSAGES_HOST: string;
  MESSAGES_OAUTH_HOST?: string;
  ACCESS_OAUTH_AUD?: string; MESSAGING_OAUTH_PROFILE?: string;
};

const HOST_LABEL = /^[a-z0-9-]+$/;
const HOST_TLD = /^[a-z]{2,63}$/;

function validHostname(hostname: string): boolean {
  if (hostname.length < 1 || hostname.length > 253) return false;
  const labels = hostname.split(".");
  if (labels.length < 2) return false;
  for (const label of labels) {
    if (label.length < 1 || label.length > 63 || !HOST_LABEL.test(label) || label.startsWith("-") || label.endsWith("-")) return false;
  }
  return HOST_TLD.test(labels[labels.length - 1]!);
}

/** The one OAuth host, or null when OAuth is unconfigured (the messages-chatgpt alias was dropped in #962); an exact match, never a suffix or wildcard. */
export function oauthHostname(env: OAuthAuthVars): string | null {
  const canonical = env.MESSAGES_OAUTH_HOST ?? "";
  const audience = env.ACCESS_OAUTH_AUD ?? "";
  const profile = env.MESSAGING_OAUTH_PROFILE ?? "";
  if (!canonical && !audience && !profile) return null;
  if (!canonical || !audience || !profile || !validHostname(canonical) ||
    canonical === env.MESSAGES_HOST) {
    throw new AccessUnavailable();
  }
  return canonical;
}

/** A configured surface identifies the profile. Request arguments never select an agent. */
export function oauthConfigured(env: OAuthAuthVars): boolean {
  try {
    return oauthHostname(env) !== null;
  } catch {
    return false;
  }
}

/**
 * The one OAuth profile authenticateOAuth() serves, or null when it serves none (OAuth unconfigured or misconfigured). A binding
 * of any other profile can never authenticate, so nothing that asks whether an agent can be called counts one.
 */
export function oauthProfile(env: OAuthAuthVars): string | null {
  const profile = env.MESSAGING_OAUTH_PROFILE;
  const audience = env.ACCESS_OAUTH_AUD;
  if (!oauthConfigured(env) || !profile || !audience || !/^[a-z0-9-]{1,32}$/.test(profile) || audience === env.ACCESS_AUD) return null;
  return profile;
}

/** Managed OAuth is verified at Access; trust only its signed, single-audience human assertion. */
export async function authenticateOAuth(request: Request, env: OAuthAuthVars, ports: AccessPorts): Promise<{ principal: string; profile: string; expiresAt: number }> {
  const hostname = oauthHostname(env);
  const profile = oauthProfile(env);
  const audience = env.ACCESS_OAUTH_AUD;
  if (!profile || !audience || hostname !== new URL(request.url).hostname) throw new AccessUnavailable();
  const token = request.headers.get("Cf-Access-Jwt-Assertion");
  if (!token) throw new AccessDenied();
  const claims = await verifyJwtClaims(token, "access", { issuer: env.ACCESS_ISSUER, audience }, ports);
  const aud = typeof claims.aud === "string" ? [claims.aud] : claims.aud;
  if (!Array.isArray(aud) || aud.length !== 1 || aud[0] !== audience || typeof claims.email !== "string" || typeof claims.common_name === "string") throw new AccessDenied();
  // canonicalEmail on the value as given, before lower-casing: a non-ASCII look-alike (the Kelvin sign lower-cases to "k") is refused.
  if (!canonicalEmail(claims.email)) throw new AccessDenied();
  const principal = claims.email.toLowerCase();
  if (!principalAllowed(env, principal)) throw new AccessDenied();
  // Replaying a long-lived assertion cannot continually renew background authority.
  // Access must supply a fresh assertion after 15 minutes; do not retain an OAuth token here.
  const expiresAt = Math.min((claims.exp as number) * 1000, (claims.iat as number) * 1000 + 15 * 60_000, ports.now() * 1000 + 15 * 60_000);
  if (expiresAt <= ports.now() * 1000) throw new AccessDenied();
  return { principal, profile, expiresAt };
}

export { ACCESS_AUDIENCES, audienceShared, type AccessAudienceVar } from "./access-audiences.ts";
/**
 * Who is redeeming a code, from the setup host's Access assertion (R4 P2c): Messaging verifies the token itself and trusts no
 * email or device the setup Worker could have written. Null refuses: a blank ACCESS_SETUP_AUD (the setup host is not deployed), a
 * token Access did not sign for that app, or one that is not a WARP sign-in naming one device. A JWKS outage is thrown instead
 * (AccessUnavailable), so the computer is told to try again rather than that its code was refused.
 */
export async function setupIdentity(
  assertion: string,
  env: { ACCESS_ISSUER: string; ACCESS_SETUP_AUD: string } & Partial<Record<AccessAudienceVar, string>>,
  ports: AccessPorts,
): Promise<{ email: string; device: string } | null> {
  const audience = env.ACCESS_SETUP_AUD;
  // The setup app must be its own: an audience shared with another Access app would let that app's tokens redeem codes.
  if (!audience || audienceShared(env, "ACCESS_SETUP_AUD")) return null;
  let claims: Record<string, unknown>;
  try {
    claims = await verifyJwtClaims(assertion, "access", { issuer: env.ACCESS_ISSUER, audience }, ports);
  } catch (error) {
    if (error instanceof AccessDenied) return null;
    throw error;
  }
  const aud = typeof claims.aud === "string" ? [claims.aud] : claims.aud;
  // Any common_name at all, whatever its type, marks a service token.
  if (!Array.isArray(aud) || aud.length !== 1 || aud[0] !== audience || "common_name" in claims) return null;
  if (claims.warp_as_auth !== true || typeof claims.device_id !== "string" || !ACCESS_DEVICE.test(claims.device_id)) return null;
  // canonicalEmail on the claim as signed, before lower-casing, as the setup Worker does: a non-ASCII look-alike is refused.
  if (!canonicalEmail(claims.email)) return null;
  return { email: claims.email.toLowerCase(), device: claims.device_id };
}

export const ENROLL_REFUSED = "this account cannot add agents or computers: that is for the accounts the deployment names in messaging.enrollPrincipals";
/**
 * Whether `principal` may make enrollment codes, agents (a workspace agent too) and agent keys (R4 P2c, T29, D3): ENROLL_PRINCIPALS entries as ALLOWED_PRINCIPALS
 * reads them, so the break-glass account stays an administrator that never enrolls a computer. Blank adds no rule; a malformed list
 * refuses everyone.
 */
export function enrollAllowed(env: { ENROLL_PRINCIPALS: string }, principal: string): boolean {
  // Only a person's email enrolls: a service principal never does, list or not.
  if (!canonicalEmail(principal)) return false;
  if (!env.ENROLL_PRINCIPALS.trim()) return true;
  try {
    return allowed(principal, parseAllowedPrincipals(env.ENROLL_PRINCIPALS));
  } catch {
    return false;
  }
}
