import { spawn, spawnSync, type SpawnSyncOptionsWithStringEncoding } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { dirname, join, relative, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { isDeepStrictEqual } from "node:util";
import { type ParseError, parse, printParseErrorCode } from "jsonc-parser";
import { resolveBinEntry } from "../cloudflare-os/scripts/bin-entry.ts";
import { pnpmCommand } from "../cloudflare-os/scripts/pnpm-command.ts";
import type {
  BaseConfigs,
  BuildCommand,
  DeploymentConfig,
  GeneratedConfigs,
  GitHubSourceDeployment,
  OpenApiDeployment,
  OpenApiKey,
  ProdWranglerConfig,
  RouterRoute,
} from "./deployment-config.ts";
import { AI_GATEWAY_PROVIDERS } from "./deployment-config.ts";
import {
  ciRun,
  defaultGhPort,
  publishRecordCommand,
  snapshotRecord,
  scrubbedEnv,
  snapshotSource,
  withDeploymentRecord,
  WORKER_NAME,
  type RecordOptions,
  type SourceSnapshot,
  type WranglerPort,
} from "./deploy-record.ts";
import {
  createCliHolderId,
  createRegistryClient,
  readExport,
  reconcileMutation,
  withDeploymentLease,
  DEPLOY_CLIENT_SECRET_ENV,
  type DeploymentMutationKind,
  type LeaseContext,
} from "./openapi-registry-client.ts";
import type { OpenApiDeploymentExportV1 } from "../packages/gatekeeper-openapi/src/installation-contracts.ts";
import { decodeOperatorPublicKey } from "../packages/gatekeeper-openapi/src/operator/contracts.ts";
import { canonicalEmail, parseAccessConfig } from "../packages/openapi-operator/src/access.ts";
import { ManualCanarySchema } from "../packages/event-runtime/src/manual-canary-scope.ts";
import { NativeAdmissionCanarySchema } from "../packages/event-runtime/src/native-admission-canary.ts";
import {
  SERVICE_PRINCIPAL,
  allowed,
  parseAllowedPrincipals,
  parseReviewers,
  parseServiceOwners,
  parseServiceTokens,
} from "../packages/gatekeeper-memory/src/principals.ts";
import { parsePublicKeys } from "../packages/gatekeeper-messaging/src/receipts.ts";
import { ENFORCED_KINDS, MAX_WINDOWS, MODES, presenceConfig } from "../packages/gatekeeper-messaging/src/presence.ts";
import { ACTIVATION_DELAY_HOURS, parsePinnedFile } from "../packages/authority/src/webauthn.ts";
import { isCanonicalPrincipal } from "../packages/authority/src/scope.ts";
import { publicHttpsOrigin } from "../packages/gatekeeper-messaging/src/ntfy-host.ts";
import { MAX_ANCHORS_PER_PRINCIPAL, MIN_ANCHORS_PER_PRINCIPAL, isoTime } from "../packages/authority/src/contract-kit.ts";
import { MAX_WINDOW_MS } from "./presence-window.ts";
import { createCloudflareApiClient, assertEventQueueRetention } from "./openapi-cloudflare-resources.ts";
import { parseCatalog } from "../packages/gatekeeper-execution/src/catalog.ts";
import { assertExecutionTasksFresh } from "./generate-execution-tasks.ts";
import {
  apiId,
  displayConfig,
  providerConfig,
  segmentConfig,
  type ConnectorConfigEnv,
} from "../packages/gatekeeper-openapi/src/config.ts";

// runner-auth.ts's RUNNER_OIDC_AUDIENCE, restated: this file is loaded by the installation
// runner under plain node, which cannot resolve runner-auth.ts's `.js` import suffixes, so it
// must not import it (see validateOpenApiOperator's note). deploy.test.ts pins the two equal.
export const RUNNER_OIDC_AUDIENCE = "https://openapi-admin.knitli.app/v1/installations/runner";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
// One deployment per checkout; use separate worktrees for concurrent deploys.
const generatedName = "wrangler.prod.jsonc";
const packageDirs = {
  router: "cloudflare-os/packages/router",
  workshop: "cloudflare-os/packages/workshop-backend",
  context: "cloudflare-os/packages/gatekeeper-context",
  scheduler: "cloudflare-os/packages/gatekeeper-scheduler",
  customGatekeeper: "packages/custom-gatekeeper",
  memory: "packages/gatekeeper-memory",
  messaging: "packages/gatekeeper-messaging",
  adminUi: "packages/admin-ui",
  setup: "packages/setup",
  presence: "packages/presence-ui",
  messagingEgress: "packages/gatekeeper-messaging-egress",
  errorReporter: "packages/error-reporter",
  github: "cloudflare-os/packages/gatekeeper-github",
  linear: "cloudflare-os/packages/gatekeeper-linear",
  microsoft: "cloudflare-os/packages/gatekeeper-microsoft",
  mcp: "cloudflare-os/packages/gatekeeper-mcp",
  mcpPortal: "cloudflare-os/packages/gatekeeper-mcp-portal",
  email: "cloudflare-os/packages/gatekeeper-email",
  cloudflare: "cloudflare-os/packages/gatekeeper-cloudflare",
  x: "cloudflare-os/packages/gatekeeper-x",
  slack: "cloudflare-os/packages/gatekeeper-slack",
  websearch: "cloudflare-os/packages/gatekeeper-websearch",
  openApi: "packages/gatekeeper-openapi",
  openApiOperator: "packages/openapi-operator",
  catalogAgent: "packages/catalog-agent",
  aiInference: "packages/ai-inference",
  aiExecutor: "cloudflare-os/packages/gatekeeper-ai-executor",
  execution: "packages/gatekeeper-execution",
  executionRuntime: "packages/execution-runtime",
  eventRuntime: "packages/event-runtime",
  eventsEdge: "packages/events-edge",
} as const;
/** Every key `deploymentOrder` can return: a fixed package, or one API entry. */
export type DeployKey = keyof typeof packageDirs | OpenApiKey;
function openApiIdOf(key: string): string | undefined {
  return key.startsWith("openApi:") ? key.slice("openApi:".length) : undefined;
}
/** Repository-relative package directory for a deploy key. */
export function packageDir(key: DeployKey): string {
  return openApiIdOf(key) === undefined ? packageDirs[key as keyof typeof packageDirs] : packageDirs.openApi;
}
/** The generated config's file name inside its package: per entry for the connector, fixed elsewhere. */
export function generatedFileName(key: DeployKey): string {
  const id = openApiIdOf(key);
  return id === undefined ? generatedName : `wrangler.prod.${id}.jsonc`;
}
/** The on-disk path of one generated wrangler config. Exported for the D4 runner. */
export function generatedPath(key: DeployKey): string {
  return join(root, packageDir(key), generatedFileName(key));
}
export const defaultContextArtifactsNamespace = "gatekeeper-context-collections";
const accountIdPattern = /^[a-f\d]{32}$/i;

const requiredPaths = [
  "accountId",
  "workers.router.name",
  "workers.workshop.name",
  "workers.context.name",
  "workers.scheduler.name",
  "workers.customGatekeeper.name",
  "access.issuer",
  "access.audience",
  "access.admins",
  "aiGateway.enabled",
  "aiExecutors.enabled",
  "errorReporting.enabled",
  "customGatekeeper.name",
  "customGatekeeper.message",
  "observability.enabled",
  "observability.headSamplingRate",
  "observability.logs.invocationLogs",
  "observability.traces.enabled",
  "observability.traces.headSamplingRate",
];

// `aiGateway.accountId` is deliberately absent: null is its normal value, meaning "the gateway
// lives in the deployment's own account".
const aiGatewayPaths = ["aiGateway.name", "aiGateway.providers"];

const aiExecutorPaths = [
  "aiExecutors.gateway.accountId",
  "aiExecutors.gateway.name",
  "workers.aiInference.name",
  "workers.aiExecutor.name",
];

const errorReportingPaths = [
  "workers.errorReporter.name",
  "errorReporting.environment",
];

const resourcePaths = [
  "context.kvNamespaceId",
  "resources.blueprintsKvNamespaceId",
  "resources.avatarsKvNamespaceId",
  "resources.blueprintContentBucket",
];

function valueAt(object: DeploymentConfig, path: string): unknown {
  return path
    .split(".")
    .reduce<unknown>(
      (value, key) => (value as Record<string, unknown> | undefined)?.[key],
      object,
    );
}

/**
 * A Worker identity `validateConfig` has already required for the feature that is switched on.
 * These stay optional on `DeploymentConfig` because they are genuinely absent when the feature is
 * off; narrowing here rather than asserting non-null means a gap in validation surfaces as a named
 * error instead of `undefined` reaching a generated wrangler config.
 */
function requiredWorkerName(
  worker: { name: string } | undefined,
  path: string,
): string {
  if (!worker) {
    throw new Error(`deployment config is missing ${path}`);
  }
  return worker.name;
}

/**
 * The deployment's public origin: the address the router answers on.
 *
 * Two things read it, and both are load-bearing in different ways. `PUBLIC_BASE_URL` is what
 * upstream builds absolute links and OAuth redirect URIs from. The Context Gatekeeper's
 * `sharingDomain` prop is a data-isolation boundary, so a value that changes silently hides
 * collections rather than breaking a link.
 *
 * `validateConfig` guarantees that one of the two sources below is present, and that they agree when
 * both are.
 */
export function publicOrigin(config: DeploymentConfig): string {
  const explicit = config.publicBaseUrl;
  if (explicit) return explicit.replace(/\/$/, "");
  return `https://${config.workers.router.route.customDomain!}`;
}

function validatePublicBaseUrl(
  config: DeploymentConfig,
  route: RouterRoute,
): void {
  const value = config.publicBaseUrl;
  if (value === undefined) {
    throw new Error(
      "publicBaseUrl must be present. Use null to derive it from " +
        "workers.router.route.customDomain.",
    );
  }
  if (value === null) {
    if (!route.customDomain) {
      throw new Error(
        "publicBaseUrl is required on a workersDev route. The account's workers.dev subdomain is " +
          "not in deployment.jsonc and wrangler exposes no command to look it up, so there is " +
          "nothing to derive the public origin from -- and PUBLIC_BASE_URL and the Context sharing " +
          "boundary both need one. Set it to https://<router-name>.<subdomain>.workers.dev.",
      );
    }
    return;
  }
  if (typeof value !== "string") {
    throw new Error("publicBaseUrl must be null or a string.");
  }
  let origin: string;
  try {
    origin = new URL(value).origin;
  } catch {
    throw new Error(
      "publicBaseUrl must be an HTTPS origin such as https://os.example.com.",
    );
  }
  if (!value.startsWith("https://") || origin !== value) {
    throw new Error(
      "publicBaseUrl must be an HTTPS origin only, with no path and no trailing slash.",
    );
  }
  if (route.customDomain && value !== `https://${route.customDomain}`) {
    throw new Error(
      `publicBaseUrl (${value}) does not match workers.router.route.customDomain ` +
        `(${route.customDomain}). Context data would then be scoped to a hostname this deployment ` +
        "does not answer on. Leave publicBaseUrl null to derive it from the custom domain.",
    );
  }
  // On a workersDev route there is nothing to cross-check the value against the way a custom domain
  // checks itself, so check its shape instead. The account's workers.dev subdomain is unknowable
  // here, but the rest of the hostname is not: wrangler serves the Worker at
  // <worker-name>.<subdomain>.workers.dev, so anything else is a typo or an unrelated host -- and it
  // would silently become both PUBLIC_BASE_URL and the Context isolation boundary, hiding existing
  // Context data and breaking every absolute link and OAuth redirect the backend builds.
  if (route.workersDev) {
    const labels = new URL(value).host.split(".");
    const [worker, subdomain, ...suffix] = labels;
    const routerName = config.workers.router.name;
    if (
      labels.length !== 4 ||
      suffix.join(".") !== "workers.dev" ||
      !/^[a-z\d](?:[a-z\d-]{0,61}[a-z\d])?$/.test(subdomain ?? "")
    ) {
      throw new Error(
        `publicBaseUrl (${value}) is not a workers.dev origin. On a workersDev route it must be ` +
          `https://${routerName}.<subdomain>.workers.dev, where <subdomain> is the account's ` +
          "workers.dev subdomain. It becomes PUBLIC_BASE_URL and the Context sharing boundary, so a " +
          "hostname this deployment does not answer on hides Context data and breaks redirects.",
      );
    }
    if (worker !== routerName) {
      throw new Error(
        `publicBaseUrl (${value}) names Worker "${worker}", but the router is ` +
          `"${routerName}". The router is what answers on the public origin, so this origin belongs ` +
          `to a different Worker. Use https://${routerName}.${subdomain}.workers.dev, or change ` +
          "workers.router.name if the other name is the one you meant.",
      );
    }
  }
}

/** `inventory.extraWorkers`: unique Worker names, nothing else. */
function validateInventory(config: DeploymentConfig): void {
  const inventory: unknown = config.inventory;
  if (inventory === undefined) return;
  if (!inventory || typeof inventory !== "object" || Array.isArray(inventory) || Object.keys(inventory).some((key) => key !== "extraWorkers")) {
    throw new Error("inventory must be an object with only an extraWorkers member.");
  }
  const extra: unknown = (inventory as { extraWorkers?: unknown }).extraWorkers;
  if (extra === undefined) return;
  if (!Array.isArray(extra)) throw new Error("inventory.extraWorkers must be an array of Worker names.");
  if (!extra.every((name) => typeof name === "string" && WORKER_NAME.test(name))) {
    throw new Error("inventory.extraWorkers names must use lowercase letters, numbers, and hyphens.");
  }
  if (new Set(extra).size !== extra.length) throw new Error("inventory.extraWorkers names must be unique.");
  const produced = new Set(Object.values(config.workers).map((worker) => worker.name));
  const clash = extra.find((name) => produced.has(name));
  if (clash !== undefined) throw new Error(`inventory.extraWorkers names ${clash}, a Worker the generator produces (workers.*.name); list only Workers it does not.`);
}

/** `taskRoot` is where the execution task manifests are read from: the checkout, except in the test that proves a stale one is refused. */
export function validateConfig(config: DeploymentConfig, taskRoot: string = root): DeploymentConfig {
  if (config.openApiPublisher !== undefined) {
    const publisher = config.openApiPublisher;
    if (!publisher || typeof publisher !== "object" || Array.isArray(publisher) ||
      Object.keys(publisher).length !== 1 || typeof publisher.enabled !== "boolean") {
      throw new Error("openApiPublisher must contain only a boolean enabled member.");
    }
  }
  if (config.webPush !== undefined) {
    const push = config.webPush;
    if (!push || typeof push !== "object" || Array.isArray(push) ||
      Object.keys(push).length !== 1 || typeof push.enabled !== "boolean") {
      throw new Error("webPush must contain only a boolean enabled member.");
    }
  }
  for (const key of ["github", "linear", "microsoft", "mcp", "mcpPortal", "email", "cloudflare"] as const) {
    if (typeof config[key]?.deploy !== "boolean") {
      throw new Error(`${key}.deploy must be a boolean.`);
    }
  }
  for (const key of ["github", "linear", "microsoft", "cloudflare"] as const) {
    if (
      config[key].deploy &&
      (typeof config[key].clientId !== "string" || !config[key].clientId.trim())
    ) {
      throw new Error(
        `${key}.clientId must be a non-empty string when ${key}.deploy is true.`,
      );
    }
  }
  // Newer than the rest, so optional: a deployment file written before them leaves them off.
  for (const key of ["x", "slack", "websearch"] as const) {
    if (config[key] !== undefined && typeof config[key]?.deploy !== "boolean") {
      throw new Error(`${key}.deploy must be a boolean.`);
    }
  }
  if (config.x?.deploy && (typeof config.x.clientId !== "string" || !config.x.clientId.trim())) {
    throw new Error("x.clientId must be a non-empty string when x.deploy is true.");
  }
  if (config.slack?.deploy && (typeof config.slack.clientId !== "string" || !config.slack.clientId.trim())) {
    throw new Error("slack.clientId must be a non-empty string when slack.deploy is true.");
  }
  if (config.x?.dailyReadLimit !== undefined && config.x?.dailyReadLimit !== null &&
    (!Number.isSafeInteger(config.x.dailyReadLimit) || config.x.dailyReadLimit < 0)) {
    // The worker silently falls back to its default on a bad value, so refuse it here instead.
    throw new Error("x.dailyReadLimit must be a non-negative integer, or omitted.");
  }
  // Microsoft's third credential: the worker refuses OAuth without the tenant (knitli-os #66
  // getOAuthConfig), so a tenantless deploy is rejected here rather than at connect time.
  if (
    config.microsoft.deploy &&
    (typeof config.microsoft.tenantId !== "string" || !config.microsoft.tenantId.trim())
  ) {
    throw new Error("microsoft.tenantId must be a non-empty string when microsoft.deploy is true.");
  }

  validateAiExecutors(config);
  validateExecution(config, taskRoot);
  validateOpenApis(config);
  validateOpenApiOperator(config);
  validateMemory(config);
  validateMessaging(config);
  validateEventRuntime(config);
  validateInventory(config);
  validateMessagingEgress(config);


  if (config.mcpPortal.deploy) {
    const portal = config.mcpPortal;
    if (portal.url !== null) {
      if (typeof portal.url !== "string" || !portal.url.trim()) {
        throw new Error("mcpPortal.url must be null or an https URL.");
      }
      let parsed: URL;
      try {
        parsed = new URL(portal.url);
      } catch {
        throw new Error(`mcpPortal.url is not a URL: ${portal.url}`);
      }
      if (parsed.protocol !== "https:") {
        throw new Error("mcpPortal.url must use https.");
      }
      if (parsed.username || parsed.password) {
        throw new Error("mcpPortal.url must not embed credentials.");
      }
    }
    const auth = portal.auth ?? "oauth";
    if (!["oauth", "none", "token"].includes(auth)) {
      throw new Error("mcpPortal.auth must be oauth, none, or token.");
    }
    if (auth === "token" && portal.url === null) {
      throw new Error("mcpPortal token auth needs a url to send the token to.");
    }
    if (
      portal.name !== undefined &&
      portal.name !== null &&
      (typeof portal.name !== "string" || !portal.name.trim())
    ) {
      throw new Error(
        "mcpPortal.name must be omitted, null, or a non-empty string.",
      );
    }
    if (
      portal.trustAnnotations !== undefined &&
      typeof portal.trustAnnotations !== "boolean"
    ) {
      throw new Error("mcpPortal.trustAnnotations must be a boolean.");
    }
  }

  // Outbound sending (knitli-os #69): the domain and the sender prefix are one switch. Either
  // alone would sit inert -- the worker throws unless both are set -- so a half-configured
  // deployment is refused rather than shipped dark. Dormant when email.deploy is false, like
  // every other integration's credentials.
  if (config.email.deploy) {
    const { domain, sendPrefix } = config.email;
    for (const [name, value] of [["domain", domain], ["sendPrefix", sendPrefix]] as const) {
      if (value !== undefined && value !== null && typeof value !== "string") {
        throw new Error(`email.${name} must be omitted, null, or a string.`);
      }
    }
    const hasDomain = typeof domain === "string" && domain.trim() !== "";
    const hasPrefix = typeof sendPrefix === "string" && sendPrefix.trim() !== "";
    if (hasDomain !== hasPrefix) {
      throw new Error(
        "email.domain and email.sendPrefix must both be set or both be omitted: the worker leaves sending off while either is unset.",
      );
    }
    // Mirrors the worker's own DOMAIN pattern (gatekeeper-email/src/fork/send.ts): a bare
    // LDH hostname, so anything accepted here also passes the worker's address checks.
    if (
      hasDomain &&
      !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/i.test(domain!.trim())
    ) {
      throw new Error("email.domain must be a bare domain (letters, digits, hyphens, dots).");
    }
    // The mailbox-name charset (gatekeeper-email/src/email.ts validateEmailName): a prefix
    // outside it could never match a real sender, so it would read configured and send nothing.
    if (hasPrefix && !/^[a-z0-9._+-]{1,64}$/i.test(sendPrefix!.trim())) {
      throw new Error(
        "email.sendPrefix must be a mailbox-name prefix (letters, digits, dots, underscores, plus, hyphens).",
      );
    }
  }

  validateAdminUi(config);
  validateSetup(config);
  validatePresenceHost(config);
  validatePresence(config);
  validateNotify(config);
  validateAuthority(config);

  const activePaths = [
    ...requiredPaths,
    ...(config.aiGateway?.enabled ? aiGatewayPaths : []),
    ...(config.aiExecutors?.enabled ? aiExecutorPaths : []),
    ...(config.execution?.enabled ? ["workers.execution.name", "workers.executionRuntime.name"] : []),
    ...(config.openApiOperator?.enabled ? ["workers.openApiOperator.name", "workers.catalogAgent.name"] : []),
    ...(config.errorReporting?.enabled ? errorReportingPaths : []),
    ...(config.github.deploy ? ["workers.github.name"] : []),
    ...(config.linear.deploy ? ["workers.linear.name"] : []),
    ...(config.microsoft.deploy ? ["workers.microsoft.name"] : []),
    ...(config.mcp.deploy ? ["workers.mcp.name"] : []),
    ...(config.mcpPortal.deploy ? ["workers.mcpPortal.name"] : []),
    ...(config.email.deploy ? ["workers.email.name"] : []),
    ...(config.cloudflare.deploy ? ["workers.cloudflare.name"] : []),
    ...(config.x?.deploy === true ? ["workers.x.name"] : []),
    ...(config.slack?.deploy === true ? ["workers.slack.name"] : []),
    ...(config.websearch?.deploy === true ? ["workers.websearch.name"] : []),
  ];
  for (const path of activePaths) {
    const value = valueAt(config, path);
    if (
      value === undefined ||
      value === null ||
      value === "" ||
      (Array.isArray(value) && !value.length)
    ) {
      throw new Error(`Missing required deployment value: ${path}`);
    }
  }

  for (const path of resourcePaths) {
    const value = valueAt(config, path);
    if (
      value === undefined ||
      (value !== null && (typeof value !== "string" || !value))
    ) {
      throw new Error(
        `Deployment resource must be null or a non-empty string: ${path}`,
      );
    }
  }

  let activeConfig: DeploymentConfig = config.aiGateway.enabled
    ? config
    : { ...config, aiGateway: { enabled: false } };
  if (!config.aiExecutors.enabled) {
    activeConfig = {
      ...activeConfig,
      aiExecutors: { enabled: false },
      workers: {
        ...activeConfig.workers,
        aiInference: undefined,
        aiExecutor: undefined,
      },
    };
  }
  if (!config.execution?.enabled) {
    activeConfig = { ...activeConfig, execution: { enabled: false },
      workers: { ...activeConfig.workers, execution: undefined, executionRuntime: undefined } };
  }
  if (!config.openApiOperator?.enabled) {
    activeConfig = { ...activeConfig, openApiOperator: { enabled: false },
      workers: { ...activeConfig.workers, openApiOperator: undefined, catalogAgent: undefined } };
  }
  if (!config.errorReporting.enabled) {
    activeConfig = {
      ...activeConfig,
      workers: { ...activeConfig.workers, errorReporter: undefined },
      errorReporting: { enabled: false },
    };
  }
  // Dormant integrations deliberately accept placeholders: none of their configuration reaches a
  // generated Worker. Keep the deploy switch itself in the placeholder scan, but remove everything
  // the switch makes inert.
  const placeholderConfig = structuredClone(activeConfig) as unknown as Record<
    string,
    unknown
  >;
  const placeholderWorkers = placeholderConfig.workers as Record<
    string,
    unknown
  >;
  for (const key of ["github", "linear", "microsoft", "mcp", "mcpPortal", "email", "cloudflare"] as const) {
    if (!config[key].deploy) {
      placeholderConfig[key] = { deploy: false };
      delete placeholderWorkers[key];
    }
  }
  for (const key of ["x", "slack", "websearch"] as const) {
    if (config[key]?.deploy !== true) {
      delete placeholderConfig[key];
      delete placeholderWorkers[key];
    }
  }
  if (!config.messagingEgress?.deploy) {
    delete placeholderConfig.messagingEgress;
    delete placeholderWorkers.messagingEgress;
  }
  if (!config.eventRuntime?.deploy) {
    delete placeholderConfig.eventRuntime;
    delete placeholderWorkers.eventRuntime;
  }
  if (!gatewayEdgeDeploys(config)) delete placeholderWorkers.eventsEdge;
  const placeholder = JSON.stringify(placeholderConfig).match(/<[^>]+>/)?.[0];
  if (placeholder)
    throw new Error(`Replace deployment placeholder ${placeholder}.`);

  const stringPaths = activePaths.filter(
    (path) =>
      ![
        "access.admins",
        "aiGateway.enabled",
        "aiGateway.providers",
        "aiExecutors.enabled",
        "errorReporting.enabled",
        "observability.enabled",
        "observability.headSamplingRate",
        "observability.logs.invocationLogs",
        "observability.traces.enabled",
        "observability.traces.headSamplingRate",
      ].includes(path),
  );
  for (const path of stringPaths) {
    if (typeof valueAt(config, path) !== "string") {
      throw new Error(`Deployment value must be a string: ${path}`);
    }
  }

  if (!accountIdPattern.test(config.accountId)) {
    throw new Error(
      "Cloudflare account IDs must be 32 hexadecimal characters.",
    );
  }
  assertWorkerNamesUnique(config, config.openApis ?? []);

  const route = config.workers.router.route;
  if (!route || Boolean(route.workersDev) === Boolean(route.customDomain)) {
    throw new Error(
      "Set exactly one router route: workersDev or customDomain.",
    );
  }
  if (route.workersDev !== undefined && route.workersDev !== true) {
    throw new Error("Router workersDev must be boolean true when selected.");
  }
  if (
    route.customDomain !== undefined &&
    typeof route.customDomain !== "string"
  ) {
    throw new Error("Router customDomain must be a string.");
  }
  const hostnamePattern =
    /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
  if (route.customDomain && !hostnamePattern.test(route.customDomain)) {
    throw new Error("Router customDomain must be a lowercase hostname.");
  }

  validatePublicBaseUrl(config, route);

  const sharingDomain = config.context.sharingDomain;
  if (
    sharingDomain !== null &&
    (typeof sharingDomain !== "string" || !sharingDomain.trim())
  ) {
    throw new Error(
      "context.sharingDomain must be null or a non-empty string. null scopes Context data to the " +
        "deployment's public origin, which is what the hosted deploy does.",
    );
  }

  const issuer = new URL(config.access.issuer);
  if (
    issuer.protocol !== "https:" ||
    issuer.origin !== config.access.issuer.replace(/\/$/, "")
  ) {
    throw new Error("Cloudflare Access issuer must be an HTTPS origin only.");
  }
  if (
    !config.access.audience.trim() ||
    config.access.audience !== config.access.audience.trim()
  ) {
    throw new Error(
      "Cloudflare Access audience must not be blank or padded with whitespace.",
    );
  }
  if (
    !Array.isArray(config.access.admins) ||
    !config.access.admins.every(
      (email) => typeof email === "string" && /^[^@\s]+@[^@\s]+$/.test(email),
    )
  ) {
    throw new Error("Every Access administrator must be an email address.");
  }

  validateAiGateway(config);
  if (config.aiExecutors.enabled && aiGatewayPlan(config)?.needsToken) {
    throw new Error(
      "When aiExecutors.enabled, only private ai-inference may require " +
        "CF_AI_GATEWAY_API_TOKEN. Use Workshop's same-account Workers AI transport.",
    );
  }

  if (typeof config.errorReporting.enabled !== "boolean") {
    throw new Error("Error reporting enabled must be a boolean.");
  }
  const release = config.errorReporting.release;
  if (
    release !== null &&
    release !== undefined &&
    (typeof release !== "string" ||
      !release.trim() ||
      release !== release.trim())
  ) {
    throw new Error(
      "Error reporting release must be null or a non-padded string.",
    );
  }

  const artifactsConfig = config.context.artifacts;
  if (
    artifactsConfig !== undefined &&
    (artifactsConfig === null ||
      typeof artifactsConfig !== "object" ||
      Array.isArray(artifactsConfig))
  ) {
    throw new Error(
      "Context Artifacts configuration must be an object when present.",
    );
  }
  const artifactsEnabled = artifactsConfig?.enabled;
  if (artifactsEnabled !== undefined && typeof artifactsEnabled !== "boolean") {
    throw new Error("Context Artifacts enabled must be a boolean.");
  }
  const artifactsNamespace = artifactsConfig?.namespace;
  if (
    artifactsNamespace !== undefined &&
    (typeof artifactsNamespace !== "string" ||
      !/^[a-z\d][a-z\d._-]*$/i.test(artifactsNamespace))
  ) {
    throw new Error(
      "Context Artifacts namespace must be omitted or start with a letter or number and use only letters, numbers, dots, underscores, and hyphens.",
    );
  }

  const sampling = config.observability.headSamplingRate;
  if (typeof config.observability.enabled !== "boolean") {
    throw new Error("Observability enabled must be a boolean.");
  }
  if (typeof sampling !== "number" || sampling < 0 || sampling > 1) {
    throw new Error("Observability headSamplingRate must be between 0 and 1.");
  }
  if (
    typeof config.observability.logs.invocationLogs !== "boolean" ||
    typeof config.observability.traces.enabled !== "boolean"
  ) {
    throw new Error("Observability log and trace controls must be booleans.");
  }
  const traceSampling = config.observability.traces.headSamplingRate;
  if (
    typeof traceSampling !== "number" ||
    traceSampling < 0 ||
    traceSampling > 1
  ) {
    throw new Error("Observability trace sampling must be between 0 and 1.");
  }
  validatePrincipals(config);
  return config;
}

/**
 * Principal parity (R4 P0): the master `principals` list is the one place a person is added, so widening any
 * service needs a second, visible edit. It never merges lists: each service keeps its own, narrower one (Execution
 * stays one person), and every entry of each must be listed here, exactly as written. Events have no list of their
 * own (the Worker gets Messaging's), and an execution profile's list only narrows execution's, so neither is repeated.
 * Two doors bypass a service's own list and are checked too: a Memory service token mapped to an email (or to a
 * `svc:` principal, through its owner) is admitted without ALLOWED_PRINCIPALS, and the OpenAPI operator has its own
 * `access.allowedEmails`. Messaging's tokens must already name one of its allowed people (validateMessaging).
 * A Memory token's email is that exact person (gatekeeper-memory's auth.ts takes the mapped principal as written and
 * applies no domain rule to it), so it must be listed in `principals` verbatim: a master "@domain" entry does not
 * stand in for it, the same exactness as every list here.
 */
function validatePrincipals(config: DeploymentConfig): void {
  const lists: [string, readonly string[]][] = [["access.admins", config.access.admins]];
  const { memory, messaging, execution, openApiOperator } = config;
  if (memory?.deploy) {
    lists.push(["memory.allowedPrincipals", memory.allowedPrincipals]);
    for (const principal of new Set(Object.values(memory.serviceTokens)))
      lists.push(SERVICE_PRINCIPAL.test(principal) ? [`memory.serviceOwners[${principal}]`, [memory.serviceOwners[principal] ?? principal]] : ["memory.serviceTokens", [principal]]);
  }
  if (messaging?.deploy) lists.push(["messaging.allowedPrincipals", messaging.allowedPrincipals]);
  if (execution?.enabled) lists.push(["execution.allowedPrincipals", execution.allowedPrincipals!]);
  if (openApiOperator?.enabled) lists.push(["openApiOperator.access.allowedEmails", openApiOperator.access.allowedEmails]);
  const master = config.principals;
  if (master === undefined) {
    if (memory?.deploy || messaging?.deploy || execution?.enabled)
      throw new Error("principals is required when memory, messaging or execution is deployed: the master list every service's principals must be in.");
    return;
  }
  if (!Array.isArray(master) || !master.length || !master.every((entry) => typeof entry === "string" && !entry.includes(",")))
    throw new Error("principals must be an explicit non-empty list.");
  try { parseAllowedPrincipals(master.join(",")); }
  catch { throw new Error("principals contains an invalid principal."); }
  const listed = new Set(master.map((entry) => entry.trim().toLowerCase()));
  const stray = lists.flatMap(([label, list]) => list.filter((entry) => !listed.has(entry.trim().toLowerCase())).map((entry) => `${label} has ${entry}`));
  if (stray.length) throw new Error(`principals must list every service principal; add each on purpose, or remove it from its service: ${stray.join("; ")}.`);
  // After the parity above, which is the more basic refusal. An execution profile that requires an origin asks Messaging
  // about its people, and Messaging answers only about a person its own list admits, so it must admit everyone the profile
  // does (its own list, else execution's; an exact person by being listed or by a listed domain, a whole domain only by
  // that domain), or every verify is denied.
  if (messaging?.deploy && execution?.enabled) {
    const rules = parseAllowedPrincipals(messaging.allowedPrincipals.join(","));
    for (const [index, profile] of (execution.profiles ?? []).entries()) {
      const unadmitted = profile.origin === "required"
        ? (profile.allowedPrincipals ?? execution.allowedPrincipals!).filter((entry) => !allowed(entry.trim().toLowerCase(), rules)) : [];
      if (unadmitted.length)
        throw new Error(`execution.profiles[${index}].origin is "required", but messaging.allowedPrincipals does not admit ${unadmitted.join(", ")}: Messaging would deny every origin for them.`);
    }
  }
}

/**
 * How the Workshop reaches AI Gateway, derived rather than configured.
 *
 * The Worker cannot discover its own account at runtime, so it cannot tell whether the gateway it
 * is pointed at is one its `WORKERS_AI` binding can reach. This script can: it holds both account
 * IDs. Everything below follows from comparing them.
 */
export interface AiGatewayPlan {
  /** The account owning the gateway, with `aiGateway.accountId: null` resolved. */
  gatewayAccountId: string;
  /** Whether the gateway lives outside the deployment's own account. */
  crossAccount: boolean;
  /** Whether `CF_AI_GATEWAY_API_TOKEN` has to be installed before the Workshop will start a chat. */
  needsToken: boolean;
  /** One sentence per reason a token is needed. Empty when the binding transport covers it all. */
  tokenReasons: string[];
}

/**
 * {@link AiGatewayPlan} for `config`, or null when the deployment advertises no model catalog.
 *
 * Both IDs are lowercased first. `accountIdPattern` accepts either case, so the same account can be
 * written two ways across `accountId` and `aiGateway.accountId`; comparing the raw strings would
 * read that as cross-account and demand a token for a gateway the binding can reach in-account.
 * Lowercase is also the form the dashboard and the API expect, so it is what the vars carry.
 */
export function aiGatewayPlan(config: DeploymentConfig): AiGatewayPlan | null {
  if (!config.aiGateway.enabled) return null;
  const deploymentAccountId = config.accountId.toLowerCase();
  const gatewayAccountId = (
    config.aiGateway.accountId ?? config.accountId
  ).toLowerCase();
  const crossAccount = gatewayAccountId !== deploymentAccountId;
  const tokenReasons: string[] = [];
  if (crossAccount) {
    tokenReasons.push(
      `aiGateway.accountId (${gatewayAccountId}) is not the deployment account, so the generated ` +
        "config sets CF_AI_GATEWAY_USE_BINDING=false: the Workers AI binding only reaches gateways " +
        "in the Worker's own account. That leaves the HTTPS transport, which needs a Run + Read " +
        "CF_AI_GATEWAY_API_TOKEN. The opt-out is a flag rather than an unbound WORKERS_AI because " +
        "webFetch's toMarkdown() runs on that binding too.",
    );
  }
  if (config.aiGateway.providers?.includes("google")) {
    tokenReasons.push(
      "The google provider needs CF_AI_GATEWAY_API_TOKEN: pi's Google adapter refuses a custom " +
        "fetch, so Google inference cannot ride the Workers AI binding transport.",
    );
  }
  return {
    gatewayAccountId,
    crossAccount,
    needsToken: tokenReasons.length > 0,
    tokenReasons,
  };
}

/**
 * The deploy-time half of `AiGatewayConfig`'s constructor checks
 * (cloudflare-os/packages/workshop-backend/src/ai-gateway.ts), mirroring `resolveAiGateway()` in
 * cloudflare-os/scripts/preview/staging-config.ts. A configuration the backend would reject belongs
 * in a failed `pnpm check`, not in somebody's first chat.
 */
function validateAiGateway(config: DeploymentConfig): void {
  if (config.aiGateway.workersAi !== undefined) {
    throw new Error(
      "aiGateway.workersAi does nothing: Workers AI rides the same gateway route as every other " +
        "provider. Leaving the key in place deploys a Workshop with an empty model picker. Delete " +
        'it; list "cloudflare" in aiGateway.providers to keep Workers AI models.',
    );
  }
  if (typeof config.aiGateway.enabled !== "boolean") {
    throw new Error("AI Gateway enabled must be a boolean.");
  }

  if (config.aiGateway.cloudflareLimits !== undefined &&
      typeof config.aiGateway.cloudflareLimits !== "boolean") {
    throw new Error("aiGateway.cloudflareLimits must be a boolean.");
  }
  if (config.aiGateway.cloudflareLimits) {
    if (!config.aiGateway.enabled) {
      throw new Error(
        "aiGateway.cloudflareLimits needs aiGateway.enabled: the free daily allowance is served " +
          "through the deployment's own AI Gateway.",
      );
    }
    if (!config.cloudflare?.deploy) {
      throw new Error(
        "aiGateway.cloudflareLimits needs cloudflare.deploy: billing reads its access token from " +
          "the connected Cloudflare gatekeeper account, and without it a user who spends the free " +
          "daily allowance is blocked with no way to continue.",
      );
    }
    const limit = config.aiGateway.dailyLlmCallLimit;
    if (limit !== undefined && limit !== null &&
        (!Number.isInteger(limit) || limit < 1)) {
      throw new Error("aiGateway.dailyLlmCallLimit must be a positive integer, or null.");
    }
  }

  if (!config.aiGateway.enabled) return;

  const providers = config.aiGateway.providers;
  if (
    !Array.isArray(providers) ||
    providers.length === 0 ||
    !providers.every((provider) => AI_GATEWAY_PROVIDERS.includes(provider))
  ) {
    throw new Error(
      `AI Gateway providers must be a non-empty subset of ${AI_GATEWAY_PROVIDERS.join(", ")}.`,
    );
  }

  const gatewayAccountId = config.aiGateway.accountId;
  if (
    gatewayAccountId !== undefined &&
    gatewayAccountId !== null &&
    (typeof gatewayAccountId !== "string" ||
      !accountIdPattern.test(gatewayAccountId))
  ) {
    throw new Error(
      "aiGateway.accountId must be null or 32 hexadecimal characters. null reuses the " +
        "deployment's own account, which is what lets the Workers AI binding reach the gateway " +
        "without an API token.",
    );
  }
}

const OPENAPI_ID = /^[a-z0-9]{1,32}$/;
const HOSTNAME_LABEL = /^[a-z0-9-]+$/;
const HOSTNAME_TLD = /^[a-z]{2,63}$/;
const D1_ID = /^(?!00000000-0000-0000-0000-000000000000$)[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;

/**
 * Linear replacement for a regex that nested an optional group inside a repeated group (flagged
 * as ReDoS-prone). Same contract as the regex it replaces: 1 to 253 characters total, at least
 * two dot-separated labels, each label 1 to 63 characters of `[a-z0-9-]` not starting or ending
 * with `-`, and a letters-only final label of 2 to 63 characters.
 */
function isValidHostname(hostname: string): boolean {
  if (hostname.length < 1 || hostname.length > 253) return false;
  const labels = hostname.split(".");
  if (labels.length < 2) return false;
  for (const label of labels) {
    if (label.length < 1 || label.length > 63) return false;
    if (!HOSTNAME_LABEL.test(label)) return false;
    if (label.startsWith("-") || label.endsWith("-")) return false;
  }
  return HOSTNAME_TLD.test(labels[labels.length - 1]);
}

/**
 * Whether a generated connector config carries exactly one credential binding: the
 * string-secret requirement, or the single Secrets Store entry binding
 * `CLIENT_SECRET` with a 32-hex store and a whitespace-free name. Both or neither
 * is false. Exported for the D4 runner's pre-deploy gate.
 */
export function isApiCredentialBinding(worker: ProdWranglerConfig): boolean {
  const stringShape = JSON.stringify(worker.secrets ?? null) === JSON.stringify({ required: ["CLIENT_SECRET"] });
  const store = worker.secrets_store_secrets;
  const storeShape = Array.isArray(store) &&
    store.length === 1 &&
    store[0]?.binding === "CLIENT_SECRET" &&
    typeof store[0]?.store_id === "string" &&
    /^[a-fA-F0-9]{32}$/.test(store[0].store_id) &&
    typeof store[0]?.secret_name === "string" &&
    store[0].secret_name.length >= 1 &&
    store[0].secret_name.length <= 256 &&
    !/[\t\n\f\r ]/.test(store[0].secret_name);
  return (stringShape ? 1 : 0) + (storeShape ? 1 : 0) === 1;
}

/** `openApi:<id>`, the generated-config and deployment-order key for one API entry. */
export function openApiKey(id: string): OpenApiKey { return `openApi:${id}`; }
/** The router and Workshop binding for one API: what makes `/gatekeeper/<id>` and the vendor exist. */
export function openApiBinding(id: string): string { return `GATEKEEPER_${id.toUpperCase()}`; }
/** The operator Worker's binding to one API's `OpenApiCatalogOperator` entrypoint. */
export function operatorBinding(id: string): string { return `OPENAPI_CATALOG_OPERATOR_${id.toUpperCase()}`; }
/** The operator Worker's R2 binding to one API's catalog bundle bucket, which is where the
 *  connector admits from. The operator stages the compiled bundle there; the installation
 *  artifact bucket cannot be used, because it also holds sealed client-secret envelopes. */
export function catalogBundlesBinding(id: string): string { return `OPENAPI_CATALOG_BUNDLES_${id.toUpperCase()}`; }
/** Every connector's binding to the operator's `OpenApiInstallationJobs` entrypoint (D2c bridge, D3 wiring). */
export const INSTALLATION_JOBS_BINDING = "OPENAPI_INSTALLATION_JOBS";
export const INSTALLATION_JOBS_ENTRYPOINT = "OpenApiInstallationJobs";
export const DISCOVERY_READER_BINDING = "CATALOG_DISCOVERY_READER";
export const DISCOVERY_READER_ENTRYPOINT = "OpenApiDiscoveryReader";
export const CATALOG_AGENT_BINDING = "CATALOG_AGENT";
export const CATALOG_AGENT_ENTRYPOINT = "CatalogAgent";

/**
 * Converts one under-lease registry export to the deployment entries generation consumes.
 * Existing helpers keep their output for a given array; this is the only shape between the
 * export and them.
 *
 * Two conversions are load-bearing. `OPENAPI_SEGMENTS` comes from `segmentSeed` only, while
 * the definition is pending B seed confirmation; every other entry emits `[]` — later
 * catalog reviews and segment UI data never rewrite it here. And every nested object is
 * rebuilt in the `deployment.jsonc` key order (baseUrl-first provider, catalogue order
 * below), because the vars serialize with `JSON.stringify` and the D5 migration proves
 * byte-identical output against the file path.
 */
export function openApiDeploymentsFromExport(exported: OpenApiDeploymentExportV1): OpenApiDeployment[] {
  return exported.entries.map((entry) => ({
    id: entry.apiId,
    worker: entry.worker,
    deploy: entry.deploy,
    // The value passes through verbatim: the export parser only requires a non-empty
    // clientId when deploy is true, and an empty clientId is only possible on a
    // deploy:false entry, which generates nothing.
    clientId: entry.clientId,
    display: {
      name: entry.display.name,
      tagline: entry.display.tagline,
      color: entry.display.color,
      logo: entry.display.logo,
    },
    provider: {
      baseUrl: entry.provider.baseUrl,
      authorizationEndpoint: entry.provider.authorizationEndpoint,
      tokenEndpoint: entry.provider.tokenEndpoint,
      allowedOrigins: [...entry.provider.allowedOrigins],
      oauth: {
        pkce: entry.provider.oauth.pkce,
        tokenEndpointAuthMethod: entry.provider.oauth.tokenEndpointAuthMethod,
        tokenLifetime: entry.provider.oauth.tokenLifetime,
        refreshToken: entry.provider.oauth.refreshToken,
        tokenScopeParameter: entry.provider.oauth.tokenScopeParameter,
        scopeResponse: {
          delimiter: entry.provider.oauth.scopeResponse.delimiter,
          omitted: entry.provider.oauth.scopeResponse.omitted,
        },
      },
      permissions: {
        baselineScopes: [...entry.provider.permissions.baselineScopes],
        segmentScopes: Object.fromEntries(
          Object.entries(entry.provider.permissions.segmentScopes).map(([segment, scopes]) => [segment, [...scopes]]),
        ),
        fallbackScopes: [...entry.provider.permissions.fallbackScopes],
      },
      ...(entry.provider.idToken === undefined
        ? {}
        : { idToken: { jwksUri: entry.provider.idToken.jwksUri, issuer: entry.provider.idToken.issuer } }),
    },
    segments: (entry.segmentSeed ?? []).map((seed) => ({
      name: seed.name,
      title: seed.title,
      description: seed.description,
      operations: [...seed.operations],
    })),
    // The credential delivery rides the projection: the export parser already pinned the
    // reference shape, and generation below turns it into exactly one binding shape.
    // The secret id never leaves the registry — the binding needs store plus name only.
    credential: entry.clientCredential.kind === "cloudflare-secrets-store-v1"
      ? {
        kind: "cloudflare-secrets-store-v1",
        storeId: entry.clientCredential.storeId,
        secretName: entry.clientCredential.secretName,
      }
      : { kind: "worker-secret-v1" },
    catalog: {
      issuer: entry.catalog.issuer,
      databaseName: entry.catalog.databaseName,
      databaseId: entry.catalog.databaseId,
      bucketName: entry.catalog.bucketName,
      manifestTrust: {
        releaseKeys: entry.catalog.manifestTrust.releaseKeys.map((key) => ({
          issuer: key.issuer,
          keyId: key.keyId,
          publicKey: key.publicKey,
        })),
        rollbackKeys: entry.catalog.manifestTrust.rollbackKeys.map((key) => ({
          issuer: key.issuer,
          keyId: key.keyId,
          publicKey: key.publicKey,
        })),
      },
    },
  }));
}

/** D3 migration mode: `openApis` comes from the file. Otherwise the registry export rules. */
export function isBootstrapFileMode(config: DeploymentConfig): boolean {
  return config.bootstrapFile?.enabled === true;
}

/** Entries that generate a Worker: `deploy: true`. The array is resolved, never merged. */
function deployedOpenApis(apis: readonly OpenApiDeployment[]): OpenApiDeployment[] {
  return apis.filter((api) => api.deploy);
}

/** Enabled file Worker names, without any OpenAPI entries. Shared by both uniqueness checks. */
function enabledWorkerNames(config: DeploymentConfig): string[] {
  return Object.entries(config.workers)
    .filter(([key]) => {
      if (key === "openApiOperator") return config.openApiOperator?.enabled === true;
      if (key === "catalogAgent") return config.openApiOperator?.enabled === true;
      if (key === "execution" || key === "executionRuntime") return config.execution?.enabled === true;
      if (key === "memory") return config.memory?.deploy === true;
      if (key === "messaging") return config.messaging?.deploy === true;
      if (key === "eventRuntime") return config.eventRuntime?.deploy === true;
      if (key === "eventsEdge") return gatewayEdgeDeploys(config);
      if (key === "adminUi") return config.adminUi?.deploy === true;
      if (key === "setup") return config.setup?.deploy === true;
      if (key === "presence") return config.presenceHost?.deploy === true;
      if (key === "messagingEgress") return config.messagingEgress?.deploy === true;
      if (key === "errorReporter") return config.errorReporting.enabled;
      if (key === "github") return config.github.deploy;
      if (key === "linear") return config.linear.deploy;
      if (key === "microsoft") return config.microsoft.deploy;
      if (key === "mcp") return config.mcp.deploy;
      if (key === "mcpPortal") return config.mcpPortal.deploy;
      if (key === "email") return config.email.deploy;
      if (key === "cloudflare") return config.cloudflare.deploy;
      if (key === "x") return config.x?.deploy === true;
      if (key === "slack") return config.slack?.deploy === true;
      if (key === "websearch") return config.websearch?.deploy === true;
      if (key === "aiInference" || key === "aiExecutor")
        return config.aiExecutors.enabled;
      return true;
    })
    .map(([, worker]) => worker.name);
}

/** File Workers plus resolved OpenAPI entries share one service-identity namespace. */
function assertWorkerNamesUnique(config: DeploymentConfig, apis: readonly OpenApiDeployment[]): void {
  const workerNames = [
    ...enabledWorkerNames(config),
    // Every entry, deployed or not: a dormant entry is validated in full (decision 2).
    ...apis.map((api) => api.worker),
  ];
  if (new Set(workerNames).size !== workerNames.length) {
    throw new Error("Enabled Worker names must be unique.");
  }
  if (
    !workerNames.every((name) =>
      /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(name),
    )
  ) {
    throw new Error(
      "Worker names must use lowercase letters, numbers, and hyphens.",
    );
  }
}

/** The env the connector will read, built exactly as `generateConfigs` writes it. */
function openApiEnv(api: OpenApiDeployment): ConnectorConfigEnv {
  return {
    OPENAPI_API_ID: api.id,
    OPENAPI_PROVIDER: JSON.stringify(api.provider),
    OPENAPI_DISPLAY: JSON.stringify(api.display),
    OPENAPI_SEGMENTS: JSON.stringify(api.segments),
  };
}

function exactKeys(value: unknown, keys: string[], fail: (detail: string) => never): Record<string, any> {
  if (!value || typeof value !== "object" || Array.isArray(value) ||
      Object.keys(value).toSorted().join(",") !== keys.toSorted().join(",")) {
    fail(`must contain exactly ${keys.join(", ")}`);
  }
  return value as Record<string, any>;
}

/** Storage and manifest trust for one entry; the same rules the old singular block enforced. */
function validateOpenApiCatalog(catalog: unknown, fail: (detail: string) => never): void {
  const c = exactKeys(catalog, ["issuer", "databaseName", "databaseId", "bucketName", "manifestTrust"], (d) => fail(`catalog ${d}`));
  if (!trustText(c.issuer, 128, 128)) fail("catalog issuer must be 1 to 128 bytes of control-free text");
  if (typeof c.databaseName !== "string" || !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(c.databaseName)) fail("catalog databaseName is not a D1 name");
  // Wrangler describes database_id as a UUID (not the 32-hex account ID form).
  if (typeof c.databaseId !== "string" || !D1_ID.test(c.databaseId)) fail("catalog databaseId is not a D1 UUID");
  if (typeof c.bucketName !== "string" || !/^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(c.bucketName)) fail("catalog bucketName is not an R2 bucket name");
  validateManifestTrust(c.manifestTrust, c.issuer, (d) => fail(`catalog ${d}`));
}

/** The worker's trust-boundary text rule (installation-contracts.ts `string()`): well-formed, 1 to
 *  maxChars characters, no C0/C1 controls; issuers additionally cap at maxBytes of UTF-8. */
function trustText(value: unknown, maxChars: number, maxBytes = Infinity): value is string {
  return typeof value === "string" && value.isWellFormed() && value.length >= 1 && value.length <= maxChars &&
    Buffer.byteLength(value) <= maxBytes &&
    // oxlint-disable-next-line no-control-regex -- the worker rejects C0 and C1 controls; preflight must too.
    !/[\u0000-\u001f\u007f-\u009f]/u.test(value);
}

/** Release/rollback key sets; shared by every openApis[].catalog and the installations profile.
 *  Mirrors the worker's parseOpenApiManifestTrustV1 (1 to 8 keys per role, control-free issuer and
 *  keyId, Ed25519 SPKI, no keyId or public key repeated anywhere in the block) plus the cross-field
 *  rule both consumers apply at use: a release is signed and admitted only under `issuer` (the
 *  compiler's trustKey lookup, the catalog ingest issuer constraint), so releaseKeys must carry at
 *  least one key for it or nothing could ever ship. */
function validateManifestTrust(manifestTrust: unknown, issuer: string, fail: (detail: string) => never): void {
  const trust = exactKeys(manifestTrust, ["releaseKeys", "rollbackKeys"], (d) => fail(`manifestTrust ${d}`));
  const ids = new Set<string>(), publicKeys = new Set<string>();
  for (const keys of [trust.releaseKeys, trust.rollbackKeys]) {
    if (!Array.isArray(keys) || !keys.length || keys.length > 8) fail("manifestTrust roles need 1 to 8 keys");
    for (const key of keys) {
      exactKeys(key, ["issuer", "keyId", "publicKey"], (d) => fail(`manifestTrust key ${d}`));
      if (!trustText(key.issuer, 128, 128)) fail("manifestTrust key issuer must be 1 to 128 bytes of control-free text");
      if (!trustText(key.keyId, 128)) fail("manifestTrust keyId must be 1 to 128 control-free characters");
      let bytes: string;
      try { bytes = Buffer.from(decodeOperatorPublicKey(key.publicKey)).toString("hex"); }
      catch { fail("manifestTrust publicKey is not an Ed25519 SPKI"); }
      if (ids.has(key.keyId) || publicKeys.has(bytes)) fail("manifestTrust reuses a keyId or public key");
      ids.add(key.keyId); publicKeys.add(bytes);
    }
  }
  if (!trust.releaseKeys.some((key: { issuer: string }) => key.issuer === issuer)) {
    fail(`manifestTrust.releaseKeys has no key for issuer "${issuer}", so no release could be signed or admitted`);
  }
}

/** Shape, id format, and worker-name checks for one `openApis[]` entry. */
function validateOpenApiIdentity(api: OpenApiDeployment, ids: Set<string>, fail: (detail: string) => never): void {
  const keys = ["id", "worker", "deploy", "clientId", "display", "provider", "segments", "catalog"];
  if ("credential" in (api as unknown as Record<string, unknown>)) keys.push("credential");
  exactKeys(api, keys, fail);
  if (typeof api.id !== "string" || !OPENAPI_ID.test(api.id)) {
    fail("id must match [a-z0-9]{1,32}: it is the /gatekeeper path, the GATEKEEPER_ suffix, and the catalog id the release was compiled with");
  }
  if (ids.has(api.id)) fail(`id "${api.id}" is repeated`);
  ids.add(api.id);
  if (typeof api.worker !== "string" || !api.worker) fail("worker must be a non-empty Worker name");
  validateOpenApiCredential(api.credential, fail);
}

/** The credential delivery, when present, must name exactly one binding shape. */
function validateOpenApiCredential(credential: OpenApiDeployment["credential"], fail: (detail: string) => never): void {
  if (credential === undefined) return;
  if (!credential || typeof credential !== "object" || Array.isArray(credential)) fail("credential must be an object");
  const kind = (credential as { kind?: unknown }).kind;
  if (kind === "worker-secret-v1") {
    exactKeys(credential, ["kind"], (detail) => fail(`credential ${detail}`));
    return;
  }
  if (kind !== "cloudflare-secrets-store-v1") fail("credential.kind must be worker-secret-v1 or cloudflare-secrets-store-v1");
  exactKeys(credential, ["kind", "storeId", "secretName"], (detail) => fail(`credential ${detail}`));
  const ref = credential as { storeId?: unknown; secretName?: unknown };
  if (typeof ref.storeId !== "string" || !/^[a-fA-F0-9]{32}$/.test(ref.storeId)) fail("credential.storeId must be 32 hexadecimal characters");
  if (
    typeof ref.secretName !== "string" || ref.secretName.length < 1 || ref.secretName.length > 256 ||
    /[\t\n\f\r ]/.test(ref.secretName)
  ) {
    fail("credential.secretName must be 1 to 256 characters with no whitespace");
  }
}

/** deploy/clientId consistency, the connector's own parsers, and catalog/trust checks for one `openApis[]` entry. */
function validateOpenApiDeployment(api: OpenApiDeployment, fail: (detail: string) => never): void {
  if (typeof api.deploy !== "boolean") fail("deploy must be a boolean");
  if (api.deploy && (typeof api.clientId !== "string" || !api.clientId.trim())) fail("clientId must be a non-empty string when deploy is true");
  if (!api.deploy && api.clientId !== null && typeof api.clientId !== "string") fail("clientId must be null or a string");
  const env = openApiEnv(api);
  try { apiId(env); providerConfig(env); displayConfig(env); segmentConfig(env); }
  catch (error) { fail((error as Error).message); }
  validateOpenApiCatalog(api.catalog, fail);
}

/** Every `openApis[]` entry, validated with the Worker's own parsers so `--check` rejects exactly what first use would. */
function validateOpenApis(config: DeploymentConfig): void {
  for (const legacy of ["openApiSearch", "openApiProvisioning"]) {
    if (legacy in config) throw new Error(`${legacy} is no longer read; describe each API under openApis[] instead.`);
  }
  if ("openApiSearch" in config.workers) throw new Error("workers.openApiSearch is no longer read; each openApis[] entry names its own worker.");
  if (config.openApiVpcEgress !== undefined && config.openApiVpcEgress !== "off" &&
      config.openApiVpcEgress !== "reads" && config.openApiVpcEgress !== "all") {
    throw new Error("openApiVpcEgress must be off, reads, or all.");
  }
  if ("bootstrapFile" in config) {
    const mode: unknown = config.bootstrapFile;
    exactKeys(mode, ["enabled"], (detail) => { throw new Error(`bootstrapFile: ${detail}`); });
    if (typeof (mode as { enabled: unknown }).enabled !== "boolean") {
      throw new Error("bootstrapFile.enabled must be a boolean.");
    }
  }
  // D-REG-002: the file array is only authority behind the explicit migration flag.
  // Otherwise its presence is an error, never a merge with the registry export.
  if ("openApis" in config && !isBootstrapFileMode(config)) {
    throw new Error(
      "openApis is only read in bootstrapFile migration mode. Set bootstrapFile.enabled to deploy " +
        "from the file during the migration, or remove openApis so the registry export is authoritative. " +
        "File and registry entries are never merged.",
    );
  }
  if (!isBootstrapFileMode(config)) return;
  validateOpenApisArray(config.openApis ?? [], "openApis");
  if (deployedOpenApis(config.openApis ?? []).length && !config.openApiOperator?.enabled) {
    throw new Error("openApis requires openApiOperator.enabled: every API deployment needs the operator to admit its catalog.");
  }
}

function validateOpenApisArray(apis: unknown, label: string): asserts apis is OpenApiDeployment[] {
  if (!Array.isArray(apis)) throw new Error(`${label} must be an array.`);
  const ids = new Set<string>();
  apis.forEach((api, index) => {
    const fail = (detail: string): never => { throw new Error(`${label}[${index}]: ${detail}`); };
    validateOpenApiIdentity(api, ids, fail);
    validateOpenApiDeployment(api, fail);
  });
}

/**
 * Validates one resolved OpenAPI array — file entries in bootstrap mode, converted export
 * entries otherwise — against the file Workers. The registry export already passed its own
 * strict parser; this re-checks the deployment shape (connector parsers, catalog trust,
 * worker-name uniqueness, operator requirement) so a skewed conversion still fails here.
 */
export function validateResolvedOpenApis(config: DeploymentConfig, apis: readonly OpenApiDeployment[]): void {
  validateOpenApisArray(apis, isBootstrapFileMode(config) ? "openApis" : "registry export");
  assertWorkerNamesUnique(config, apis);
  const extra = new Set(config.inventory?.extraWorkers ?? []);
  const clash = apis.find((api) => extra.has(api.worker));
  if (clash !== undefined) throw new Error(`inventory.extraWorkers names ${clash.worker}, an OpenAPI connector Worker the generator produces; list only Workers it does not.`);
  if (deployedOpenApis(apis).length && config.openApiOperator?.enabled !== true) {
    throw new Error("openApis requires openApiOperator.enabled: every API deployment needs the operator to admit its catalog.");
  }
}

// The Worker re-parses every value per request and answers 503 on anything it cannot use
// (packages/gatekeeper-memory/src/auth.ts authConfig, src/index.ts handle). The principal lists go
// through the Worker's own parsers, so a value that would 503 is refused here instead.
/** The SERVICE_OWNERS var: `svc:<name>=<email>` pairs, comma-separated. */
const serviceOwnersVar = (owners: Record<string, string>): string =>
  Object.entries(owners)
    .map(([service, owner]) => `${service}=${owner}`)
    .join(",");

function validateMemory(config: DeploymentConfig): void {
  const memory = config.memory;
  if (memory === undefined) return;
  const fail = (detail: string): never => {
    throw new Error(`memory.${detail}`);
  };
  if (typeof memory.deploy !== "boolean") fail("deploy must be a boolean.");
  if (!memory.deploy) return;
  if (!config.workers.memory?.name) throw new Error("workers.memory.name is required when memory.deploy is true.");
  const text = (value: unknown): value is string => typeof value === "string" && value.trim() !== "";
  if (!text(memory.namespace)) fail("namespace must be a non-empty string.");
  if (!text(memory.hostname) || !isValidHostname(memory.hostname)) fail("hostname must be a valid hostname.");
  // The memory-review host was retired (#962); a leftover key would be silently ignored, so refuse it.
  if (Object.hasOwn(memory, "reviewHostname")) fail("reviewHostname was retired; remove it.");
  const access = memory.access;
  if (!access || !text(access.audience)) fail("access needs an audience.");
  // exactKeys also refuses the retired access.reviewAudience, which would otherwise be silently ignored.
  exactKeys(access, ["issuer", "audience"], detail => fail(`access ${detail}.`));
  // The same rule the OpenAPI operator's Access config follows: an https team origin on
  // cloudflareaccess.com with no path, query, port or credentials, and a plain-identifier audience.
  try {
    parseAccessConfig({ issuer: access.issuer, audience: access.audience, allowedEmails: [] });
  } catch {
    fail("access.issuer must be an https://<team>.cloudflareaccess.com origin, and the audience a plain identifier.");
  }
  for (const key of ["allowedPrincipals", "reviewers"] as const)
    if (!Array.isArray(memory[key]) || memory[key].length === 0 || !memory[key].every(text)) fail(`${key} must be a non-empty list of strings.`);
  const tokens = memory.serviceTokens;
  if (!tokens || typeof tokens !== "object" || Array.isArray(tokens)) fail("serviceTokens must map Access client ids to principals.");
  // Joined exactly as generateConfigs writes the vars.
  const workerParses = (key: string, parse: () => unknown): void => {
    try {
      parse();
    } catch {
      fail(`${key} has an entry the Worker would refuse, which makes every request 503.`);
    }
  };
  workerParses("allowedPrincipals", () => parseAllowedPrincipals(memory.allowedPrincipals.join(",")));
  workerParses("reviewers", () => parseReviewers(memory.reviewers.join(",")));
  workerParses("serviceTokens", () => parseServiceTokens(JSON.stringify(memory.serviceTokens)));
  if (memory.requireAgent !== undefined && typeof memory.requireAgent !== "boolean") fail("requireAgent must be a boolean.");
  // Agent tokens are verified by Messaging (AuthorityMemory): with no Messaging beside Memory, requiring one would refuse every call.
  if (memory.requireAgent === true && !config.messaging?.deploy) fail("requireAgent needs messaging.deploy: Messaging verifies the agent tokens it requires.");
  const owners = memory.serviceOwners;
  if (!owners || typeof owners !== "object" || Array.isArray(owners)) fail("serviceOwners must map svc:<name> to an email.");
  workerParses("serviceOwners", () => parseServiceOwners(serviceOwnersVar(owners)));
  // The memory registry refuses to migrate a service principal's memory with no human owner, which
  // would make every memory call fail: refuse that here instead.
  const owned = parseServiceOwners(serviceOwnersVar(owners));
  for (const principal of Object.values(parseServiceTokens(JSON.stringify(memory.serviceTokens))))
    if (SERVICE_PRINCIPAL.test(principal) && !owned[principal]) fail(`serviceOwners must name a human owner for ${principal}.`);
  // The admin UI signs people in against allowedPrincipals before it checks reviewer status, so a reviewer
  // outside that list could never use it.
  const rules = parseAllowedPrincipals(memory.allowedPrincipals.join(","));
  if (!parseReviewers(memory.reviewers.join(",")).every((reviewer) => allowed(reviewer, rules)))
    fail("every reviewer must also be an allowedPrincipal, or the admin UI refuses them.");
}

// The Worker refuses everyone when ALLOWED_PRINCIPALS does not parse, and every receipt when
// RECEIPT_PUBLIC_KEYS does not: both go through the Worker's own parsers here instead.
function validateMessaging(config: DeploymentConfig): void {
  const messaging = config.messaging;
  if (messaging === undefined) return;
  const fail = (detail: string): never => {
    throw new Error(`messaging.${detail}`);
  };
  if (!messaging || typeof messaging !== "object" || typeof messaging.deploy !== "boolean") fail("deploy must be a boolean.");
  const keys = ["deploy", "hostname", "namespace", "access", "allowedPrincipals", "serviceTokens", "retiredPublicKeys"];
  if (messaging.oauth !== undefined) keys.push("oauth");
  if (messaging.queueDelivery !== undefined) keys.push("queueDelivery");
  if (messaging.enrollPrincipals !== undefined) keys.push("enrollPrincipals");
  // Messaging reaches the egress Worker only through its service binding (#962); a leftover public URL is refused even when off.
  if (messaging.oauth && typeof messaging.oauth === "object" && Object.hasOwn(messaging.oauth, "egressUrl")) fail("oauth.egressUrl was retired; remove it.");
  // Off, it may keep its settings for later; on, it must have exactly these (a misspelled key fails).
  if (!messaging.deploy) {
    const unknown = Object.keys(messaging).filter((key) => !keys.includes(key));
    if (unknown.length) throw new Error(`messaging has unknown keys: ${unknown.join(", ")}.`);
    return;
  }
  exactKeys(messaging, keys, (detail) => {
    throw new Error(`messaging ${detail}.`);
  });
  if (!config.workers.messaging?.name) throw new Error("workers.messaging.name is required when messaging.deploy is true.");
  if (messaging.queueDelivery !== undefined && typeof messaging.queueDelivery !== "boolean") fail("queueDelivery must be a boolean.");
  if (typeof messaging.namespace !== "string" || !messaging.namespace.trim()) fail("namespace must be a non-empty string.");
  const text = (value: unknown): value is string => typeof value === "string" && value.trim() !== "";
  if (!text(messaging.hostname) || !isValidHostname(messaging.hostname)) fail("hostname must be a valid hostname.");
  const access = messaging.access;
  if (!access || !text(access.audience)) fail("access needs an audience.");
  // exactKeys also refuses the retired access.adminAudience, which would otherwise be silently ignored.
  exactKeys(access, ["issuer", "audience"], detail => fail(`access ${detail}.`));
  try {
    parseAccessConfig({ issuer: access.issuer, audience: access.audience, allowedEmails: [] });
  } catch {
    fail("access.issuer must be an https://<team>.cloudflareaccess.com origin, and the audience a plain identifier.");
  }
  if (messaging.oauth !== undefined) {
    const oauth = messaging.oauth;
    if (!oauth || typeof oauth !== "object" || Array.isArray(oauth)) fail("oauth must be an object.");
    if (config.messagingEgress?.deploy !== true) fail("oauth needs messagingEgress.deploy: Messaging reaches the egress Worker through a service binding.");
    // The messages-chatgpt alias was the only user of compatibility hostnames; the support was removed (#962).
    if (Object.hasOwn(oauth, "compatibilityHostnames")) fail("oauth.compatibilityHostnames was retired; remove it.");
    exactKeys(oauth, ["hostname", "audience", "profile"], detail => fail(`oauth ${detail}.`));
    const reservedHosts = [
      new URL(publicOrigin(config)).hostname,
      messaging.hostname,
      ...(config.memory?.deploy ? [config.memory.hostname] : []),
      ...(config.openApiOperator?.enabled ? [config.openApiOperator.hostname] : []),
    ];
    if (!text(oauth.hostname) || !isValidHostname(oauth.hostname) || reservedHosts.includes(oauth.hostname))
      fail("oauth.hostname must be a distinct lowercase hostname across all enabled public Workers.");
    const reservedAudiences = [
      config.access.audience, access.audience,
      ...(config.memory?.deploy ? [config.memory.access.audience] : []),
      ...(config.openApiOperator?.enabled ? [config.openApiOperator.access.audience] : []),
    ];
    if (typeof oauth.audience !== "string" || !/^[a-zA-Z0-9_-]{1,256}$/.test(oauth.audience) || reservedAudiences.includes(oauth.audience))
      fail("oauth.audience must be one plain identifier, dedicated across all enabled Access surfaces.");
    if (typeof oauth.profile !== "string" || !/^[a-z0-9-]{1,32}$/.test(oauth.profile))
      fail("oauth.profile must be 1-32 lowercase letters, digits or hyphens.");
  }
  if (!Array.isArray(messaging.allowedPrincipals) || messaging.allowedPrincipals.length === 0) fail("allowedPrincipals must be a non-empty list.");
  try {
    parseAllowedPrincipals(messaging.allowedPrincipals.join(","));
  } catch {
    fail("allowedPrincipals has an entry the Worker would refuse, which refuses everyone.");
  }
  let tokens: Readonly<Record<string, string>> = {};
  try {
    tokens = parseServiceTokens(JSON.stringify(messaging.serviceTokens ?? null));
  } catch {
    fail("serviceTokens must map Access client ids to principals.");
  }
  // The Worker checks ALLOWED_PRINCIPALS on every request, service tokens included (it is how removing a
  // person suspends their agents), so a token for anyone else could never sign in.
  const rules = parseAllowedPrincipals(messaging.allowedPrincipals.join(","));
  if (!Object.values(tokens).every((principal) => canonicalEmail(principal) && allowed(principal, rules)))
    fail("serviceTokens must map to allowed people's emails: the Worker refuses anyone else.");
  if (messaging.enrollPrincipals !== undefined) {
    if (!Array.isArray(messaging.enrollPrincipals) || messaging.enrollPrincipals.length === 0) fail("enrollPrincipals must be a non-empty list.");
    try {
      parseAllowedPrincipals(messaging.enrollPrincipals.join(","));
    } catch {
      fail("enrollPrincipals has an entry the Worker would refuse, which refuses every mint.");
    }
    // Enrolling is for people Messaging admits at all: an entry allowedPrincipals does not cover (a typo like "@knitli.cm") could never mint.
    // allowed() reads a "@domain" entry as the domain it names, so one check covers both kinds.
    if (!messaging.enrollPrincipals.every((entry) => allowed(entry.trim().toLowerCase(), rules))) fail("enrollPrincipals must be covered by allowedPrincipals: a domain or email Messaging refuses could never make a code.");
  }
  try {
    parsePublicKeys(JSON.stringify({ keys: messaging.retiredPublicKeys }));
  } catch {
    fail("retiredPublicKeys must be Ed25519 public JWKs with distinct kids.");
  }
  // AuthorityMemory verifies the Access assertion Memory forwards against THIS Worker's issuer, so Memory behind another team's issuer would be refused on every call.
  if (config.memory?.deploy && config.memory.access.issuer !== messaging.access.issuer)
    fail("access.issuer must match memory.access.issuer: AuthorityMemory checks the Access assertions Memory forwards against it.");
  // AuthorityMemory refuses every call when Memory's agent audience is one of Messaging's own (#configuration()).
  if (config.memory?.deploy && messaging.access.audience === config.memory.access.audience)
    fail("access.audience must differ from memory.access.audience: AuthorityMemory refuses every call otherwise.");
}

/** Whether the Gateway Forward Worker for Event Gateway's node requests (packages/events-edge, #993) deploys. */
export const gatewayEdgeDeploys = (config: DeploymentConfig): boolean =>
  config.eventRuntime?.deploy === true && config.eventRuntime.gatewayEdge?.deploy === true;

const POSTURE_CHECK = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

/** The one deployment mapping is checked with the same closed rules for config and live settings. */
function validateGitHubSourceMapping(mapping: unknown, fail: (detail: string) => never): asserts mapping is GitHubSourceDeployment["mapping"] {
  if (!mapping || typeof mapping !== "object" || Array.isArray(mapping)) fail("mapping must be one source mapping.");
  exactKeys(mapping, ["principal", "agent", "installationId", "repositoryId", "revision", "actorPolicy"], (detail: string) => fail(`mapping ${detail}`));
  const sourceMapping = mapping as GitHubSourceDeployment["mapping"];
  const actorPolicy = sourceMapping.actorPolicy;
  if (!actorPolicy || typeof actorPolicy !== "object" || Array.isArray(actorPolicy)) fail("mapping.actorPolicy must contain version, userIds and appIds.");
  exactKeys(actorPolicy, ["version", "userIds", "appIds"], (detail: string) => fail(`mapping.actorPolicy ${detail}`));
  const validActorIds = (ids: unknown, min: number) => Array.isArray(ids) && ids.length >= min && ids.length <= 64 &&
    ids.every(id => Number.isSafeInteger(id) && id > 0) && new Set(ids).size === ids.length;
  if (actorPolicy.version !== 1 || !validActorIds(actorPolicy.userIds, 1) || !validActorIds(actorPolicy.appIds, 0))
    fail("mapping.actorPolicy requires version 1, 1-64 positive safe user IDs and 0-64 positive safe app IDs.");
  if (!NativeAdmissionCanarySchema.safeParse({ principal: sourceMapping.principal, agent: sourceMapping.agent }).success ||
      ![sourceMapping.installationId, sourceMapping.repositoryId].every(id => Number.isSafeInteger(id) && id > 0) ||
      typeof sourceMapping.revision !== "string" || [...sourceMapping.revision].length < 1 || [...sourceMapping.revision].length > 128)
    fail("mapping must be one exact owner, agent, installation and repository with a revision.");
}

/** Event proofs have a fixed, separately admitted audience in the Messaging authority. */
function validateEventRuntime(config: DeploymentConfig): void {
  const runtime = config.eventRuntime;
  if (runtime === undefined) return;
  const fail = (detail: string): never => { throw new Error(`eventRuntime.${detail}`); };
  if (!runtime || typeof runtime !== "object" || Array.isArray(runtime) || typeof runtime.deploy !== "boolean")
    fail("deploy must be a boolean.");
  const allowedKeys = ["deploy", "hostname", "access", "transportKeyId", "queues", "manualCanary", "nativeCanary", "assignedStockCanary", "assignedStockMessaging", "githubSource", "gatewayEdge"];
  if (runtime.assignedStockMessaging !== undefined && typeof runtime.assignedStockMessaging !== "boolean")
    fail("assignedStockMessaging must be a boolean.");
  if (runtime.assignedStockMessaging === true && !NativeAdmissionCanarySchema.safeParse(runtime.assignedStockCanary).success)
    fail("assignedStockMessaging requires assignedStockCanary with an exact principal and agent.");
  if (runtime.manualCanary !== undefined && runtime.manualCanary !== false) {
    if (!ManualCanarySchema.safeParse(runtime.manualCanary).success)
      fail("manualCanary must be false or contain only a valid subjectId or 1-7 unique subjectIds, and canonical millisecond UTC expiresAt.");
    if (!NativeAdmissionCanarySchema.safeParse(runtime.nativeCanary).success
      && !NativeAdmissionCanarySchema.safeParse(runtime.assignedStockCanary).success)
      fail("manualCanary requires nativeCanary or assignedStockCanary with an exact principal and agent.");
  }
  if (!runtime.deploy) {
    if (Object.keys(runtime).some(key => !allowedKeys.includes(key))) fail("has unknown configuration keys.");
    return;
  }
  exactKeys(runtime, allowedKeys.filter(key => (key !== "manualCanary" || runtime.manualCanary !== undefined)
    && (key !== "nativeCanary" || runtime.nativeCanary !== undefined)
    && (key !== "assignedStockCanary" || runtime.assignedStockCanary !== undefined)
    && (key !== "assignedStockMessaging" || runtime.assignedStockMessaging !== undefined)
    && (key !== "githubSource" || runtime.githubSource !== undefined)
    && (key !== "gatewayEdge" || runtime.gatewayEdge !== undefined)), fail);
  if (runtime.gatewayEdge !== undefined) {
    const edge = runtime.gatewayEdge;
    if (!edge || typeof edge !== "object" || Array.isArray(edge) || typeof edge.deploy !== "boolean") fail("gatewayEdge.deploy must be a boolean.");
    exactKeys(edge, ["deploy", "posture"], (detail: string) => fail(`gatewayEdge.${detail}`));
    // Every listed check must pass on the device for a request to reach NodeEdge; none would let any WARP device through.
    if (!Array.isArray(edge.posture) || edge.posture.length < 1 || edge.posture.length > 8 ||
        !edge.posture.every(id => typeof id === "string" && POSTURE_CHECK.test(id)) || new Set(edge.posture).size !== edge.posture.length)
      fail("gatewayEdge.posture must list 1-8 unique lowercase device posture check UUIDs.");
    const edgeName = config.workers.eventsEdge?.name;
    if (edge.deploy && (typeof edgeName !== "string" || !WORKER_NAME.test(edgeName)))
      fail("gatewayEdge needs workers.eventsEdge.name to be a lowercase Worker name.");
  }
  if (!config.messaging?.deploy) fail("requires messaging.deploy to be true.");
  const name = config.workers.eventRuntime?.name;
  if (typeof name !== "string" || !WORKER_NAME.test(name)) fail("workers.eventRuntime.name must be a lowercase Worker name.");
  const messaging = config.messaging!;
  const hosts = [
    new URL(publicOrigin(config)).hostname, messaging.hostname,
    messaging.oauth?.hostname,
    ...(config.memory?.deploy ? [config.memory.hostname] : []),
    ...(config.adminUi?.deploy ? [config.adminUi.hostname] : []),
    ...(config.openApiOperator?.enabled ? [config.openApiOperator.hostname] : []),
    ...(config.mcpPortal.deploy && config.mcpPortal.url ? [new URL(config.mcpPortal.url).hostname] : []),
  ];
  if (typeof runtime.hostname !== "string" || !isValidHostname(runtime.hostname) || hosts.includes(runtime.hostname) ||
      runtime.hostname === "workers.dev" || runtime.hostname.endsWith(".workers.dev"))
    fail("hostname must be a distinct custom domain.");
  if (!runtime.access || typeof runtime.access !== "object" || Array.isArray(runtime.access)) fail("access is required.");
  exactKeys(runtime.access, ["issuer", "audience"], fail);
  try {
    parseAccessConfig({ ...runtime.access, allowedEmails: [] });
  } catch {
    fail("access must contain a valid Cloudflare Access issuer and plain audience identifier.");
  }
  if (runtime.access.issuer !== messaging.access.issuer) fail("access.issuer must match Messaging's issuer.");
  const audiences = [
    config.access.audience, messaging.access.audience, messaging.oauth?.audience,
    ...(config.memory?.deploy ? [config.memory.access.audience] : []),
    ...(config.adminUi?.deploy ? [config.adminUi.access.audience] : []),
    ...(config.openApiOperator?.enabled ? [config.openApiOperator.access.audience] : []),
  ];
  if (audiences.includes(runtime.access.audience)) fail("access.audience must be dedicated across all enabled Access surfaces.");
  if (typeof runtime.transportKeyId !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(runtime.transportKeyId))
    fail("transportKeyId must identify the reviewed gateway trusted public key.");
  if (runtime.nativeCanary !== undefined) {
    const canaryFail = (detail: string): never => fail(`nativeCanary ${detail}`);
    if (!NativeAdmissionCanarySchema.safeParse(runtime.nativeCanary).success)
      canaryFail("must contain an exact lowercase principal email and Event agent name.");
    if (!allowed(runtime.nativeCanary.principal, parseAllowedPrincipals(messaging.allowedPrincipals.join(","))))
      canaryFail("principal must be admitted by Messaging.");
  }
  if (runtime.assignedStockCanary !== undefined) {
    if (!NativeAdmissionCanarySchema.safeParse(runtime.assignedStockCanary).success)
      fail("assignedStockCanary must contain an exact lowercase principal email and Event agent name.");
    if (!allowed(runtime.assignedStockCanary.principal, parseAllowedPrincipals(messaging.allowedPrincipals.join(","))))
      fail("assignedStockCanary principal must be admitted by Messaging.");
  }
  if (runtime.githubSource !== undefined) {
    const source = runtime.githubSource;
    if (!source || typeof source !== "object" || Array.isArray(source)) fail("githubSource must contain an App ID and one source mapping.");
    exactKeys(source, ["appId", "mapping", "sourceControl", "watchControl", "initialReconciliation"].filter(key =>
      (key !== "sourceControl" || source.sourceControl !== undefined) &&
      (key !== "watchControl" || source.watchControl !== undefined) &&
      (key !== "initialReconciliation" || source.initialReconciliation !== undefined)), detail => fail(`githubSource ${detail}`));
    if (source.sourceControl !== undefined) {
      const control = source.sourceControl;
      if (!control || typeof control !== "object" || Array.isArray(control)) fail("githubSource.sourceControl must contain enabled and gateEpoch.");
      exactKeys(control, ["enabled", "gateEpoch"], detail => fail(`githubSource.sourceControl ${detail}`));
      if (typeof control.enabled !== "boolean" || !Number.isSafeInteger(control.gateEpoch) || control.gateEpoch < 1)
        fail("githubSource.sourceControl requires a boolean enabled and positive safe integer gateEpoch.");
    }
    for (const gate of ["watchControl", "initialReconciliation"] as const) {
      if (source[gate] !== undefined && typeof source[gate] !== "boolean") fail(`githubSource.${gate} must be a boolean.`);
    }
    if (source.watchControl === true && source.sourceControl?.enabled !== true)
      fail("githubSource.watchControl requires sourceControl.enabled.");
    if (source.initialReconciliation === true && source.watchControl !== true)
      fail("githubSource.initialReconciliation requires watchControl.");
    if (typeof source.appId !== "string" || !/^[1-9][0-9]{0,127}$/.test(source.appId))
      fail("githubSource.appId must be a positive decimal GitHub App ID.");
    const mapping = source.mapping;
    validateGitHubSourceMapping(mapping, detail => fail(`githubSource.${detail}`));
    if (!allowed(source.mapping.principal, parseAllowedPrincipals(messaging.allowedPrincipals.join(","))))
      fail("githubSource.mapping principal must be admitted by Messaging.");
  }
  if (!runtime.queues || typeof runtime.queues !== "object") fail("queues must identify provisioned delivery and dead-letter queues.");
  exactKeys(runtime.queues, ["delivery", "deadLetter"], fail);
  for (const queue of [runtime.queues.delivery, runtime.queues.deadLetter]) {
    if (!queue || typeof queue !== "object") fail("queues must contain name and id.");
    exactKeys(queue, ["name", "id"], fail);
    if (typeof queue.name !== "string" || !/^[a-z0-9][a-z0-9-]{0,62}$/.test(queue.name) ||
        typeof queue.id !== "string" || !/^[0-9a-f]{32}$/.test(queue.id)) fail("queues must contain fixed names and Cloudflare queue ids.");
  }
  if (runtime.queues.delivery.name === runtime.queues.deadLetter.name || runtime.queues.delivery.id === runtime.queues.deadLetter.id)
    fail("queues must be distinct.");
}

/** The shared human shell has its own origin and audience; both gatekeepers remain authoritative. */
function validateAdminUi(config: DeploymentConfig): void {
  const ui = config.adminUi;
  if (ui === undefined) return;
  const fail = (detail: string): never => { throw new Error(`adminUi.${detail}`); };
  if (!ui || typeof ui !== "object" || typeof ui.deploy !== "boolean") fail("deploy must be a boolean.");
  if (!ui.deploy) { exactKeys(ui, ["deploy"], fail); return; }
  exactKeys(ui, ["deploy", "hostname", "access"], fail);
  if (!config.memory?.deploy || !config.messaging?.deploy) fail("requires both native gatekeepers to be deployed.");
  if (!config.workers.adminUi?.name || !WORKER_NAME.test(config.workers.adminUi.name)) fail("workers.adminUi.name must be a lowercase Worker name.");
  const hosts = [new URL(publicOrigin(config)).hostname, config.memory?.hostname,
    config.messaging?.hostname, config.messaging?.oauth?.hostname,
    config.openApiOperator?.enabled ? config.openApiOperator.hostname : undefined,
    config.mcpPortal.deploy && config.mcpPortal.url ? new URL(config.mcpPortal.url).hostname : undefined];
  if (typeof ui.hostname !== "string" || !isValidHostname(ui.hostname) || hosts.includes(ui.hostname) ||
      ui.hostname === "workers.dev" || ui.hostname.endsWith(".workers.dev")) fail("hostname must be a distinct custom domain.");
  if (!ui.access || typeof ui.access !== "object") fail("access is required.");
  exactKeys(ui.access, ["issuer", "audience"], fail);
  const issuers = [config.memory?.access.issuer, config.messaging?.access.issuer];
  if (typeof ui.access.issuer !== "string" || issuers.some(issuer => issuer !== ui.access.issuer)) fail("access.issuer must match both gatekeepers.");
  const audiences = [config.access.audience, config.memory?.access.audience,
    config.messaging?.access.audience, config.messaging?.oauth?.audience,
    config.openApiOperator?.enabled ? config.openApiOperator.access.audience : undefined];
  if (typeof ui.access.audience !== "string" || !/^[a-f0-9]{64}$/.test(ui.access.audience) || audiences.includes(ui.access.audience))
    fail("access.audience must identify a separate human-only application.");
}

/** The org domain the setup Worker admits (packages/setup DOMAIN): every enrollPrincipals entry must sit inside it. */
export const SETUP_DOMAIN = "@knitli.com";
/** The setup host the helper, the installer and the Agents page have compiled in (c2-7 pins them to this). */
export const SETUP_HOSTNAME = "setup.knitli.app";
const RELEASE_SHA256 = /^[0-9a-f]{64}$/;

/**
 * The setup host (R4 P2c): its own hostname and Access audience, distinct from every other enabled surface, the issuer Messaging
 * verifies its assertions with, and the committed release hash. The other validators do not list setup's host or audience: equality
 * is symmetric, so this one check covers both directions, and they run before this one has checked setup's shape.
 */
function validateSetup(config: DeploymentConfig): void {
  const setup = config.setup;
  if (setup === undefined) return;
  const fail = (detail: string): never => { throw new Error(`setup.${detail}`); };
  if (!setup || typeof setup !== "object" || Array.isArray(setup) || typeof setup.deploy !== "boolean") fail("deploy must be a boolean.");
  if (setup.releaseSha256 !== undefined && (typeof setup.releaseSha256 !== "string" || !RELEASE_SHA256.test(setup.releaseSha256)))
    fail("releaseSha256 must be the installer's SHA-256, 64 lowercase hex characters (pnpm run setup:release-hash writes it).");
  if (!setup.deploy) {
    if (Object.keys(setup).some((key) => !["deploy", "releaseSha256"].includes(key))) fail("holds only deploy and releaseSha256 while deploy is false.");
    return;
  }
  exactKeys(setup, ["deploy", "hostname", "access", "releaseSha256"], fail);
  if (!config.workers.setup?.name || !WORKER_NAME.test(config.workers.setup.name)) fail("workers.setup.name must be a lowercase Worker name.");
  const messaging = config.messaging;
  if (!messaging?.deploy) fail("deploy requires messaging.deploy: the setup host relays every redeem and poll to Messaging.");
  // The Worker admits only the org domain, so a code minted for anyone else could never be redeemed through it.
  if (!messaging!.enrollPrincipals?.length || !messaging!.enrollPrincipals.every((entry) => entry.trim().toLowerCase().endsWith(SETUP_DOMAIN)))
    fail(`deploy requires messaging.enrollPrincipals, every entry within ${SETUP_DOMAIN} (the domain the setup Worker admits).`);
  const hosts = [new URL(publicOrigin(config)).hostname, messaging!.hostname, messaging!.oauth?.hostname,
    ...(config.memory?.deploy ? [config.memory.hostname] : []),
    ...(config.eventRuntime?.deploy ? [config.eventRuntime.hostname] : []),
    ...(config.adminUi?.deploy ? [config.adminUi.hostname] : []),
    ...(config.openApiOperator?.enabled ? [config.openApiOperator.hostname] : []),
    ...(config.mcpPortal.deploy && config.mcpPortal.url ? [new URL(config.mcpPortal.url).hostname] : [])];
  if (typeof setup.hostname !== "string" || !isValidHostname(setup.hostname) || hosts.includes(setup.hostname) ||
      setup.hostname === "workers.dev" || setup.hostname.endsWith(".workers.dev")) fail("hostname must be a distinct custom domain.");
  if (setup.hostname !== SETUP_HOSTNAME) fail(`hostname must be ${SETUP_HOSTNAME}, the host the helper, the installer and the Agents page have compiled in.`);
  if (!setup.access || typeof setup.access !== "object" || Array.isArray(setup.access)) fail("access is required.");
  exactKeys(setup.access, ["issuer", "audience"], fail);
  if (setup.access.issuer !== messaging!.access.issuer) fail("access.issuer must match Messaging's, which verifies the setup host's assertions.");
  const audiences = [config.access.audience, messaging!.access.audience, messaging!.oauth?.audience,
    ...(config.memory?.deploy ? [config.memory.access.audience] : []),
    ...(config.eventRuntime?.deploy ? [config.eventRuntime.access.audience] : []),
    ...(config.adminUi?.deploy ? [config.adminUi.access.audience] : []),
    ...(config.openApiOperator?.enabled ? [config.openApiOperator.access.audience] : [])];
  if (typeof setup.access.audience !== "string" || !/^[a-f0-9]{64}$/.test(setup.access.audience) || audiences.includes(setup.access.audience))
    fail("access.audience must identify the setup host's own Access application.");
}

// --- human presence (R4 P5a-2, plan 6.3, Appendix A) --------------------------------------------------------------

export { MAX_WINDOW_MS };
const SHA256_HEX_RE = /^[0-9a-f]{64}$/;
const NAMESPACE_RE = /^[a-z0-9-]{1,64}$/;

/** Every hostname another enabled surface holds, for the new hosts to differ from: symmetric with the others' lists, since this runs after them. */
function otherHostnames(config: DeploymentConfig): string[] {
  const messaging = config.messaging;
  return [new URL(publicOrigin(config)).hostname, messaging?.hostname, messaging?.oauth?.hostname,
    ...(config.memory?.deploy ? [config.memory.hostname] : []),
    ...(config.eventRuntime?.deploy ? [config.eventRuntime.hostname] : []),
    ...(config.adminUi?.deploy ? [config.adminUi.hostname] : []),
    ...(config.setup?.deploy ? [config.setup.hostname] : []),
    ...(config.openApiOperator?.enabled ? [config.openApiOperator.hostname] : []),
    ...(config.mcpPortal.deploy && config.mcpPortal.url ? [new URL(config.mcpPortal.url).hostname] : [])].filter((host): host is string => typeof host === "string");
}

/** The presence host (R4 P5a): its own hostname and Access application, the issuer Messaging verifies its assertions with, and the Worker (packages/presence-ui) that serves it. */
function validatePresenceHost(config: DeploymentConfig): void {
  const host = config.presenceHost;
  if (host === undefined) return;
  const fail = (detail: string): never => { throw new Error(`presenceHost.${detail}`); };
  if (!host || typeof host !== "object" || Array.isArray(host) || typeof host.deploy !== "boolean") fail("deploy must be a boolean.");
  if (!host.deploy) { exactKeys(host, ["deploy"], fail); return; }
  exactKeys(host, ["deploy", "hostname", "access"], fail);
  const messaging = config.messaging;
  if (!messaging?.deploy) fail("deploy requires messaging.deploy: Messaging verifies the presence host's assertions.");
  if (!config.workers.presence?.name || !WORKER_NAME.test(config.workers.presence.name)) fail("deploy requires workers.presence.name, a lowercase Worker name.");
  if (typeof host.hostname !== "string" || !isValidHostname(host.hostname) || otherHostnames(config).includes(host.hostname) ||
      host.hostname === "workers.dev" || host.hostname.endsWith(".workers.dev")) fail("hostname must be a distinct custom domain.");
  if (!host.access || typeof host.access !== "object" || Array.isArray(host.access)) fail("access is required.");
  exactKeys(host.access, ["issuer", "audience"], fail);
  if (host.access.issuer !== messaging!.access.issuer) fail("access.issuer must match Messaging's, which verifies the presence host's assertions.");
  // A sixth audience, collision-checked against every other Access application in this file (a token for one must not pass for the presence host).
  const audiences = [config.access.audience, messaging!.access.audience, messaging!.oauth?.audience,
    ...(config.memory?.deploy ? [config.memory.access.audience] : []),
    ...(config.eventRuntime?.deploy ? [config.eventRuntime.access.audience] : []),
    ...(config.adminUi?.deploy ? [config.adminUi.access.audience] : []),
    ...(config.setup?.deploy ? [config.setup.access.audience] : []),
    ...(config.openApiOperator?.enabled ? [config.openApiOperator.access.audience] : [])];
  if (typeof host.access.audience !== "string" || !/^[a-f0-9]{64}$/.test(host.access.audience) || audiences.includes(host.access.audience))
    fail("access.audience must identify the presence host's own Access application.");
}

type PresenceOn = Extract<NonNullable<DeploymentConfig["presence"]>, { deploy: true }>;

/**
 * The origins the presence Worker will link and refresh to once a ceremony is done: the admin UI and the deployment's public origin (admin.knitli.app and os.knitli.app
 * in the live deployment). Nothing else is ever followed. This is the Worker's list; Messaging's admin API stores only the admin UI's origin with a draft, so what a
 * draft can ask for is narrower, and the Worker checks it again against this wider one.
 */
export function presenceReturnOrigins(config: DeploymentConfig): string[] {
  return [...new Set([...(config.adminUi?.deploy ? [`https://${config.adminUi.hostname}`] : []), new URL(publicOrigin(config)).origin])];
}

/** The Messaging variables presence generates: the blank off state, or the pins, floors, windows and flags of the block (never hand-edited). */
export function presenceMessagingVars(config: DeploymentConfig, windows: readonly { principal: string; until: string; secretSha256: string }[] = []): Record<string, string> {
  const presence = config.presence;
  const host = config.presenceHost;
  if (!presence?.deploy || !host?.deploy) {
    return {
      ACCESS_PRESENCE_AUD: "", PRESENCE_RP_ID: "", PRESENCE_ORIGIN: "", PRESENCE_AUD: "", PRESENCE_ANCHORS: "[]", PRESENCE_FLOORS: "{}",
      PRESENCE_ENROLL_WINDOWS: "[]", PRESENCE_ENFORCE: "{}", PRESENCE_LIVENESS_ANCHORS: "{}",
    };
  }
  return {
    ACCESS_PRESENCE_AUD: host.access.audience,
    PRESENCE_RP_ID: presence.rpId, PRESENCE_ORIGIN: presence.origin, PRESENCE_AUD: `knitli-os/${config.messaging!.namespace}`,
    PRESENCE_ANCHORS: JSON.stringify(presence.anchors), PRESENCE_FLOORS: JSON.stringify(presence.assuranceFloors),
    PRESENCE_ENROLL_WINDOWS: JSON.stringify(windows), PRESENCE_ENFORCE: JSON.stringify(presence.enforce), PRESENCE_LIVENESS_ANCHORS: JSON.stringify(presence.livenessAnchors),
  };
}

/** What a verifying service (Memory, Execution) is given of the trust root: the relying party, the audience of acts, the pins and the floors. Nothing when presence is off. */
export function presenceVerifierVars(config: DeploymentConfig): Record<string, string> {
  const vars = presenceMessagingVars(config);
  if (!vars.PRESENCE_RP_ID) return {};
  return { PRESENCE_RP_ID: vars.PRESENCE_RP_ID!, PRESENCE_ORIGIN: vars.PRESENCE_ORIGIN!, PRESENCE_AUD: vars.PRESENCE_AUD!, PRESENCE_ANCHORS: vars.PRESENCE_ANCHORS!, PRESENCE_FLOORS: vars.PRESENCE_FLOORS! };
}

/**
 * Human presence (R4 P5a, plan 6.3): the deployed trust root. Off, the block holds only `deploy`. On, every member is explicit and checked by the readers the Workers
 * use (authority's pinned-file parser, Messaging's own presenceConfig over the variables this would generate), so a block that the Worker would refuse fails here, not live.
 */
function validatePresence(config: DeploymentConfig): void {
  const presence = config.presence;
  if (presence === undefined) return;
  const fail = (detail: string): never => { throw new Error(`presence.${detail}`); };
  if (!presence || typeof presence !== "object" || Array.isArray(presence) || typeof presence.deploy !== "boolean") fail("deploy must be a boolean.");
  if (!presence.deploy) { exactKeys(presence, ["deploy"], fail); return; }
  exactKeys(presence, ["deploy", "rpId", "origin", "anchors", "enrollWindows", "assuranceFloors", "activationDelayHours", "enforce", "livenessAnchors"], fail);
  const on = presence as PresenceOn;
  const host = config.presenceHost;
  const messaging = config.messaging;
  if (!host?.deploy || !messaging?.deploy) fail("deploy requires presenceHost.deploy and messaging.deploy: the ceremony runs on the presence host and is hosted in Messaging.");
  const presenceHostname = (host as { hostname: string }).hostname;
  // The relying party is permanent (plan 6.3): a credential is bound to it, and changing it invalidates every one.
  if (on.rpId !== presenceHostname) fail("rpId must be the presence host's hostname.");
  if (on.origin !== `https://${presenceHostname}`) fail("origin must be https:// and the presence host's hostname, nothing more.");
  if (typeof messaging!.namespace !== "string" || !NAMESPACE_RE.test(messaging!.namespace)) fail("requires messaging.namespace to be lowercase letters, digits and hyphens: an act's audience is knitli-os/<namespace>.");
  if (on.activationDelayHours !== ACTIVATION_DELAY_HOURS) fail(`activationDelayHours must be ${ACTIVATION_DELAY_HOURS}: the renderer tells the person that number.`);
  if (!parsePinnedFile({ v: 1, anchors: on.anchors, floors: on.assuranceFloors, activationDelayHours: on.activationDelayHours }))
    fail("anchors (a principal, a canonical thumbprint and a label each; at most eight a person; a key pins one person) or assuranceFloors (a default, and touch-only for orders alone) is malformed.");
  const rules = parseAllowedPrincipals(messaging!.allowedPrincipals.join(","));
  const admitted = (principal: unknown): boolean => typeof principal === "string" && isCanonicalPrincipal(principal) && allowed(principal, rules);
  if (!on.anchors.every((anchor) => admitted(anchor.principal))) fail("anchors must name people messaging.allowedPrincipals admits: a pin for anyone else could never sign.");
  if (!Array.isArray(on.enrollWindows) || on.enrollWindows.length > MAX_WINDOWS) fail(`enrollWindows is a list of at most ${MAX_WINDOWS}.`);
  for (const window of on.enrollWindows) {
    exactKeys(window, ["principal", "until", "secretSha256"], (detail) => fail(`enrollWindows entry ${detail}`));
    if (!admitted(window.principal) || typeof window.until !== "string" || !Number.isFinite(isoTime(window.until))) fail("enrollWindows entries are { principal, until, secretSha256 }: an admitted person, an ISO time with a zone and the secret's hash.");
    // The owner makes the secret locally (scripts/presence-window.ts) and writes only its hash here; CI never sees the secret.
    if (typeof window.secretSha256 !== "string" || !SHA256_HEX_RE.test(window.secretSha256) || window.secretSha256 === "0".repeat(64)) fail("enrollWindows secretSha256 is the lowercase 64-hex SHA-256 that scripts/presence-window.ts prints (not all zeros).");
  }
  if (new Set(on.enrollWindows.map((window) => window.secretSha256)).size !== on.enrollWindows.length) fail("enrollWindows secretSha256 repeats: each window has its own secret (a copied entry is a mistake).");
  exactKeys(on.enforce, [...ENFORCED_KINDS], (detail) => fail(`enforce ${detail}`));
  if (!ENFORCED_KINDS.every((kind) => (MODES as readonly unknown[]).includes(on.enforce[kind]))) fail(`enforce values are ${MODES.join(" | ")}.`);
  // Plan 13.3 item 3 as a check: closing the grant and scope paths while a key, a binding or a wake policy can still be set by a session is theatre.
  for (const kind of ["grant", "agent-scope"] as const) {
    const open = (["agent-enroll", "bind-existing", "activation", "declare-task"] as const).filter((core) => on.enforce[core] !== "enforce");
    if (on.enforce[kind] === "enforce" && open.length > 0) fail(`enforce.${kind} is enforce while ${open.join(", ")} ${open.length === 1 ? "is" : "are"} not: enforce the core kinds first (plan 13.3).`);
  }
  if (on.livenessAnchors === null || typeof on.livenessAnchors !== "object" || Array.isArray(on.livenessAnchors) ||
      !Object.entries(on.livenessAnchors).every(([principal, count]) => admitted(principal) && Number.isSafeInteger(count) && count >= MIN_ANCHORS_PER_PRINCIPAL && count <= MAX_ANCHORS_PER_PRINCIPAL))
    fail(`livenessAnchors maps an admitted person to the number of pins declared for them, from ${MIN_ANCHORS_PER_PRINCIPAL} to the most a person can pin.`);
  // The liveness ceremony is offered only when the pins are exactly the number declared (liveness.ts), so a count that is not the number of anchors would leave it denied for good.
  const pinned = new Map<string, number>();
  for (const anchor of on.anchors) pinned.set(anchor.principal, (pinned.get(anchor.principal) ?? 0) + 1);
  for (const [principal, count] of pinned) if (on.livenessAnchors[principal] !== count) fail(`livenessAnchors[${principal}] must equal the number of anchors pinned for them (${count}): the liveness check is offered only when they match.`);
  for (const [principal, count] of Object.entries(on.livenessAnchors)) if ((pinned.get(principal) ?? 0) !== count) fail(`livenessAnchors[${principal}] is ${count} but ${pinned.get(principal) ?? 0} anchors are pinned for them: they must be the same number.`);
  // The last word is the Worker's own reader: what it would refuse, this refuses.
  const vars = {
    ...presenceMessagingVars(config, on.enrollWindows),
    ACCESS_ISSUER: messaging!.access.issuer, ACCESS_AUD: messaging!.access.audience,
    ...(messaging!.oauth && { ACCESS_OAUTH_AUD: messaging!.oauth.audience }),
    ...(config.memory?.deploy && { ACCESS_MEMORY_AUD: config.memory.access.audience }),
    ...(config.eventRuntime?.deploy && { ACCESS_EVENT_AUD: config.eventRuntime.access.audience }),
    ...(config.adminUi?.deploy && { ACCESS_UI_AUD: config.adminUi.access.audience }),
    ...(config.setup?.deploy && { ACCESS_SETUP_AUD: config.setup.access.audience }),
  };
  if (presenceConfig(vars) === null) fail("is not a configuration the Messaging Worker accepts (check the pins, the floors and the presence audience).");
}

/** The notice channel (R4 D11): ntfy, its secrets installed as Worker secrets, and the admin UI's origin for the link. */
function validateNotify(config: DeploymentConfig): void {
  const notify = config.notify;
  if (notify === undefined) return;
  const fail = (detail: string): never => { throw new Error(`notify.${detail}`); };
  if (!notify || typeof notify !== "object" || Array.isArray(notify) || typeof notify.deploy !== "boolean") fail("deploy must be a boolean.");
  if (!notify.deploy) { exactKeys(notify, ["deploy"], fail); return; }
  exactKeys(notify, ["deploy", "channel", "baseUrl"], fail);
  if (!config.messaging?.deploy || !config.adminUi?.deploy) fail("deploy requires messaging.deploy and adminUi.deploy: a notice links to the admin UI's Security page.");
  if (notify.channel !== "ntfy") fail('channel must be "ntfy" (the email fallback waits on SP-8 and is not built).');
  // The Worker pushes only to a public https host (ntfy-host.ts, the same rule): not localhost, an address, or an internal name.
  if (publicHttpsOrigin(notify.baseUrl) === null) fail("baseUrl must be an https origin on a public DNS name such as https://ntfy.sh, with no path, port or credentials.");
}

/**
 * Orders (R4 P5b, plan 13.3a, 13.3 item 3). An order is a hardware-signed act, so emission needs presence; the consequence rule needs orders to exist, and
 * `enforce` comes after `declare-task` is enforced (lowest blast radius first): a session could otherwise declare a type inform to slip past it.
 */
function validateAuthority(config: DeploymentConfig): void {
  const authority = config.authority;
  if (authority === undefined) return;
  const fail = (detail: string): never => { throw new Error(`authority.${detail}`); };
  if (!authority || typeof authority !== "object" || Array.isArray(authority)) fail("must be { orderEmission, consequenceRule }.");
  exactKeys(authority, ["orderEmission", "consequenceRule"], fail);
  if (authority.orderEmission !== "off" && authority.orderEmission !== "on") fail('orderEmission is "off" or "on".');
  if (!(MODES as readonly unknown[]).includes(authority.consequenceRule)) fail(`consequenceRule is ${MODES.join(" | ")}.`);
  if (authority.orderEmission === "on" && !config.presence?.deploy) fail("orderEmission on requires presence.deploy: an order is a hardware-signed act.");
  if (authority.consequenceRule !== "off" && authority.orderEmission !== "on") fail("consequenceRule needs orderEmission on: without orders, nothing could satisfy it.");
  const presence = config.presence as { deploy: true; enforce: Record<string, string> } | undefined;
  if (authority.consequenceRule === "enforce" && presence?.enforce["declare-task"] !== "enforce") fail("consequenceRule is enforce while presence.enforce.declare-task is not: enforce declare-task first (plan 13.3).");
}

/** The Messaging variables of the authority block: both off when it is absent. */
export function authorityMessagingVars(config: DeploymentConfig): Record<string, string> {
  return { AUTHORITY_ORDER_EMISSION: config.authority?.orderEmission ?? "off", AUTHORITY_CONSEQUENCE_RULE: config.authority?.consequenceRule ?? "off" };
}

/** The Messaging variables the notice channel generates; the topic and token are secrets, required when it is on. */
export function notifyMessagingVars(config: DeploymentConfig): Record<string, string> {
  const notify = config.notify;
  if (!notify?.deploy || !config.adminUi?.deploy) return { NOTIFY_CHANNEL: "", NOTIFY_NTFY_URL: "", NOTIFY_LINK_ORIGIN: "" };
  return { NOTIFY_CHANNEL: notify.channel, NOTIFY_NTFY_URL: notify.baseUrl, NOTIFY_LINK_ORIGIN: `https://${config.adminUi.hostname}` };
}
export const NOTIFY_SECRETS = ["NOTIFY_NTFY_TOPIC", "NOTIFY_NTFY_TOKEN"] as const;

/** The clock, replaced in tests only. */
export type PresenceInput = { now?: number };

/** The windows open at `input.now`, each with the hash of its own secret, which the owner made locally and wrote in deployment.jsonc. */
export function openEnrollWindows(config: DeploymentConfig, input: PresenceInput): { principal: string; until: string; secretSha256: string }[] {
  const presence = config.presence;
  if (!presence?.deploy) return [];
  const now = input.now ?? Date.now();
  return presence.enrollWindows.filter((window) => isoTime(window.until) > now).map((window) => ({ principal: window.principal, until: new Date(isoTime(window.until)).toISOString(), secretSha256: window.secretSha256 }));
}

/** A deploy that would open a window that outlasts MAX_WINDOW_MS, or two open windows for one person, is refused before anything is deployed. */
export function assertPresenceWindows(config: DeploymentConfig, input: PresenceInput): void {
  const presence = config.presence;
  if (!presence?.deploy) return;
  const now = input.now ?? Date.now();
  const seen = new Set<string>();
  for (const window of presence.enrollWindows.filter((window) => isoTime(window.until) > now)) {
    if (isoTime(window.until) - now > MAX_WINDOW_MS) throw new Error(`presence.enrollWindows for ${window.principal} ends more than ${MAX_WINDOW_MS / 3600_000} hours from now: a registration window is hours long.`);
    // Messaging takes the first open window of a person, so a second one would make the newer secret fail while the older one stayed valid.
    if (seen.has(window.principal)) throw new Error(`presence.enrollWindows has more than one open window for ${window.principal}: remove the old entry (a lost or replaced secret) so only one secret can register.`);
    seen.add(window.principal);
  }
}

/** Standalone Node egress can be deployed before the managed OAuth Access app exists. */
function validateMessagingEgress(config: DeploymentConfig): void {
  const egress = config.messagingEgress;
  if (egress === undefined) return;
  const fail = (detail: string): never => { throw new Error(`messagingEgress.${detail}`); };
  if (!egress || typeof egress !== "object" || Array.isArray(egress) || typeof egress.deploy !== "boolean") fail("deploy must be a boolean.");
  // The egress Worker has no public hostname (#962); a leftover key would be silently ignored, so refuse it.
  if (Object.hasOwn(egress, "hostname")) fail("hostname was retired; remove it.");
  if (!egress.deploy) {
    if (Object.keys(egress).some(key => key !== "deploy")) fail("has unknown keys.");
    return;
  }
  exactKeys(egress, ["deploy"], detail => fail(detail));
  const name = config.workers.messagingEgress?.name;
  if (typeof name !== "string" || !WORKER_NAME.test(name)) fail("workers.messagingEgress.name must be a lowercase Worker name.");
}

/** The Access-protected ingestion control plane: its own hostname and audience, never the Workshop's. */
function validateOpenApiOperator(config: DeploymentConfig): void {
  const operator = config.openApiOperator;
  if (operator === undefined) return;
  const fail = (detail: string): never => { throw new Error(`openApiOperator: ${detail}`); };
  if (!operator || typeof operator.enabled !== "boolean") fail("enabled must be a boolean");
  if (!operator.enabled) { exactKeys(operator, ["enabled"], fail); return; }
  const keys = ["enabled", "hostname", "access"];
  if (operator.installations !== undefined) keys.push("installations");
  if (operator.catalogAgentModels !== undefined) keys.push("catalogAgentModels");
  exactKeys(operator, keys, fail);
  if (!config.workers.openApiOperator?.name) fail("workers.openApiOperator.name is required when enabled");
  if (!config.workers.catalogAgent?.name) fail("workers.catalogAgent.name is required when enabled");
  const models = operator.catalogAgentModels;
  if (
    models !== undefined &&
    (!Array.isArray(models) ||
      models.some((id) => typeof id !== "string" || !/^@cf\/[A-Za-z0-9._-]+\/[A-Za-z0-9._-]+$/.test(id)))
  )
    fail("catalogAgentModels must list Workers AI model ids (@cf/<vendor>/<model>)");
  if (aiGatewayPlan(config)?.crossAccount)
    fail(
      "catalog-agent needs an in-account aiGateway: cross-account gateways require token " +
        "transport, which the agent worker does not support",
    );
  try { parseAccessConfig(operator.access); } catch { fail("access is not a valid Access configuration"); }
  if (!operator.access.allowedEmails.length || operator.access.allowedEmails.some((email) => email.includes("*"))) fail("access.allowedEmails must list exact addresses");
  if (!/^[a-f0-9]{64}$/.test(operator.access.audience) || operator.access.audience === config.access.audience) fail("access.audience must be a dedicated Access application, not the Workshop's");
  const { hostname } = operator;
  if (typeof hostname !== "string" || !isValidHostname(hostname) || hostname === "workers.dev" || hostname.endsWith(".workers.dev") ||
      hostname === new URL(publicOrigin(config)).hostname) fail("hostname must be a dedicated custom domain");
  validateInstallations(operator, fail);
}

/** The installations backend block: storage names plus the machine-auth trust pins. Absent means off. */
function validateInstallations(operator: { hostname: string; installations?: unknown }, fail: (detail: string) => never): void {
  const installations = operator.installations;
  if (installations === undefined) return;
  if (!installations || typeof installations !== "object" || Array.isArray(installations)) fail("installations must be an object");
  const inst = installations as Record<string, unknown>;
  if (typeof inst.enabled !== "boolean") fail("installations.enabled must be a boolean");
  if (inst.enabled === false) { exactKeys(inst, ["enabled"], fail); return; }
  exactKeys(inst, ["enabled", "bucket", "secretKeyVersion", "runnerClientId", "deployClientId",
    "repository", "repositoryId", "ref", "environment", "workflowRef", "catalogIssuer", "manifestTrust",
    ...["publicationExecutor", "inspectionExecutor", "installationExecutor", "workflowRuntime", "runnerOidcAudience"].filter(key => Object.hasOwn(inst, key))],
    (d) => fail(`installations ${d}`));
  for (const key of ["publicationExecutor", "inspectionExecutor", "installationExecutor"]) {
    if (Object.hasOwn(inst, key) && inst[key] !== "actions" && inst[key] !== "workflow-v1") fail(`installations.${key} must be actions or workflow-v1`);
    if (key !== "publicationExecutor" && inst[key] === "workflow-v1") fail(`installations.${key} Workflow execution is not yet enabled; use actions`);
    if (inst[key] === "workflow-v1" && inst.workflowRuntime !== "deployed-v1") fail(`installations.${key} requires workflowRuntime deployed-v1`);
  }
  if (Object.hasOwn(inst, "workflowRuntime") && inst.workflowRuntime !== "absent" && inst.workflowRuntime !== "deployed-v1") fail("installations.workflowRuntime must be absent or deployed-v1");
  // The profile every new installation is minted with. Same rules as an openApis[].catalog issuer
  // and trust block; the worker re-parses it strictly (parseInstallationDeploymentProfile).
  if (!trustText(inst.catalogIssuer, 128, 128)) fail("installations.catalogIssuer must be 1 to 128 bytes of control-free text");
  validateManifestTrust(inst.manifestTrust, inst.catalogIssuer, (d) => fail(`installations ${d}`));
  if (typeof inst.bucket !== "string" || !/^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(inst.bucket)) {
    fail("installations.bucket must be a valid R2 bucket name (3-63 lowercase alphanumerics and hyphens)");
  }
  if (typeof inst.secretKeyVersion !== "string" || !inst.secretKeyVersion) fail("installations.secretKeyVersion must be a non-empty version label");
  // Mirrors the parseRunnerAuthConfig field rules (runner-auth.ts imports with .js suffixes, which
  // plain node cannot load, so deploy.ts cannot call it directly). The worker re-validates strictly
  // at runtime, so drift here only weakens preflight errors, never security.
  // Same shape as the worker's identifier(): non-empty, byte-bounded, no controls or spaces.
  const trust = (value: unknown, max: number): value is string => {
    if (typeof value !== "string" || value.length === 0 || Buffer.byteLength(value) > max) return false;
    return !Array.from(value).some((character) => {
      const code = character.charCodeAt(0);
      return code <= 0x20 || (code >= 0x7f && code <= 0x9f);
    });
  };
  if (!trust(inst.runnerClientId, 256) || !trust(inst.deployClientId, 256) || inst.runnerClientId === inst.deployClientId) {
    fail("installations runnerClientId and deployClientId must be distinct non-empty identifiers");
  }
  const part = "[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,99})";
  if (typeof inst.repository !== "string" || !new RegExp(`^${part}/${part}$`).test(inst.repository)) {
    fail("installations.repository must be owner/name");
  }
  if (!trust(inst.repositoryId, 20) || !/^[1-9][0-9]{0,19}$/.test(inst.repositoryId as string)) {
    fail("installations.repositoryId must be a decimal GitHub repository id");
  }
  if (!trust(inst.ref, 256) || !(inst.ref as string).startsWith("refs/")) fail("installations.ref must use the full claim form (refs/heads/...)");
  if (!trust(inst.environment, 256)) fail("installations.environment must be a non-empty identifier");
  if (!trust(inst.workflowRef, 512) || !(inst.workflowRef as string).includes("@") ||
      !(inst.workflowRef as string).split("@")[0].includes("/")) {
    fail("installations.workflowRef must be a full job_workflow_ref claim (...@refs/heads/...)");
  }
  // The runner mints its OIDC audience from the operator hostname (mintRunnerOidc), so that is the
  // only audience that can ever verify: an explicit value must equal it, and generateConfigs derives
  // it when absent. The worker re-checks the URL shape and a 256-byte cap (runner-auth.ts
  // runnerOidcAudience); enforce the cap here so a long hostname fails preflight, not every route.
  const audience = runnerAudience(operator.hostname);
  if ((Object.hasOwn(inst, "runnerOidcAudience") && inst.runnerOidcAudience !== audience) || audience.length > 256) {
    fail(`installations.runnerOidcAudience must be ${audience}, at most 256 bytes`);
  }
}

/** The only OIDC audience the runner mints for an operator on `hostname`. */
function runnerAudience(hostname: string): string {
  return `https://${hostname}/v1/installations/runner`;
}

/** The execution gatekeeper and its runtime, both deployed here when `enabled` (#624 phase 2). */
function validateExecution(config: DeploymentConfig, taskRoot: string): void {
  const execution = config.execution;
  if (execution === undefined) return;
  if (!execution || typeof execution !== "object" || Array.isArray(execution) ||
      typeof execution.enabled !== "boolean" ||
      !Object.keys(execution).every((key) => ["enabled", "budgetUsd", "namespace", "allowedPrincipals", "profiles"].includes(key))) {
    throw new Error("execution has invalid or unknown configuration.");
  }
  if (!execution.enabled) return;
  // The task manifests are the pins; a generated file that disagrees with them (edited by hand, or not regenerated) must not ship.
  assertExecutionTasksFresh(taskRoot);
  if (typeof execution.budgetUsd !== "number" || !Number.isFinite(execution.budgetUsd) ||
      execution.budgetUsd < 1 || execution.budgetUsd > 10 ||
      !/^(?:0|[1-9]\d*)(?:\.\d{1,2})?$/.test(String(execution.budgetUsd)))
    throw new Error("execution.budgetUsd must fund at least $1 and at most $10, with at most two decimal places.");
  if (typeof execution.namespace !== "string" || !execution.namespace.trim())
    throw new Error("execution.namespace must be a non-empty string.");
  if (!Array.isArray(execution.allowedPrincipals) || !execution.allowedPrincipals.length ||
      !execution.allowedPrincipals.every((value) => typeof value === "string" && !value.includes(",")))
    throw new Error("execution.allowedPrincipals must be an explicit non-empty list.");
  try { parseAllowedPrincipals(execution.allowedPrincipals.join(",")); }
  catch { throw new Error("execution.allowedPrincipals contains an invalid principal."); }
  // The gatekeeper's own rules (#624), so a catalog it would refuse never deploys.
  const profiles = parseCatalog(execution.profiles, execution.allowedPrincipals.join(","));
  for (const [index, profile] of profiles.entries()) {
    if (!profile.image.startsWith(`registry.cloudflare.com/${config.accountId}/`))
      throw new Error(`execution.profiles[${index}].image must be in this account's Cloudflare registry (registry.cloudflare.com/${config.accountId}/).`);
    // The origin check reaches Messaging through MESSAGING_AUTHORITY, which is bound only while Messaging deploys here.
    if (profile.origin === "required" && !config.messaging?.deploy)
      throw new Error(`execution.profiles[${index}].origin is "required", which needs messaging.deploy to be true: without Messaging the profile could never run.`);
  }
  // The RunLedger bounds spend and concurrency at run time (R4 E1): per profile by its own caps, across profiles by the
  // funded budget over any 24 hours. That replaces the static ceiling of one $1 reservation per profile, which only held
  // while every profile ran once. What deploy can still refuse is a profile that could never run.
  for (const [index, profile] of profiles.entries())
    if (profile.run?.mode === "ledger" && profile.run.usdPerRun > execution.budgetUsd)
      throw new Error(`execution.profiles[${index}].run.usdPerRun ($${profile.run.usdPerRun}) exceeds execution.budgetUsd ($${execution.budgetUsd}), so the ledger could never admit a run.`);
}

/** Reject partial or token-bearing AI Executor configuration before any files are generated. */
function validateAiExecutors(config: DeploymentConfig): void {
  const executors = config.aiExecutors;
  if (
    !executors ||
    typeof executors !== "object" ||
    Array.isArray(executors) ||
    !Object.keys(executors).every(
      (key) => key === "enabled" || key === "gateway",
    )
  ) {
    throw new Error(
      "aiExecutors must contain only enabled and gateway configuration.",
    );
  }
  if (typeof executors.enabled !== "boolean") {
    throw new Error("aiExecutors.enabled must be a boolean.");
  }
  const gateway = executors.gateway;
  if (
    gateway !== undefined &&
    (!gateway ||
      typeof gateway !== "object" ||
      Array.isArray(gateway) ||
      !Object.keys(gateway).every(
        (key) => key === "accountId" || key === "name",
      ))
  ) {
    throw new Error(
      "aiExecutors.gateway must contain only accountId and name, never a token.",
    );
  }
  if (!executors.enabled) return;
  if (!gateway) {
    throw new Error(
      "aiExecutors.gateway is required when aiExecutors.enabled is true.",
    );
  }
  if (!accountIdPattern.test(gateway.accountId)) {
    throw new Error(
      "aiExecutors.gateway.accountId must be 32 hexadecimal characters.",
    );
  }
  if (typeof gateway.name !== "string" || !gateway.name.trim()) {
    throw new Error("aiExecutors.gateway.name must be a non-empty string.");
  }
}

function routeConfig(route: RouterRoute) {
  return route.workersDev
    ? { workers_dev: true, routes: undefined }
    : {
        workers_dev: false,
        routes: [{ pattern: route.customDomain!, custom_domain: true }],
      };
}

function setCommon(
  config: ProdWranglerConfig,
  deployment: DeploymentConfig,
  name: string,
  route: RouterRoute = { workersDev: false },
): void {
  config.account_id = deployment.accountId;
  config.name = name;
  config.workers_dev = route.workersDev;
  delete config.routes;
  if (route.customDomain) Object.assign(config, routeConfig(route));
  // The router is the Access-protected origin, and a preview URL is an unauthenticated path around
  // it. Off on every Worker: the five behind the router have no business being publicly reachable
  // either.
  config.preview_urls = false;
  config.observability = {
    ...config.observability,
    enabled: deployment.observability.enabled,
    head_sampling_rate: deployment.observability.headSamplingRate,
    logs: {
      ...config.observability?.logs,
      invocation_logs: deployment.observability.logs.invocationLogs,
    },
    traces: {
      ...config.observability?.traces,
      enabled: deployment.observability.traces.enabled,
      head_sampling_rate: deployment.observability.traces.headSamplingRate,
    },
  };
}

export function generateConfigs(
  config: DeploymentConfig,
  bases: BaseConfigs,
  resolvedApis: readonly OpenApiDeployment[] = config.openApis ?? [],
  presenceInput: PresenceInput = {},
): GeneratedConfigs {
  validateConfig(config);
  validateResolvedOpenApis(config, resolvedApis);
  // Here, not only in a real deploy, so --check, --dry-run and the pre-approval jobs refuse what the approved deploy would.
  assertPresenceWindows(config, presenceInput);
  const router = structuredClone(bases.router);
  const workshop = structuredClone(bases.workshop);
  const context = structuredClone(bases.context);
  const scheduler = structuredClone(bases.scheduler);
  const customGatekeeper = structuredClone(bases.customGatekeeper);
  const errorReporter = config.errorReporting.enabled
    ? structuredClone(bases.errorReporter)
    : undefined;
  const github = config.github.deploy
    ? structuredClone(bases.github)
    : undefined;
  const linear = config.linear.deploy
    ? structuredClone(bases.linear)
    : undefined;
  const microsoft = config.microsoft.deploy
    ? structuredClone(bases.microsoft)
    : undefined;
  const mcp = config.mcp.deploy ? structuredClone(bases.mcp) : undefined;
  const mcpPortal = config.mcpPortal.deploy
    ? structuredClone(bases.mcpPortal)
    : undefined;
  const email = config.email.deploy ? structuredClone(bases.email) : undefined;
  const cloudflare = config.cloudflare.deploy
    ? structuredClone(bases.cloudflare)
    : undefined;
  const x = config.x?.deploy === true ? structuredClone(bases.x) : undefined;
  const slack = config.slack?.deploy === true ? structuredClone(bases.slack) : undefined;
  const websearch = config.websearch?.deploy === true ? structuredClone(bases.websearch) : undefined;
  const apis = deployedOpenApis(resolvedApis);
  const operatorEnabled = config.openApiOperator?.enabled === true;
  if (operatorEnabled && !bases.openApiOperator) throw new Error("Missing openApiOperator base config.");
  const openApiOperator = operatorEnabled ? structuredClone(bases.openApiOperator!) : undefined;
  const catalogAgent = operatorEnabled ? structuredClone(bases.catalogAgent) : undefined;
  const memoryEnabled = config.memory?.deploy === true;
  if (memoryEnabled && !bases.memory) throw new Error("Missing memory base config.");
  const memory = memoryEnabled ? structuredClone(bases.memory!) : undefined;
  const messagingEnabled = config.messaging?.deploy === true;
  if (messagingEnabled && !bases.messaging) throw new Error("Missing messaging base config.");
  const messaging = messagingEnabled ? structuredClone(bases.messaging!) : undefined;
  const eventEnabled = config.eventRuntime?.deploy === true;
  if (eventEnabled && !bases.eventRuntime) throw new Error("Missing eventRuntime base config.");
  const eventRuntime = eventEnabled ? structuredClone(bases.eventRuntime!) : undefined;
  if (gatewayEdgeDeploys(config) && !bases.eventsEdge) throw new Error("Missing eventsEdge base config.");
  const eventsEdge = gatewayEdgeDeploys(config) ? structuredClone(bases.eventsEdge!) : undefined;
  const uiEnabled = config.adminUi?.deploy === true;
  if (uiEnabled && !bases.adminUi) throw new Error("Missing adminUi base config.");
  const adminUi = uiEnabled ? structuredClone(bases.adminUi!) : undefined;
  const setupEnabled = config.setup?.deploy === true;
  if (setupEnabled && !bases.setup) throw new Error("Missing setup base config.");
  const setup = setupEnabled ? structuredClone(bases.setup!) : undefined;
  const presenceEnabled = config.presenceHost?.deploy === true;
  if (presenceEnabled && !bases.presence) throw new Error("Missing presence base config.");
  const presenceUi = presenceEnabled ? structuredClone(bases.presence!) : undefined;
  const egressEnabled = config.messagingEgress?.deploy === true;
  if (egressEnabled && !bases.messagingEgress) throw new Error("Missing messagingEgress base config.");
  const messagingEgress = egressEnabled ? structuredClone(bases.messagingEgress!) : undefined;
  const aiInference = config.aiExecutors.enabled
    ? structuredClone(bases.aiInference)
    : undefined;
  const aiExecutor = config.aiExecutors.enabled
    ? structuredClone(bases.aiExecutor)
    : undefined;
  if (config.execution?.enabled && !bases.execution) throw new Error("Missing execution base config.");
  const execution = config.execution?.enabled ? structuredClone(bases.execution!) : undefined;
  if (config.execution?.enabled && !bases.executionRuntime) throw new Error("Missing executionRuntime base config.");
  const executionRuntime = config.execution?.enabled ? structuredClone(bases.executionRuntime!) : undefined;
  const origin = publicOrigin(config);

  setCommon(
    router,
    config,
    config.workers.router.name,
    config.workers.router.route,
  );
  router.services = [
    { binding: "WORKSHOP_BACKEND", service: config.workers.workshop.name },
    // No entrypoint and no props: the router forwards whole HTTP requests, unlike the backend's
    // vendor-RPC bindings. The binding name is what picks the /gatekeeper/<name> path.
    { binding: "GATEKEEPER_CONTEXT", service: config.workers.context.name },
    { binding: "GATEKEEPER_SCHEDULER", service: config.workers.scheduler.name },
    {
      binding: "GATEKEEPER_CUSTOM",
      service: config.workers.customGatekeeper.name,
    },
    ...(github
      ? [{ binding: "GATEKEEPER_GITHUB", service: config.workers.github.name }]
      : []),
    ...(linear
      ? [{ binding: "GATEKEEPER_LINEAR", service: config.workers.linear.name }]
      : []),
    ...(microsoft
      ? [{ binding: "GATEKEEPER_MICROSOFT", service: config.workers.microsoft.name }]
      : []),
    ...(mcp
      ? [{ binding: "GATEKEEPER_MCP", service: config.workers.mcp.name }]
      : []),
    ...(mcpPortal
      ? [
          {
            binding: "GATEKEEPER_MCP_PORTAL",
            service: config.workers.mcpPortal.name,
          },
        ]
      : []),
    ...(email
      ? [{ binding: "GATEKEEPER_EMAIL", service: config.workers.email.name }]
      : []),
    ...(cloudflare
      ? [{ binding: "GATEKEEPER_CLOUDFLARE", service: config.workers.cloudflare.name }]
      : []),
    ...(x ? [{ binding: "GATEKEEPER_X", service: requiredWorkerName(config.workers.x, "workers.x.name") }] : []),
    ...(slack ? [{ binding: "GATEKEEPER_SLACK", service: requiredWorkerName(config.workers.slack, "workers.slack.name") }] : []),
    // No GATEKEEPER_WEBSEARCH: Web Search has no connect flow and no fetch handler to route to.
    // No entrypoint, like every other gatekeeper here: the router forwards whole HTTP requests, so
    // /gatekeeper/<id>/oauth and the connect link reach the connector's default fetch.
    ...apis.map((api) => ({ binding: openApiBinding(api.id), service: api.worker })),
  ];

  setCommon(workshop, config, config.workers.workshop.name);
  workshop.vars = {
    OPENAPI_MCP_PUBLISHER_ENABLED: config.openApiPublisher?.enabled === true ? "true" : "false",
    OPENAPI_MCP_PUBLISHER_VENDOR_IDS: JSON.stringify(
      config.openApiPublisher?.enabled === true ? apis.map((api) => api.id).toSorted() : [],
    ),
    ADMINS: config.access.admins,
    CF_ACCESS_ISS: config.access.issuer.replace(/\/$/, ""),
    CF_ACCESS_AUD: config.access.audience,
    // Upstream builds OAuth redirect URIs and other absolute links from this. The backend has no
    // public route of its own, so the router's origin is the only correct value.
    PUBLIC_BASE_URL: origin,
  };
  if (config.openApiPublisher?.enabled === true &&
    (apis.length > 1024 || Buffer.byteLength(workshop.vars.OPENAPI_MCP_PUBLISHER_VENDOR_IDS as string) > 64 * 1024)) {
    throw new Error("openApiPublisher vendor list exceeds the host limit.");
  }
  const gateway = aiGatewayPlan(config);
  if (gateway) {
    Object.assign(workshop.vars, {
      CF_AI_GATEWAY: config.aiGateway.name,
      CF_AI_GATEWAY_ACCOUNT_ID: gateway.gatewayAccountId,
      CF_AI_GATEWAY_PROVIDERS: config.aiGateway.providers?.join(","),
      ...(gateway.crossAccount ? { CF_AI_GATEWAY_USE_BINDING: "false" } : {}),
    });
    // Only when a token is genuinely needed. On the common path the WORKERS_AI binding is the
    // transport and is pre-authenticated in-account, so demanding a secret would block a deploy
    // that has everything it needs. Where one IS needed, wrangler refusing to deploy without it is
    // a better check than anything this script could do.
    if (gateway.needsToken) {
      workshop.secrets = {
        required: [
          ...new Set([
            ...(workshop.secrets?.required ?? []),
            "CF_AI_GATEWAY_API_TOKEN",
          ]),
        ],
      };
    }
  }
  // The optional free-tier + Cloudflare-credits flow. Emitted only when asked for: the backend
  // reads `env.ENABLE_CLOUDFLARE_LIMITS === "true"`, so an absent var and a "false" var behave the
  // same and the absent one is the one nobody has to reason about.
  if (config.aiGateway.cloudflareLimits) {
    Object.assign(workshop.vars, {
      ENABLE_CLOUDFLARE_LIMITS: "true",
      ...(config.aiGateway.dailyLlmCallLimit != null
        ? { DAILY_LLM_CALL_LIMIT: String(config.aiGateway.dailyLlmCallLimit) }
        : {}),
    });
  }
  // Browser Web Push rides the VAPID secret alone: the backend derives the public identity from
  // it and PUBLIC_BASE_URL (emitted unconditionally above), and every push entry point is a
  // no-op without it. Required only when enabled, so the default deploy stays secret-free.
  if (config.webPush?.enabled === true) {
    workshop.secrets = {
      required: [
        ...new Set([
          ...(workshop.secrets?.required ?? []),
          "WEB_PUSH_VAPID_PRIVATE_KEY",
        ]),
      ],
    };
  }
  // Unconditional: as well as being the AI Gateway transport, this binding is what webFetch's
  // toMarkdown() runs on.
  workshop.ai = { binding: "WORKERS_AI" };
  workshop.services = [
    ...apis.map((api) => ({ binding: openApiBinding(api.id), service: api.worker, entrypoint: "GatekeeperVendor" })),
    // The D2c installer vendor surfaces the "OpenAPI APIs" admin frame. It needs no
    // account or resources, but without the installations backend the frame fails
    // unavailable — so the binding rides the installations flag, not just the operator.
    ...(config.openApiOperator?.enabled === true && config.openApiOperator.installations?.enabled === true
      ? [{
          binding: "GATEKEEPER_OPENAPI_INSTALLER",
          service: requiredWorkerName(config.workers.openApiOperator, "workers.openApiOperator.name"),
          entrypoint: "OpenApiInstallationVendor",
        }]
      : []),
    ...(config.errorReporting.enabled
      ? [
          {
            binding: "ERROR_REPORTER",
            service: requiredWorkerName(
              config.workers.errorReporter,
              "workers.errorReporter.name",
            ),
            entrypoint: "ErrorReporter",
            props: {
              service: config.workers.workshop.name,
              environment: config.errorReporting.environment,
              ...(config.errorReporting.release
                ? { release: config.errorReporting.release }
                : {}),
            },
          },
        ]
      : []),
    {
      binding: "GATEKEEPER_CONTEXT",
      service: config.workers.context.name,
      entrypoint: "GatekeeperVendor",
      props: { sharingDomain: config.context.sharingDomain ?? origin },
    },
    // No props: unlike Context, the Scheduler scopes nothing to a domain -- its schedules live in
    // its own `ScheduleDriver`/`SchedulerGatekeeper` Durable Objects, which belong to that Worker's
    // script identity and are reached through `ctx.exports` rather than a binding.
    {
      binding: "GATEKEEPER_SCHEDULER",
      service: config.workers.scheduler.name,
      entrypoint: "GatekeeperVendor",
    },
    {
      binding: "GATEKEEPER_CUSTOM",
      service: config.workers.customGatekeeper.name,
      entrypoint: "GatekeeperVendor",
    },
    ...(execution
      ? [{ binding: "GATEKEEPER_EXECUTION", service: requiredWorkerName(config.workers.execution, "workers.execution.name"), entrypoint: "GatekeeperVendor" }]
      : []),
    // Knitli Memory's vendor RPC. No router binding: it serves no /gatekeeper/<name> HTTP, and the
    // spec keeps the OS path to it private.
    ...(memory
      ? [{ binding: "GATEKEEPER_MEMORY", service: requiredWorkerName(config.workers.memory, "workers.memory.name"), entrypoint: "GatekeeperVendor" }]
      : []),
    // Knitli Messaging's vendor RPC. No router binding: it serves no /gatekeeper/<name> HTTP (its own
    // hostnames serve MCP and the owner page). The fork allowlists attestAudience() to this vendor id
    // ("messaging", the binding's suffix).
    ...(messaging
      ? [{ binding: "GATEKEEPER_MESSAGING", service: requiredWorkerName(config.workers.messaging, "workers.messaging.name"), entrypoint: "GatekeeperVendor" }]
      : []),
    ...(github
      ? [
          {
            binding: "GATEKEEPER_GITHUB",
            service: config.workers.github.name,
            entrypoint: "GatekeeperVendor",
          },
        ]
      : []),
    ...(linear
      ? [
          {
            binding: "GATEKEEPER_LINEAR",
            service: config.workers.linear.name,
            entrypoint: "GatekeeperVendor",
          },
        ]
      : []),
    ...(microsoft
      ? [
          {
            binding: "GATEKEEPER_MICROSOFT",
            service: config.workers.microsoft.name,
            entrypoint: "GatekeeperVendor",
          },
        ]
      : []),
    ...(mcp
      ? [
          {
            binding: "GATEKEEPER_MCP",
            service: config.workers.mcp.name,
            entrypoint: "GatekeeperVendor",
          },
        ]
      : []),
    ...(mcpPortal
      ? [
          {
            binding: "GATEKEEPER_MCP_PORTAL",
            service: config.workers.mcpPortal.name,
            entrypoint: "GatekeeperVendor",
          },
        ]
      : []),
    ...(email
      ? [
          {
            binding: "GATEKEEPER_EMAIL",
            service: config.workers.email.name,
            entrypoint: "GatekeeperVendor",
          },
        ]
      : []),
    ...(cloudflare
      ? [
          {
            binding: "GATEKEEPER_CLOUDFLARE",
            service: config.workers.cloudflare.name,
            entrypoint: "GatekeeperVendor",
          },
        ]
      : []),
    ...(x
      ? [{ binding: "GATEKEEPER_X", service: requiredWorkerName(config.workers.x, "workers.x.name"), entrypoint: "GatekeeperVendor" }]
      : []),
    ...(slack
      ? [{ binding: "GATEKEEPER_SLACK", service: requiredWorkerName(config.workers.slack, "workers.slack.name"), entrypoint: "GatekeeperVendor" }]
      : []),
    // Ambient and auto-provisioned like Scheduler: the binding suffix is the vendor id ("websearch").
    ...(websearch
      ? [{ binding: "GATEKEEPER_WEBSEARCH", service: requiredWorkerName(config.workers.websearch, "workers.websearch.name"), entrypoint: "GatekeeperVendor" }]
      : []),
    ...(aiInference && aiExecutor
      ? [
          {
            binding: "AI_INFERENCE_ADMIN",
            service: requiredWorkerName(
              config.workers.aiInference,
              "workers.aiInference.name",
            ),
            entrypoint: "InferenceAdmin",
          },
          {
            binding: "GATEKEEPER_AI_EXECUTOR",
            service: requiredWorkerName(
              config.workers.aiExecutor,
              "workers.aiExecutor.name",
            ),
            entrypoint: "GatekeeperVendor",
          },
        ]
      : []),
  ];
  workshop.kv_namespaces = [
    {
      binding: "BLUEPRINTS",
      ...(config.resources.blueprintsKvNamespaceId
        ? { id: config.resources.blueprintsKvNamespaceId }
        : {}),
    },
    {
      binding: "AVATARS",
      ...(config.resources.avatarsKvNamespaceId
        ? { id: config.resources.avatarsKvNamespaceId }
        : {}),
    },
  ];
  workshop.r2_buckets = [
    {
      binding: "BLUEPRINT_CONTENT",
      ...(config.resources.blueprintContentBucket
        ? { bucket_name: config.resources.blueprintContentBucket }
        : {}),
    },
  ];
  // The router serves the frontend, and it is the only Worker with a public route.
  delete workshop.assets;

  setCommon(context, config, config.workers.context.name);
  context.kv_namespaces = [
    {
      binding: "CONTEXT_COLLECTIONS",
      ...(config.context.kvNamespaceId
        ? { id: config.context.kvNamespaceId }
        : {}),
    },
  ];
  if (config.context.artifacts?.enabled ?? false) {
    context.artifacts = [
      {
        binding: "ARTIFACTS",
        namespace:
          config.context.artifacts?.namespace ??
          defaultContextArtifactsNamespace,
      },
    ];
  } else {
    delete context.artifacts;
  }

  // Nothing but the common block: the Scheduler takes no vars, no secrets and no storage bindings of
  // its own -- which is what makes it installable with no user interaction upstream, and deployable
  // here without adding a configuration surface for it.
  setCommon(scheduler, config, config.workers.scheduler.name);

  setCommon(customGatekeeper, config, config.workers.customGatekeeper.name);
  customGatekeeper.vars = {
    CUSTOM_NAME: config.customGatekeeper.name,
    CUSTOM_MESSAGE: config.customGatekeeper.message,
  };

  if (memory && config.memory) {
    const settings = config.memory;
    setCommon(memory, config, requiredWorkerName(config.workers.memory, "workers.memory.name"));
    memory.routes = [{ pattern: settings.hostname, custom_domain: true }];
    // No traces, as the standalone M2 Worker had none. Invocation logs capture request headers, and an agent's
    // token travels in one (X-Knitli-Agent-Token, R4 P4b): never on for this Worker, whatever the deployment-wide
    // setting, as for Messaging.
    const { traces: _traces, ...observability } = memory.observability!; // set by setCommon
    memory.observability = { ...observability, logs: { ...observability.logs, invocation_logs: false } };
    // Who an agent is and what ceiling it has (R4 AuthorityMemory): optional, absent unless Messaging deploys here, and Messaging deploys first.
    // Memory reads a missing binding as a refusal. The base declares the binding for generated types; deployment owns its target.
    memory.services = messaging
      ? [{ binding: "AUTHORITY_MEMORY", service: requiredWorkerName(config.workers.messaging, "workers.messaging.name"), entrypoint: "AuthorityMemory" }]
      : [];
    memory.vars = {
      MEMORY_NAMESPACE: settings.namespace,
      MEMORY_HOST: settings.hostname,
      ACCESS_ISSUER: settings.access.issuer,
      ACCESS_AUD: settings.access.audience,
      ALLOWED_PRINCIPALS: settings.allowedPrincipals.join(","),
      MEMORY_REVIEWERS: settings.reviewers.join(","),
      MEMORY_SERVICE_TOKENS: JSON.stringify(settings.serviceTokens),
      SERVICE_OWNERS: serviceOwnersVar(settings.serviceOwners),
      MEMORY_REQUIRE_AGENT: settings.requireAgent === true ? "true" : "false",
      // The trust root a verifying service holds for itself (R4 P5a-2): nothing while presence is off.
      ...presenceVerifierVars(config),
    };
  }

  if (messagingEgress && config.messagingEgress?.deploy) {
    setCommon(messagingEgress, config, requiredWorkerName(config.workers.messagingEgress, "workers.messagingEgress.name"));
    // No route: only Messaging's service binding reaches it (#962). setCommon already forces workers_dev and preview_urls off.
    messagingEgress.routes = [];
    messagingEgress.secrets = { required: ["EGRESS_SHARED_SECRET"] };
    messagingEgress.observability = { enabled: false };
    for (const container of messagingEgress.containers ?? []) container.observability = { enabled: false };
  }

  if (messaging && config.messaging) {
    const settings = config.messaging;
    // Explicit rollback keeps proof verification available for outstanding ACKs.
    const eventAuthority = eventAuthoritySettings(config);
    setCommon(messaging, config, requiredWorkerName(config.workers.messaging, "workers.messaging.name"));
    messaging.routes = [{ pattern: settings.hostname, custom_domain: true }];
    // Invocation logs capture request headers, and an agent's token travels in one (X-Knitli-Agent-Token):
    // never on for this Worker, whatever the deployment-wide setting.
    const observability = messaging.observability!; // set by setCommon
    messaging.observability = { ...observability, logs: { ...observability.logs, invocation_logs: false } };
    messaging.vars = {
      MESSAGING_NAMESPACE: settings.namespace,
      MESSAGES_HOST: settings.hostname,
      ACCESS_ISSUER: settings.access.issuer,
      ACCESS_AUD: settings.access.audience,
      EVENT_HOST: eventAuthority?.host ?? "",
      ACCESS_EVENT_AUD: eventAuthority?.audience ?? "",
      // Memory's agent host and its Access application: what AuthorityMemory checks an agent token and an assertion against. Blank, it refuses.
      MEMORY_HOST: config.memory?.deploy ? config.memory.hostname : "",
      ACCESS_MEMORY_AUD: config.memory?.deploy ? config.memory.access.audience : "",
      ALLOWED_PRINCIPALS: settings.allowedPrincipals.join(","),
      MESSAGING_SERVICE_TOKENS: JSON.stringify(settings.serviceTokens),
      RECEIPT_PUBLIC_KEYS: JSON.stringify({ keys: settings.retiredPublicKeys }),
      MESSAGING_QUEUE_DELIVERY: settings.queueDelivery === true ? "on" : "off",
      // Who may make enrollment codes (R4 P2c, T29); blank adds no rule.
      ENROLL_PRINCIPALS: (settings.enrollPrincipals ?? []).join(","),
      // The setup host's Access application, which every redeem's assertion must name: the same audience the setup Worker checks.
      // Blank while the setup host is not deployed, so every redeem is refused (E13).
      ACCESS_SETUP_AUD: config.setup?.deploy ? config.setup.access.audience : "",
      // Human presence (R4 P5a-2): blank while presence is off, so HumanProof answers unavailable to everything. Each open window carries the hash written in its own deployment.jsonc entry.
      ...presenceMessagingVars(config, openEnrollWindows(config, presenceInput)),
      // The notice channel: blank while off; its topic and token are secrets, required below when on.
      ...notifyMessagingVars(config),
      // Orders (R4 P5b): both off unless deployment.jsonc's authority block says otherwise.
      ...authorityMessagingVars(config),
    };
    // Queues are created out of band and must exist at publish: without this, a
    // queueDelivery=false deploy would fail on queues nobody reads. Enabling flips
    // the var and rewires in the same redeploy (after creating the queues).
    if (settings.queueDelivery !== true) delete messaging.queues;
    // The base declares these capabilities for generated types; deployment owns their targets and opt-ins.
    messaging.services = (messaging.services ?? []).filter(service =>
      service.binding !== "MESSAGING_EGRESS" && service.binding !== "EVENT_MESSAGE_CONSUMER" && service.binding !== "MESSAGE_RECEIVER");
    if (eventRuntime) messaging.services.push({ binding: "EVENT_MESSAGE_CONSUMER",
      service: requiredWorkerName(config.workers.eventRuntime, "workers.eventRuntime.name"), entrypoint: "MessageConsumerAuthority" });
    if (eventRuntime && config.eventRuntime?.assignedStockMessaging) messaging.services.push({ binding: "MESSAGE_RECEIVER",
      service: requiredWorkerName(config.workers.eventRuntime, "workers.eventRuntime.name"), entrypoint: "MessageReceiver" });
    if (settings.oauth && messagingEgress) {
      messaging.services.push({ binding: "MESSAGING_EGRESS", service: messagingEgress.name! });
    }
    const oauthSecrets = ["MESSAGING_EGRESS_TOKEN", "MESSAGING_EVENT_KEY"];
    const required = (messaging.secrets?.required ?? []).filter(name => !oauthSecrets.includes(name));
    if (settings.oauth) {
      messaging.routes.push({ pattern: settings.oauth.hostname, custom_domain: true });
      Object.assign(messaging.vars, {
        MESSAGES_OAUTH_HOST: settings.oauth.hostname,
        ACCESS_OAUTH_AUD: settings.oauth.audience,
        MESSAGING_OAUTH_PROFILE: settings.oauth.profile,
      });
      required.push(...oauthSecrets);
    }
    // The notice channel's reserved topic and token are secrets, never config, and required only when it is on.
    if (config.notify?.deploy) required.push(...NOTIFY_SECRETS);
    // Keep base requirements (including RECEIPT_KEYS); OAuth egress secrets are required only when enabled.
    messaging.secrets = { required };
  }

  if (eventRuntime && config.eventRuntime?.deploy) {
    const settings = config.eventRuntime;
    const manualCanary = ManualCanarySchema.safeParse(settings.manualCanary);
    setCommon(eventRuntime, config, requiredWorkerName(config.workers.eventRuntime, "workers.eventRuntime.name"));
    eventRuntime.routes = [{ pattern: settings.hostname, custom_domain: true }];
    eventRuntime.vars = { EVENT_NATIVE_BINDING_ENABLED: settings.nativeCanary ? "true" : "false",
      EVENT_NATIVE_BINDING_CANARY: settings.nativeCanary ? JSON.stringify(settings.nativeCanary) : "",
      EVENT_ASSIGNED_STOCK_ENABLED: settings.assignedStockCanary ? "true" : "false",
      EVENT_ASSIGNED_STOCK_CANARY: settings.assignedStockCanary ? JSON.stringify(settings.assignedStockCanary) : "",
      EVENT_GITHUB_ENABLED: settings.githubSource ? "true" : "false", GITHUB_APP_ID: settings.githubSource?.appId ?? "",
      GITHUB_SOURCE_MAP: settings.githubSource ? JSON.stringify([settings.githubSource.mapping]) : "[]",
      EVENT_GITHUB_SOURCE_CONTROL_ENABLED: settings.githubSource?.sourceControl?.enabled === true ? "true" : "false",
      EVENT_GITHUB_SOURCE_GATE_EPOCH: settings.githubSource?.sourceControl?.gateEpoch?.toString() ?? "0",
      EVENT_GITHUB_WATCH_CONTROL_ENABLED: settings.githubSource?.watchControl === true ? "true" : "false",
      EVENT_GITHUB_INITIAL_RECONCILIATION_ENABLED: settings.githubSource?.initialReconciliation === true ? "true" : "false",
      EVENT_ENABLED: "true", EVENT_MANUAL_ENABLED: manualCanary.success ? "true" : "",
      EVENT_MANUAL_CANARY: manualCanary.success ? JSON.stringify(manualCanary.data) : "",
      EVENT_MESSAGING_ACCEPT_ENABLED: settings.assignedStockMessaging ? "true" : "false",
      EVENT_MESSAGING_DELIVERY_ENABLED: settings.assignedStockMessaging ? "true" : "false",
      EVENT_HOST: settings.hostname, ACCESS_ISSUER: settings.access.issuer,
      ACCESS_EVENT_AUD: settings.access.audience, ALLOWED_PRINCIPALS: config.messaging!.allowedPrincipals.join(","),
      MESSAGE_NAMESPACE: config.messaging!.namespace,
      ACCESS_UI_AUD: "", ADMIN_UI_ORIGIN: "", EVENT_TRANSPORT_KEY_ID: settings.transportKeyId,
      EVENT_DELIVERY_DLQ: settings.queues.deadLetter.name };
    const githubSecrets = ["GITHUB_APP_PRIVATE_KEY", "GITHUB_WEBHOOK_SECRET"];
    eventRuntime.secrets = { required: [...new Set([
      ...(eventRuntime.secrets?.required ?? []).filter(name => !githubSecrets.includes(name)),
      ...(settings.githubSource ? githubSecrets : []),
    ])] };
    eventRuntime.services = [{ binding: "MESSAGE_AUTHORITY", service: config.workers.messaging!.name, entrypoint: "EventAuthority" }];
    if (messaging) Object.assign(messaging.vars!, {
      MESSAGING_EVENT_PUBLISH_ENABLED: settings.assignedStockMessaging ? "true" : "false",
      EVENT_ASSIGNED_STOCK_ENABLED: settings.assignedStockMessaging ? "true" : "false",
      EVENT_ASSIGNED_STOCK_CANARY: settings.assignedStockMessaging ? JSON.stringify(settings.assignedStockCanary) : "",
    });
    eventRuntime.vpc_networks = [{ binding: "MESH", network_id: "cf1:network", remote: true }];
    eventRuntime.queues = { producers: [{ binding: "DELIVERY_QUEUE", queue: settings.queues.delivery.name }],
      consumers: [
        { queue: settings.queues.delivery.name, max_batch_size: 10, max_batch_timeout: 5, max_retries: 5,
          max_concurrency: 1, dead_letter_queue: settings.queues.deadLetter.name },
        { queue: settings.queues.deadLetter.name, max_batch_size: 10, max_batch_timeout: 5, max_retries: 5, max_concurrency: 1 }
      ] };
    eventRuntime.observability = { ...eventRuntime.observability!, logs: { ...eventRuntime.observability!.logs, invocation_logs: false } };
  }

  if (eventsEdge && eventRuntime && config.eventRuntime?.deploy && config.eventRuntime.gatewayEdge?.deploy) {
    setCommon(eventsEdge, config, requiredWorkerName(config.workers.eventsEdge, "workers.eventsEdge.name"));
    // No route: only a Gateway Forward policy invokes it (the owner's, selecting this Worker by name).
    eventsEdge.routes = [];
    eventsEdge.vars = { EVENTS_EDGE_POSTURE: config.eventRuntime.gatewayEdge.posture.join(",") };
    eventsEdge.services = [{ binding: "NODE_EDGE", service: eventRuntime.name!, entrypoint: "NodeEdge" }];
    eventsEdge.observability = { ...eventsEdge.observability!, logs: { ...eventsEdge.observability!.logs, invocation_logs: false } };
  }

  const configureGatekeeper = (
    gatekeeper: ProdWranglerConfig,
    name: string,
    path: string,
  ): void => {
    setCommon(gatekeeper, config, name);
    gatekeeper.vars = {
      ...gatekeeper.vars,
      BASE_URL: `${origin}/gatekeeper/${path}`,
      CF_ACCESS_ISS: config.access.issuer.replace(/\/$/, ""),
      CF_ACCESS_AUD: config.access.audience,
    };
  };

  if (github) {
    configureGatekeeper(github, config.workers.github.name, "github");
    github.vars = { ...github.vars, CLIENT_ID: config.github.clientId!.trim() };
    github.secrets = {
      ...github.secrets,
      required: [
        ...new Set([...(github.secrets?.required ?? []), "CLIENT_SECRET"]),
      ],
    };
  }
  if (linear) {
    configureGatekeeper(linear, config.workers.linear.name, "linear");
    linear.vars = { ...linear.vars, CLIENT_ID: config.linear.clientId!.trim() };
    linear.secrets = {
      ...linear.secrets,
      required: [
        ...new Set([...(linear.secrets?.required ?? []), "CLIENT_SECRET"]),
      ],
    };
  }
  if (microsoft) {
    // Connector-only: no sign-in var. The tenant is an identifier like the client ID, so it
    // ships as a var; only the Entra client secret stays a secret. Trimmed, matching what
    // validation checked: the file is hand-edited, and padded IDs must not reach the worker.
    // The assertions hold because generateConfigs validates first, which rejects a deploying
    // connector with a missing ID.
    configureGatekeeper(microsoft, config.workers.microsoft.name, "microsoft");
    microsoft.vars = {
      ...microsoft.vars,
      CLIENT_ID: config.microsoft.clientId!.trim(),
      TENANT_ID: config.microsoft.tenantId!.trim(),
    };
    microsoft.secrets = {
      ...microsoft.secrets,
      required: [
        ...new Set([...(microsoft.secrets?.required ?? []), "CLIENT_SECRET"]),
      ],
    };
  }
  if (mcp) {
    configureGatekeeper(mcp, config.workers.mcp.name, "mcp");
  }
  if (mcpPortal) {
    configureGatekeeper(mcpPortal, config.workers.mcpPortal.name, "mcp-portal");
    const auth = config.mcpPortal.auth ?? "oauth";
    mcpPortal.vars = {
      ...mcpPortal.vars,
      ...(config.mcpPortal.url ? { MCP_PORTAL_URL: config.mcpPortal.url.trim() } : {}),
      ...(config.mcpPortal.name
        ? { MCP_PORTAL_NAME: config.mcpPortal.name.trim() }
        : {}),
      MCP_PORTAL_AUTH: auth,
      MCP_PORTAL_TRUST_ANNOTATIONS: String(
        config.mcpPortal.trustAnnotations ?? false,
      ),
    };
    if (auth === "token") {
      mcpPortal.secrets = {
        ...mcpPortal.secrets,
        required: [
          ...new Set([
            ...(mcpPortal.secrets?.required ?? []),
            "MCP_PORTAL_TOKEN",
          ]),
        ],
      };
    }
  }
  if (email) {
    // No OAuth application and no secrets. Outbound sending (knitli-os #69) adds its two vars
    // when configured; validateConfig enforces both-or-neither, so a set domain always has its
    // prefix and emitting each independently is exact. Trimmed, matching what validation
    // checked: the file is hand-edited, and padded values must not reach the worker.
    configureGatekeeper(email, config.workers.email.name, "email");
    email.vars = {
      ...email.vars,
      ...(config.email.domain ? { EMAIL_DOMAIN: config.email.domain.trim() } : {}),
      ...(config.email.sendPrefix ? { EMAIL_SEND_PREFIX: config.email.sendPrefix.trim() } : {}),
    };
  }
  if (cloudflare) {
    configureGatekeeper(cloudflare, config.workers.cloudflare.name, "cloudflare");
    cloudflare.vars = { ...cloudflare.vars, CLIENT_ID: config.cloudflare.clientId!.trim() };
    cloudflare.secrets = {
      ...cloudflare.secrets,
      required: [
        ...new Set([...(cloudflare.secrets?.required ?? []), "CLIENT_SECRET"]),
      ],
    };
  }

  if (x) {
    configureGatekeeper(x, requiredWorkerName(config.workers.x, "workers.x.name"), "x");
    x.vars = {
      ...x.vars,
      CLIENT_ID: config.x!.clientId!.trim(),
      ...(config.x!.dailyReadLimit !== undefined && config.x!.dailyReadLimit !== null
        ? { X_DAILY_READ_LIMIT: String(config.x!.dailyReadLimit) }
        : {}),
    };
    x.secrets = {
      ...x.secrets,
      required: [...new Set([...(x.secrets?.required ?? []), "CLIENT_SECRET"])],
    };
  }
  if (slack) {
    configureGatekeeper(slack, requiredWorkerName(config.workers.slack, "workers.slack.name"), "slack");
    slack.vars = { ...slack.vars, CLIENT_ID: config.slack!.clientId!.trim() };
    slack.secrets = {
      ...slack.secrets,
      required: [...new Set([...(slack.secrets?.required ?? []), "CLIENT_SECRET"])],
    };
  }
  if (websearch) {
    // No routes, no OAuth and no secrets: only the Workers AI binding its base config declares.
    // Searches go through the deployment's AI Gateway, which the binding reaches only in its own
    // account; a cross-account gateway leaves the worker on its "default" gateway.
    setCommon(websearch, config, requiredWorkerName(config.workers.websearch, "workers.websearch.name"));
    if (gateway && !gateway.crossAccount) {
      websearch.vars = { ...websearch.vars, CF_AI_GATEWAY: config.aiGateway.name };
    }
  }

  const openApis = Object.fromEntries(apis.map((api) => {
    const worker = structuredClone(bases.openApi);
    setCommon(worker, config, api.worker);
    // The per-API catalog frame reaches the installation registry only through this
    // operator entrypoint (D2c bridge) — never browser HTTP. Deployed connectors imply
    // an enabled operator, so the name below is always validated present.
    worker.services = [{
      binding: INSTALLATION_JOBS_BINDING,
      service: requiredWorkerName(config.workers.openApiOperator, "workers.openApiOperator.name"),
      entrypoint: INSTALLATION_JOBS_ENTRYPOINT,
    },
    {
      binding: CATALOG_AGENT_BINDING,
      service: requiredWorkerName(config.workers.catalogAgent, "workers.catalogAgent.name"),
      entrypoint: CATALOG_AGENT_ENTRYPOINT,
    }];
    // Set here, not in the base config, so dev and the workerd test pool (whose
    // runtime predates VPC bindings) never see it. cf1:network reaches the public
    // Internet through Gateway, which applies the account's DNS, HTTP, network, and
    // egress policies and logs the traffic. Only read when OPENAPI_VPC_EGRESS names it.
    // Off (or absent) omits the binding entirely: declaring it would make a non-VPC
    // deployment require VPC permissions at publish time for a binding it never uses.
    if (config.openApiVpcEgress === "reads" || config.openApiVpcEgress === "all") {
      worker.vpc_networks = [{ binding: "VPC_EGRESS", network_id: "cf1:network", remote: true }];
    } else {
      delete worker.vpc_networks;
    }
    worker.vars = {
      BASE_URL: `${origin}/gatekeeper/${api.id}`,
      CF_ACCESS_ISS: config.access.issuer.replace(/\/$/, ""),
      CF_ACCESS_AUD: config.access.audience,
      OPENAPI_API_ID: api.id,
      OPENAPI_DISPLAY: JSON.stringify(api.display),
      OPENAPI_PROVIDER: JSON.stringify(api.provider),
      OPENAPI_SEGMENTS: JSON.stringify(api.segments),
      OPENAPI_VPC_EGRESS: config.openApiVpcEgress ?? "off",
      CLIENT_ID: api.clientId!,
      // The catalog authority Durable Object's name, and the catalog id and issuer the operator
      // admits under. One value: record ids are `operation:<id>:<operationId>` on both sides.
      OPENAPI_CATALOG_NAME: api.id,
      OPENAPI_CATALOG_ID: api.id,
      OPENAPI_CATALOG_ISSUER: api.catalog.issuer,
      OPENAPI_MANIFEST_TRUST: JSON.stringify(api.catalog.manifestTrust),
    };
    // Exactly one credential binding per delivery: the string-secret path requires
    // CLIENT_SECRET for `wrangler secret put`, while a Secrets Store reference binds
    // it from the store. Each branch clears the other shape so a base config can
    // never smuggle in both; the graph assertion below rejects both/neither anyway.
    if (api.credential?.kind === "cloudflare-secrets-store-v1") {
      delete worker.secrets;
      worker.secrets_store_secrets = [{
        binding: "CLIENT_SECRET",
        store_id: api.credential.storeId,
        secret_name: api.credential.secretName,
      }];
    } else {
      delete worker.secrets_store_secrets;
      worker.secrets = { required: ["CLIENT_SECRET"] };
    }
    worker.d1_databases = [{ binding: "OPENAPI_CATALOG_DB", database_name: api.catalog.databaseName,
      database_id: api.catalog.databaseId, migrations_dir: "migrations" }];
    worker.r2_buckets = [{ binding: "OPENAPI_CATALOG_BUNDLES", bucket_name: api.catalog.bucketName }];
    return [openApiKey(api.id), worker] as const;
  }));
  if (openApiOperator && config.openApiOperator?.enabled) {
    const operator = config.openApiOperator;
    setCommon(openApiOperator, config, requiredWorkerName(config.workers.openApiOperator, "workers.openApiOperator.name"));
    openApiOperator.vars = { OPENAPI_ACCESS_CONFIG: JSON.stringify(operator.access) };
    openApiOperator.services = apis.map((api) => ({ binding: operatorBinding(api.id), service: api.worker, entrypoint: "OpenApiCatalogOperator" }));
    openApiOperator.routes = [{ pattern: operator.hostname, custom_domain: true }];
    // The v1 registry migration rides the base config in both branches: registering the class is
    // harmless without the binding, and it avoids a migration version bump when enabling later.
    const installations = operator.installations;
    if (installations?.enabled) {
      openApiOperator.vars = {
        ...openApiOperator.vars,
        OPENAPI_RUNNER_AUTH_CONFIG: JSON.stringify({
          access: operator.access,
          runnerClientId: installations.runnerClientId,
          deployClientId: installations.deployClientId,
          repository: installations.repository,
          repositoryId: installations.repositoryId,
          ref: installations.ref,
          environment: installations.environment,
          workflowRef: installations.workflowRef,
          // Emitted only off the production host, so production keeps the exact bytes it had and the
          // worker's default applies; any other host gets the audience its runner will mint.
          ...(runnerAudience(operator.hostname) === RUNNER_OIDC_AUDIENCE ? {} : { runnerOidcAudience: runnerAudience(operator.hostname) }),
        }),
        OPENAPI_INSTALLATION_SECRET_KEY_VERSION: installations.secretKeyVersion,
        OPENAPI_INSTALLATION_WORKFLOW_ROUTING: JSON.stringify({
          publicationExecutor: installations.publicationExecutor ?? "actions",
          inspectionExecutor: installations.inspectionExecutor ?? "actions",
          installationExecutor: installations.installationExecutor ?? "actions",
          workflowRuntime: installations.workflowRuntime ?? "absent",
        }),
        // Rebuilt field by field, like the connector vars: the value serializes with JSON.stringify
        // and the worker parser requires exactly these keys.
        OPENAPI_INSTALLATION_DEPLOYMENT_PROFILE: JSON.stringify({
          catalogIssuer: installations.catalogIssuer,
          manifestTrust: {
            releaseKeys: installations.manifestTrust.releaseKeys.map((key) => ({ issuer: key.issuer, keyId: key.keyId, publicKey: key.publicKey })),
            rollbackKeys: installations.manifestTrust.rollbackKeys.map((key) => ({ issuer: key.issuer, keyId: key.keyId, publicKey: key.publicKey })),
          },
        }),
      };
      openApiOperator.durable_objects = {
        bindings: [{ name: "OPENAPI_INSTALLATION_REGISTRY", class_name: "OpenApiInstallationRegistry" }],
      };
      openApiOperator.r2_buckets = [
        { binding: "OPENAPI_INSTALLATION_ARTIFACTS", bucket_name: installations.bucket },
        ...apis.map((api) => ({ binding: catalogBundlesBinding(api.id), bucket_name: api.catalog.bucketName })),
      ];
      openApiOperator.secrets = { required: ["OPENAPI_INSTALLATION_SECRET_KEK"] };
      if (installations.workflowRuntime === "deployed-v1") {
        openApiOperator.workflows = [
          { binding: "OPENAPI_PUBLICATION_WORKFLOW", class_name: "OpenApiPublicationWorkflow", name: `${openApiOperator.name}-publication-v1` },
          { binding: "OPENAPI_INSPECTION_WORKFLOW", class_name: "OpenApiInspectionWorkflow", name: `${openApiOperator.name}-inspection-v1` },
        ];
        if (openApiOperator.workflows.some(workflow => workflow.name.length > 64)) throw new Error("Installation Workflow name exceeds 64 characters.");
      } else {
        delete openApiOperator.workflows;
      }
    } else {
      delete openApiOperator.secrets;
      delete openApiOperator.durable_objects;
      delete openApiOperator.d1_databases;
      delete openApiOperator.r2_buckets;
      delete openApiOperator.workflows;
    }
  }

  if (catalogAgent) {
    setCommon(
      catalogAgent,
      config,
      requiredWorkerName(config.workers.catalogAgent, "workers.catalogAgent.name"),
    );
    // Deliberately outside the per-user free tier: the daily LLM cap binds
    // end users at the Workshop surface, while this worker serves only the
    // ADMINS-allowlisted admin frame — operator tooling, like aiInference and
    // aiExecutor, with no end user to charge. Each run is still bounded
    // (turn budget and server-held deadline in catalog-agent AGENT_LIMITS).
    catalogAgent.vars = {
      AI_GATEWAY_NAME: config.aiGateway.enabled ? (config.aiGateway.name ?? "") : "",
      EXTRA_MODELS: (config.openApiOperator?.enabled
        ? (config.openApiOperator.catalogAgentModels ?? [])
        : []
      ).join(","),
    };
    catalogAgent.services = [{
      binding: DISCOVERY_READER_BINDING,
      service: requiredWorkerName(config.workers.openApiOperator, "workers.openApiOperator.name"),
      entrypoint: DISCOVERY_READER_ENTRYPOINT,
    }];
  }

  if (execution && executionRuntime) {
    // The gatekeeper and the runtime get the same catalog, principals and budget: the runtime re-checks every request
    // against its own copy (#624 Decision 5). As written in deployment.jsonc; both parse it with the same rules.
    const catalogVars = {
      EXECUTION_CATALOG: JSON.stringify(config.execution!.profiles),
      EXECUTION_BUDGET_USD: String(config.execution!.budgetUsd),
      ALLOWED_PRINCIPALS: config.execution!.allowedPrincipals!.join(","),
    };
    setCommon(executionRuntime, config, requiredWorkerName(config.workers.executionRuntime, "workers.executionRuntime.name"));
    executionRuntime.observability = { enabled: false };
    executionRuntime.vars = catalogVars;
    // One named image per profile, the only images its controllers can start (ctx.container.images[profileId]).
    const [container, ...others] = executionRuntime.containers ?? [];
    if (!container || others.length || container.scheduling_policy !== "durable_object")
      throw new Error("The execution runtime base must declare exactly one durable_object container.");
    container.images = Object.fromEntries(parseCatalog(config.execution!.profiles, catalogVars.ALLOWED_PRINCIPALS)
      .map((profile) => [profile.id, { image: profile.image }]));
    container.observability = { enabled: false };
    setCommon(execution, config, requiredWorkerName(config.workers.execution, "workers.execution.name"));
    execution.services = [
      { binding: "EXECUTION_RUNTIME", service: executionRuntime.name!, entrypoint: "ExecutionRuntimeEntrypoint" },
      // Which inbox message started a run (R4 origin binding): optional, absent unless Messaging deploys here, and Messaging deploys first.
      ...(messaging ? [{ binding: "MESSAGING_AUTHORITY", service: requiredWorkerName(config.workers.messaging, "workers.messaging.name"), entrypoint: "AuthorityExecution" }] : []),
    ];
    execution.vars = { EXECUTION_NAMESPACE: config.execution!.namespace!, ...catalogVars, ...presenceVerifierVars(config) };
  }

  if (aiInference && aiExecutor) {
    setCommon(
      aiInference,
      config,
      requiredWorkerName(config.workers.aiInference, "workers.aiInference.name"),
    );
    aiInference.vars = {
      AI_GATEWAY_ACCOUNT_ID: config.aiExecutors.gateway?.accountId,
      AI_GATEWAY_NAME: config.aiExecutors.gateway?.name,
    };
    aiInference.secrets = { required: ["CF_AI_GATEWAY_API_TOKEN"] };

    setCommon(
      aiExecutor,
      config,
      requiredWorkerName(config.workers.aiExecutor, "workers.aiExecutor.name"),
    );
    aiExecutor.services = [
      {
        binding: "AI_INFERENCE_RUNTIME",
        service: requiredWorkerName(
          config.workers.aiInference,
          "workers.aiInference.name",
        ),
        entrypoint: "InferenceRuntime",
      },
    ];
  }

  if (errorReporter) {
    setCommon(
      errorReporter,
      config,
      requiredWorkerName(
        config.workers.errorReporter,
        "workers.errorReporter.name",
      ),
    );
  }

  if (adminUi && config.adminUi?.deploy) {
    const settings = config.adminUi;
    setCommon(adminUi, config, requiredWorkerName(config.workers.adminUi, "workers.adminUi.name"));
    adminUi.routes = [{ pattern: settings.hostname, custom_domain: true }];
    // UI transports the original human assertion and protected form/DTO content.
    adminUi.observability = { enabled: false, logs: { enabled: false, invocation_logs: false }, traces: { enabled: false } };
    adminUi.vars = { ACCESS_ISSUER: settings.access.issuer, ACCESS_UI_AUD: settings.access.audience,
      ADMIN_UI_ORIGIN: `https://${settings.hostname}` };
    adminUi.services = [
      { binding: "MEMORY_ADMIN", service: requiredWorkerName(config.workers.memory, "workers.memory.name"), entrypoint: "MemoryAdmin" },
      { binding: "MESSAGING_ADMIN", service: requiredWorkerName(config.workers.messaging, "workers.messaging.name"), entrypoint: "MessagingAdmin" },
      ...(eventRuntime ? [{ binding: "EVENT_ADMIN", service: eventRuntime.name!, entrypoint: "EventAdmin" }] : []),
      ...(execution ? [{ binding: "EXECUTION_ADMIN", service: execution.name!, entrypoint: "ExecutionAdmin" }] : []),
    ];
    for (const gatekeeper of [memory, messaging, ...(eventRuntime ? [eventRuntime] : []), ...(execution ? [execution] : [])]) Object.assign(gatekeeper!.vars!, {
      ACCESS_UI_AUD: settings.access.audience, ADMIN_UI_ORIGIN: `https://${settings.hostname}`,
    });
    // Memory, Messaging and Events already hold their own issuer; Execution has no Access app, so it takes the UI's.
    if (execution) execution.vars!.ACCESS_ISSUER = settings.access.issuer;
    // The Agents page prints the install and connect commands with this hash, only once the host that serves it is deployed:
    // otherwise it would print a command for a host that does not exist.
    if (config.setup?.deploy) adminUi.vars.SETUP_RELEASE_SHA256 = config.setup.releaseSha256;
    // The Security pages link to the presence host's key and liveness pages only once it is deployed.
    adminUi.vars.PRESENCE_ORIGIN = config.presenceHost?.deploy ? `https://${config.presenceHost.hostname}` : "";
  }

  if (setup && config.setup?.deploy) {
    const settings = config.setup;
    setCommon(setup, config, requiredWorkerName(config.workers.setup, "workers.setup.name"));
    setup.routes = [{ pattern: settings.hostname, custom_domain: true }];
    setup.workers_dev = false;
    setup.preview_urls = false;
    // After setCommon, which applies the deployment-wide default: requests carry the one-time code, the poll secret and the
    // Access assertion, so nothing about them is logged, sampled or traced, whatever that default says.
    setup.observability = { enabled: false, logs: { enabled: false, invocation_logs: false }, traces: { enabled: false } };
    // Exactly the one binding to Messaging's AgentEnrollment, by this deployment's Messaging Worker name.
    setup.services = [{ binding: "ENROLLMENT", service: requiredWorkerName(config.workers.messaging, "workers.messaging.name"), entrypoint: "AgentEnrollment" }];
    setup.vars = { ACCESS_ISSUER: settings.access.issuer, ACCESS_SETUP_AUD: settings.access.audience, SETUP_RELEASE_SHA256: settings.releaseSha256 };
  }

  if (presenceUi && config.presenceHost?.deploy) {
    const settings = config.presenceHost;
    setCommon(presenceUi, config, requiredWorkerName(config.workers.presence, "workers.presence.name"));
    presenceUi.routes = [{ pattern: settings.hostname, custom_domain: true }];
    presenceUi.workers_dev = false;
    presenceUi.preview_urls = false;
    // After setCommon, which applies the deployment-wide default: requests carry the Access assertion and a key's signed answer, so nothing about them is logged, sampled or traced.
    presenceUi.observability = { enabled: false, logs: { enabled: false, invocation_logs: false }, traces: { enabled: false } };
    // Exactly the one binding to Messaging's HumanProof, by this deployment's Messaging Worker name.
    presenceUi.services = [{ binding: "HUMAN_PROOF", service: requiredWorkerName(config.workers.messaging, "workers.messaging.name"), entrypoint: "HumanProof" }];
    // The pins are the Messaging variables' own (one generator, so the host and the ceremony cannot disagree); blank while presence is off, which makes every request a 503.
    const pins = presenceMessagingVars(config);
    presenceUi.vars = {
      ACCESS_ISSUER: settings.access.issuer, ACCESS_PRESENCE_AUD: pins.ACCESS_PRESENCE_AUD!, PRESENCE_RP_ID: pins.PRESENCE_RP_ID!, PRESENCE_ORIGIN: pins.PRESENCE_ORIGIN!,
      PRESENCE_AUD: pins.PRESENCE_AUD!, PRESENCE_ANCHORS: pins.PRESENCE_ANCHORS!, PRESENCE_FLOORS: pins.PRESENCE_FLOORS!, PRESENCE_RETURN_ORIGINS: pins.PRESENCE_RP_ID ? JSON.stringify(presenceReturnOrigins(config)) : "[]", // blank, like the pins, while presence is off
      PRESENCE_ADMIN_ORIGIN: pins.PRESENCE_RP_ID && config.adminUi?.deploy ? `https://${config.adminUi.hostname}` : "",
    };
  }

  const generated: GeneratedConfigs = {
    router,
    workshop,
    context,
    scheduler,
    customGatekeeper,
    ...(memory && { memory }),
    ...(messaging && { messaging }),
    ...(eventRuntime && { eventRuntime }),
    ...(eventsEdge && { eventsEdge }),
    ...(adminUi && { adminUi }),
    ...(setup && { setup }),
    ...(presenceUi && { presence: presenceUi }),
    ...(messagingEgress && { messagingEgress }),
    ...(errorReporter && { errorReporter }),
    ...(github && { github }),
    ...(linear && { linear }),
    ...(microsoft && { microsoft }),
    ...(mcp && { mcp }),
    ...(mcpPortal && { mcpPortal }),
    ...(email && { email }),
    ...(cloudflare && { cloudflare }),
    ...(x && { x }),
    ...(slack && { slack }),
    ...(websearch && { websearch }),
    ...openApis,
    ...(executionRuntime && { executionRuntime }),
    ...(openApiOperator && { openApiOperator }),
    ...(catalogAgent && { catalogAgent }),
    ...(aiInference && { aiInference }),
    ...(aiExecutor && { aiExecutor }),
    ...(execution && { execution }),
  };
  validateOpenApiGraph(config, generated, resolvedApis);
  return generated;
}

/** Assert the actual named capability graph after all templates and overrides are applied. */
export function validateOpenApiGraph(
  config: DeploymentConfig,
  generated: GeneratedConfigs,
  resolvedApis: readonly OpenApiDeployment[] = config.openApis ?? [],
): void {
  const apis = deployedOpenApis(resolvedApis);
  const apiWorkers = new Set(apis.map((api) => api.worker));
  const operator = config.openApiOperator?.enabled ? config.workers.openApiOperator?.name : undefined;
  const installations = config.openApiOperator?.enabled ? config.openApiOperator.installations : undefined;
  const fail = (): never => { throw new Error("OpenAPI generated capability graph must contain only the reviewed private entrypoints and production source."); };
  const expected: Record<string, unknown[]> = {
    router: apis.map((api) => ({ binding: openApiBinding(api.id), service: api.worker })),
    workshop: [
      ...apis.map((api) => ({ binding: openApiBinding(api.id), service: api.worker, entrypoint: "GatekeeperVendor" })),
      ...(operator !== undefined && installations?.enabled === true
        ? [{ binding: "GATEKEEPER_OPENAPI_INSTALLER", service: operator, entrypoint: "OpenApiInstallationVendor" }]
        : []),
    ],
    openApiOperator: apis.map((api) => ({ binding: operatorBinding(api.id), service: api.worker, entrypoint: "OpenApiCatalogOperator" })),
    catalogAgent: operator !== undefined
      ? [{ binding: DISCOVERY_READER_BINDING, service: operator, entrypoint: DISCOVERY_READER_ENTRYPOINT }]
      : [],
  };
  for (const api of apis) {
    expected[openApiKey(api.id)] = [{
      binding: INSTALLATION_JOBS_BINDING,
      service: operator,
      entrypoint: INSTALLATION_JOBS_ENTRYPOINT,
    }];
  }
  const agentName = config.openApiOperator?.enabled ? config.workers.catalogAgent?.name : undefined;
  if ((generated.catalogAgent !== undefined) !== (agentName !== undefined)) fail();
  if ((generated.openApiOperator !== undefined) !== (operator !== undefined)) fail();
  for (const api of apis) if (!generated[openApiKey(api.id)]) fail();
  const expectedVars = ["BASE_URL", "CF_ACCESS_AUD", "CF_ACCESS_ISS", "CLIENT_ID", "OPENAPI_API_ID", "OPENAPI_CATALOG_ID",
    "OPENAPI_CATALOG_ISSUER", "OPENAPI_CATALOG_NAME", "OPENAPI_DISPLAY", "OPENAPI_MANIFEST_TRUST", "OPENAPI_PROVIDER",
    "OPENAPI_SEGMENTS", "OPENAPI_VPC_EGRESS"].join(",");
  for (const [name, worker] of Object.entries(generated) as [string, ProdWranglerConfig][]) {
    const capabilities = (worker.services ?? []).filter((binding) =>
      apiWorkers.has(binding.service) || (operator !== undefined && binding.service === operator) ||
      /openapi/i.test(`${binding.binding} ${binding.entrypoint ?? ""}`));
    if (!isDeepStrictEqual(capabilities, expected[name] ?? [])) fail();
    // The installations KEK is the one reviewed OPENAPI_-prefixed secret, operator-only: naming it
    // required makes wrangler refuse an upload while it is unset, instead of failing at runtime.
    if (worker.secrets?.required?.some((secret) => secret.startsWith("OPENAPI_") &&
        !(name === "openApiOperator" && secret === "OPENAPI_INSTALLATION_SECRET_KEK" && installations?.enabled === true))) fail();
    const isApi = name.startsWith("openApi:");
    if ((name !== "openApiOperator" || installations?.enabled !== true || installations.workflowRuntime !== "deployed-v1") &&
      worker.workflows?.some(workflow => workflow.binding.startsWith("OPENAPI_") || workflow.class_name.startsWith("OpenApi"))) fail();
    // Likewise the registry DO is the one reviewed OpenApi* class outside API workers.
    if (!isApi && worker.durable_objects?.bindings.some((binding) =>
      !(installations?.enabled === true && name === "openApiOperator" &&
        binding.name === "OPENAPI_INSTALLATION_REGISTRY" && binding.class_name === "OpenApiInstallationRegistry") &&
      (binding.class_name.startsWith("OpenApi") || apiWorkers.has(binding.script_name ?? "")))) fail();
    if (isApi) {
      if (worker.main !== ".wrangler/validate/src/index.ts" || worker.workers_dev !== false || worker.preview_urls !== false) fail();
      if (worker.build?.command !== "pnpm exec capnweb-validate build --out .wrangler/validate" || worker.build?.watch_dir !== "src" ||
          Object.keys(worker.build).toSorted().join(",") !== "command,watch_dir") fail();
      if ((worker.routes ?? []).length) fail();
      if (!isDeepStrictEqual(worker.services ?? [], [
        {
          binding: INSTALLATION_JOBS_BINDING,
          service: operator,
          entrypoint: INSTALLATION_JOBS_ENTRYPOINT,
        },
        {
          binding: CATALOG_AGENT_BINDING,
          service: agentName,
          entrypoint: CATALOG_AGENT_ENTRYPOINT,
        },
      ])) fail();
      if (JSON.stringify(worker.durable_objects?.bindings) !== JSON.stringify([
        { name: "OPENAPI_CATALOG_AUTHORITY", class_name: "OpenApiCatalogAuthority" },
        { name: "OPENAPI_ACCOUNTS", class_name: "OpenApiAccount" },
      ])) fail();
      // Exactly one credential shape: the string-secret requirement or the single
      // Secrets Store binding — both or neither fails before Wrangler. The store
      // reference re-validates here so a skewed conversion still fails closed.
      if (!isApiCredentialBinding(worker)) fail();
      if (Object.keys(worker.vars ?? {}).toSorted().join(",") !== expectedVars) fail();
      if (worker.d1_databases?.length !== 1 || worker.r2_buckets?.length !== 1) fail();
    }
    if (name === "openApiOperator") {
      const hostname = config.openApiOperator?.enabled ? config.openApiOperator.hostname : undefined;
      if (worker.main !== "src/index.ts" || worker.workers_dev !== false || worker.preview_urls !== false) fail();
      if (installations?.enabled === true) {
        if (JSON.stringify(worker.durable_objects?.bindings) !== JSON.stringify([
          { name: "OPENAPI_INSTALLATION_REGISTRY", class_name: "OpenApiInstallationRegistry" },
        ])) fail();
        if (JSON.stringify(worker.r2_buckets) !== JSON.stringify([
          { binding: "OPENAPI_INSTALLATION_ARTIFACTS", bucket_name: installations.bucket },
          ...apis.map((api) => ({ binding: catalogBundlesBinding(api.id), bucket_name: api.catalog.bucketName })),
        ])) fail();
        if (JSON.stringify(worker.secrets) !== JSON.stringify({ required: ["OPENAPI_INSTALLATION_SECRET_KEK"] })) fail();
        if (worker.d1_databases) fail();
        if (Object.keys(worker.vars ?? {}).toSorted().join(",") !==
          "OPENAPI_ACCESS_CONFIG,OPENAPI_INSTALLATION_DEPLOYMENT_PROFILE,OPENAPI_INSTALLATION_SECRET_KEY_VERSION,OPENAPI_INSTALLATION_WORKFLOW_ROUTING,OPENAPI_RUNNER_AUTH_CONFIG") fail();
        const workflows = installations.workflowRuntime === "deployed-v1" ? [
          { binding: "OPENAPI_PUBLICATION_WORKFLOW", class_name: "OpenApiPublicationWorkflow", name: `${worker.name}-publication-v1` },
          { binding: "OPENAPI_INSPECTION_WORKFLOW", class_name: "OpenApiInspectionWorkflow", name: `${worker.name}-inspection-v1` },
        ] : [];
        if (!isDeepStrictEqual(worker.workflows ?? [], workflows)) fail();
      } else if (worker.durable_objects || worker.d1_databases || worker.r2_buckets || worker.secrets) fail();
      if (JSON.stringify(worker.routes) !== JSON.stringify([{ pattern: hostname, custom_domain: true }])) fail();
    }
    if (name === "catalogAgent") {
      if (worker.main !== "src/index.ts" || worker.workers_dev !== false || worker.preview_urls !== false) fail();
      if ((worker.routes ?? []).length) fail();
      if (Object.keys(worker.vars ?? {}).toSorted().join(",") !== "AI_GATEWAY_NAME,EXTRA_MODELS") fail();
      if (worker.durable_objects || worker.d1_databases || worker.r2_buckets || worker.secrets || worker.workflows) fail();
      if (!isDeepStrictEqual(worker.services ?? [], [{
        binding: DISCOVERY_READER_BINDING,
        service: operator,
        entrypoint: DISCOVERY_READER_ENTRYPOINT,
      }])) fail();
    }
  }
}

/** Save reviewable identities/graph and hashes of variable values, never their payloads. */
export function deploymentEvidence(
  config: DeploymentConfig,
  generated: GeneratedConfigs,
  resolvedApis: readonly OpenApiDeployment[] = config.openApis ?? [],
  registry?: { projectionRevision: number },
) {
  validateOpenApiGraph(config, generated, resolvedApis);
  const sha256 = (value: string) => createHash("sha256").update(value).digest("hex");
  return {
    version: 1,
    accountId: config.accountId,
    generatedAt: new Date().toISOString(),
    source: registry === undefined
      ? { mode: "bootstrapFile" as const }
      : { mode: "registry" as const, projectionRevision: registry.projectionRevision },
    deploymentOrder: deploymentOrder(config, resolvedApis),
    catalogs: deployedOpenApis(resolvedApis).map((api) => ({
      id: api.id, worker: api.worker,
      keys: Object.entries({ "catalog-release": api.catalog.manifestTrust.releaseKeys, "catalog-rollback": api.catalog.manifestTrust.rollbackKeys })
        .flatMap(([role, keys]) => keys.map((key) => ({ role, issuer: key.issuer, keyId: key.keyId,
          publicKeySha256: createHash("sha256").update(decodeOperatorPublicKey(key.publicKey)).digest("hex") }))),
    })),
    generated: Object.fromEntries(Object.entries(generated).map(([name, worker]: [string, ProdWranglerConfig]) => [name, {
      name: worker.name, account_id: worker.account_id, main: worker.main,
      workers_dev: worker.workers_dev, preview_urls: worker.preview_urls, routes: worker.routes ?? [],
      services: worker.services ?? [], durable_objects: worker.durable_objects,
      migrations: worker.migrations, d1_databases: worker.d1_databases,
      r2_buckets: worker.r2_buckets, kv_namespaces: worker.kv_namespaces,
      // Identifiers only (bindings, queue names, network targets): a changed
      // egress network or queue must show in the reviewable topology.
      vpc_networks: worker.vpc_networks, queues: worker.queues,
      requiredSecretNames: worker.secrets?.required ?? [],
      // Secrets Store bindings record the binding name and credential kind only:
      // store ids and secret names never enter evidence, even 0600 evidence.
      secretsStoreBindings: (worker.secrets_store_secrets ?? []).map((entry) => entry.binding),
      // Rate limits (the setup host's): their caps are part of what an approver reviews.
      ...(worker.ratelimits ? { ratelimits: worker.ratelimits.map((limit) => ({ name: limit.name, limit: limit.simple.limit, period: limit.simple.period })) } : {}),
      ...(name.startsWith("openApi:")
        ? { credentialKind: (worker.secrets_store_secrets ?? []).length ? "cloudflare-secrets-store-v1" : "worker-secret-v1" }
        : {}),
      variableSha256: Object.fromEntries(Object.entries(worker.vars ?? {}).map(([key, value]) => [key, sha256(JSON.stringify(value) ?? "undefined")])),
    }])),
  };
}

/** Check installed secret names before starting any Worker deployment. Never read values. */
export async function assertMessagingSecretsInstalled(
  config: DeploymentConfig,
  generated: GeneratedConfigs,
  offline: boolean,
  command: typeof spawnSync = spawnSync,
): Promise<void> {
  if (offline) return;
  const targets = [
    ...(config.messagingEgress?.deploy ? [generated.messagingEgress] : []),
    ...(config.messaging?.deploy && (config.messaging.oauth || config.notify?.deploy) ? [generated.messaging] : []),
    ...(config.eventRuntime?.deploy ? [generated.eventRuntime] : []),
    // The runtime signs every execution receipt (R4 P6d): without EXECUTION_RECEIPT_KEYS no run could finish.
    ...(config.execution?.enabled ? [generated.executionRuntime] : []),
  ];
  for (const target of targets) {
    if (!target?.name || !target.secrets?.required?.length) throw new Error("Messaging secret preflight has no generated requirements.");
    let names: Set<string>;
    try {
      const entry = resolveBinEntry(root, "wrangler");
      if (!entry) throw new Error();
      const output = command(process.execPath, [entry, "secret", "list", "--name", target.name, "--format", "json", "--env-file=/dev/null"], {
        cwd: root, env: { ...scrubbedEnv(), CLOUDFLARE_ACCOUNT_ID: config.accountId, CI: "true", WRANGLER_SEND_METRICS: "false", WRANGLER_WRITE_LOGS: "false" },
        encoding: "utf8", timeout: 30_000, maxBuffer: 65_536, stdio: ["ignore", "pipe", "pipe"],
      });
      if (output.status !== 0 || typeof output.stdout !== "string") throw new Error();
      const inventory: unknown = JSON.parse(output.stdout);
      if (!Array.isArray(inventory) || inventory.some(item => !item || typeof item.name !== "string")) throw new Error();
      names = new Set(inventory.map(item => item.name));
    } catch {
      throw new Error(`Cannot inspect messaging secrets for ${target.name}; no deployment was started.`);
    }
    const missing = target.secrets.required.filter(name => !names.has(name));
    if (missing.length) throw new Error(`Missing secrets for ${target.name}: ${missing.join(", ")}. No deployment was started.`);
  }
}


// `--no-cache` goes before the task name. Everything after it is `[ADDITIONAL_ARGS]`, forwarded to
// the task's own command -- `vp run -F x build --no-cache` reaches `tsc` as an unknown option.

/** `vp run --no-cache <task>` for a package in the submodule's workspace. */
function submoduleBuild(pkg: string, task = "build"): string[] {
  return [
    "--dir",
    "cloudflare-os",
    "exec",
    "vp",
    "run",
    "-F",
    pkg,
    "--no-cache",
    task,
  ];
}

/** `vp run --no-cache <task>` for a package in this repository's own workspace. */
function ownBuild(pkg: string, task = "build"): string[] {
  return ["exec", "vp", "run", "-F", pkg, "--no-cache", task];
}

/**
 * The build steps `pnpm check` and `pnpm deploy` run, in order, from the repository root.
 *
 * Every one goes through `vp run` rather than `pnpm --filter <pkg> build`, except the first,
 * which regenerates the gitignored declarations through `pnpm run` (it is a root script, not a
 * build artifact, so there is nothing to cache or replay). Two of the three
 * submodule targets have no `build` *script* at all any more -- they have a Vite+ *task*, which
 * `pnpm --filter` cannot see -- and `vp run` runs scripts and tasks alike, so one form covers both.
 *
 * `--no-cache` on every one. A cache hit is only as good as its fingerprint, which is cheap to get
 * wrong on a build you can re-run and expensive on a deploy you cannot; it is upstream's rule for
 * the same reason (cloudflare-os/scripts/deploy-scripts.test.ts). It also restores the full ambient
 * environment, which is the belt to `workshop-frontend`'s `cache.env: ['VITE_*']` braces: under a *cached*
 * `vp` run only declared patterns survive, and an undeclared variable is dropped from the command
 * and from the fingerprint both.
 *
 * The ordering matters at the end: the frontend has to build before the router deploy picks up
 * `../workshop-frontend/dist` as its assets.
 */
export function buildCommands(
  config: DeploymentConfig,
  resolvedApis: readonly OpenApiDeployment[] = config.openApis ?? [],
): BuildCommand[] {
  return [
    // The gitignored worker declarations every later step's tsc type-check reads. First,
    // unconditionally: deploy, --check, --dry-run, and the D4 installation runner all funnel
    // through here, and a clean checkout has none of these files until this step recreates them.
    { args: ["run", "types:generate"] },
    // `build:app` before `build`, and separately. `gatekeeper-context`'s `build` is a package.json script
    // that spawns `vp run --cache build:app` itself, and the outer `--no-cache` does not reach a
    // nested invocation carrying its own flag -- measured: the configurator app replayed from
    // cache. Rebuilding it here from source is what upstream's own `deploy` script does; the
    // `build` step below then type-checks and replays the bytes this step just wrote.
    { args: submoduleBuild("@gadgets/gatekeeper-context", "build:app") },
    { args: submoduleBuild("@gadgets/gatekeeper-context") },
    // The Scheduler's `build` nests the same cached `vp run build:app`, so it needs the same pair.
    { args: submoduleBuild("@gadgets/gatekeeper-scheduler", "build:app") },
    { args: submoduleBuild("@gadgets/gatekeeper-scheduler") },
    { args: ownBuild("custom-gatekeeper") },
    ...(config.memory?.deploy ? [{ args: ownBuild("gatekeeper-memory") }] : []),
    ...(config.execution?.enabled ? [{ args: ownBuild("execution-runtime", "types:check") }, { args: ownBuild("gatekeeper-execution") }] : []),
    ...(config.messagingEgress?.deploy ? [{ args: ownBuild("gatekeeper-messaging-egress", "types:check") }] : []),
    ...(config.messaging?.deploy ? [{ args: ownBuild("gatekeeper-messaging") }] : []),
    ...(config.eventRuntime?.deploy ? [{ args: ownBuild("event-runtime") }] : []),
    ...(gatewayEdgeDeploys(config) ? [{ args: ownBuild("events-edge", "types:check") }] : []),
    ...(config.adminUi?.deploy ? [{ args: ownBuild("admin-ui", "build") }] : []),
    // Builds the release into src/generated/ (scripts/release.mjs); build() then compares it with the committed hash.
    ...(config.setup?.deploy ? [{ args: ownBuild("setup", "build") }] : []),
    ...(config.presenceHost?.deploy ? [{ args: ownBuild("presence-ui", "build") }] : []),
    ...(deployedOpenApis(resolvedApis).length ? [{ args: ownBuild("gatekeeper-openapi") }] : []),
    ...(config.openApiOperator?.enabled ? [{ args: ownBuild("openapi-operator") }] : []),
    ...(config.openApiOperator?.enabled ? [{ args: ownBuild("catalog-agent") }] : []),
    ...(config.errorReporting.enabled
      ? [{ args: ownBuild("error-reporter") }]
      : []),
    ...(config.github.deploy
      ? [{ args: submoduleBuild("@gadgets/github-gatekeeper") }]
      : []),
    ...(config.linear.deploy
      ? [{ args: submoduleBuild("@gadgets/linear-gatekeeper") }]
      : []),
    ...(config.microsoft.deploy
      ? [{ args: submoduleBuild("@gadgets/microsoft-gatekeeper") }]
      : []),
    ...(config.mcp.deploy
      ? [{ args: submoduleBuild("@gadgets/mcp-gatekeeper") }]
      : []),
    ...(config.mcpPortal.deploy
      ? [{ args: submoduleBuild("@gadgets/mcp-portal-gatekeeper") }]
      : []),
    ...(config.email.deploy
      ? [{ args: submoduleBuild("@gadgets/email-gatekeeper") }]
      : []),
    ...(config.cloudflare.deploy
      ? [{ args: submoduleBuild("@gadgets/cloudflare-gatekeeper") }]
      : []),
    // X's `build` task depends on `build:configurator`, so one step builds both.
    ...(config.x?.deploy === true ? [{ args: submoduleBuild("@gadgets/x-gatekeeper") }] : []),
    ...(config.slack?.deploy === true ? [{ args: submoduleBuild("@gadgets/slack-gatekeeper") }] : []),
    ...(config.websearch?.deploy === true ? [{ args: submoduleBuild("@gadgets/gatekeeper-websearch") }] : []),
    ...(config.aiExecutors.enabled
      ? [
          { args: ownBuild("@knitli/os-ai-inference") },
          { args: submoduleBuild("@gadgets/gatekeeper-ai-executor") },
        ]
      : []),
    // Access mode is a build-time constant in the frontend bundle (`src/useAuth.ts`), so it is set
    // here rather than inherited: a bundle built under a different value is wrong, not just stale.
    {
      args: submoduleBuild("@gadgets/workshop-frontend"),
      env: { VITE_CF_ACCESS_MODE: "true" },
    },
    { args: submoduleBuild("@gadgets/router") },
    { args: submoduleBuild("@gadgets/workshop-backend") },
  ];
}

/**
 * Service bindings require their target Worker to exist first. Keep this graph explicit so Router
 * remains the final, sole public entrypoint and the AI Executor path is independently auditable.
 */
export function deploymentOrder(
  config: DeploymentConfig,
  resolvedApis: readonly OpenApiDeployment[] = config.openApis ?? [],
): DeployKey[] {
  // The operator both binds and is bound by every connector, so no static
  // order satisfies target-first in both directions — but the reverse edge
  // only exists once connectors are deployed. With none, the operator has
  // no per-connector bindings and deploys first (fresh adoption); with any,
  // the agent's one-directional edge goes first and the operator stays
  // after the connectors it binds. A virgin rollout WITH connectors still
  // needs a manual bootstrap pass: the cycle is unsatisfiable by ordering.
  const apis = deployedOpenApis(resolvedApis);
  const operatorEnabled = config.openApiOperator?.enabled === true;
  const operatorFirst = operatorEnabled && apis.length === 0;
  return [
    ...(config.errorReporting.enabled ? ["errorReporter" as const] : []),
    "context",
    "scheduler",
    "customGatekeeper",
    // Before workshop, whose GATEKEEPER_MESSAGING binding needs it to exist.
    ...(config.messagingEgress?.deploy ? ["messagingEgress" as const] : []),
    ...(config.messaging?.deploy ? ["messaging" as const] : []),
    // After messaging, whose AuthorityMemory entrypoint Memory's AUTHORITY_MEMORY binding needs to exist; and before workshop, whose GATEKEEPER_MEMORY binding needs Memory.
    ...(config.memory?.deploy ? ["memory" as const] : []),
    ...(config.eventRuntime?.deploy ? ["eventRuntime" as const] : []),
    // After eventRuntime, whose NodeEdge entrypoint its NODE_EDGE binding needs.
    ...(gatewayEdgeDeploys(config) ? ["eventsEdge" as const] : []),
    // The runtime first: the gatekeeper's EXECUTION_RUNTIME service binding needs it to exist. Both before
    // adminUi, whose EXECUTION_ADMIN binding needs the gatekeeper. So a Worker the runtime or gatekeeper binds
    // later must deploy above this line too (or adminUi must move below it): target-first, as everywhere here.
    ...(config.execution?.enabled ? ["executionRuntime" as const, "execution" as const] : []),
    // After messaging, whose AgentEnrollment its ENROLLMENT binding needs; before adminUi, which prints the commands that fetch from it.
    ...(config.setup?.deploy ? ["setup" as const] : []),
    // After messaging, whose HumanProof its HUMAN_PROOF binding needs; before adminUi, which links to it.
    ...(config.presenceHost?.deploy ? ["presence" as const] : []),
    ...(config.adminUi?.deploy ? ["adminUi" as const] : []),
    ...(operatorFirst ? ["openApiOperator" as const] : []),
    ...(operatorEnabled ? ["catalogAgent" as const] : []),
    ...apis.map((api) => openApiKey(api.id)),
    ...(operatorEnabled && !operatorFirst ? ["openApiOperator" as const] : []),
    ...(config.github.deploy ? ["github" as const] : []),
    ...(config.linear.deploy ? ["linear" as const] : []),
    ...(config.microsoft.deploy ? ["microsoft" as const] : []),
    ...(config.mcp.deploy ? ["mcp" as const] : []),
    ...(config.mcpPortal.deploy ? ["mcpPortal" as const] : []),
    ...(config.email.deploy ? ["email" as const] : []),
    ...(config.cloudflare.deploy ? ["cloudflare" as const] : []),
    ...(config.x?.deploy === true ? ["x" as const] : []),
    ...(config.slack?.deploy === true ? ["slack" as const] : []),
    ...(config.websearch?.deploy === true ? ["websearch" as const] : []),
    // The private inference service must precede its runtime Gatekeeper, which must precede
    // Workshop's vendor binding. Router is still the sole public Worker and deploys last.
    ...(config.aiExecutors.enabled
      ? ["aiInference" as const, "aiExecutor" as const]
      : []),
    "workshop",
    "router",
  ];
}

/**
 * Every Worker name this config could produce, enabled or not: `config.workers` lists each fixed
 * Worker whether or not it deploys, `apis` holds every connector, `deploy: false` included, and
 * `inventory.extraWorkers` names OS Workers the generator doesn't produce. The deploy record's
 * `retained` and `--snapshot` universe; it never lists the account's other Workers.
 */
export function allWorkerNames(config: DeploymentConfig, apis: readonly OpenApiDeployment[]): string[] {
  const names = [
    ...Object.values(config.workers).map((worker) => worker.name),
    ...apis.map((api) => api.worker),
    ...(config.inventory?.extraWorkers ?? []),
  ];
  return [...new Set(names.filter((name) => typeof name === "string" && WORKER_NAME.test(name)))].toSorted();
}

/**
 * Read-only wrangler lookups (`deployments list`, `versions list`) for the deploy record: piped,
 * never echoed. 15 s each: they block the event loop, and a lease heartbeat shares it.
 */
function wranglerLookupPort(cwd: string): WranglerPort {
  return (args, env) => {
    const entry = resolveBinEntry(cwd, "wrangler");
    if (!entry) throw new Error("wrangler is not installed");
    const result = spawnSync(process.execPath, [entry, ...args], {
      cwd, env, stdio: ["ignore", "pipe", "pipe"], encoding: "utf8", timeout: 15_000, maxBuffer: 8 * 1024 * 1024,
    });
    if (result.error) throw result.error;
    return { status: result.status, stdout: result.stdout, stderr: result.stderr };
  };
}

// `allowTrailingComma` because wrangler accepts them and upstream uses them: the Scheduler's base
// config closes `build`, `migrations` and `observability` with one. Without the option every such
// comma is a parse *error*, so the deploy refuses a file wrangler itself reads happily.
const jsoncOptions = { allowTrailingComma: true };

async function readJsonc<T>(path: string): Promise<T> {
  const errors: ParseError[] = [];
  const result = parse(await readFile(path, "utf8"), errors, jsoncOptions) as T;
  if (errors.length) {
    const where = relative(root, path) || path;
    throw new Error(
      `${where}: ${printParseErrorCode(errors[0].error)} at offset ${errors[0].offset}`,
    );
  }
  return result;
}

// Every validateConfig message names a config path, so say which file those paths live in.
/** Reads and validates `deployment.jsonc`. Exported for the D4 runner. */
export async function readDeployment(path: string): Promise<DeploymentConfig> {
  const config = await readJsonc<DeploymentConfig>(path);
  try {
    return validateConfig(config);
  } catch (error) {
    throw new Error(`${relative(root, path)}: ${(error as Error).message}`, {
      cause: error,
    });
  }
}

/** Runs build/deploy children without starving the deployment lease heartbeat. */
export async function runCommand(
  command: string,
  argv: string[],
  cwd: string,
  env: NodeJS.ProcessEnv,
  label: string,
): Promise<void> {
  await new Promise<void>((done, reject) => {
    const child = spawn(command, argv, { cwd, env, stdio: "inherit" });
    child.once("error", reject);
    child.once("close", (code) => {
      if (code === 0) done();
      else {
        const where = relative(root, cwd) || ".";
        reject(new Error(`${where}: ${label} failed. Its output is above.`));
      }
    });
  });
}

// Spawned through pnpmCommand rather than as a bare "pnpm": on Windows the pnpm on PATH is a `.cmd`
// shim Node refuses to spawn without a shell, and `shell: true` would re-split argv and break any
// checkout path containing a space.
async function run(
  args: string[],
  cwd = root,
  env: NodeJS.ProcessEnv = process.env,
): Promise<void> {
  const [command, argv] = pnpmCommand(args, env);
  await runCommand(command, argv, cwd, env, `pnpm ${args.join(" ")}`);
}

/**
 * `wrangler deploy` for one package, spawned as `node <entry>` when the entry point behind the
 * `.bin` shim can be found. That saves the ~0.33s `pnpm exec` costs per call and sidesteps the
 * Windows `.cmd` shim entirely; when it cannot be resolved, the pnpm path is still there.
 */
export async function deployWorker(
  dir: string,
  configFile: string,
  extraArgs: string[],
  env: NodeJS.ProcessEnv = process.env,
): Promise<void> {
  const cwd = join(root, dir);
  const args = ["deploy", "--config", configFile, ...extraArgs];
  const entry = resolveBinEntry(cwd, "wrangler");
  if (entry) {
    await runCommand(
      process.execPath,
      [entry, ...args],
      cwd,
      env,
      `wrangler ${args.join(" ")}`,
    );
  } else {
    await run(["exec", "wrangler", ...args], cwd, env);
  }
}

export function workerDeployArgs(worker: DeployKey, dryRun: boolean): string[] {
  return dryRun ? ["--dry-run"] : [];
}

/** One Worker's deploy step. `key` names the Worker, so a recording wrapper can attribute its output. */
export type DeployFn = (dir: string, configFile: string, args: string[], key: DeployKey) => void | Promise<void>;

/** Deploy a receiver-free Messaging stage before its target Event Runtime exists. */
async function deployMessagingBootstrap(finalConfig: ProdWranglerConfig | undefined, args: string[], deploy: DeployFn): Promise<void> {
  if (!finalConfig) throw new Error("Missing generated Messaging config for Event Runtime bootstrap.");
  const bootstrap = structuredClone(finalConfig);
  bootstrap.services = (bootstrap.services ?? []).filter(service =>
    service.binding !== "EVENT_MESSAGE_CONSUMER" && service.binding !== "MESSAGE_RECEIVER");
  bootstrap.vars = { ...bootstrap.vars, MESSAGING_EVENT_PUBLISH_ENABLED: "false" };
  const configFile = `wrangler.bootstrap.${randomUUID()}.jsonc`;
  const path = join(root, packageDir("messaging"), configFile);
  await writeFile(path, `${JSON.stringify(bootstrap, null, 2)}\n`, { mode: 0o600 });
  try {
    await deploy(packageDir("messaging"), configFile, args, "messaging");
  } finally {
    await rm(path, { force: true });
  }
}

/** `deployWorker` as a `DeployFn`. Not `deployWorker` itself: its fourth parameter is `env`, which would receive the key. */
const deployStep: DeployFn = (dir, configFile, args) => deployWorker(dir, configFile, args);

/** Deploys each worker in dependency order via the injectable `deploy` (real Wrangler by default). */
export async function deployWorkers(
  config: DeploymentConfig,
  dryRun: boolean,
  deploy: DeployFn = deployStep,
  resolvedApis: readonly OpenApiDeployment[] = config.openApis ?? [],
  deactivation: EventRuntimeDeactivationPorts = {},
): Promise<void> {
  await deactivateEventRuntime(config, dryRun, deactivation);
  const eventBindingCycle = config.eventRuntime?.deploy === true;
  const messagingConfig = eventBindingCycle ? await readJsonc<ProdWranglerConfig>(generatedPath("messaging")) : undefined;
  for (const worker of deploymentOrder(config, resolvedApis)) {
    if (eventBindingCycle && worker === "messaging") {
      await deployMessagingBootstrap(messagingConfig, workerDeployArgs(worker, dryRun), deploy);
      continue;
    }
    await deploy(packageDir(worker), generatedFileName(worker), workerDeployArgs(worker, dryRun), worker);
    if (eventBindingCycle && worker === "eventRuntime")
      await deploy(packageDir("messaging"), generatedFileName("messaging"), workerDeployArgs("messaging", dryRun), "messaging");
  }
}

/**
 * The deployment-mutation kind for one deploy step, if the closed kind set covers it. Only
 * the OpenAPI binding graph carries markers — connectors, operator, Workshop, router —
 * because only those deploys derive from the leased revision. Every other Worker deploys
 * unwrapped: inventing a kind for it would require a server contract change (D4 owns kinds).
 */
export function mutationKindForWorker(worker: DeployKey): DeploymentMutationKind | undefined {
  if (worker === "router") return "router-deploy";
  if (worker === "workshop") return "workshop-deploy";
  if (worker === "openApiOperator") return "operator-deploy";
  if (worker.startsWith("openApi:")) return "connector-deploy";
  return undefined;
}

/**
 * `deployWorkers` under a deployment lease: every covered Wrangler child runs inside a
 * start/finish marker pair naming the deployed Worker. A dry run finishes `absent` — it
 * applies nothing, so its outcome is unambiguous. A live failure leaves its marker live
 * for `--reconcile-mutation`: the deploy may or may not have landed, and only an
 * administrator's review of the live account state can close it (D-REG-004).
 */
export async function deployWorkersWithLease(
  config: DeploymentConfig,
  generated: GeneratedConfigs,
  dryRun: boolean,
  deploy: DeployFn,
  context: LeaseContext,
  resolvedApis: readonly OpenApiDeployment[] = config.openApis ?? [],
  deactivation: EventRuntimeDeactivationPorts = {},
): Promise<void> {
  await deactivateEventRuntime(config, dryRun, deactivation);
  const eventBindingCycle = config.eventRuntime?.deploy === true;
  const messagingConfig = eventBindingCycle ? generated.messaging : undefined;
  for (const worker of deploymentOrder(config, resolvedApis)) {
    if (eventBindingCycle && worker === "messaging") {
      await context.catchUp();
      await deployMessagingBootstrap(messagingConfig, workerDeployArgs(worker, dryRun), deploy);
      continue;
    }
    const kind = mutationKindForWorker(worker);
    const args = workerDeployArgs(worker, dryRun);
    if (kind === undefined) {
      // Catch up any outstanding beat before starting the next deploy.
      await context.catchUp();
      await deploy(packageDir(worker), generatedFileName(worker), args, worker);
      if (eventBindingCycle && worker === "eventRuntime") {
        await context.catchUp();
        await deploy(packageDir("messaging"), generatedFileName("messaging"), workerDeployArgs("messaging", dryRun), "messaging");
      }
      continue;
    }
    const target = (generated as unknown as Record<string, ProdWranglerConfig | undefined>)[worker]?.name;
    if (target === undefined || target === "") {
      throw new Error(`Cannot name the deployment marker target for ${worker}: no generated Worker name.`);
    }
    const targetNames = [target];
    const mutationId = await context.startMutation({ kind, targetNames, requestCorrelation: randomUUID() });
    try {
      await deploy(packageDir(worker), generatedFileName(worker), args, worker);
    } catch (cause) {
      if (dryRun) await context.finishMutation(mutationId, { state: "absent" });
      throw cause;
    }
    await context.finishMutation(mutationId, dryRun ? { state: "absent" } : { state: "confirmed", resourceIds: targetNames });
  }
}

function requireSubmodule(): void {
  if (!existsSync(join(root, "cloudflare-os/package.json"))) {
    throw new Error(
      "CloudflareOS submodule is not initialized. Run git submodule update --init.",
    );
  }
}

/**
 * A build child's env: the process env plus the command's own, without a GitHub token. CI sets
 * GH_TOKEN (a `deployments: write` token the deploy record publishes with), and no build needs it.
 * Exported for tests.
 */
export function buildEnv(env: NodeJS.ProcessEnv = {}): NodeJS.ProcessEnv {
  const { GH_TOKEN: _gh, GITHUB_TOKEN: _github, ...rest } = process.env;
  return { ...rest, ...env };
}

/** What build() runs commands with and reads the setup release from. Replaced in tests only. */
export type BuildPorts = { run: (args: string[], cwd: string, env: NodeJS.ProcessEnv) => Promise<unknown>; setupRelease: () => { installer?: { sha256?: unknown } } };
const buildPorts: BuildPorts = {
  run: (args, cwd, env) => run(args, cwd, env),
  setupRelease: () => JSON.parse(readFileSync(join(root, packageDirs.setup, "src", "generated", "release.json"), "utf8")),
};

async function build(config: DeploymentConfig, resolvedApis: readonly OpenApiDeployment[], ports: BuildPorts = buildPorts): Promise<void> {
  for (const { args, env } of buildCommands(config, resolvedApis)) {
    await ports.run(args, root, buildEnv(env));
  }
  if (config.setup?.deploy) checkSetupRelease(config.setup.releaseSha256, ports.setupRelease());
}

/**
 * The fresh build's installer hash must be the committed one (O6): the setup Worker serves those bytes and the Agents page prints that
 * hash, so a helper change without a reviewed hash bump stops the deploy instead of shipping. Exported for tests.
 */
export function checkSetupRelease(committed: string, release: { installer?: { sha256?: unknown } }): void {
  const built = release.installer?.sha256;
  if (built !== committed)
    throw new Error(`setup.releaseSha256 is ${committed}, but this build's installer hashes to ${String(built)}: run pnpm run setup:release-hash, review the helper change and commit the new hash.`);
}

/** Builds every worker `deployWorkersWithLease` may deploy. Exported for the D4 runner. */
export async function buildDeploymentWorkers(
  config: DeploymentConfig,
  resolvedApis: readonly OpenApiDeployment[],
  ports?: BuildPorts,
): Promise<void> {
  await build(config, resolvedApis, ports);
}

// Said once, up front, rather than discovered when the first chat throws.
function reportAiGateway(config: DeploymentConfig): void {
  const gateway = aiGatewayPlan(config);
  if (!gateway) {
    console.warn(
      "\naiGateway.enabled is false: this deployment advertises no model catalog, and each user " +
        "supplies their own model API keys. A Workshop migrated from the hosted deploy will show an " +
        "empty model picker -- see docs/migrate-from-hosted.md.",
    );
    return;
  }
  if (!gateway.needsToken) return;
  // CLOUDFLARE_ACCOUNT_ID pins the account the way the deploys themselves are pinned: every
  // generated config carries `account_id`, but `wrangler secret put` takes only `--name`
  console.warn(
    `\nCF_AI_GATEWAY_API_TOKEN is required by this configuration:\n` +
      gateway.tokenReasons.map((reason) => `  - ${reason}`).join("\n") +
      `\nInstall it before deploying:\n  CLOUDFLARE_ACCOUNT_ID=${config.accountId} ` +
      `pnpm exec wrangler secret put CF_AI_GATEWAY_API_TOKEN ` +
      `--name ${config.workers.workshop.name}\n`,
  );
}

/** The sixteen base wrangler configs generation clones. Exported for the D4 runner. */
export async function readBases(config?: DeploymentConfig): Promise<BaseConfigs> {
  return {
    router: await readJsonc(join(root, packageDirs.router, "wrangler.jsonc")),
    workshop: await readJsonc(
      join(root, packageDirs.workshop, "wrangler.jsonc"),
    ),
    context: await readJsonc(join(root, packageDirs.context, "wrangler.jsonc")),
    scheduler: await readJsonc(
      join(root, packageDirs.scheduler, "wrangler.jsonc"),
    ),
    customGatekeeper: await readJsonc(
      join(root, packageDirs.customGatekeeper, "wrangler.jsonc"),
    ),
    errorReporter: await readJsonc(
      join(root, packageDirs.errorReporter, "wrangler.jsonc"),
    ),
    github: await readJsonc(join(root, packageDirs.github, "wrangler.jsonc")),
    linear: await readJsonc(join(root, packageDirs.linear, "wrangler.jsonc")),
    microsoft: await readJsonc(join(root, packageDirs.microsoft, "wrangler.jsonc")),
    mcp: await readJsonc(join(root, packageDirs.mcp, "wrangler.jsonc")),
    mcpPortal: await readJsonc(
      join(root, packageDirs.mcpPortal, "wrangler.jsonc"),
    ),
    email: await readJsonc(join(root, packageDirs.email, "wrangler.jsonc")),
    cloudflare: await readJsonc(
      join(root, packageDirs.cloudflare, "wrangler.jsonc"),
    ),
    x: await readJsonc(join(root, packageDirs.x, "wrangler.jsonc")),
    slack: await readJsonc(join(root, packageDirs.slack, "wrangler.jsonc")),
    websearch: await readJsonc(join(root, packageDirs.websearch, "wrangler.jsonc")),
    openApi: await readJsonc(join(root, packageDirs.openApi, "wrangler.jsonc")),
    openApiOperator: await readJsonc(join(root, packageDirs.openApiOperator, "wrangler.jsonc")),
    catalogAgent: await readJsonc(join(root, packageDirs.catalogAgent, "wrangler.jsonc")),
    memory: await readJsonc(join(root, packageDirs.memory, "wrangler.jsonc")),
    execution: await readJsonc(join(root, packageDirs.execution, "wrangler.jsonc")),
    ...(config?.execution?.enabled ? {
      executionRuntime: await readJsonc<ProdWranglerConfig>(join(root, packageDirs.executionRuntime, "wrangler.jsonc")),
    } : {}),
    messaging: await readJsonc(join(root, packageDirs.messaging, "wrangler.jsonc")),
    ...(config?.eventRuntime?.deploy ? { eventRuntime: await readJsonc<ProdWranglerConfig>(join(root, packageDirs.eventRuntime, "wrangler.jsonc")) } : {}),
    ...(config && gatewayEdgeDeploys(config) ? { eventsEdge: await readJsonc<ProdWranglerConfig>(join(root, packageDirs.eventsEdge, "wrangler.jsonc")) } : {}),
    ...(config?.adminUi?.deploy ? { adminUi: await readJsonc<ProdWranglerConfig>(join(root, packageDirs.adminUi, "wrangler.jsonc")) } : {}),
    ...(config?.setup?.deploy ? { setup: await readJsonc<ProdWranglerConfig>(join(root, packageDirs.setup, "wrangler.jsonc")) } : {}),
    ...(config?.presenceHost?.deploy ? { presence: await readJsonc<ProdWranglerConfig>(join(root, packageDirs.presence, "wrangler.jsonc")) } : {}),
    ...(config?.messagingEgress?.deploy ? { messagingEgress: await readJsonc<ProdWranglerConfig>(join(root, packageDirs.messagingEgress, "wrangler.jsonc")) } : {}),
    aiInference: await readJsonc(
      join(root, packageDirs.aiInference, "wrangler.jsonc"),
    ),
    aiExecutor: await readJsonc(
      join(root, packageDirs.aiExecutor, "wrangler.jsonc"),
    ),
  };
}

/** `--evidence-dir <path>`, or `.wrangler/deployment-evidence`, resolved against apps/os. */
function evidenceDirFromArgv(): string {
  const evidenceIndex = process.argv.indexOf("--evidence-dir");
  const evidenceArg = evidenceIndex < 0 ? undefined : process.argv[evidenceIndex + 1];
  if (evidenceIndex >= 0 && (!evidenceArg || evidenceArg.startsWith("--"))) throw new Error("--evidence-dir requires a path.");
  return resolve(root, evidenceArg ?? ".wrangler/deployment-evidence");
}

async function runDeployment(
  config: DeploymentConfig,
  bases: BaseConfigs,
  apis: readonly OpenApiDeployment[],
  registry: { projectionRevision: number } | undefined,
  deployRunner: (config: DeploymentConfig, generated: GeneratedConfigs, dryRun: boolean, deploy: DeployFn, deactivation: EventRuntimeDeactivationPorts) => Promise<void>,
): Promise<void> {
  // One clock for the deploy: the windows checked below are the windows generated here.
  const presenceInput = presenceInputFromEnv();
  const generated = generateConfigs(config, bases, apis, presenceInput);
  reportAiGateway(config);
  const evidenceDir = evidenceDirFromArgv();
  await mkdir(evidenceDir, { recursive: true, mode: 0o700 });
  let evidenceText = `${JSON.stringify(deploymentEvidence(config, generated, apis, registry), null, 2)}\n`;
  await writeFile(join(evidenceDir, "generated-config.json"), evidenceText, { mode: 0o600 });
  console.log(`Sanitized deployment evidence: ${join(evidenceDir, "generated-config.json")}`);

  // `keyof GeneratedConfigs`, not `DeployKey`: the latter also contains the bare "openApi"
  // packageDirs lookup key, which `generated` never actually has (each entry is "openApi:<id>").
  const keys = Object.keys(generated) as (keyof GeneratedConfigs)[];
  const check = process.argv.includes("--check");
  const dryRun = check || process.argv.includes("--dry-run");
  // A dry run cannot qualify live epoch transitions. A real deploy reads the current
  // Worker bindings before build/deploy/resource mutations begin.
  await assertGitHubSourceEpoch(config, dryRun);
  // The source as the deploy sees it (git state and patches), before the build writes anything.
  // A failure is recorded, not fatal.
  let snapshot: SourceSnapshot | Error | undefined;
  if (!dryRun) {
    try {
      snapshot = await snapshotSource(root);
    } catch (error) {
      snapshot = error as Error;
    }
  }
  try {
    for (const key of keys) {
      await writeFile(generatedPath(key), `${JSON.stringify(generated[key], null, 2)}\n`);
    }
    if (check) await run(["test"]);
    await build(config, apis);
    await assertMessagingSecretsInstalled(config, generated, dryRun);
    const eventQueueReadback = await readEventQueueRetention(config, dryRun);
    if (eventQueueReadback) {
      evidenceText = `${JSON.stringify({ ...deploymentEvidence(config, generated, apis, registry), eventQueueReadback }, null, 2)}\n`;
      await writeFile(join(evidenceDir, "generated-config.json"), evidenceText, { mode: 0o600 });
    }
    const eventRuntimeDeactivation: RecordOptions["eventRuntimeDeactivation"] = config.eventRuntime?.deploy === false
      ? { worker: config.workers.eventRuntime?.name ?? null, status: "pending" } : undefined;
    // The record covers the deploy phase only: a build failure above never touched Cloudflare.
    await runDeployPhase(dryRun, (phaseDryRun, deploy) => deployRunner(config, generated, phaseDryRun, deploy, { record: eventRuntimeDeactivation }),
      () => deployRecordOptions({ config, generated, apis, registry, evidenceDir, evidenceText, snapshot, eventRuntimeDeactivation }));
  } finally {
    await Promise.all(keys.map((key) => rm(generatedPath(key), { force: true })));
  }
}

/** The clock, as this process has it. */
function presenceInputFromEnv(): PresenceInput {
  return { now: Date.now() };
}

/** The deploy record's options for one live run. Pure apart from building the lookup port. Exported for tests. */
export function deployRecordOptions(input: {
  config: DeploymentConfig; generated: GeneratedConfigs; apis: readonly OpenApiDeployment[];
  registry: { projectionRevision: number } | undefined; evidenceDir: string; evidenceText: string; snapshot?: SourceSnapshot | Error;
  eventRuntimeDeactivation?: RecordOptions["eventRuntimeDeactivation"];
}): RecordOptions {
  const { config, generated, apis, registry } = input;
  const execution = config.execution;
  const keys = Object.keys(generated) as (keyof GeneratedConfigs)[];
  return {
    eventRuntimeDeactivation: input.eventRuntimeDeactivation,
    evidenceDir: input.evidenceDir, appsOsRoot: root, accountId: config.accountId,
    deployer: process.env.GITHUB_ACTOR ?? process.env.USER ?? process.env.LOGNAME ?? "unknown",
    run: ciRun(),
    order: deploymentOrder(config, apis),
    names: Object.fromEntries(keys.map((key) => [key, generated[key]!.name!])),
    universe: allWorkerNames(config, apis),
    inventory: config.inventory?.extraWorkers ?? [],
    evidenceSha256: createHash("sha256").update(input.evidenceText).digest("hex"),
    evidenceText: input.evidenceText,
    source: registry ? { mode: "registry", projectionRevision: registry.projectionRevision } : { mode: "bootstrapFile" },
    pins: { execution: execution ? {
      // The key predates the runtime's move into this wrapper (#624 phase 2): it now names the deployed runtime Worker.
      enabled: execution.enabled, runtimeService: config.workers.executionRuntime?.name,
      // A disabled block skips validation and may hold placeholders, so only an enabled, validated list is pinned.
      profiles: execution.enabled && Array.isArray(execution.profiles) ? execution.profiles.map(({ id, image }) => ({ id, image })) : undefined,
    } : null },
    snapshot: input.snapshot,
    ports: { deploy: deployWorker, wrangler: wranglerLookupPort(root), gh: defaultGhPort },
  };
}

/** A dry run deploys unrecorded; a live run goes through the deploy record. Exported for tests. */
export async function runDeployPhase(
  dryRun: boolean,
  runner: (dryRun: boolean, deploy: DeployFn) => Promise<void>,
  recordOptions: () => RecordOptions,
): Promise<void> {
  if (dryRun) {
    await runner(true, deployStep);
    return;
  }
  await withDeploymentRecord(recordOptions(), (deploy) => runner(false, deploy));
}

function registryClientFrom(
  config: DeploymentConfig,
  holderLabel: string,
): { client: ReturnType<typeof createRegistryClient>; hostname: string } {
  const operator = config.openApiOperator;
  if (operator?.enabled !== true) {
    throw new Error(
      "The registry path needs openApiOperator.enabled: the export and lease routes live on the operator.",
    );
  }
  const installations = operator.installations;
  if (installations?.enabled !== true) {
    throw new Error(
      "The registry path needs openApiOperator.installations.enabled: without the installations " +
        "backend the export and lease routes answer 503. Enable it, or set bootstrapFile.enabled " +
        "to deploy from the file during the migration.",
    );
  }
  const secret = process.env[DEPLOY_CLIENT_SECRET_ENV];
  if (!secret) {
    throw new Error(
      `The registry path needs ${DEPLOY_CLIENT_SECRET_ENV} in the environment: the deploy ` +
        "principal's Access service-token secret. It is never written anywhere by this script.",
    );
  }
  return {
    client: createRegistryClient({
      baseUrl: `https://${operator.hostname}`,
      clientId: installations.deployClientId,
      clientSecret: secret,
      holderId: createCliHolderId(holderLabel),
    }),
    hostname: operator.hostname,
  };
}

/** Registry mode: every OpenAPI step generates from the under-lease export. See D-REG-001..004. */
async function runRegistryDeployment(config: DeploymentConfig, bases: BaseConfigs): Promise<void> {
  const label = process.env.USER ?? process.env.LOGNAME ?? "deploy";
  const { client } = registryClientFrom(config, label);
  await withDeploymentLease(client, async (context) => {
    await assertWorkflowRuntimeRetained(config, process.argv.includes("--check") || process.argv.includes("--dry-run"));
    const apis = openApiDeploymentsFromExport(context.exported);
    console.log(
      `Registry export at revision ${context.projectionRevision}: ${apis.filter((api) => api.deploy).length} API(s) to deploy.`,
    );
    await runDeployment(config, bases, apis, { projectionRevision: context.projectionRevision },
      async (deployment, generated, dryRun, deploy, deactivation) => {
        await context.catchUp();
        await deployWorkersWithLease(deployment, generated, dryRun, deploy, context, apis, deactivation);
      });
  });
}

/**
 * `--snapshot`: records what is live now and deploys nothing. Registry mode reads the export
 * unscoped, without a lease; `registryClientFrom` refuses without the deploy secret, so the
 * connectors' names are never silently missed. Configs are generated for names and order only:
 * nothing is written into the packages and nothing is built.
 */
async function snapshotCommand(config: DeploymentConfig, bases: BaseConfigs): Promise<void> {
  let apis: readonly OpenApiDeployment[] = config.openApis ?? [];
  let registry: { projectionRevision: number } | undefined;
  if (!isBootstrapFileMode(config)) {
    const label = process.env.USER ?? process.env.LOGNAME ?? "deploy";
    const { exported } = await readExport(registryClientFrom(config, `${label}-snapshot`).client);
    apis = openApiDeploymentsFromExport(exported);
    registry = { projectionRevision: exported.projectionRevision };
  }
  const generated = generateConfigs(config, bases, apis, presenceInputFromEnv());
  const evidenceDir = evidenceDirFromArgv();
  const evidenceText = `${JSON.stringify(deploymentEvidence(config, generated, apis, registry), null, 2)}\n`;
  const { ok } = await snapshotRecord(deployRecordOptions({ config, generated, apis, registry, evidenceDir, evidenceText }));
  if (!ok) {
    console.error("\nSnapshot failed: no Cloudflare lookup succeeded (each one failed, or the lookup budget ran out first). The record was still written.");
    process.exitCode = 1;
  }
}

/**
 * Same-principal reconcile for one ambiguous deployment marker. The result is an
 * administrator's reviewed reading of the live account state — this command takes their
 * word for it, and the server re-checks identity, staleness, and principal.
 */
async function reconcileCommand(args: readonly string[]): Promise<void> {
  const mutationId = args[0];
  if (!mutationId || mutationId.startsWith("--")) {
    throw new Error("--reconcile-mutation requires a mutation id.");
  }
  for (const arg of args) {
    if (arg.startsWith("--") && arg !== "--state" && arg !== "--resource-ids") {
      throw new Error(`Unknown reconcile flag: ${arg}.`);
    }
  }
  const stateIndex = args.indexOf("--state");
  const state = stateIndex < 0 ? undefined : args[stateIndex + 1];
  if (state !== "confirmed" && state !== "absent" && state !== "foreign-collision") {
    throw new Error("--reconcile-mutation requires --state confirmed|absent|foreign-collision.");
  }
  const idsIndex = args.indexOf("--resource-ids");
  const csv = idsIndex < 0 ? undefined : args[idsIndex + 1];
  if (idsIndex >= 0 && (!csv || csv.startsWith("--"))) {
    throw new Error("--resource-ids requires a comma-separated list.");
  }
  const resourceIds = csv === undefined ? [] : csv.split(",").map((name) => name.trim()).filter((name) => name !== "");
  if (state === "absent" && resourceIds.length) {
    throw new Error("An absent reconciliation carries no --resource-ids.");
  }
  if (state !== "absent" && !resourceIds.length) {
    throw new Error(`A ${state} reconciliation requires --resource-ids naming what the marker left behind.`);
  }
  const result = state === "absent"
    ? { state: state as "absent" }
    : { state: state as "confirmed" | "foreign-collision", resourceIds: resourceIds.toSorted() };
  const config = await readDeployment(join(root, "deployment.jsonc"));
  const label = process.env.USER ?? process.env.LOGNAME ?? "deploy";
  const { client } = registryClientFrom(config, `${label}-reconcile`);
  await reconcileMutation(client, mutationId, result);
  console.log(`Reconciled deployment marker ${mutationId} as ${state}.`);
}

type CloudflareAuthCommand = (command: string, args: string[], options: SpawnSyncOptionsWithStringEncoding) => { status: number | null; stdout: string };

function deploymentAuthHeaders(unavailable: () => Error, authCommand?: CloudflareAuthCommand): Record<string, string> {
  let headers: Record<string, string>;
  try {
    // Never use runCommand: auth output is secret, captured only in memory.
    const entry = resolveBinEntry(root, "wrangler");
    if (!entry) throw unavailable();
    const output = (authCommand ?? spawnSync)(process.execPath, [entry, "auth", "token", "--json"], {
      cwd: root, env: { ...process.env, CI: "true", WRANGLER_SEND_METRICS: "false", WRANGLER_WRITE_LOGS: "false" },
      encoding: "utf8", timeout: 30_000, maxBuffer: 65_536, stdio: ["ignore", "pipe", "pipe"],
    });
    if (output.status !== 0 || typeof output.stdout !== "string" || Buffer.byteLength(output.stdout) > 65_536) throw unavailable();
    const auth: unknown = JSON.parse(output.stdout);
    if (!auth || typeof auth !== "object" || Array.isArray(auth)) throw unavailable();
    const value = auth as Record<string, unknown>;
    // Reject control bytes and spaces in authentication header values.
    // eslint-disable-next-line no-control-regex
    const secret = (input: unknown): input is string => typeof input === "string" && input.length > 0 && input.length < 16_384 && !/[\x00-\x20\x7f]/.test(input);
    if ((value.type === "api_token" || value.type === "oauth") && Object.keys(value).toSorted().join() === "token,type" && secret(value.token)) headers = { Authorization: `Bearer ${value.token}` };
    else if (value.type === "api_key" && Object.keys(value).toSorted().join() === "email,key,type" && secret(value.key) && secret(value.email)) headers = { "X-Auth-Key": value.key, "X-Auth-Email": value.email };
    else throw unavailable();
  } catch { throw unavailable(); }
  return headers;
}

export interface EventRuntimeDeactivationPorts {
  authCommand?: CloudflareAuthCommand;
  fetch?: typeof fetch;
  record?: NonNullable<RecordOptions["eventRuntimeDeactivation"]>;
}

export interface GitHubSourceEpochPorts { authCommand?: CloudflareAuthCommand; fetch?: typeof fetch }

type GitHubSourceLiveProfile = { eventEnabled: boolean; sourceEnabled: boolean; enabled: boolean; epoch: number; watch: boolean; initial: boolean; appId: string; mapping: string; stockEnabled: boolean; stockCanary: string };

/** Pure guard over Cloudflare's current source settings and the reviewed deployment profile. */
export function validateGitHubSourceEpoch(current: GitHubSourceLiveProfile, config: DeploymentConfig): void {
  const proposed = config.eventRuntime?.githubSource;
  const enabled = proposed?.sourceControl?.enabled === true;
  const epoch = proposed?.sourceControl?.gateEpoch ?? 0;
  const watch = proposed?.watchControl === true;
  const initial = proposed?.initialReconciliation === true;
  const appId = proposed?.appId ?? "";
  const mapping = proposed ? JSON.stringify([proposed.mapping]) : "[]";
  const sourceEnabled = proposed !== undefined;
  const stockEnabled = config.eventRuntime?.assignedStockCanary !== undefined;
  const stockCanary = stockEnabled ? JSON.stringify(config.eventRuntime!.assignedStockCanary) : "";
  const githubSourceExists = current.enabled || current.watch || current.initial || current.appId !== "" || current.mapping !== "[]" || proposed !== undefined;
  const changed = current.enabled !== enabled || current.watch !== watch || current.initial !== initial ||
    current.appId !== appId || current.mapping !== mapping || (githubSourceExists && (current.eventEnabled !== true || current.sourceEnabled !== sourceEnabled
      || current.stockEnabled !== stockEnabled || current.stockCanary !== stockCanary));
  if (changed && (!proposed?.sourceControl || epoch <= current.epoch))
    throw new Error(`GitHub source authority changed; eventRuntime.githubSource.sourceControl.gateEpoch must exceed the live epoch ${current.epoch}. No deployment was started.`);
  if (!changed && epoch !== current.epoch)
    throw new Error(`GitHub source authority is unchanged; gateEpoch must remain at the live epoch ${current.epoch}. No deployment was started.`);
  if (watch && !enabled) throw new Error("GitHub watch control requires source control to be enabled. No deployment was started.");
  if (initial && !watch) throw new Error("GitHub initial reconciliation requires watch control. No deployment was started.");
}

/** Reads the exact Event Worker settings needed to qualify source authority epoch changes. */
export async function assertGitHubSourceEpoch(config: DeploymentConfig, offline: boolean, ports: GitHubSourceEpochPorts = {}): Promise<void> {
  if (offline || config.eventRuntime?.deploy !== true) return;
  const worker = config.workers.eventRuntime?.name;
  if (!worker || !/^[a-z0-9-]{1,63}$/.test(worker) || !/^[a-f0-9]{32}$/i.test(config.accountId))
    throw new Error("GitHub source epoch preflight could not identify the Event Worker. No deployment was started.");
  const unavailable = () => new Error("GitHub source epoch preflight could not verify live Worker settings. No deployment was started.");
  const headers = deploymentAuthHeaders(unavailable, ports.authCommand);
  const url = `https://api.cloudflare.com/client/v4/accounts/${config.accountId}/workers/scripts/${worker}/settings`;
  let response: Response;
  let bytes: Uint8Array;
  try {
    response = await (ports.fetch ?? fetch)(url, { headers, redirect: "error", signal: AbortSignal.timeout(30_000) });
    const reader = response.body?.getReader(); if (!reader) throw unavailable();
    const chunks: Uint8Array[] = []; let size = 0;
    try { for (;;) { const item = await reader.read(); if (item.done) break; size += item.value.byteLength; if (size > 65_536) { await reader.cancel(); throw unavailable(); } chunks.push(item.value); } }
    finally { reader.releaseLock(); }
    bytes = new Uint8Array(size); let offset = 0; for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  } catch { throw unavailable(); }
  let envelope: any;
  try { envelope = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes)); } catch { throw unavailable(); }
  if (response.status === 404 && envelope?.success === false && Array.isArray(envelope.errors) && envelope.errors.length === 1 && envelope.errors[0]?.code === 10007) {
    validateGitHubSourceEpoch({ eventEnabled: false, sourceEnabled: false, enabled: false, epoch: 0, watch: false, initial: false, appId: "", mapping: "[]", stockEnabled: false, stockCanary: "" }, config); return;
  }
  if (!response.ok || envelope?.success !== true || !envelope.result || typeof envelope.result !== "object" || Array.isArray(envelope.result) || !Array.isArray(envelope.result.bindings)) throw unavailable();
  const vars = new Map<string, string>();
  for (const binding of envelope.result.bindings) {
    if (!binding || typeof binding !== "object" || typeof binding.name !== "string" || !binding.name || vars.has(binding.name)) throw unavailable();
    if (["EVENT_ENABLED", "EVENT_GITHUB_SOURCE_CONTROL_ENABLED", "EVENT_GITHUB_SOURCE_GATE_EPOCH", "EVENT_GITHUB_WATCH_CONTROL_ENABLED", "EVENT_GITHUB_INITIAL_RECONCILIATION_ENABLED", "EVENT_GITHUB_ENABLED", "GITHUB_APP_ID", "GITHUB_SOURCE_MAP", "EVENT_ASSIGNED_STOCK_ENABLED", "EVENT_ASSIGNED_STOCK_CANARY"].includes(binding.name)) {
      if (binding.type !== "plain_text" || typeof binding.text !== "string") throw unavailable();
      vars.set(binding.name, binding.text);
    }
  }
  const flag = (name: string): boolean => { const value = vars.get(name); if (value === undefined || value === "false") return false; if (value === "true") return true; throw unavailable(); };
  const eventEnabled = flag("EVENT_ENABLED");
  const enabled = flag("EVENT_GITHUB_SOURCE_CONTROL_ENABLED");
  const rawEpoch = vars.get("EVENT_GITHUB_SOURCE_GATE_EPOCH");
  const epoch = rawEpoch === undefined && !enabled ? 0 : rawEpoch && /^(0|[1-9][0-9]*)$/.test(rawEpoch) && Number.isSafeInteger(Number(rawEpoch)) ? Number(rawEpoch) : NaN;
  if (!Number.isSafeInteger(epoch) || epoch < 0 || (enabled && epoch < 1)) throw unavailable();
  const sourceEnabled = flag("EVENT_GITHUB_ENABLED");
  const appId = vars.get("GITHUB_APP_ID") ?? "";
  const rawMapping = vars.get("GITHUB_SOURCE_MAP") ?? "[]";
  let mapping: string;
  try {
    if (rawMapping.length > 32_768) throw unavailable();
    const parsed = JSON.parse(rawMapping);
    const deactivated = !eventEnabled && !sourceEnabled;
    if (!Array.isArray(parsed) || parsed.length > 64 || (sourceEnabled && parsed.length === 0) || (!sourceEnabled && !deactivated && parsed.length !== 0)) throw unavailable();
    const identities = new Set<string>();
    for (const item of parsed) {
      validateGitHubSourceMapping(item, () => { throw unavailable(); });
      const identity = JSON.stringify([item.principal, item.agent, item.repositoryId]);
      if (identities.has(identity)) throw unavailable();
      identities.add(identity);
    }
    mapping = JSON.stringify(parsed);
  } catch { throw unavailable(); }
  const deactivated = !eventEnabled && !sourceEnabled;
  if ((!deactivated && sourceEnabled !== Boolean(appId)) || (deactivated && Boolean(appId) !== (mapping !== "[]")) ||
      (appId !== "" && !/^[1-9][0-9]{0,127}$/.test(appId)) || (sourceEnabled && mapping === "[]")) throw unavailable();
  const watch = flag("EVENT_GITHUB_WATCH_CONTROL_ENABLED"), initial = flag("EVENT_GITHUB_INITIAL_RECONCILIATION_ENABLED");
  if ((!eventEnabled && sourceEnabled) || (eventEnabled && ((enabled && !sourceEnabled) || (watch && !enabled) || (initial && !watch)))) throw unavailable();
  const stockEnabled = flag("EVENT_ASSIGNED_STOCK_ENABLED");
  const rawStockCanary = vars.get("EVENT_ASSIGNED_STOCK_CANARY") ?? "";
  let stockCanary = "";
  try {
    if (stockEnabled) {
      const candidate = JSON.parse(rawStockCanary);
      if (!NativeAdmissionCanarySchema.safeParse(candidate).success) throw unavailable();
      stockCanary = JSON.stringify(candidate);
    } else if (rawStockCanary !== "") throw unavailable();
  } catch { throw unavailable(); }
  validateGitHubSourceEpoch({ eventEnabled, sourceEnabled, enabled, epoch, watch, initial, appId, mapping, stockEnabled, stockCanary }, config);
}

/** Disabled placeholders are permitted only when no existing runtime needs ACK proof verification. */
function eventAuthoritySettings(config: DeploymentConfig): { host: string; audience: string } | undefined {
  const settings = config.eventRuntime;
  if (!settings) return undefined;
  try {
    const access = parseAccessConfig({ ...settings.access, allowedEmails: [] });
    if (typeof settings.hostname === "string" && isValidHostname(settings.hostname) && !/<[^>]+>/.test(access.audience) && access.issuer === config.messaging?.access.issuer)
      return { host: settings.hostname, audience: access.audience };
  } catch { /* An unconfigured disabled block may contain placeholders. */ }
  return undefined;
}

/** Authenticate through Wrangler, including its normal interactive OAuth login. */
export async function readEventQueueRetention(config: DeploymentConfig, offline: boolean, ports: Pick<EventRuntimeDeactivationPorts, "authCommand" | "fetch"> = {}) {
  if (offline || config.eventRuntime?.deploy !== true) return undefined;
  const unavailable = () => new Error("Event queue inspection authentication unavailable; log in with Wrangler or configure a Cloudflare API token. No deployment was started.");
  const headers = deploymentAuthHeaders(unavailable, ports.authCommand);
  const authorization = headers.Authorization;
  // This fixed API client accepts bearer tokens, not legacy email/global-key auth.
  if (!authorization?.startsWith("Bearer ")) throw unavailable();
  const client = createCloudflareApiClient(config.accountId, authorization.slice("Bearer ".length), { fetch: ports.fetch });
  return [
    await assertEventQueueRetention(client, config.eventRuntime.queues.delivery),
    await assertEventQueueRetention(client, config.eventRuntime.queues.deadLetter),
  ];
}

/** Disable existing event code without uploading code, migrating SQLite, or changing queues. */
export async function deactivateEventRuntime(config: DeploymentConfig, offline: boolean, ports: EventRuntimeDeactivationPorts = {}): Promise<void> {
  if (offline || config.eventRuntime?.deploy !== false) return;
  const worker = config.workers.eventRuntime?.name;
  const record = ports.record;
  const finish = (status: "absent" | "disabled" | "already_disabled" | "failed" | "unverified") => {
    if (record) { record.status = status; record.checkedAt = new Date().toISOString(); }
  };
  const unavailable = () => new Error("Event runtime deactivation could not be verified; no subsequent Worker was deployed. Retain the existing Worker and retry.");
  let mutationAttempted = false;
  try {
    if (typeof worker !== "string" || !/^[a-z0-9-]{1,63}$/.test(worker) || !/^[a-f0-9]{32}$/i.test(config.accountId)) throw unavailable();
    const headers = deploymentAuthHeaders(unavailable, ports.authCommand);
    const url = `https://api.cloudflare.com/client/v4/accounts/${config.accountId}/workers/scripts/${worker}/settings`;
    const readResponse = async (target: string, init: RequestInit = {}) => {
      const response = await (ports.fetch ?? fetch)(target, { ...init, headers, redirect: "error", signal: AbortSignal.timeout(30_000) });
      const reader = response.body?.getReader(); if (!reader) throw unavailable();
      const chunks: Uint8Array[] = []; let size = 0;
      try {
        for (;;) {
          const item = await reader.read(); if (item.done) break;
          size += item.value.byteLength;
          if (size > 65_536) { await reader.cancel(); throw unavailable(); }
          chunks.push(item.value);
        }
      } finally { reader.releaseLock(); }
      const bytes = new Uint8Array(size); let offset = 0;
      for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
      return { response, bytes };
    };
    const request = async (init: RequestInit = {}, target = url, array = false): Promise<Record<string, unknown> | null> => {
      const { response, bytes } = await readResponse(target, init);
      const envelope = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
      if (!init.method && response.status === 404 && envelope?.success === false && Array.isArray(envelope.errors) && envelope.errors.length === 1 && envelope.errors[0]?.code === 10007) return null;
      if (!response.ok || envelope?.success !== true || !envelope.result || typeof envelope.result !== "object" || (!array && Array.isArray(envelope.result))) throw unavailable();
      return envelope.result;
    };
    const bindings = (settings: Record<string, unknown>) => {
      if (!Array.isArray(settings.bindings)) throw unavailable();
      const names = new Set<string>();
      for (const binding of settings.bindings) {
        if (!binding || typeof binding !== "object" || typeof binding.name !== "string" || !binding.name || typeof binding.type !== "string" || !binding.type || names.has(binding.name)) throw unavailable();
        names.add(binding.name);
      }
      return settings.bindings as Array<Record<string, unknown> & { name: string; type: string }>;
    };
    const before = await request();
    if (before === null) { finish("absent"); return; }
    const authority = eventAuthoritySettings(config);
    if (!authority) throw unavailable();
    const original = bindings(before);
    // The retained Worker verifies ACKs with these inherited values. Messaging
    // must receive the same proof configuration, not merely valid new values.
    for (const [name, text] of Object.entries({ EVENT_HOST: authority.host, ACCESS_EVENT_AUD: authority.audience, ACCESS_ISSUER: config.messaging!.access.issuer })) {
      const binding = original.find(candidate => candidate.name === name);
      if (binding?.type !== "plain_text" || binding.text !== text) throw unavailable();
    }
    const service = original.find(binding => binding.name === "MESSAGE_AUTHORITY");
    if (service?.type !== "service" || service.service !== config.workers.messaging?.name ||
        !config.workers.messaging?.name || service.entrypoint !== "EventAuthority" ||
        (service.environment !== undefined && service.environment !== "production")) throw unavailable();
    const foundationNames = ["ACCESS_EVENT_AUD", "ACCESS_ISSUER", "EVENT_HOST", "MESSAGE_AUTHORITY"];
    const names = original.map(binding => binding.name).toSorted();
    const flag = original.find(binding => binding.name === "EVENT_ENABLED");
    const foundationCandidate = isDeepStrictEqual(names, foundationNames) ||
      (flag?.type === "plain_text" && flag.text === "false" && isDeepStrictEqual(names, [...foundationNames, "EVENT_ENABLED"].toSorted()));
    if (foundationCandidate) {
      // e595a593 PR1 compiled with its locked Wrangler 4.147.0: one 503-only
      // module. A missing DO alone never proves this was the inert foundation.
      const scriptUrl = url.slice(0, -"/settings".length);
      const readFoundationVersion = async () => {
        const deployments = await request({}, `${scriptUrl}/deployments`);
        const versions = await request({}, `${scriptUrl}/versions`);
        const active = Array.isArray(deployments?.deployments) ? deployments.deployments[0]?.versions : undefined;
        const latest = Array.isArray(versions?.items) ? versions.items[0]?.id : undefined;
        // Both lists are newest first. Content cannot prove a foundation while
        // another version serves traffic or a different version is staged.
        if (!Array.isArray(active) || active.length !== 1 || active[0]?.percentage !== 100 ||
            typeof latest !== "string" || !latest || active[0]?.version_id !== latest) throw unavailable();
        return latest;
      };
      const version = await readFoundationVersion();
      const { response, bytes } = await readResponse(`${scriptUrl}/content/v2`);
      if (!response.ok || !response.headers.get("content-type")?.startsWith("multipart/form-data") || response.headers.get("cf-entrypoint") !== "index.js") throw unavailable();
      const form = await new Response(bytes, { headers: response.headers }).formData();
      const modules = [...form.entries()];
      if (modules.length !== 1 || modules[0]![0] !== "index.js" || typeof modules[0]![1] === "string") throw unavailable();
      const module = modules[0]![1] as File;
      if (createHash("sha256").update(new Uint8Array(await module.arrayBuffer())).digest("hex") !== "37399102477edd1485ee515e0ff1f752595d802dee975219fde11672d4fa0653") throw unavailable();
      const environmentUrl = `https://api.cloudflare.com/client/v4/accounts/${config.accountId}/workers/services/${worker}/environments/production`;
      const metadata = await request({}, environmentUrl);
      const script = metadata?.script as Record<string, unknown> | undefined;
      if (!script || typeof script !== "object" || Array.isArray(script) || (script.migration_tag !== undefined && script.migration_tag !== null && script.migration_tag !== "")) throw unavailable();
      const routes = await request({}, `${environmentUrl}/routes?show_zonename=true`, true);
      const domains = await request({}, `https://api.cloudflare.com/client/v4/accounts/${config.accountId}/workers/domains/records?page=0&per_page=5&service=${worker}&environment=production`, true);
      const subdomain = await request({}, `${environmentUrl}/subdomain`);
      if (!Array.isArray(routes) || routes.length !== 0 || !Array.isArray(domains) || domains.length !== 0 || subdomain?.enabled !== false || subdomain.previews_enabled !== false) throw unavailable();
      if (await readFoundationVersion() !== version) throw unavailable();
    } else {
      // runtimeConfigured rejects an Event/UI audience collision even for ACKs.
      // UI is optional, but a present binding must retain a string audience.
      const uiAudience = original.find(binding => binding.name === "ACCESS_UI_AUD");
      if (uiAudience && (uiAudience.type !== "plain_text" || typeof uiAudience.text !== "string" || uiAudience.text === authority.audience)) throw unavailable();
      for (const [name, className] of [["OWNER_REGISTRY", "OwnerRegistry"], ["AGENT_COORDINATOR", "AgentCoordinator"]]) {
        const binding = original.find(candidate => candidate.name === name);
        if (binding?.type !== "durable_object_namespace" || binding.class_name !== className ||
            typeof binding.namespace_id !== "string" || !/^[a-f0-9]{32}$/i.test(binding.namespace_id) ||
            (binding.script_name !== undefined && binding.script_name !== worker) ||
            (binding.environment !== undefined && binding.environment !== "production") ||
            binding.dispatch_namespace !== undefined) throw unavailable();
      }
    }
    const assertAckRoute = async () => {
      const domains = await request({}, `https://api.cloudflare.com/client/v4/accounts/${config.accountId}/workers/domains?hostname=${encodeURIComponent(authority.host)}`, true);
      if (!Array.isArray(domains) || domains.length !== 1 || domains[0]?.hostname !== authority.host ||
          domains[0]?.service !== worker || domains[0]?.environment !== "production" || domains[0]?.enabled === false) throw unavailable();
    };
    if (!foundationCandidate) await assertAckRoute();
    if (record) record.bindingNames = original.map(binding => binding.name).toSorted();
    const githubFlag = original.find(binding => binding.name === "EVENT_GITHUB_ENABLED");
    if (flag?.type === "plain_text" && flag.text === "false" &&
        (!githubFlag || (githubFlag.type === "plain_text" && githubFlag.text === "false"))) { finish("already_disabled"); return; }
    const disabledNames = ["EVENT_ENABLED", ...(githubFlag ? ["EVENT_GITHUB_ENABLED"] : [])];
    const disabledFlags = disabledNames.map(name => ({ name, type: "plain_text", text: "false" }));
    // Native inherit preserves opaque secrets and the existing Durable Object namespace.
    // PATCH preserves omitted settings, except annotations. Copy only their two
    // mutable values; never replay migrations or response-only reconciliation data.
    const annotations: Record<string, unknown> = {};
    if (before.annotations && typeof before.annotations === "object" && !Array.isArray(before.annotations)) {
      for (const key of ["workers/message", "workers/tag"]) {
        const value = (before.annotations as Record<string, unknown>)[key];
        if (value !== undefined) annotations[key] = value;
      }
    }
    const body = new FormData();
    body.set("settings", JSON.stringify({ annotations, bindings: [
      ...original.filter(binding => !disabledNames.includes(binding.name)).map(binding => ({ name: binding.name, type: "inherit" })),
      ...disabledFlags,
    ] }));
    mutationAttempted = true;
    finish("unverified");
    await request({ method: "PATCH", body });
    const after = await request();
    if (!after) throw unavailable();
    const observed = bindings(after);
    const expected = [...original.filter(binding => !disabledNames.includes(binding.name)), ...disabledFlags];
    const byName = (items: typeof observed) => items.toSorted((a, b) => a.name.localeCompare(b.name));
    if (!isDeepStrictEqual(byName(observed), byName(expected))) throw unavailable();
    for (const key of ["compatibility_date", "compatibility_flags", "cache_options", "limits", "logpush", "observability", "placement", "tags", "tail_consumers", "usage_model", "exports"]) {
      if (before[key] !== undefined && !isDeepStrictEqual(before[key], after[key])) throw unavailable();
    }
    for (const [key, value] of Object.entries(annotations)) {
      if (!isDeepStrictEqual(value, (after.annotations as Record<string, unknown> | undefined)?.[key])) throw unavailable();
    }
    if (!foundationCandidate) await assertAckRoute();
    finish("disabled");
  } catch { finish(mutationAttempted ? "unverified" : "failed"); throw unavailable(); }
}

/** Current-platform retirement guard; no drain-proof API exists, so removal stays closed. */
export async function assertWorkflowRuntimeRetained(
  config: DeploymentConfig,
  offline: boolean,
  ports: {
    authCommand?: (command: string, args: string[], options: SpawnSyncOptionsWithStringEncoding) => { status: number | null; stdout: string };
    bootstrap?: boolean;
    fetch?: typeof fetch;
  } = {},
): Promise<void> {
  const operator = config.openApiOperator;
  // An omitted operator is not deployed/deleted by this CLI. Retaining runtime
  // requires no drain proof, even when every new-job routing selector is Actions.
  if (offline || operator?.enabled !== true || (operator.installations?.enabled === true && operator.installations.workflowRuntime === "deployed-v1")) return;
  const unavailable = () => new Error("Workflow runtime retirement inspection unavailable; retain installations.workflowRuntime deployed-v1. No deployment was started.");
  const retained = () => new Error("Previously deployed Workflow runtime cannot be removed: authenticated registry drain proof is unavailable. Retain installations.workflowRuntime deployed-v1, bindings, handlers and keys.");
  const worker = config.workers.openApiOperator?.name;
  if (!worker || !/^[a-z0-9-]{1,63}$/.test(worker) || !/^[a-f0-9]{32}$/i.test(config.accountId)) throw unavailable();
  const headers = deploymentAuthHeaders(unavailable, ports.authCommand);
  const read = async (path: string, workerSettings = false): Promise<Record<string, unknown> | null> => {
    try {
      const response = await (ports.fetch ?? fetch)(`https://api.cloudflare.com/client/v4/accounts/${config.accountId}${path}`, { headers, redirect: "error", signal: AbortSignal.timeout(30_000) });
      const reader = response.body?.getReader();
      if (!reader) throw unavailable();
      const chunks: Uint8Array[] = []; let size = 0;
      try {
        for (;;) {
          const item = await reader.read(); if (item.done) break;
          size += item.value.byteLength;
          if (size > 1024 * 1024) { await reader.cancel(); throw unavailable(); }
          chunks.push(item.value);
        }
      } finally { reader.releaseLock(); }
      const bytes = new Uint8Array(size); let offset = 0;
      for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
      const body: unknown = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
      if (!body || typeof body !== "object" || Array.isArray(body)) throw unavailable();
      const envelope = body as Record<string, unknown>;
      // Only the documented missing-script code proves absence; generic 404s do not.
      if (workerSettings && response.status === 404 && envelope.success === false && Array.isArray(envelope.errors) && envelope.errors.length === 1 && envelope.errors[0]?.code === 10007) return null;
      if (!response.ok || envelope.success !== true) throw unavailable();
      return envelope;
    } catch { throw unavailable(); }
  };
  const settings = await read(`/workers/scripts/${worker}/settings`, true);
  if (settings && ports.bootstrap) throw new Error("Existing operator cannot deploy without runtime through file bootstrap; use the registry deployment lease path.");
  if (settings) {
    const result = settings.result as { bindings?: unknown } | null;
    if (!result || !Array.isArray(result.bindings)) throw unavailable();
    for (const binding of result.bindings) {
      if (!binding || typeof binding !== "object" || typeof binding.type !== "string" || typeof binding.name !== "string") throw unavailable();
      if (binding.type === "workflow") throw retained();
    }
  }
  // Settings alone miss a Workflow still owned by an older deployed version.
  // Bound the complete account inventory; a truncated/unstable list cannot prove absence.
  let total: number | undefined; let seen = 0; const names = new Set<string>();
  for (let page = 1; page <= 100; page++) {
    const envelope = (await read(`/workflows?page=${page}&per_page=100`))!;
    const info = envelope.result_info as Record<string, unknown> | undefined;
    if (!info || (info.page !== undefined && info.page !== page) || info.per_page !== 100 || !Number.isSafeInteger(info.total_count) || (info.total_count as number) < 0 || (info.total_count as number) > 10_000 || !Array.isArray(envelope.result)) throw unavailable();
    if (total !== undefined && total !== info.total_count) throw unavailable();
    total = info.total_count as number;
    const pages = Math.max(1, Math.ceil(total / 100));
    if ((info.total_pages !== undefined && info.total_pages !== pages && !(total === 0 && info.total_pages === 0)) || envelope.result.length !== Math.min(100, total - seen)) throw unavailable();
    for (const workflow of envelope.result) {
      if (!workflow || typeof workflow !== "object" || typeof workflow.name !== "string" || !workflow.name || typeof workflow.script_name !== "string" || !workflow.script_name || typeof workflow.class_name !== "string" || !workflow.class_name || names.has(workflow.name)) throw unavailable();
      names.add(workflow.name);
      if (workflow.script_name === worker || workflow.name === `${worker}-publication-v1` || workflow.name === `${worker}-inspection-v1`) throw retained();
    }
    seen += envelope.result.length;
    if (page === pages && seen === total) {
      return;
    }
  }
  throw unavailable();
}

async function main(): Promise<void> {
  // Needs only gh: no config, no deploy secret, no lease. `pnpm run deploy` (deploy-entry.ts) also
  // dispatches it before this module loads, so it runs without the submodule too.
  const publishIndex = process.argv.indexOf("--publish-record");
  if (publishIndex >= 0) {
    if (!(await publishRecordCommand(process.argv.slice(publishIndex + 1), defaultGhPort))) process.exitCode = 1;
    return;
  }
  requireSubmodule();
  const reconcileIndex = process.argv.indexOf("--reconcile-mutation");
  if (reconcileIndex >= 0) {
    await reconcileCommand(process.argv.slice(reconcileIndex + 1));
    return;
  }
  const config = await readDeployment(join(root, "deployment.jsonc"));
  const bases = await readBases(config);
  if (process.argv.includes("--snapshot")) {
    await snapshotCommand(config, bases);
    return;
  }
  if (isBootstrapFileMode(config)) {
    await assertWorkflowRuntimeRetained(config, process.argv.includes("--check") || process.argv.includes("--dry-run"), { bootstrap: true });
    await runDeployment(config, bases, config.openApis ?? [], undefined,
      async (deployment, _generated, dryRun, deploy, deactivation) => {
        await deployWorkers(deployment, dryRun, deploy, deployment.openApis ?? [], deactivation);
      });
    return;
  }
  await runRegistryDeployment(config, bases);
}

/** The CLI: `main`, with failures reported in one line. Run by deploy-entry.ts, or directly. */
export async function cli(): Promise<void> {
  try {
    await main();
  } catch (error) {
    // One line, no stack: every failure here is a config or subprocess problem, not a script bug.
    console.error(`\nDeploy failed. ${(error as Error).message}`);
    process.exitCode = 1;
  }
}

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(resolve(process.argv[1])).href
) {
  await cli();
}
