import { Hono, type Context, type Next } from "hono";
import { GITHUB_WEBHOOK_PATH, githubWebhookFetch, githubWebhookRefusal } from './github/route';
import type { GitHubHostEnvironment } from './github/host';
import { GITHUB_MATERIAL_READ_PATH, GitHubMaterialReadRequestSchema, GitHubMaterialReadResultSchema, materialPageMatches } from './github/material-read-contract';
import { GITHUB_SOURCE_REFERENCE_ISSUE_PATH, GITHUB_SOURCE_REFERENCE_RESOLVE_PATH, SourceReferenceIssueRequestSchema,
  SourceReferenceResolveRequestSchema, SourceReferenceIssueResultSchema, SourceReferenceResolveResultSchema,
  sourceReferenceIssueMatches, sourceReferenceResolveMatches } from './github/source-reference-contract';
import { GitHubSourceReadRequestSchema, GitHubSourceReadResultSchema } from './github/readback-contract';
import { GITHUB_EVENT_READ_PATH, GitHubEventReadRequestSchema, GitHubEventReadResultSchema } from './github/event-read-contract';
import { requireAssignedStockProfile, requireNativeAdmissionCanary } from "./native-admission-gate.ts";
import { z } from "zod";
import { admitCoordinator } from "./coordinator-admission.ts";
import { authenticateAgent, credentialsFromGateway, credentialsFromRequest } from "./authority-client.ts";
import type { EventAuthorityCredentialsV1 } from "gatekeeper-messaging/src/event-authority-contract";
import { ClaimRequestSchema, CompleteEnrollmentSchema, coordinatorName, DispatchClaimResultSchema, DispatchNoStartRequestSchema, DispatchNoStartResultSchema, EventApiError, NodeProofSchema, parseApiJson, readApiBody, RuntimeRequestSchema, runtimeConfigured, type EventApiEnvironment } from "./contracts.ts";
import { ownerRegistryName } from "./registry.ts";
import { EventProtocolError, parseEventObservationAck } from "./protocol.ts";
import { parseMessagingObservationAckV2 } from "./messaging/protocol-v2.ts";
import { EventRequestDeadline } from "./request-deadline.ts";
import {
  NativeRuntimeAttachRequestSchema, NativeRuntimeAttachResponseSchema,
  NativeRuntimeChallengeRequestSchema, NativeRuntimeChallengeResponseSchema,
  NativeRuntimeRenewRequestSchema, NativeRuntimeRenewResponseSchema,
  NativeRuntimeTransferRequestSchema, NativeRuntimeTransferResponseSchema,
  NativeRuntimeStatusRequestSchema, NativeRuntimeStatusResponseSchema,
} from "./native-admission-contract.ts";
import { AssignedStockRuntimeRequestSchema, AssignedStockRuntimeResponseSchema } from "./assigned-stock-contract.ts";
import { AssignedStockWatchRequestSchema, AssignedStockWatchResponseSchema } from './assigned-stock-watch-contract';

const agentPaths = [GITHUB_SOURCE_REFERENCE_ISSUE_PATH, GITHUB_SOURCE_REFERENCE_RESOLVE_PATH, GITHUB_MATERIAL_READ_PATH, GITHUB_EVENT_READ_PATH, "/v1/github/source/read", "/v1/nodes/complete", "/v1/runtimes/status", "/v1/runtimes/assigned-stock", "/v1/runtimes/challenge", "/v1/runtimes/attach", "/v1/runtimes/renew", "/v1/runtimes/transfer", "/v1/dispatch/claim", "/v1/dispatch/settle-no-start", "/v1/ack"];
/** The routes Event Gateway's CloudClient calls. Source references are not among them, so NodeEdge serves none. */
const nodeEdgePaths = agentPaths.filter((path) => path !== GITHUB_SOURCE_REFERENCE_ISSUE_PATH && path !== GITHUB_SOURCE_REFERENCE_RESOLVE_PATH);
const nativeRuntimeCommitPaths = new Set(["/v1/runtimes/attach", "/v1/runtimes/renew", "/v1/runtimes/transfer"]);
const response = (value: unknown, status = 200): Response => Response.json(value, { status, headers: { "cache-control": "no-store" } });

type AppEnv = { Bindings: EventApiEnvironment & GitHubHostEnvironment };
type AppContext = Context<AppEnv>;

/** Matched on the raw pathname, as the router always has: a percent-escaped path reaches no route. */
const rawPath = (request: Request) => new URL(request.url).pathname;

// Hono middleware, not Express: a rejected promise from an async handler or middleware reaches `app.onError`, which rethrows it to fetch, so oxc's
// Express-specific rule does not apply here.
/* oxlint-disable oxc/no-async-endpoint-handlers */

// Registered first, so the runtime gate below never sees the webhook: GitHub is answered whether or not event admission is on.
async function githubWebhookGate(c: AppContext, next: Next): Promise<Response | void> {
  const refusal = githubWebhookRefusal(c.req.raw, c.env);
  if (refusal) return refusal;
  if (c.req.method !== "POST") return new Response(null, { status: 405 });
  await next();
}
const githubWebhook = (c: AppContext) => githubWebhookFetch(c.req.raw, c.env);

async function runtimeGate(c: AppContext, next: Next): Promise<Response | void> {
  // A claim retry may carry durable, provably unissued stock work that must be
  // compensated during rollback. The coordinator still requires current auth and
  // node proof, and refuses every new permit while event admission is disabled.
  const acknowledgmentOnly = c.req.method === "POST" && ["/v1/ack", "/v1/dispatch/settle-no-start", "/v1/dispatch/claim"].includes(rawPath(c.req.raw));
  if (!runtimeConfigured(c.env, acknowledgmentOnly)) return response({ error: "runtime_disabled" }, 503);
  await next();
}

async function hostGate(c: AppContext, next: Next): Promise<Response | void> {
  const url = new URL(c.req.url);
  if (url.protocol !== "https:" || url.host !== c.env.EVENT_HOST || url.search) return response({ error: "not_found" }, 404);
  await next();
}

/** A known path with another method is a 405 before its credentials or body are read. */
async function postOnly(c: AppContext, next: Next): Promise<Response | void> {
  if (c.req.method !== "POST") return response({ error: "method_not_allowed" }, 405);
  await next();
}

const serveEvent = (c: AppContext) => eventRoute(c.req.raw, c.env, credentialsFromRequest);

/** The fetch routing. Middleware runs in registration order: the webhook, then the runtime and host gates, then each route's method check. */
export const app = new Hono<AppEnv>({ getPath: rawPath, strict: true });
app.use(GITHUB_WEBHOOK_PATH, githubWebhookGate);
app.post(GITHUB_WEBHOOK_PATH, githubWebhook);
app.use("*", runtimeGate);
app.use("*", hostGate);
for (const path of agentPaths) {
  app.use(path, postOnly);
  app.post(path, serveEvent);
}
app.notFound((c) => response({ error: "not_found" }, 404));
// An error that escapes a route rejects fetch, as it always has, rather than becoming Hono's text 500.
app.onError((error) => { throw error; });

export async function eventFetch(request: Request, env: EventApiEnvironment): Promise<Response> {
  return app.fetch(request, env);
}

/**
 * NodeEdge's routing: the node routes behind the same runtime, host and method gates, with the person Gateway Forward
 * identified (events-edge) in place of an Access assertion. Built per call, so the identity is this request's alone.
 */
export async function nodeEdgeFetch(request: Request, env: EventApiEnvironment, email: string): Promise<Response> {
  const edge = new Hono<AppEnv>({ getPath: rawPath, strict: true });
  edge.use("*", runtimeGate);
  edge.use("*", hostGate);
  for (const path of nodeEdgePaths) {
    edge.use(path, postOnly);
    edge.post(path, (c) => eventRoute(c.req.raw, c.env, (raw) => credentialsFromGateway(raw, email)));
  }
  edge.notFound(() => response({ error: "not_found" }, 404));
  edge.onError((error) => { throw error; });
  return edge.fetch(request, env);
}

async function eventRoute(request: Request, env: EventApiEnvironment, credentialsOf: (request: Request) => EventAuthorityCredentialsV1): Promise<Response> {
  const url = new URL(request.url);
  const deadline = new EventRequestDeadline();
  try {
    if ([GITHUB_SOURCE_REFERENCE_ISSUE_PATH, GITHUB_SOURCE_REFERENCE_RESOLVE_PATH].includes(url.pathname)
      && env.EVENT_GITHUB_SOURCE_REFERENCES_ENABLED !== 'true') return response({ error: 'runtime_disabled' }, 503);
    const credentials = credentialsOf(request);
    const identity = await authenticateAgent(env.MESSAGE_AUTHORITY, credentials, deadline);
    const raw = await readApiBody(request);
    const payload = parseApiJson(raw);
    const registry = env.OWNER_REGISTRY.getByName(ownerRegistryName(identity.principal));

    if (url.pathname === "/v1/nodes/complete") {
      const completion = CompleteEnrollmentSchema.parse(payload);
      const current = await authenticateAgent(env.MESSAGE_AUTHORITY, credentials, deadline);
      if (current.principal !== identity.principal || current.agent !== identity.agent || current.keyThumbprint !== identity.keyThumbprint)
        throw new EventApiError("denied", 403);
      const node = await deadline.run(() => registry.completeEnrollment(completion));
      // The owner-approved challenge and node signature admit the node. This caller's
      // proof additionally selects its owner partition; it cannot change the challenge.
      return response({ nodeId: node.nodeId, generation: node.generation });
    }

    if (url.pathname === GITHUB_SOURCE_REFERENCE_ISSUE_PATH || url.pathname === GITHUB_SOURCE_REFERENCE_RESOLVE_PATH) {
      if (new TextEncoder().encode(raw).length > 4096) throw new EventApiError('request_too_large', 413);
      const issue = url.pathname === GITHUB_SOURCE_REFERENCE_ISSUE_PATH;
      const input = issue ? SourceReferenceIssueRequestSchema.parse(payload) : SourceReferenceResolveRequestSchema.parse(payload);
      const proofHeader = request.headers.get('x-event-node-proof');
      if (!proofHeader || proofHeader.length > 2048) throw new EventApiError('node_proof_required', 403);
      const proof = NodeProofSchema.parse(parseApiJson(proofHeader));
      const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(raw)));
      const bodySha256 = [...digest].map(byte => byte.toString(16).padStart(2, '0')).join('');
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const scope = { ...identity, proof, proofBinding: { audience: `https://${env.EVENT_HOST}`, method: request.method, path: url.pathname, bodySha256 },
        credentials, bodySha256, nodeId: proof.nodeId, nodeGeneration: proof.nodeGeneration };
      if ('material' in input) {
        const result = SourceReferenceIssueResultSchema.safeParse(await deadline.run<unknown>(() => coordinator.issueGitHubSourceReference(raw, scope)));
        if (env.EVENT_GITHUB_SOURCE_REFERENCES_ENABLED !== 'true') throw new EventApiError('runtime_disabled', 503);
        if (!result.success || !sourceReferenceIssueMatches(input, result.data)) throw new EventApiError('unavailable', 503);
        return response(result.data);
      }
      const result = SourceReferenceResolveResultSchema.safeParse(await deadline.run<unknown>(() => coordinator.resolveGitHubSourceReference(raw, scope)));
      if (env.EVENT_GITHUB_SOURCE_REFERENCES_ENABLED !== 'true') throw new EventApiError('runtime_disabled', 503);
      if (!result.success || !sourceReferenceResolveMatches(input, result.data)) throw new EventApiError('unavailable', 503);
      return response(result.data);
    }

    if (url.pathname === GITHUB_MATERIAL_READ_PATH) {
      if (new TextEncoder().encode(raw).length > 4096) throw new EventApiError("request_too_large", 413);
      const input = GitHubMaterialReadRequestSchema.parse(payload);
      const proofHeader = request.headers.get("x-event-node-proof");
      if (!proofHeader || proofHeader.length > 2048) throw new EventApiError("node_proof_required", 403);
      const proof = NodeProofSchema.parse(parseApiJson(proofHeader));
      const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)));
      const bodySha256 = [...digest].map(byte => byte.toString(16).padStart(2, "0")).join("");
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const parsed = GitHubMaterialReadResultSchema.safeParse(await deadline.run<unknown>(() => coordinator.readGitHubMaterial(raw, {
        ...identity, proof, proofBinding: { audience: `https://${env.EVENT_HOST}`, method: request.method, path: url.pathname, bodySha256 },
        credentials, bodySha256, nodeId: proof.nodeId, nodeGeneration: proof.nodeGeneration,
      })));
      if (!parsed.success || !materialPageMatches(input, parsed.data)) throw new EventApiError("unavailable", 503);
      return response(parsed.data);
    }

    if (url.pathname === GITHUB_EVENT_READ_PATH) {
      if (new TextEncoder().encode(raw).length > 4096) throw new EventApiError("request_too_large", 413);
      GitHubEventReadRequestSchema.parse(payload);
      const proofHeader = request.headers.get("x-event-node-proof");
      if (!proofHeader || proofHeader.length > 2048) throw new EventApiError("node_proof_required", 403);
      const proof = NodeProofSchema.parse(parseApiJson(proofHeader));
      const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)));
      const bodySha256 = [...digest].map(byte => byte.toString(16).padStart(2, "0")).join("");
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const parsed = GitHubEventReadResultSchema.safeParse(await deadline.run<unknown>(() => coordinator.readGitHubEvent(raw, {
        ...identity, proof, proofBinding: { audience: `https://${env.EVENT_HOST}`, method: request.method, path: url.pathname, bodySha256 },
        credentials, bodySha256, nodeId: proof.nodeId, nodeGeneration: proof.nodeGeneration,
      })));
      if (!parsed.success || new TextEncoder().encode(JSON.stringify(parsed.data)).length > 4096) throw new EventApiError("unavailable", 503);
      return response(parsed.data);
    }

    if (url.pathname === "/v1/github/source/read") {
      const input = GitHubSourceReadRequestSchema.parse(payload);
      if (new TextEncoder().encode(raw).length > 4096) throw new EventApiError("request_too_large", 413);
      const proofHeader = request.headers.get("x-event-node-proof");
      if (!proofHeader || proofHeader.length > 2048) throw new EventApiError("node_proof_required", 403);
      const proof = NodeProofSchema.parse(parseApiJson(proofHeader));
      const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)));
      const bodySha256 = [...digest].map(byte => byte.toString(16).padStart(2, "0")).join("");
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const parsed = GitHubSourceReadResultSchema.safeParse(await deadline.run<unknown>(() => coordinator.readGitHubSource(raw, {
        ...identity, proof, proofBinding: { audience: `https://${env.EVENT_HOST}`, method: request.method, path: url.pathname, bodySha256 },
        credentials, bodySha256, nodeId: proof.nodeId, nodeGeneration: proof.nodeGeneration,
      })));
      if (!parsed.success) throw new EventApiError("unavailable", 503);
      const result = parsed.data;
      if (result.status === "ok" && (JSON.stringify(result.subject) !== JSON.stringify(input.subject)
        || result.requestedRange.fromVersion !== input.fromVersion || result.requestedRange.toVersion !== input.toVersion))
        throw new EventApiError("unavailable", 503);
      if (new TextEncoder().encode(JSON.stringify(result)).length > 8192) throw new EventApiError("unavailable", 503);
      return response(result);
    }

    if (url.pathname === "/v1/runtimes/status") {
      const input = NativeRuntimeStatusRequestSchema.parse(payload);
      requireNativeAdmissionCanary(env, identity);
      const proofHeader = request.headers.get("x-event-node-proof");
      if (!proofHeader || proofHeader.length > 2048) throw new EventApiError("node_proof_required", 403);
      const proof = NodeProofSchema.parse(parseApiJson(proofHeader));
      const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)));
      const bodySha256 = [...digest].map((byte) => byte.toString(16).padStart(2, "0")).join("");
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const result = NativeRuntimeStatusResponseSchema.safeParse(await deadline.run<unknown>(() => coordinator.runtimeStatus(raw, {
        principal: identity.principal, agent: identity.agent, keyThumbprint: identity.keyThumbprint,
        proof, proofBinding: { audience: `https://${env.EVENT_HOST}`, method: request.method, path: url.pathname, bodySha256 },
        credentials, bodySha256, nodeId: proof.nodeId, nodeGeneration: proof.nodeGeneration,
      })));
      if (!result.success || result.data.runtimeId !== input.runtimeId) throw new EventApiError("registry_unavailable", 503);
      return response(result.data);
    }

    if (url.pathname === "/v1/runtimes/assigned-stock") {
      const watchInput=AssignedStockWatchRequestSchema.safeParse(payload);
      if(watchInput.success){
        requireAssignedStockProfile(env,identity);
        if(new TextEncoder().encode(raw).length>4096)throw new EventApiError('request_too_large',413);
        const proofHeader=request.headers.get('x-event-node-proof');
        if(!proofHeader||proofHeader.length>2048)throw new EventApiError('node_proof_required',403);
        const proof=NodeProofSchema.parse(parseApiJson(proofHeader));
        const digest=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(raw)));
        const bodySha256=[...digest].map(byte=>byte.toString(16).padStart(2,'0')).join('');
        await admitCoordinator(env,identity.principal,identity.agent,deadline);
        const coordinator=env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal,identity.agent));
        const result=AssignedStockWatchResponseSchema.safeParse(await deadline.run<unknown>(()=>coordinator.assignedStockWatchLease(raw,{
          principal:identity.principal,agent:identity.agent,keyThumbprint:identity.keyThumbprint,proof,
          proofBinding:{audience:`https://${env.EVENT_HOST}`,method:request.method,path:url.pathname,bodySha256},
          credentials,bodySha256,nodeId:proof.nodeId,nodeGeneration:proof.nodeGeneration,
        })));
        if(!result.success||result.data.runtime.runtimeId!==watchInput.data.runtimeId
          ||result.data.runtime.runtimeProfile.conversationId!==watchInput.data.conversationId
          ||result.data.runtime.runtimeGeneration!==watchInput.data.expectedRuntimeGeneration
          ||result.data.runtime.attachmentGeneration!==watchInput.data.expectedAttachmentGeneration
          ||result.data.runtime.nodeId!==proof.nodeId||result.data.runtime.nodeGeneration!==proof.nodeGeneration
          ||(result.data.outcome.status==='committed'||result.data.outcome.status==='known')
            &&(result.data.outcome.watch.subject.repositoryId!==('subject'in watchInput.data?watchInput.data.subject.repositoryId:-1)
              ||result.data.outcome.watch.subject.prNumber!==('subject'in watchInput.data?watchInput.data.subject.prNumber:-1))
          ||(result.data.outcome.status==='committed'||result.data.outcome.status==='known'||result.data.outcome.status==='unresolved'||result.data.outcome.status==='conflict')
            &&result.data.outcome.operationId!==('operationId'in watchInput.data?watchInput.data.operationId:''))
          throw new EventApiError('registry_unavailable',503);
        if(new TextEncoder().encode(JSON.stringify(result.data)).length>6000)throw new EventApiError('registry_unavailable',503);
        return response(result.data);
      }
      const input = AssignedStockRuntimeRequestSchema.parse(payload);
      requireAssignedStockProfile(env, identity);
      const proofHeader = request.headers.get("x-event-node-proof");
      if (!proofHeader || proofHeader.length > 2048) throw new EventApiError("node_proof_required", 403);
      const proof = NodeProofSchema.parse(parseApiJson(proofHeader));
      const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)));
      const bodySha256 = [...digest].map(byte => byte.toString(16).padStart(2, "0")).join("");
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const result = AssignedStockRuntimeResponseSchema.safeParse(await deadline.run(() => coordinator.assignAssignedStockRuntime(raw, {
        principal: identity.principal, agent: identity.agent, keyThumbprint: identity.keyThumbprint,
        proof, proofBinding: { audience: `https://${env.EVENT_HOST}`, method: request.method, path: url.pathname, bodySha256 },
        credentials, bodySha256, nodeId: proof.nodeId, nodeGeneration: proof.nodeGeneration,
      })));
      if (!result.success || result.data.runtimeId !== input.runtimeId || result.data.runtimeProfile.conversationId !== input.conversationId
        || result.data.nodeId !== proof.nodeId || result.data.nodeGeneration !== proof.nodeGeneration
        || result.data.status !== (input.operation === "attach" ? "attached" : "renewed"))
        throw new EventApiError("registry_unavailable", 503);
      return response(result.data);
    }

    if (url.pathname === "/v1/runtimes/challenge") {
      const input = NativeRuntimeChallengeRequestSchema.parse(payload);
      requireNativeAdmissionCanary(env, identity);
      const proofHeader = request.headers.get("x-event-node-proof");
      if (!proofHeader || proofHeader.length > 2048) throw new EventApiError("node_proof_required", 403);
      const proof = NodeProofSchema.parse(parseApiJson(proofHeader));
      const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)));
      const bodySha256 = [...digest].map((byte) => byte.toString(16).padStart(2, "0")).join("");
      const nodeAuth = await deadline.run(async () => await registry.authenticateNode(proof, {
        audience: `https://${env.EVENT_HOST}`, method: request.method, path: url.pathname, bodySha256,
      }));
      if (nodeAuth.status !== "authorized" || !nodeAuth.node.agents.includes(identity.agent))
        throw new EventApiError("node_denied", 403);
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const currentNode = await deadline.run(async () => await registry.currentNode({ nodeId: nodeAuth.node.nodeId,
        agent: identity.agent, generation: nodeAuth.node.generation }));
      if (currentNode.status !== "authorized" || currentNode.node.nodeId !== nodeAuth.node.nodeId
        || currentNode.node.generation !== nodeAuth.node.generation || !currentNode.node.agents.includes(identity.agent))
        throw new EventApiError("node_denied", 403);
      const current = await authenticateAgent(env.MESSAGE_AUTHORITY, credentials, deadline);
      if (current.principal !== identity.principal || current.agent !== identity.agent || current.keyThumbprint !== identity.keyThumbprint)
        throw new EventApiError("denied", 403);
      requireNativeAdmissionCanary(env, current);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const result = NativeRuntimeChallengeResponseSchema.safeParse(await deadline.run(() => coordinator.createNativeRuntimeChallenge(input, {
        principal: identity.principal, agent: identity.agent, keyThumbprint: identity.keyThumbprint,
        nodeId: currentNode.node.nodeId, nodeGeneration: currentNode.node.generation,
      })));
      if (!result.success) throw new EventApiError("registry_unavailable", 503);
      return response(result.data);
    }

    if (nativeRuntimeCommitPaths.has(url.pathname)) {
      const operation = url.pathname === "/v1/runtimes/attach" ? "attach"
        : url.pathname === "/v1/runtimes/renew" ? "renew" : "transfer";
      const input = operation === "attach" ? NativeRuntimeAttachRequestSchema.parse(payload)
        : operation === "renew" ? NativeRuntimeRenewRequestSchema.parse(payload)
          : NativeRuntimeTransferRequestSchema.parse(payload);
      requireNativeAdmissionCanary(env, identity);
      const proofHeader = request.headers.get("x-event-node-proof");
      if (!proofHeader || proofHeader.length > 2048) throw new EventApiError("node_proof_required", 403);
      const proof = NodeProofSchema.parse(parseApiJson(proofHeader));
      const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)));
      const bodySha256 = [...digest].map((byte) => byte.toString(16).padStart(2, "0")).join("");
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const value = await deadline.run(() => coordinator.commitNativeRuntime(operation, raw, {
        principal: identity.principal, agent: identity.agent, keyThumbprint: identity.keyThumbprint,
        proof, proofBinding: { audience: `https://${env.EVENT_HOST}`, method: request.method, path: url.pathname, bodySha256 },
        credentials, bodySha256, nodeId: proof.nodeId, nodeGeneration: proof.nodeGeneration,
      }));
      const nativeBinding = input.nativeEvidence.witness && {
        clientId: input.nativeEvidence.witness.clientId, connectionId: input.nativeEvidence.witness.connectionId,
        backendPid: input.nativeEvidence.witness.backendPid, threadId: input.nativeEvidence.witness.threadId,
        generation: input.nativeEvidence.witness.generation, serverInstanceId: input.nativeEvidence.witness.serverInstanceId,
        serverGeneration: input.nativeEvidence.witness.serverGeneration,
      };
      const result = operation === "attach" ? NativeRuntimeAttachResponseSchema.safeParse(value)
        : operation === "renew" ? NativeRuntimeRenewResponseSchema.safeParse(value)
          : NativeRuntimeTransferResponseSchema.safeParse(value);
      const expectedRuntimeId = operation === "transfer" && "replacementRuntimeId" in input
        ? input.replacementRuntimeId : "runtimeId" in input ? input.runtimeId : "";
      if (!result.success || result.data.runtimeId !== expectedRuntimeId || result.data.nodeId !== proof.nodeId
        || result.data.nodeGeneration !== proof.nodeGeneration || JSON.stringify(result.data.nativeBinding) !== JSON.stringify(nativeBinding))
        throw new EventApiError("registry_unavailable", 503);
      if (operation === "transfer" && "sourceRuntimeId" in input
        && (result.data.status !== "transferred" || result.data.sourceRuntimeId !== input.sourceRuntimeId))
        throw new EventApiError("registry_unavailable", 503);
      return response(result.data);
    }

    const proofHeader = request.headers.get("x-event-node-proof");
    if (!proofHeader || proofHeader.length > 2048) throw new EventApiError("node_proof_required", 403);
    const proof = NodeProofSchema.parse(parseApiJson(proofHeader));
    const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)));
    const nodeAuth = await deadline.run(async () => await registry.authenticateNode(proof, {
      audience: `https://${env.EVENT_HOST}`, method: request.method, path: url.pathname,
      bodySha256: [...digest].map((byte) => byte.toString(16).padStart(2, "0")).join(""),
    }));
    if (nodeAuth.status !== "authorized" || !nodeAuth.node.agents.includes(identity.agent))
      throw new EventApiError("node_denied", 403);

    if (url.pathname === "/v1/runtimes/attach" || url.pathname === "/v1/runtimes/renew") {
      RuntimeRequestSchema.parse(payload);
      // A node signature is not evidence of the actual live native client. No public
      // route can mint qualification while that binding protocol remains unproved.
      return response({ error: "native_binding_unqualified" }, 409);
    }
    if (url.pathname === "/v1/dispatch/claim") {
      const input = ClaimRequestSchema.parse(payload);
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const result = DispatchClaimResultSchema.safeParse(await deadline.run(async () => await coordinator.claim(
        { ...input, nodeId: nodeAuth.node.nodeId, nodeGeneration: nodeAuth.node.generation }, credentials,
      )));
      if (!result.success) throw new EventApiError("invalid_dispatch_response", 503);
      if (result.data.status === "admitted") {
        const envelope = result.data.envelope;
        if (result.data.nodeId !== nodeAuth.node.nodeId || envelope.principal !== identity.principal || envelope.agent !== identity.agent ||
          envelope.deliveryId !== input.deliveryId || envelope.attemptId !== input.attemptId ||
          envelope.nodeGeneration !== nodeAuth.node.generation) throw new EventApiError("invalid_dispatch_response", 503);
      }
      return response(result.data);
    }

    if (url.pathname === "/v1/dispatch/settle-no-start") {
      const input = DispatchNoStartRequestSchema.parse(payload);
      if (input.nodeGeneration !== nodeAuth.node.generation) throw new EventApiError("denied", 403);
      const current = await authenticateAgent(env.MESSAGE_AUTHORITY, credentials, deadline);
      if (current.principal !== identity.principal || current.agent !== identity.agent || current.keyThumbprint !== identity.keyThumbprint)
        throw new EventApiError("denied", 403);
      await admitCoordinator(env, identity.principal, identity.agent, deadline);
      const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
      const result = DispatchNoStartResultSchema.safeParse(await deadline.run(() => coordinator.settleNoStart(input,
        { nodeId: nodeAuth.node.nodeId, generation: nodeAuth.node.generation }, credentials)));
      if (!result.success || result.data.nodeId !== nodeAuth.node.nodeId || result.data.deliveryId !== input.deliveryId ||
        result.data.attemptId !== input.attemptId || result.data.permitId !== input.permitId || result.data.nodeGeneration !== input.nodeGeneration ||
        result.data.evidence.type !== input.evidence.type || (input.evidence.type === "native_terminal_no_start" &&
          (result.data.evidence.type !== "native_terminal_no_start" || result.data.evidence.receiptId !== input.evidence.receiptId)))
        throw new EventApiError("invalid_dispatch_response", 503);
      return response(result.data);
    }

    let acknowledgment;
    try { acknowledgment = parseEventObservationAck(raw); }
    catch { acknowledgment = parseMessagingObservationAckV2(raw); }
    if (acknowledgment.principal !== identity.principal || acknowledgment.agent !== identity.agent || acknowledgment.nodeGeneration !== nodeAuth.node.generation)
      throw new EventApiError("acknowledgment_denied", 403);
    // Authentication preceded node verification; refresh it immediately before handing
    // the ACK to its coordinator. The coordinator rechecks the current node fence.
    const current = await authenticateAgent(env.MESSAGE_AUTHORITY, credentials, deadline);
    if (current.principal !== identity.principal || current.agent !== identity.agent || current.keyThumbprint !== identity.keyThumbprint)
      throw new EventApiError("denied", 403);
    await admitCoordinator(env, identity.principal, identity.agent, deadline);
    const coordinator = env.AGENT_COORDINATOR.getByName(coordinatorName(identity.principal, identity.agent));
    return response(await deadline.run(() => coordinator.acknowledge(acknowledgment,
      { nodeId: nodeAuth.node.nodeId, generation: nodeAuth.node.generation }, credentials)));
  } catch (error) {
    if (error instanceof EventApiError) return response({ error: error.code }, error.status);
    if (error instanceof z.ZodError || error instanceof EventProtocolError) return response({ error: "invalid_request" }, 400);
    // Durable Object RPC preserves Error.message, not the custom error class or fields.
    if (error instanceof Error && /^(invalid|conflict|denied|node_denied|expired|capacity|not_found|native_binding_unqualified|assigned_stock_disabled|github_source_conflict|github_operation_conflict|github_capacity)$/.test(error.message))
      return response({ error: error.message }, ["denied", "node_denied"].includes(error.message) ? 403 : 409);
    if (error instanceof Error && /^(authority_unavailable|registry_unavailable|runtime_disabled)$/.test(error.message))
      return response({ error: error.message }, 503);
    return response({ error: "unavailable" }, 503);
  } finally { deadline.dispose(); }
}
