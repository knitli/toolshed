// The deployment's human-presence configuration as Messaging reads it (R4 plan 6.3, Appendix A): the variables deploy.ts generates from deployment.jsonc's
// `presence` and `presenceHost` blocks, parsed once into the verifier's own pins. Anchors, floors, the relying party and the enroll windows are here and nowhere else;
// no stored row is ever a root of trust for them (INV5). Free of Worker types.
//
// Everything is closed: a variable that does not parse as a whole configuration makes the whole of it null, and every caller treats null as `unavailable`.
// A blank PRESENCE_RP_ID is the off state (presence.deploy false): nothing in the host works, and nothing else depends on it.

import { ACTIVATION_DELAY_HOURS, readPinned, type PinnedPresence } from "authority/src/webauthn.ts";
import { MAX_ANCHORS_PER_PRINCIPAL, MIN_ANCHORS_PER_PRINCIPAL, isoTime, matches, plain, principal as isPrincipal } from "authority/src/contract-kit.ts";
import { isCanonicalPrincipal } from "authority/src/scope.ts";
import { snapshot } from "authority/src/snapshot.ts";
import { identifier } from "openapi-operator/src/access.ts";
import { audienceShared, type AccessAudienceVar } from "./access-audiences.ts";

/** The act kinds whose legacy session path an enforcement flag governs (plan 5.11). Orders, credential acts and liveness have no flag (VS-17). `exec-admit` is P7's. */
export const ENFORCED_KINDS = ["agent-enroll", "bind-existing", "activation", "declare-task", "grant", "agent-scope", "exec-admit"] as const;
export type EnforcedKind = (typeof ENFORCED_KINDS)[number];
export const MODES = ["off", "observe", "enforce"] as const;
export type Mode = (typeof MODES)[number];

/** An enroll window (plan 6.3): a principal may register a first credential until `until`, with the secret whose SHA-256 this is. The owner makes the secret locally; the deploy ships its hash from deployment.jsonc. */
export type EnrollWindow = Readonly<{ principal: string; until: number; secretSha256: string }>;

export type PresenceConfig = Readonly<{
  pinned: PinnedPresence;
  windows: readonly EnrollWindow[];
  enforce: Readonly<Record<EnforcedKind, Mode>>;
  /** How many anchors the owner declared for each principal (plan 6.3 step 3): a liveness ceremony needs exactly this many pins, and every one touched. */
  livenessAnchors: Readonly<Record<string, number>>;
  /** The presence host's Access audience: with its origin (the relying party's own, `pinned.origin`) the `vars` the ceremony's four checks run with. */
  accessAudience: string;
}>;

export type PresenceVars = Partial<Record<
  | "PRESENCE_RP_ID" | "PRESENCE_ORIGIN" | "PRESENCE_AUD" | "PRESENCE_ANCHORS" | "PRESENCE_FLOORS" | "PRESENCE_ENROLL_WINDOWS" | "PRESENCE_ENFORCE" | "PRESENCE_LIVENESS_ANCHORS"
  | "ACCESS_ISSUER",
  string
>> & Partial<Record<AccessAudienceVar, string>>;

const VAR_NAMES = [
  "PRESENCE_RP_ID", "PRESENCE_ORIGIN", "PRESENCE_AUD", "PRESENCE_ANCHORS", "PRESENCE_FLOORS", "PRESENCE_ENROLL_WINDOWS", "PRESENCE_ENFORCE", "PRESENCE_LIVENESS_ANCHORS",
  "ACCESS_PRESENCE_AUD", "ACCESS_ISSUER", "ACCESS_AUD", "ACCESS_OAUTH_AUD", "ACCESS_MEMORY_AUD", "ACCESS_EVENT_AUD", "ACCESS_UI_AUD", "ACCESS_SETUP_AUD",
] as const;

/** The presence variables of an env, as plain strings. The Mailbox reads them from its own env; the entrypoints use it to check the same configuration before they verify anything. */
export const presenceVarsOf = (env: PresenceVars): PresenceVars => Object.fromEntries(VAR_NAMES.filter((name) => typeof env[name] === "string").map((name) => [name, env[name]])) as PresenceVars;

const SHA256_HEX = /^[0-9a-f]{64}$/;
export const MAX_WINDOWS = 8;

function json(text: string | undefined): unknown {
  try {
    return JSON.parse(text ?? "");
  } catch {
    return undefined;
  }
}

function windowsOf(value: unknown): EnrollWindow[] | null {
  if (!Array.isArray(value) || value.length > MAX_WINDOWS) return null;
  const out: EnrollWindow[] = [];
  for (const entry of value) {
    const w = plain(entry, ["principal", "until", "secretSha256"]);
    const until = typeof w?.until === "string" ? isoTime(w.until) : Number.NaN;
    if (!w || !isPrincipal(w.principal) || !isCanonicalPrincipal(w.principal) || !Number.isFinite(until) || !matches(w.secretSha256, SHA256_HEX)) return null;
    out.push(Object.freeze({ principal: w.principal, until, secretSha256: w.secretSha256 }));
  }
  return out;
}

function enforceOf(value: unknown): Record<EnforcedKind, Mode> | null {
  const e = plain(value, ENFORCED_KINDS);
  if (!e || !ENFORCED_KINDS.every((kind) => (MODES as readonly unknown[]).includes(e[kind]))) return null;
  return Object.fromEntries(ENFORCED_KINDS.map((kind) => [kind, e[kind]])) as Record<EnforcedKind, Mode>;
}

function livenessOf(value: unknown): Record<string, number> | null {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return null;
  const out: Record<string, number> = {};
  for (const [name, count] of Object.entries(value)) {
    if (!isPrincipal(name) || !isCanonicalPrincipal(name) || !Number.isSafeInteger(count) || (count as number) < MIN_ANCHORS_PER_PRINCIPAL || (count as number) > MAX_ANCHORS_PER_PRINCIPAL) return null;
    out[name] = count as number;
  }
  return out;
}

/**
 * The presence configuration these variables spell, or null: off (blank relying party), or malformed, or inconsistent (the presence audience is another Access
 * app's). The pins are read by authority's readPinned, so a Worker holds nothing a pinned file could not. That the origin and the rpId are the presence host's own
 * is enforced at deploy (validatePresence in scripts/deploy.ts), not here.
 */
export function presenceConfig(env: PresenceVars): PresenceConfig | null {
  if (!env.PRESENCE_RP_ID) return null;
  const anchors = json(env.PRESENCE_ANCHORS);
  const floors = json(env.PRESENCE_FLOORS);
  const windows = windowsOf(json(env.PRESENCE_ENROLL_WINDOWS));
  const enforce = enforceOf(json(env.PRESENCE_ENFORCE));
  const liveness = livenessOf(json(env.PRESENCE_LIVENESS_ANCHORS));
  const once = snapshot({ anchors, floors });
  if (!once || !windows || !enforce || !liveness) return null;
  const pinned = readPinned(
    { rpId: env.PRESENCE_RP_ID, origin: env.PRESENCE_ORIGIN, aud: env.PRESENCE_AUD, ...(once.value as object), activationDelayHours: ACTIVATION_DELAY_HOURS },
    "full",
  );
  if (!pinned) return null;
  const { ACCESS_PRESENCE_AUD: accessAudience } = env;
  if (!accessAudience || !identifier(accessAudience, 256) || !env.ACCESS_ISSUER) return null;
  // The presence host is its own Access application: a token for any other of Messaging's would otherwise pass for it (collision-checked like the others, auth.ts).
  if (audienceShared(env, "ACCESS_PRESENCE_AUD")) return null;
  return Object.freeze({ pinned, windows: Object.freeze(windows), enforce: Object.freeze(enforce), livenessAnchors: Object.freeze(liveness), accessAudience });
}

/** The window open for `principal` at `now`, or null. A window opens by deploy and closes at `until`; there is no other way to open one. */
export function openWindow(config: PresenceConfig, principal: string, now: number): EnrollWindow | null {
  return config.windows.find((w) => w.principal === principal && now < w.until) ?? null;
}

// --- orders (R4 P5b, plan 13.3a) ------------------------------------------------------------------------------

export type AuthorityVars = Partial<Record<"AUTHORITY_CONSEQUENCE_RULE" | "AUTHORITY_ORDER_EMISSION", string>>;
/**
 * The two order knobs deploy.ts writes from deployment.jsonc's `authority` block. `orderEmission`: whether an order can be drafted and applied (no order, so no
 * v3 receipt, while off). `consequenceRule`: whether a consequential type needs a live order. Blank is off; any other unknown value fails closed (no emission,
 * the rule enforced), so a broken deploy refuses rather than letting through.
 */
export function authorityFlags(env: AuthorityVars): { consequenceRule: Mode; orderEmission: boolean } {
  const rule = env.AUTHORITY_CONSEQUENCE_RULE ?? "";
  return {
    consequenceRule: rule === "" ? "off" : (MODES as readonly string[]).includes(rule) ? (rule as Mode) : "enforce",
    orderEmission: env.AUTHORITY_ORDER_EMISSION === "on",
  };
}
