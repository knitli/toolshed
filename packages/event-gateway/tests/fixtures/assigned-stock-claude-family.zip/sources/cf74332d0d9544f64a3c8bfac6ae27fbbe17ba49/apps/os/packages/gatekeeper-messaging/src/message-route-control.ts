import { AccessDenied, AccessUnavailable, canonicalEmail } from "openapi-operator/src/access.ts";
import { codeOf, fail, mailboxName } from "./model.ts";
import { credentialActive } from "./registry.ts";
import { messageRoute, transferMessageRoute, type MessageRouteReceipt } from "./event-bridge.ts";
import { MessageRouteOwnerProofVerifier, type MessageRouteOwnerEnvironment } from "./message-route-owner-proof.ts";
import { parseMessageConsumerSnapshot, parseMessageRouteControlInput, parseMessageRouteOwnerCall,
  type MessageConsumerServiceV1, type MessageConsumerSnapshotV1, type MessageRouteControlResult } from "./message-route-control-contract.ts";

export type MessageRouteControlEnvironment = MessageRouteOwnerEnvironment & { EVENT_MESSAGE_CONSUMER?: MessageConsumerServiceV1 };
export const MESSAGE_CONSUMER_DEADLINE_MS = 10_000;
export function routeControlFailure(error: unknown): MessageRouteControlResult {
  if (error instanceof AccessDenied) return { status: "denied" };
  if (error instanceof AccessUnavailable) return { status: "unavailable" };
  const code = codeOf(error);
  return { status: code === "conflict" ? "conflict" : code === "over_budget" ? "capacity" : code === "invalid" ? "invalid"
    : ["forbidden", "not_found", "suspended", "key_provisional"].includes(code ?? "") ? "denied" : "unavailable" };
}

/** Original human proof is verified here, inside the actual storage-owning Mailbox. */
export async function controlMessageRoute(storage: DurableObjectStorage, selfName: string | undefined,
  env: MessageRouteControlEnvironment, verifier: MessageRouteOwnerProofVerifier, originalCall: unknown, originalInput: unknown,
): Promise<MessageRouteControlResult> {
  const call = parseMessageRouteOwnerCall(originalCall), input = parseMessageRouteControlInput(originalInput);
  if (!call || !input) return { status: "invalid" };
  const queryService = env.EVENT_MESSAGE_CONSUMER;
  const namespace = env.MESSAGING_NAMESPACE;
  try {
    const self: unknown = JSON.parse(selfName ?? "null");
    if (!Array.isArray(self) || self.length !== 2 || self[0] !== namespace || typeof self[1] !== "string" ||
      !canonicalEmail(self[1]) || self[1] !== self[1].toLowerCase() || mailboxName(namespace, self[1]) !== selfName) throw new AccessDenied();
    const principal = self[1], agent = input.agent, request = input.request;
    const incarnation = () => storage.sql.exec<{ created_at: number }>("SELECT created_at FROM agents WHERE name=?", agent).toArray()[0]?.created_at;
    const agentCreatedAt = incarnation();
    if (agentCreatedAt === undefined) throw new AccessDenied();
    if (request.operation !== "read" && request.agentCreatedAt !== agentCreatedAt) throw fail("conflict", "agent incarnation changed");
    const proof = await verifier.requireOwner(call, { namespace, principal, agent }, request.operation);
    const common = (): void => {
      verifier.assertCurrent(proof);
      if (env.MESSAGING_NAMESPACE !== namespace || incarnation() !== agentCreatedAt) throw new AccessDenied();
    };
    common();
    if (request.operation === "read") return { status: "ok", namespace, agentCreatedAt, currentRoute: messageRoute(storage.sql, agent), receipt: null };
    if (request.operation === "operation_readback") {
      const row = storage.sql.exec<{ agent: string; agent_created_at: number; result_json: string }>(
        "SELECT agent,agent_created_at,result_json FROM message_route_operations WHERE operation_id=?", request.operationId).toArray()[0];
      if (!row) return { status: "unknown" };
      if (row.agent !== agent || row.agent_created_at !== agentCreatedAt) return { status: "conflict" };
      const saved = JSON.parse(row.result_json) as { route: MessageRouteReceipt["route"]; runtimeProfile?: MessageRouteReceipt["runtimeProfile"] };
      const receipt: MessageRouteReceipt = { operationId: request.operationId, agentCreatedAt, route: saved.route, replayed: true,
        ...(saved.runtimeProfile ? { runtimeProfile: saved.runtimeProfile } : {}) };
      return { status: "ok", namespace, agentCreatedAt, currentRoute: messageRoute(storage.sql, agent), receipt };
    }
    let fingerprint: string | undefined;
    let observed: Extract<MessageConsumerSnapshotV1, { status: "current" }> | undefined;
    let started = 0;
    let qualificationFailure: unknown;
    const keyFingerprint = (): string | null => {
      if (request.owner !== "event" || !request.keyThumbprint || !credentialActive(storage.sql, agent, request.keyThumbprint)) return null;
      const row = storage.sql.exec("SELECT agent,thumbprint,x,created_at,state FROM agent_keys WHERE agent=? AND thumbprint=?", agent, request.keyThumbprint).toArray()[0];
      return row ? JSON.stringify(row) : null;
    };
    const activation = (): void => {
      if (qualificationFailure) throw qualificationFailure;
      if (queryService !== env.EVENT_MESSAGE_CONSUMER || !fingerprint || keyFingerprint() !== fingerprint || !observed) throw new AccessDenied();
      const now = Date.now(), checkedAt = Date.parse(observed.checkedAt);
      if (checkedAt < started || checkedAt > now || now - checkedAt > MESSAGE_CONSUMER_DEADLINE_MS ||
        Date.parse(observed.leaseUntil) <= now || JSON.stringify(observed.consumer) !== JSON.stringify(request.consumer)) throw new AccessDenied();
    };
    const receipt = await transferMessageRoute(storage, { namespace, principal, admitted: () => { common(); return true; } }, agent, request, {
      currentConsumer: async () => false,
      authorizeTransfer: async claim => {
        common();
        if (claim.replay) return true;
        if (request.owner === "os") {
          if (claim.previous.generation === 0) throw new AccessDenied();
          return true;
        }
        const before = keyFingerprint();
        if (!before) { qualificationFailure = new AccessDenied(); return true; }
        fingerprint = before;
        if (!queryService) { qualificationFailure = new AccessUnavailable(); return true; }
        started = Date.now();
        let timer: ReturnType<typeof setTimeout> | undefined;
        try {
          const response = await Promise.race([
            queryService.verifyMessageConsumer({ principal, agent, keyThumbprint: request.keyThumbprint!, consumer: structuredClone(request.consumer!),
              ...(request.runtimeProfile ? { runtimeProfile: request.runtimeProfile } : {}) }),
            new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new AccessUnavailable()), MESSAGE_CONSUMER_DEADLINE_MS); }),
          ]);
          common();
          const parsed = parseMessageConsumerSnapshot(response);
          if (!parsed || parsed.status === "unavailable" || parsed.status === "invalid") throw new AccessUnavailable();
          if (parsed.status !== "current") throw new AccessDenied();
          observed = parsed;
          // The phase-aware transaction fence checks activation. A concurrent exact receipt
          // remains historical even if the key or lease changed during this query.
          return true;
        } catch (error) {
          common();
          qualificationFailure = error instanceof AccessDenied ? error : new AccessUnavailable();
          return true;
        } finally { if (timer !== undefined) clearTimeout(timer); }
      },
    }, phase => {
      common();
      if (phase === "commit") {
        const budget = storage.kv.get<{ stockWakeAttempts?: { settledAt: number | null }[]; pendingToken?: string | null }>(`wake-budget:${agent}`);
        if (budget?.stockWakeAttempts?.some(row => row.settledAt === null) || budget?.pendingToken?.startsWith("event:") ||
          storage.kv.get(`event-native-unsettled:${agent}`)) throw fail("conflict", "an Event wake outcome is still unresolved");
        if (request.owner === "event") activation();
      }
    });
    common();
    return { status: "ok", namespace, agentCreatedAt, currentRoute: messageRoute(storage.sql, agent), receipt };
  } catch (error) { return routeControlFailure(error); }
}
