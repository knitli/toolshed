import { z } from 'zod';
import { AssignedStockRuntimeBindingSchema } from './assigned-stock-contract';
import { WatchSubjectSchema, WatchViewSchema } from './github/watch-control-internal';

const uuid = z.uuid().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[47][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
const generation = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);
export const ASSIGNED_STOCK_WATCH_PAGE_LIMIT = 2;
const base = { runtimeId: uuid, conversationId: uuid, expectedRuntimeGeneration: generation,
  expectedAttachmentGeneration: generation };
export const AssignedStockWatchRequestSchema = z.discriminatedUnion('operation', [
  z.strictObject({ operation: z.literal('watch_list'), ...base, afterSubject: WatchSubjectSchema.nullable() }),
  z.strictObject({ operation: z.literal('watch_renew'), ...base, operationId: uuid, subject: WatchSubjectSchema,
    expectedWatchIncarnation: generation, expectedRoutingRevision: generation, expectedLeaseRevision: generation,
    leaseMs: z.number().int().positive().max(90_000) }),
  z.strictObject({ operation: z.literal('watch_readback'), ...base, operationId: uuid, subject: WatchSubjectSchema }),
]);
export type AssignedStockWatchRequest = z.infer<typeof AssignedStockWatchRequestSchema>;

export const AssignedStockWatchRuntimeSchema = z.strictObject({ runtimeProfile: AssignedStockRuntimeBindingSchema,
  runtimeId: uuid, runtimeGeneration: generation, nodeId: uuid, nodeGeneration: generation,
  attachmentGeneration: generation, leaseUntil: z.iso.datetime({ precision: 3 }) });
const listOutcome = z.strictObject({ status: z.literal('list'), watches: z.array(WatchViewSchema).max(ASSIGNED_STOCK_WATCH_PAGE_LIMIT),
  nextSubject: WatchSubjectSchema.nullable() });
const renewOutcome = z.strictObject({ status: z.literal('committed'), operationId: uuid, watch: WatchViewSchema });
const readbackOutcome = z.discriminatedUnion('status', [
  z.strictObject({ status: z.literal('known'), operationId: uuid, watch: WatchViewSchema }),
  z.strictObject({ status: z.enum(['unresolved', 'conflict']), operationId: uuid }),
]);
export const AssignedStockWatchResponseSchema = z.strictObject({ runtime: AssignedStockWatchRuntimeSchema,
  outcome: z.union([listOutcome, renewOutcome, readbackOutcome]) });
export type AssignedStockWatchResponse = z.infer<typeof AssignedStockWatchResponseSchema>;
