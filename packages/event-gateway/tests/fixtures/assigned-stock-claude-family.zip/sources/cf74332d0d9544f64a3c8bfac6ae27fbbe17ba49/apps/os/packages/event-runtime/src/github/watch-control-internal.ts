import { z } from 'zod';
import { agent, generation, uuid } from '../contracts';
import { AssignedStockRuntimeBindingSchema } from '../assigned-stock-contract';

const principal = z.string().email().max(254).refine(value => value === value.toLowerCase());
const revision = z.string().min(1).max(128);
const counter = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER);
export const WatchSubjectSchema = z.strictObject({ repositoryId: generation, prNumber: generation });
const tokenFields = {
  operationId: uuid, principal, agent, subject: WatchSubjectSchema,
  sourceIncarnation: generation, lifecycleEpoch: generation, obligationId: uuid,
  installationId: generation, grantRevision: generation, mappingRevision: revision,
  policyRevision: revision, sourceEnableGeneration: generation,
};
// Shared definition avoids a source-control/internal-union import cycle. Its public alias remains exact.
export const SourceOnlyControlTokenSchema = z.strictObject({
  operationId: uuid, principal, agent, subject: WatchSubjectSchema,
  sourceIncarnation: generation, watchIncarnation: z.literal(0), routingRevision: z.literal(0),
  lifecycleEpoch: generation, obligationId: uuid, action: z.literal('activate'), mode: z.literal('source_only'),
  installationId: generation, grantRevision: generation, mappingRevision: revision,
  policyRevision: revision, sourceEnableGeneration: generation,
});
export const WatchActivateTokenSchema = z.strictObject({ ...tokenFields,
  watchIncarnation: generation, routingRevision: generation, action: z.literal('activate'), mode: z.literal('watch') });
export const WatchStopTokenSchema = z.strictObject({ ...tokenFields,
  watchIncarnation: generation, routingRevision: generation, action: z.literal('stop'), mode: z.literal('stopped') });
export const InternalControlTokenSchema = z.union([SourceOnlyControlTokenSchema, WatchActivateTokenSchema, WatchStopTokenSchema]);
export const WatchControlTokenSchema = z.union([WatchActivateTokenSchema, WatchStopTokenSchema]);
export type WatchActivateToken = z.infer<typeof WatchActivateTokenSchema>;
export type WatchStopToken = z.infer<typeof WatchStopTokenSchema>;
export type WatchControlToken = z.infer<typeof WatchControlTokenSchema>;
export type InternalControlToken = z.infer<typeof InternalControlTokenSchema>;
export type SourceKey = z.infer<typeof WatchSubjectSchema>;
export const WatchPredecessorRefSchema = z.strictObject({ operationId: uuid, obligationId: uuid, lifecycleEpoch: generation });
export const WatchPromotionRequestSchema = z.strictObject({ predecessor: WatchPredecessorRefSchema, token: WatchActivateTokenSchema,
  expectedSourceVersion: counter, expectedHostEpoch: counter, initialReconciliation: z.literal(true).optional() });
export const WatchStopRequestSchema = z.strictObject({ token: WatchStopTokenSchema });
export const WatchAppliedOutcomeSchema = z.strictObject({ status: z.enum(['activated', 'stopped']), sourceVersion: counter, hostEpoch: counter });
export const WatchSettlementWitnessSchema = z.strictObject({ retirementOperationId: uuid, status: z.literal('settled') });
export const WatchStopEvidenceSchema = z.strictObject({ outcome: WatchAppliedOutcomeSchema.extend({ status: z.literal('stopped') }),
  settlement: WatchSettlementWitnessSchema.nullable() });
export const WatchRetirementRequestSchema = z.strictObject({ token: WatchStopTokenSchema, retirementOperationId: uuid });
export const WatchOutcomeReadbackSchema = z.discriminatedUnion('status', [
  z.strictObject({ status: z.literal('known'), token: WatchControlTokenSchema, outcome: WatchAppliedOutcomeSchema }),
  z.strictObject({ status: z.literal('unresolved') }),
]);
export const WatchRetirementSettlementSchema = z.strictObject({ token: WatchStopTokenSchema, settlement: WatchSettlementWitnessSchema });
export const WatchAuthorityReadbackSchema = z.discriminatedUnion('status', [
  z.strictObject({ status: z.literal('source_only') }), z.strictObject({ status: z.literal('absent') }),
  z.strictObject({ status: z.literal('unavailable') }),
  z.strictObject({ status: z.literal('watch'), token: WatchControlTokenSchema,
    phase: z.enum(['activation_pending', 'active', 'stop_pending', 'stopped']),
    reservation: z.enum(['protected', 'released']), retirementOperationId: uuid.nullable(),
    stopOutcome: WatchAppliedOutcomeSchema.extend({ status: z.literal('stopped') }).nullable() }),
]);
export type WatchPredecessorRef = z.infer<typeof WatchPredecessorRefSchema>;
export type WatchPromotionRequest = z.infer<typeof WatchPromotionRequestSchema>;
export type WatchStopRequest = z.infer<typeof WatchStopRequestSchema>;
export type WatchAppliedOutcome = z.infer<typeof WatchAppliedOutcomeSchema>;
export type WatchSettlementWitness = z.infer<typeof WatchSettlementWitnessSchema>;
export type WatchStopEvidence = z.infer<typeof WatchStopEvidenceSchema>;
export type WatchRetirementRequest = z.infer<typeof WatchRetirementRequestSchema>;
export type WatchOutcomeReadback = z.infer<typeof WatchOutcomeReadbackSchema>;
export type WatchRetirementSettlement = z.infer<typeof WatchRetirementSettlementSchema>;
export type WatchAuthorityReadback = z.infer<typeof WatchAuthorityReadbackSchema>;

export const WATCH_CONTROL_LIMITS = Object.freeze({ messageBytes: 4096, coordinatorProtectedBytes: 12288,
  hostProtectedBytes: 8192, hostEvidenceBytes: 4096, maxLeaseMs: 90_000, retainedOperations: 64,
  retainedBytes: 256 * 1024, terminalRetentionMs: 7 * 86_400_000, operationLeaseMs: 30_000,
  associations: 32, retainedWatches: 1000, authorityAuditMs: 60_000 });
export function watchJson(value: unknown, maximum: number = WATCH_CONTROL_LIMITS.messageBytes): string {
  const result = JSON.stringify(value);
  if (typeof result !== 'string' || new TextEncoder().encode(result).byteLength > maximum) throw new Error('github_capacity');
  return result;
}
export function internalTokenEquals(left: unknown, right: unknown): boolean {
  const a = InternalControlTokenSchema.safeParse(left), b = InternalControlTokenSchema.safeParse(right);
  return a.success && b.success && JSON.stringify(a.data) === JSON.stringify(b.data);
}
export const WatchHolderSchema = z.strictObject({ runtimeId: uuid, runtimeGeneration: generation,
  attachmentGeneration: generation, nodeId: uuid, nodeGeneration: generation });
export const WatchSourceSchema = z.strictObject({ installationId: generation, grantRevision: generation,
  mappingRevision: revision, policyRevision: revision });
export const WatchFenceSchema = z.strictObject({ expectedIncarnation: generation, expectedRoutingRevision: generation });
export const CreateWatchRequestSchema = z.strictObject({ operationId: uuid, subject: WatchSubjectSchema,
  expectedIncarnation: z.literal(0), expectedSourceIncarnation: generation, expectedRoutingRevision: z.literal(0),
  expectedLifecycleEpoch: generation, source: WatchSourceSchema, holder: WatchHolderSchema,
  runtimeProfile: AssignedStockRuntimeBindingSchema.optional(),
  leaseMs: z.number().int().positive().max(WATCH_CONTROL_LIMITS.maxLeaseMs) });
export const CleanupWatchRequestSchema = z.strictObject({ operationId: uuid, subject: WatchSubjectSchema, fence: WatchFenceSchema });
export const WatchRequestSchema = z.discriminatedUnion('kind', [
  z.strictObject({ kind: z.literal('create'), input: CreateWatchRequestSchema }),
  z.strictObject({ kind: z.literal('read'), input: z.strictObject({ subject: WatchSubjectSchema }) }),
  z.strictObject({ kind: z.literal('operation_readback'), input: z.strictObject({ subject: WatchSubjectSchema, operationId: uuid }) }),
  z.strictObject({ kind: z.literal('detach'), input: CleanupWatchRequestSchema }),
  z.strictObject({ kind: z.literal('unsubscribe'), input: CleanupWatchRequestSchema }),
]);
export type WatchRequest = z.infer<typeof WatchRequestSchema>;
export type WatchOperationKind = WatchRequest['kind'];
export type CreateWatchRequest = z.infer<typeof CreateWatchRequestSchema>;
export type CleanupWatchRequest = z.infer<typeof CleanupWatchRequestSchema>;
export type WatchHolder = z.infer<typeof WatchHolderSchema>;
export const WatchViewSchema = z.strictObject({ subject: WatchSubjectSchema, incarnation: generation,
  routingRevision: generation, lifecycleEpoch: generation, state: z.enum(['attached', 'detached', 'retired']),
  source: WatchSourceSchema.extend({ sourceIncarnation: generation }),
  attachment: z.strictObject({ holder: WatchHolderSchema, leaseRevision: generation, leaseUntil: generation }).nullable(),
  sourceControl: z.strictObject({ mode: z.enum(['watch', 'stopped']), status: z.enum(['pending', 'acknowledged', 'blocked']),
    operationId: uuid, obligationId: uuid, reason: z.enum(['authority_changed', 'authority_unavailable', 'host_unavailable']).nullable() }) });
export type WatchView = z.infer<typeof WatchViewSchema>;
export const WatchOutcomeSchema = z.discriminatedUnion('status', [
  z.strictObject({ status: z.literal('absent') }),
  z.strictObject({ status: z.literal('present'), watch: WatchViewSchema, attachmentStatus: z.enum(['live', 'expired', 'none']) }),
  z.strictObject({ status: z.literal('committed'), operationId: uuid, result: WatchViewSchema }),
  z.strictObject({ status: z.literal('conflict'), operationId: uuid }),
  z.strictObject({ status: z.literal('unresolved'), operationId: uuid }),
  z.strictObject({ status: z.literal('error'), code: z.enum(['invalid', 'denied', 'conflict', 'capacity', 'unavailable', 'unsupported']) }),
]);
export type WatchOutcome = z.infer<typeof WatchOutcomeSchema>;
