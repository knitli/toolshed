// The Access applications Messaging verifies assertions for, and the one check that keeps them apart. Free of Worker types, so deploy.ts (which validates the
// same rule over the deployment file) and the Workers read one list.

/** Every Access application Messaging verifies assertions for, by its var. Each must be its own: one list for every check. */
export const ACCESS_AUDIENCES = ["ACCESS_AUD", "ACCESS_OAUTH_AUD", "ACCESS_MEMORY_AUD", "ACCESS_EVENT_AUD", "ACCESS_UI_AUD", "ACCESS_SETUP_AUD", "ACCESS_PRESENCE_AUD"] as const;
export type AccessAudienceVar = (typeof ACCESS_AUDIENCES)[number];
/** Whether the audience `own` names is also another of Messaging's Access apps: that app's tokens would then pass for this one's. */
export function audienceShared(env: Partial<Record<AccessAudienceVar, string>>, own: AccessAudienceVar): boolean {
  const mine = env[own];
  return !!mine && ACCESS_AUDIENCES.some((name) => name !== own && env[name] === mine);
}
