import { z } from 'zod';
import { generation, uuid } from '../contracts';
import { SourceOnlyControlTokenSchema, WatchControlTokenSchema, WATCH_CONTROL_LIMITS as L } from './watch-control-internal';

const counter = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER);
const positive = generation;
const operationSubject = z.strictObject({ installationId: positive, repositoryId: positive, prNumber: positive });
const expectedControlSchema = z.strictObject({ operationId: uuid, sourceIncarnation: positive, lifecycleEpoch: positive });
function requestExpectedControl(value: unknown): z.infer<typeof expectedControlSchema> | null {
  if (!value || typeof value !== 'object' || !('expectedControl' in value)) return null;
  const parsed = expectedControlSchema.safeParse((value as { expectedControl?: unknown }).expectedControl);
  return parsed.success ? parsed.data : null;
}

export const GITHUB_SOURCE_CONTROL_LIMITS = Object.freeze({
  requestBytes: 4 * 1024,
  operationLeaseMs: 30_000,
  terminalRetentionMs: 7 * 86_400_000,
  retainedOperations: 64,
  retainedBytes: 256 * 1024,
  sourceOnlyAssociationsPerAgent: 32,
  historicalHostPreflightsPerSource: 32,
  protectedCleanupBundlesPerAgent: 32,
  protectedCleanupBytes: 4 * 1024,
  activeAuthorityAuditIntervalMs: 60_000,
});

/** Immutable authority for one source-only host incarnation. Watch routing remains zero. */
export const GitHubSourceControlTokenSchema = SourceOnlyControlTokenSchema;
export type GitHubSourceControlToken = z.infer<typeof GitHubSourceControlTokenSchema>;

export const GitHubSourceInitializationInputSchema = z.strictObject({
  operationId: uuid,
  subject: operationSubject,
  expectedWatchIncarnation: z.literal(0),
  expectedSourceIncarnation: z.literal(0),
  expectedRoutingRevision: z.literal(0),
  expectedLifecycleEpoch: z.literal(0),
  expectedRevision: z.number().int().positive().max(Number.MAX_SAFE_INTEGER),
});
export type GitHubSourceInitializationInput = z.infer<typeof GitHubSourceInitializationInputSchema>;

export const GitHubSourceAdoptionInputSchema = z.strictObject({
  operationId: uuid,
  subject: operationSubject,
  expectedRevision: z.number().int().positive().max(Number.MAX_SAFE_INTEGER),
  expectedSourceVersion: counter,
  expectedHostEpoch: counter,
  expectedControl: expectedControlSchema.optional(),
});
export type GitHubSourceAdoptionInput = z.infer<typeof GitHubSourceAdoptionInputSchema>;

export const GitHubSourceOperationReceiptSchema = z.strictObject({
  operationId: uuid,
  kind: z.enum(['initialize', 'adopt']),
  status: z.enum(['pending', 'active', 'parked', 'legacy', 'refused']),
  reason: z.string().max(128).nullable(),
  sourceIncarnation: counter,
  lifecycleEpoch: counter,
});
export type GitHubSourceOperationReceipt = z.infer<typeof GitHubSourceOperationReceiptSchema>;

/** Internal host-authority readback. Legacy mode is the only tokenless compatibility path. */
export const GitHubSourceFenceStatusSchema = z.discriminatedUnion('mode', [
  z.strictObject({ mode: z.literal('legacy'), deploymentEpoch: counter.nullable() }),
  z.strictObject({ mode: z.literal('pending'), operationId: uuid, phase: z.enum(['prepare', 'quiesce', 'activate', 'park', 'revalidate']), token: GitHubSourceControlTokenSchema.optional(), deploymentEpoch: counter.nullable() }),
  z.strictObject({ mode: z.literal('controlled'), token: GitHubSourceControlTokenSchema, state: z.enum(['activation_pending', 'active', 'parked']), deploymentEpoch: counter.nullable() }),
]);
export type GitHubSourceFenceStatus = z.infer<typeof GitHubSourceFenceStatusSchema>;

export const GitHubSourceControlViewSchema = z.strictObject({
  status: z.enum(['absent', 'legacy', 'initialization_pending', 'migration_pending', 'activation_pending', 'revalidation_pending', 'parking', 'active', 'parked', 'quiesced']),
  sourceIncarnation: counter,
  watchIncarnation: z.literal(0),
  routingRevision: z.literal(0),
  lifecycleEpoch: counter,
  operationId: uuid.nullable(),
  hostEpoch: counter,
  pendingReason: z.enum(['waiting_for_host', 'waiting_for_authority', 'revalidation_required', 'revalidation_exhausted']).nullable(),
});
export type GitHubSourceControlView = z.infer<typeof GitHubSourceControlViewSchema>;

export const GitHubSourceParkingResultSchema = z.discriminatedUnion('status', [
  z.strictObject({ status: z.literal('no_effect'), operationId: uuid, token: GitHubSourceControlTokenSchema, sourceVersion: counter, hostEpoch: counter }),
  z.strictObject({ status: z.literal('parked'), operationId: uuid, token: GitHubSourceControlTokenSchema, sourceVersion: counter, hostEpoch: counter }),
]);
export type GitHubSourceParkingResult = z.infer<typeof GitHubSourceParkingResultSchema>;
export const GitHubSourceRevalidationResultSchema = z.strictObject({
  status: z.literal('revalidated'), operationId: uuid, token: GitHubSourceControlTokenSchema, sourceVersion: counter, hostEpoch: counter,
});
export type GitHubSourceRevalidationResult = z.infer<typeof GitHubSourceRevalidationResultSchema>;

/** Canonical PR key intentionally excludes installation ID; installation belongs to the token. */
export function canonicalSourceKey(subject: { repositoryId: number; prNumber: number }): string {
  return JSON.stringify([subject.repositoryId, subject.prNumber]);
}

export function sourceTokenEquals(left: unknown, right: unknown): boolean {
  const a = GitHubSourceControlTokenSchema.safeParse(left), b = GitHubSourceControlTokenSchema.safeParse(right);
  return a.success && b.success && JSON.stringify(a.data) === JSON.stringify(b.data);
}

export function checkedRequestJson(value: unknown): string {
  const json = JSON.stringify(value);
  if (typeof json !== 'string') throw new Error('github_invalid_request');
  if (new TextEncoder().encode(json).byteLength > GITHUB_SOURCE_CONTROL_LIMITS.requestBytes) throw new Error('github_capacity');
  return json;
}

export function createSourceControlTables(sql: SqlStorage): void {
  sql.exec(`
    CREATE TABLE IF NOT EXISTS github_source_controls(
      canonical_subject TEXT PRIMARY KEY, subject_json TEXT NOT NULL, token_json TEXT NOT NULL,
      state TEXT NOT NULL CHECK(state IN ('activation_pending','active','parked')),
      operation_id TEXT NOT NULL, updated_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS github_source_operations(
      operation_id TEXT PRIMARY KEY, canonical_subject TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('initialize','adopt')),
      request_json TEXT NOT NULL, result_json TEXT, created_at INTEGER NOT NULL, terminal_at INTEGER);
    CREATE INDEX IF NOT EXISTS github_source_operations_retention ON github_source_operations(terminal_at,created_at);
    CREATE TABLE IF NOT EXISTS github_source_outbox(
      operation_id TEXT PRIMARY KEY, canonical_subject TEXT NOT NULL,
      phase TEXT NOT NULL CHECK(phase IN ('prepare','quiesce','activate','park','revalidate')), token_json TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0, next_at INTEGER NOT NULL,
      claim_id TEXT, claim_until INTEGER, last_reason TEXT);
    CREATE INDEX IF NOT EXISTS github_source_outbox_due ON github_source_outbox(next_at,claim_until);
    CREATE TABLE IF NOT EXISTS github_source_cleanup_bundles(
      canonical_subject TEXT PRIMARY KEY, operation_id TEXT NOT NULL,
      protected_bytes INTEGER NOT NULL CHECK(protected_bytes=4096), created_at INTEGER NOT NULL);
  `);
}

/** Rebuilds only the constrained source-control tables on the first v5 opt-in. Caller owns the transaction. */
export function upgradeSourceControlParkingSchema(sql: SqlStorage): void {
  const controlSql = sql.exec<{ sql: string }>("SELECT sql FROM sqlite_master WHERE type='table' AND name='github_source_controls'").toArray()[0]?.sql ?? '';
  if (!controlSql.includes("'parked'")) {
    sql.exec(`CREATE TABLE github_source_controls_parking_v5(
      canonical_subject TEXT PRIMARY KEY, subject_json TEXT NOT NULL, token_json TEXT NOT NULL,
      state TEXT NOT NULL CHECK(state IN ('activation_pending','active','parked')),
      operation_id TEXT NOT NULL, updated_at INTEGER NOT NULL)`);
    sql.exec(`INSERT INTO github_source_controls_parking_v5(canonical_subject,subject_json,token_json,state,operation_id,updated_at)
      SELECT canonical_subject,subject_json,token_json,state,operation_id,updated_at FROM github_source_controls`);
    sql.exec('DROP TABLE github_source_controls');
    sql.exec('ALTER TABLE github_source_controls_parking_v5 RENAME TO github_source_controls');
  }
  const outboxSql = sql.exec<{ sql: string }>("SELECT sql FROM sqlite_master WHERE type='table' AND name='github_source_outbox'").toArray()[0]?.sql ?? '';
  if (!outboxSql.includes("'park'") || !outboxSql.includes("'revalidate'")) {
    sql.exec('DROP INDEX IF EXISTS github_source_outbox_due');
    sql.exec(`CREATE TABLE github_source_outbox_parking_v5(
      operation_id TEXT PRIMARY KEY, canonical_subject TEXT NOT NULL,
      phase TEXT NOT NULL CHECK(phase IN ('prepare','quiesce','activate','park','revalidate')), token_json TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0, next_at INTEGER NOT NULL,
      claim_id TEXT, claim_until INTEGER, last_reason TEXT)`);
    sql.exec(`INSERT INTO github_source_outbox_parking_v5(operation_id,canonical_subject,phase,token_json,attempts,next_at,claim_id,claim_until,last_reason)
      SELECT operation_id,canonical_subject,phase,token_json,attempts,next_at,claim_id,claim_until,last_reason FROM github_source_outbox`);
    sql.exec('DROP TABLE github_source_outbox');
    sql.exec('ALTER TABLE github_source_outbox_parking_v5 RENAME TO github_source_outbox');
    sql.exec('CREATE INDEX github_source_outbox_due ON github_source_outbox(next_at,claim_until)');
  }
}

type OperationRow = { operation_id: string; canonical_subject: string; kind: 'initialize' | 'adopt'; request_json: string; result_json: string | null; created_at: number; terminal_at: number | null };
type ControlRow = { subject_json: string; token_json: string; state: 'activation_pending' | 'active' | 'parked'; operation_id: string; updated_at: number };
type OutboxRow = { operation_id: string; canonical_subject: string; phase: 'prepare' | 'quiesce' | 'activate' | 'park' | 'revalidate'; token_json: string; attempts: number; next_at: number; claim_id: string | null; claim_until: number | null; last_reason: string | null };

/** Coordinator-local canonical CAS, exact receipts and leased recovery outbox. Caller owns SQL transaction. */
export class GitHubSourceControlStore {
  constructor(private readonly sql: SqlStorage, private readonly principalName: string, private readonly agentName: string) {
    createSourceControlTables(sql);
  }
  requireSourceOnlyOwnership(subject: { repositoryId: number; prNumber: number }): void {
    if (!this.sourceOnlyFilter()) return;
    const row=this.sql.exec<{control_owner:string;token_json:string;operation_id:string}>('SELECT control_owner,token_json,operation_id FROM github_source_controls WHERE canonical_subject=?',canonicalSourceKey(subject)).toArray()[0];
    if(!row)return;
    if(row.control_owner!=='watch' && row.control_owner!=='source_only')throw new Error('github_source_unavailable');
    let raw:unknown;try{raw=JSON.parse(row.token_json);}catch{throw new Error('github_source_unavailable');}
    const token=(row.control_owner==='watch'?WatchControlTokenSchema:SourceOnlyControlTokenSchema).safeParse(raw);
    if(!token.success || token.data.principal!==this.principalName || token.data.agent!==this.agentName || token.data.operationId!==row.operation_id || canonicalSourceKey(token.data.subject)!==canonicalSourceKey(subject))throw new Error('github_source_unavailable');
    if(row.control_owner==='watch')throw new Error('github_source_conflict');
  }
  private sourceOnlyFilter(): string {
    return this.sql.exec<{name:string}>('PRAGMA table_info(github_source_controls)').toArray().some(column => column.name === 'control_owner') ? " AND control_owner='source_only'" : '';
  }
  control(subject: { repositoryId: number; prNumber: number }): (ControlRow & { token: GitHubSourceControlToken }) | null {
    this.requireSourceOnlyOwnership(subject);
    const raw = this.sql.exec<ControlRow>('SELECT subject_json,token_json,state,operation_id,updated_at FROM github_source_controls WHERE canonical_subject=?', canonicalSourceKey(subject)).toArray().at(0);
    if (!raw) return null;
    const token = GitHubSourceControlTokenSchema.parse(JSON.parse(raw.token_json));
    if (token.principal !== this.principalName || token.agent !== this.agentName || canonicalSourceKey(token.subject) !== canonicalSourceKey(subject)) throw new Error('github_source_conflict');
    return { ...raw, token };
  }
  hasActiveControls(): boolean {
    return this.sql.exec("SELECT 1 FROM github_source_controls WHERE state='active'" + this.sourceOnlyFilter() + ' LIMIT 1').toArray().length > 0;
  }
  activeControlsDue(now: number): Array<ControlRow & { token: GitHubSourceControlToken }> {
    return this.sql.exec<ControlRow>(`SELECT subject_json,token_json,state,operation_id,updated_at FROM github_source_controls
      WHERE state='active' ${this.sourceOnlyFilter()} AND updated_at+?<=? ORDER BY updated_at,canonical_subject LIMIT ?`,
      GITHUB_SOURCE_CONTROL_LIMITS.activeAuthorityAuditIntervalMs, now,
      GITHUB_SOURCE_CONTROL_LIMITS.sourceOnlyAssociationsPerAgent).toArray().map(raw => {
      const token = GitHubSourceControlTokenSchema.parse(JSON.parse(raw.token_json));
      return { ...raw, token };
    });
  }
  touchActiveControl(token: GitHubSourceControlToken, now: number): boolean {
    this.requireSourceOnlyOwnership(token.subject);
    return this.sql.exec(`UPDATE github_source_controls SET updated_at=? WHERE canonical_subject=? AND operation_id=?
      AND token_json=? AND state='active'`, now, canonicalSourceKey(token.subject), token.operationId, JSON.stringify(token)).rowsWritten === 1;
  }
  beginActiveParking(token: GitHubSourceControlToken, now: number, nextAt = now): boolean {
    const key = canonicalSourceKey(token.subject), current = this.control(token.subject);
    if (!current || current.state !== 'active' || current.operation_id !== token.operationId || !sourceTokenEquals(current.token, token)) return false;
    if (this.sql.exec('SELECT 1 FROM github_source_outbox WHERE canonical_subject=? LIMIT 1', key).toArray().length) return false;
    this.requireCleanupOwner(key, token.operationId);
    if (new TextEncoder().encode(JSON.stringify(token)).byteLength > GITHUB_SOURCE_CONTROL_LIMITS.protectedCleanupBytes)
      throw new Error('github_cleanup_capacity');
    const marker = this.sql.exec<{ version: number }>('SELECT max(version) AS version FROM schema_migrations').one().version;
    if (marker > 16) throw new Error('unsupported coordinator schema');
    upgradeSourceControlParkingSchema(this.sql);
    this.sql.exec('INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES (5,?)', now);
    this.sql.exec(`INSERT INTO github_source_outbox(operation_id,canonical_subject,phase,token_json,attempts,next_at,last_reason)
      VALUES (?,?,'park',?,0,?,'authority_changed')`, token.operationId, key, JSON.stringify(token), nextAt);
    return this.outbox(token.operationId)?.phase === 'park';
  }
  deferDueOutbox(now: number, nextAt: number): void {
    for(const row of this.sql.exec<{operation_id:string}>('SELECT operation_id FROM github_source_outbox WHERE next_at<=?',now)) this.outbox(row.operation_id);
    this.sql.exec(`UPDATE github_source_outbox SET next_at=?,claim_id=NULL,claim_until=NULL
      WHERE next_at<=? AND (claim_until IS NULL OR claim_until<=?)`, nextAt, now, now);
  }
  operationIdOwned(operationId: string): boolean {
    if (this.sourceOnlyFilter() && this.sql.exec('SELECT 1 FROM github_watch_operations WHERE operation_id=? UNION ALL SELECT 1 FROM github_watch_history WHERE operation_id=? UNION ALL SELECT 1 FROM github_watch_state WHERE retirement_operation_id=? LIMIT 1',operationId,operationId,operationId).toArray().length) return true;
    return this.sql.exec(`SELECT 1 FROM github_source_controls WHERE operation_id=?
      UNION ALL SELECT 1 FROM github_source_outbox WHERE operation_id=?
      UNION ALL SELECT 1 FROM github_source_cleanup_bundles WHERE operation_id=? LIMIT 1`, operationId, operationId, operationId).toArray().length > 0;
  }
  operation(operationId: string): OperationRow | null {
    const row = this.sql.exec<OperationRow>('SELECT operation_id,canonical_subject,kind,request_json,result_json,created_at,terminal_at FROM github_source_operations WHERE operation_id=?', operationId).toArray().at(0) ?? null;
    if (row) { const [repositoryId, prNumber] = JSON.parse(row.canonical_subject); this.requireSourceOnlyOwnership({repositoryId,prNumber}); }
    return row;
  }
  operationReceipt(subject: { repositoryId: number; prNumber: number }, operationId?: string): GitHubSourceOperationReceipt | null {
    this.requireSourceOnlyOwnership(subject);
    const operation = operationId ? this.operation(operationId) : this.latestOperation(subject);
    if (!operation || operation.canonical_subject !== canonicalSourceKey(subject)) return null;
    if (operation.result_json) {
      let result: { status?: unknown; reason?: unknown; token?: unknown };
      try { result = JSON.parse(operation.result_json) as typeof result; } catch { return null; }
      if (result.status === 'active') {
        const token = GitHubSourceControlTokenSchema.safeParse(result.token);
        if (!token.success || token.data.operationId !== operation.operation_id) return null;
        return GitHubSourceOperationReceiptSchema.parse({ operationId: operation.operation_id, kind: operation.kind, status: 'active', reason: null,
          sourceIncarnation: token.data.sourceIncarnation, lifecycleEpoch: token.data.lifecycleEpoch });
      }
      if (result.status === 'parked') {
        const token = GitHubSourceControlTokenSchema.safeParse(result.token);
        if (!token.success || token.data.operationId !== operation.operation_id) return null;
        return GitHubSourceOperationReceiptSchema.parse({ operationId: operation.operation_id, kind: operation.kind, status: 'parked', reason: 'authority_changed',
          sourceIncarnation: token.data.sourceIncarnation, lifecycleEpoch: token.data.lifecycleEpoch });
      }
      if (result.status === 'legacy' || result.status === 'refused') return GitHubSourceOperationReceiptSchema.parse({
        operationId: operation.operation_id, kind: operation.kind, status: result.status,
        reason: typeof result.reason === 'string' ? result.reason.slice(0, 128) : 'outcome_unavailable', sourceIncarnation: 0, lifecycleEpoch: 0,
      });
      return null;
    }
    const outbox = this.outbox(operation.operation_id);
    if (!outbox) return GitHubSourceOperationReceiptSchema.parse({ operationId: operation.operation_id, kind: operation.kind,
      status: 'pending', reason: null, sourceIncarnation: 0, lifecycleEpoch: 0 });
    // A provisional request token does not allocate counters. Only the canonical
    // row committed after host prepare/quiesce acknowledgement owns that lineage.
    const control = this.control(subject);
    // A revalidation is a new immutable operation over the retained parked
    // lineage. Until the host checkpoint ACK commits, expose only that
    // predecessor's already-committed counters, never provisional counters.
    const committed = control?.token ?? null;
    return GitHubSourceOperationReceiptSchema.parse({ operationId: operation.operation_id, kind: operation.kind,
      status: 'pending', reason: outbox.last_reason, sourceIncarnation: committed?.sourceIncarnation ?? 0,
      lifecycleEpoch: committed?.lifecycleEpoch ?? 0 });
  }
  latestOperation(subject: { repositoryId: number; prNumber: number }): OperationRow | null {
    this.requireSourceOnlyOwnership(subject);
    // Retained rowid order tracks admission even when wall-clock timestamps tie or regress.
    return this.sql.exec<OperationRow>('SELECT operation_id,canonical_subject,kind,request_json,result_json,created_at,terminal_at FROM github_source_operations WHERE canonical_subject=? ORDER BY rowid DESC LIMIT 1', canonicalSourceKey(subject)).toArray().at(0) ?? null;
  }
  pendingFor(subject: { repositoryId: number; prNumber: number }): OutboxRow | null {
    this.requireSourceOnlyOwnership(subject);
    return this.sql.exec<OutboxRow>(`SELECT operation_id,canonical_subject,phase,token_json,attempts,next_at,claim_id,claim_until,last_reason
      FROM github_source_outbox WHERE canonical_subject=? ORDER BY next_at,operation_id LIMIT 1`, canonicalSourceKey(subject)).toArray().at(0) ?? null;
  }
  exactOperation(operationId: string, request: unknown, now: number): OperationRow | null {
    void now;
    const prior = this.operation(operationId);
    if (prior && prior.request_json !== checkedRequestJson(request)) throw new Error('github_operation_conflict');
    return prior;
  }
  outbox(operationId: string): OutboxRow | null {
    const row = this.sql.exec<OutboxRow>('SELECT operation_id,canonical_subject,phase,token_json,attempts,next_at,claim_id,claim_until,last_reason FROM github_source_outbox WHERE operation_id=?', operationId).toArray().at(0) ?? null;
    if(row) { const [repositoryId,prNumber]=JSON.parse(row.canonical_subject); this.requireSourceOnlyOwnership({repositoryId,prNumber}); }
    return row;
  }
  reserve(input: {
    operationId: string; kind: 'initialize' | 'adopt'; request: unknown; subject: { installationId: number; repositoryId: number; prNumber: number };
    token: GitHubSourceControlToken; phase: 'prepare' | 'quiesce' | 'activate'; now: number;
  }): 'reserved' | 'replay' {
    const requestJson = checkedRequestJson(input.request), tokenJson = checkedRequestJson(input.token), key = canonicalSourceKey(input.subject);
    const checkedToken = GitHubSourceControlTokenSchema.parse(input.token);
    if (checkedToken.principal !== this.principalName || checkedToken.agent !== this.agentName || checkedToken.operationId !== input.operationId
      || checkedToken.installationId !== input.subject.installationId || canonicalSourceKey(checkedToken.subject) !== key)
      throw new Error('github_source_conflict');
    this.requireSourceOnlyOwnership(input.subject);
    this.prune(input.now);
    const previous = this.operation(input.operationId);
    if (previous) {
      if (previous.request_json !== requestJson) throw new Error('github_operation_conflict');
      return 'replay';
    }
    if (this.operationIdOwned(input.operationId)) throw new Error('github_operation_conflict');
    const occupied = this.sql.exec('SELECT 1 FROM github_source_controls WHERE canonical_subject=? UNION ALL SELECT 1 FROM github_source_outbox WHERE canonical_subject=? LIMIT 1', key, key).toArray().length > 0;
    if (occupied) throw new Error('github_source_conflict');
    // Source-only initialization and watch lifecycle share one canonical PR
    // authority key even though the historical watch table includes an owner
    // partition and watch rows retain installation identity.
    const watchTable = this.sql.exec<{ name: string }>("SELECT name FROM sqlite_master WHERE type='table' AND name='github_delivery_watches'").toArray().length > 0;
    if (watchTable && this.sql.exec('SELECT 1 FROM github_delivery_watches WHERE owner=? AND subject=? LIMIT 1',
      JSON.stringify([this.principalName, this.agentName]), key).toArray().length > 0) throw new Error('github_source_conflict');
    if (this.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_source_operations').one().n >= GITHUB_SOURCE_CONTROL_LIMITS.retainedOperations) throw new Error('github_capacity');
    const associations = new Set<string>();
    for (const item of this.sql.exec<{ canonical_subject: string }>('SELECT canonical_subject FROM github_source_controls')) associations.add(item.canonical_subject);
    for (const item of this.sql.exec<{ canonical_subject: string }>('SELECT canonical_subject FROM github_source_outbox')) associations.add(item.canonical_subject);
    if (associations.size >= GITHUB_SOURCE_CONTROL_LIMITS.sourceOnlyAssociationsPerAgent) throw new Error('github_capacity');
    // Reserve the future lifecycle-stop representation before any host-side
    // prepare/quiesce write can happen. This allowance is independent of the
    // ordinary request/receipt byte cap.
    this.reserveCleanupBundle(key, input.operationId, input.now);
    if (input.phase === 'activate') {
      this.sql.exec('INSERT INTO github_source_controls(canonical_subject,subject_json,token_json,state,operation_id,updated_at) VALUES (?,?,?,\'activation_pending\',?,?)', key, JSON.stringify(input.subject), tokenJson, input.operationId, input.now);
    }
    this.sql.exec('INSERT INTO github_source_operations(operation_id,canonical_subject,kind,request_json,created_at) VALUES (?,?,?,?,?)', input.operationId, key, input.kind, requestJson, input.now);
    this.sql.exec('INSERT INTO github_source_outbox(operation_id,canonical_subject,phase,token_json,attempts,next_at) VALUES (?,?,?,?,0,?)', input.operationId, key, input.phase, tokenJson, input.now);
    this.assertCapacity();
    return 'reserved';
  }
  reserveRevalidation(input: {
    operationId: string; request: unknown; subject: { installationId: number; repositoryId: number; prNumber: number };
    predecessor: GitHubSourceControlToken; token: GitHubSourceControlToken; now: number;
  }): 'reserved' | 'replay' {
    const requestJson = checkedRequestJson(input.request), tokenJson = checkedRequestJson(input.token), key = canonicalSourceKey(input.subject);
    this.requireSourceOnlyOwnership(input.subject);
    this.prune(input.now);
    const previous = this.operation(input.operationId);
    if (previous) {
      if (previous.request_json !== requestJson) throw new Error('github_operation_conflict');
      return 'replay';
    }
    if (this.operationIdOwned(input.operationId)) throw new Error('github_operation_conflict');
    const control = this.control(input.subject);
    if (!control || control.state !== 'parked' || !sourceTokenEquals(control.token, input.predecessor)
      || !requestExpectedControl(input.request) || requestExpectedControl(input.request)!.operationId !== control.token.operationId
      || requestExpectedControl(input.request)!.sourceIncarnation !== control.token.sourceIncarnation
      || requestExpectedControl(input.request)!.lifecycleEpoch !== control.token.lifecycleEpoch
      || input.token.operationId !== input.operationId || input.token.installationId !== input.subject.installationId
      || input.token.subject.repositoryId !== input.subject.repositoryId || input.token.subject.prNumber !== input.subject.prNumber
      || input.token.sourceIncarnation !== control.token.sourceIncarnation || input.token.lifecycleEpoch !== control.token.lifecycleEpoch + 1
      || input.token.principal !== this.principalName || input.token.agent !== this.agentName || input.token.action !== 'activate')
      throw new Error('github_source_conflict');
    const priorOutbox = this.sql.exec('SELECT 1 FROM github_source_outbox WHERE canonical_subject=? LIMIT 1', key).toArray().length > 0;
    if (priorOutbox) throw new Error('github_source_conflict');
    const cleanup = this.sql.exec<{ operation_id: string }>('SELECT operation_id FROM github_source_cleanup_bundles WHERE canonical_subject=?', key).toArray().at(0);
    if (!cleanup || cleanup.operation_id !== control.operation_id) throw new Error('github_source_conflict');
    const operations = this.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_source_operations').one().n;
    if (operations >= GITHUB_SOURCE_CONTROL_LIMITS.retainedOperations) throw new Error('github_capacity');
    const marker = this.sql.exec<{ version: number }>('SELECT max(version) AS version FROM schema_migrations').one().version;
    if (marker > 16) throw new Error('unsupported coordinator schema');
    upgradeSourceControlParkingSchema(this.sql);
    this.sql.exec("INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES (5,?)", input.now);
    this.sql.exec('INSERT INTO github_source_operations(operation_id,canonical_subject,kind,request_json,created_at) VALUES (?,?,?,?,?)', input.operationId, key, 'adopt', requestJson, input.now);
    this.sql.exec('INSERT INTO github_source_outbox(operation_id,canonical_subject,phase,token_json,attempts,next_at) VALUES (?,?,\'revalidate\',?,0,?)', input.operationId, key, tokenJson, input.now);
    this.assertCapacity();
    return 'reserved';
  }
  settlePrepare(operationId: string, claimId: string, now: number): boolean {
    const outbox = this.outbox(operationId);
    if (!outbox || outbox.phase !== 'prepare' || outbox.claim_id !== claimId || outbox.claim_until === null || outbox.claim_until <= now) return false;
    const token = GitHubSourceControlTokenSchema.parse(JSON.parse(outbox.token_json));
    const key = outbox.canonical_subject;
    const occupied = this.sql.exec('SELECT 1 FROM github_source_controls WHERE canonical_subject=?', key).toArray().length > 0;
    if (occupied) throw new Error('github_source_conflict');
    this.sql.exec('INSERT INTO github_source_controls(canonical_subject,subject_json,token_json,state,operation_id,updated_at) VALUES (?,?,?,\'activation_pending\',?,?)', key, JSON.stringify(token.subject), outbox.token_json, operationId, now);
    this.sql.exec(`UPDATE github_source_outbox SET phase='activate',next_at=?,claim_id=NULL,claim_until=NULL,last_reason=NULL
      WHERE operation_id=? AND claim_id=? AND phase='prepare'`, now, operationId, claimId);
    this.assertCapacity();
    return true;
  }
  failPrepare(operationId: string, claimId: string, reason: 'legacy_source_present' | 'authority_changed', now: number): boolean {
    const outbox = this.outbox(operationId);
    if (!outbox || outbox.phase !== 'prepare' || outbox.claim_id !== claimId || outbox.claim_until === null || outbox.claim_until <= now) return false;
    const result = checkedRequestJson({ status: reason === 'legacy_source_present' ? 'legacy' : 'refused', reason });
    this.sql.exec('UPDATE github_source_operations SET result_json=?,terminal_at=? WHERE operation_id=? AND result_json IS NULL', result, now, operationId);
    this.sql.exec('DELETE FROM github_source_outbox WHERE operation_id=? AND claim_id=? AND phase=\'prepare\'', operationId, claimId);
    this.sql.exec('DELETE FROM github_source_cleanup_bundles WHERE canonical_subject=? AND operation_id=?', outbox.canonical_subject, operationId);
    this.assertCapacity();
    return true;
  }
  failQuiesce(operationId: string, claimId: string, reason: 'source_checkpoint_changed' | 'host_epoch_exhausted', now: number): boolean {
    const outbox = this.outbox(operationId);
    if (!outbox || outbox.phase !== 'quiesce' || outbox.claim_id !== claimId || outbox.claim_until === null || outbox.claim_until <= now) return false;
    const result = checkedRequestJson({ status: 'refused', reason });
    this.sql.exec('UPDATE github_source_operations SET result_json=?,terminal_at=? WHERE operation_id=? AND result_json IS NULL', result, now, operationId);
    this.sql.exec('DELETE FROM github_source_outbox WHERE operation_id=? AND claim_id=? AND phase=\'quiesce\'', operationId, claimId);
    this.sql.exec('DELETE FROM github_source_cleanup_bundles WHERE canonical_subject=? AND operation_id=?', outbox.canonical_subject, operationId);
    this.assertCapacity();
    return true;
  }
  claim(now: number, claimId: string): OutboxRow | null {
    const due = this.sql.exec<OutboxRow>(`SELECT operation_id,canonical_subject,phase,token_json,attempts,next_at,claim_id,claim_until,last_reason
      FROM github_source_outbox WHERE next_at<=? AND (claim_until IS NULL OR claim_until<=?) ORDER BY next_at,operation_id LIMIT 1`, now, now).toArray().at(0);
    if (!due) return null;
    const [repositoryId,prNumber]=JSON.parse(due.canonical_subject); this.requireSourceOnlyOwnership({repositoryId,prNumber});
    const until = now + GITHUB_SOURCE_CONTROL_LIMITS.operationLeaseMs;
    const changed = this.sql.exec(`UPDATE github_source_outbox SET claim_id=?,claim_until=?,attempts=attempts+1
      WHERE operation_id=? AND next_at<=? AND (claim_until IS NULL OR claim_until<=?)`, claimId, until, due.operation_id, now, now).rowsWritten;
    return changed ? { ...due, claim_id: claimId, claim_until: until, attempts: due.attempts + 1 } : null;
  }
  settleQuiesce(operationId: string, claimId: string, now: number): boolean {
    const outbox = this.outbox(operationId);
    if (!outbox || outbox.phase !== 'quiesce' || outbox.claim_id !== claimId || outbox.claim_until === null || outbox.claim_until <= now) return false;
    const token = GitHubSourceControlTokenSchema.parse(JSON.parse(outbox.token_json));
    const key = outbox.canonical_subject;
    const occupied = this.sql.exec('SELECT 1 FROM github_source_controls WHERE canonical_subject=?', key).toArray().length > 0;
    if (occupied) throw new Error('github_source_conflict');
    this.sql.exec('INSERT INTO github_source_controls(canonical_subject,subject_json,token_json,state,operation_id,updated_at) VALUES (?,?,?,\'activation_pending\',?,?)', key, JSON.stringify(token.subject), outbox.token_json, operationId, now);
    this.sql.exec(`UPDATE github_source_outbox SET phase='activate',next_at=?,claim_id=NULL,claim_until=NULL,last_reason=NULL
      WHERE operation_id=? AND claim_id=? AND phase='quiesce'`, now, operationId, claimId);
    this.assertCapacity();
    return true;
  }
  settleActivation(operationId: string, claimId: string, now: number): boolean {
    const outbox = this.outbox(operationId);
    if (!outbox || outbox.phase !== 'activate' || outbox.claim_id !== claimId || outbox.claim_until === null || outbox.claim_until <= now) return false;
    const token = GitHubSourceControlTokenSchema.parse(JSON.parse(outbox.token_json));
    const current = this.control(token.subject);
    if (!current || !sourceTokenEquals(current.token, token)) throw new Error('github_source_conflict');
    this.sql.exec("UPDATE github_source_controls SET state='active',updated_at=? WHERE canonical_subject=? AND operation_id=? AND token_json=? AND state='activation_pending'", now, outbox.canonical_subject, operationId, outbox.token_json);
    const result = checkedRequestJson({ status: 'active', token });
    this.sql.exec('UPDATE github_source_operations SET result_json=?,terminal_at=? WHERE operation_id=? AND result_json IS NULL', result, now, operationId);
    this.sql.exec('DELETE FROM github_source_outbox WHERE operation_id=? AND claim_id=?', operationId, claimId);
    this.assertCapacity();
    return true;
  }
  beginParking(operationId: string, claimId: string, now: number): boolean {
    const outbox = this.outbox(operationId);
    if (!outbox || !['quiesce', 'activate', 'revalidate'].includes(outbox.phase)
      || outbox.claim_id !== claimId || outbox.claim_until === null || outbox.claim_until <= now) return false;
    const marker = this.sql.exec<{ version: number }>('SELECT max(version) AS version FROM schema_migrations').one().version;
    if (marker > 16) throw new Error('unsupported coordinator schema');
    upgradeSourceControlParkingSchema(this.sql);
    this.sql.exec("INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES (5,?)", now);
    return this.sql.exec(`UPDATE github_source_outbox SET phase='park',last_reason='authority_changed',claim_id=NULL,claim_until=NULL,next_at=?
      WHERE operation_id=? AND claim_id=? AND claim_until>? AND phase IN ('quiesce','activate','revalidate')`, now, operationId, claimId, now).rowsWritten > 0;
  }
  settleParking(operationId: string, claimId: string, result: GitHubSourceParkingResult, now: number): boolean {
    const outbox = this.outbox(operationId);
    if (!outbox || outbox.phase !== 'park' || outbox.claim_id !== claimId || outbox.claim_until === null || outbox.claim_until <= now
      || result.operationId !== operationId) return false;
    const token = GitHubSourceControlTokenSchema.parse(JSON.parse(outbox.token_json));
    if (!sourceTokenEquals(result.token, token)) throw new Error('github_source_conflict');
    const current = this.control(token.subject);
    const operation = this.operation(operationId);
    const postActivation = current?.state === 'active' && current.operation_id === operationId && sourceTokenEquals(current.token, token);
    if (postActivation) {
      if (result.status !== 'parked') throw new Error('github_source_conflict');
      if (operation && (operation.canonical_subject !== outbox.canonical_subject
        || operation.result_json !== checkedRequestJson({ status: 'active', token }) || operation.terminal_at === null))
        throw new Error('github_source_conflict');
      this.requireCleanupOwner(outbox.canonical_subject, operationId);
      if (this.sql.exec("UPDATE github_source_controls SET state='parked',updated_at=? WHERE canonical_subject=? AND state='active' AND operation_id=? AND token_json=?",
        now, outbox.canonical_subject, operationId, outbox.token_json).rowsWritten !== 1) throw new Error('github_source_conflict');
    } else if (result.status === 'no_effect') {
      if (!operation || operation.canonical_subject !== outbox.canonical_subject || operation.result_json !== null || operation.terminal_at !== null)
        throw new Error('github_source_conflict');
      const checkpoint = operation?.kind === 'adopt' ? requestExpectedControl(JSON.parse(operation.request_json)) : null;
      const preservesParkedPredecessor = !!current && current.state === 'parked' && !!checkpoint
        && current.token.operationId === checkpoint.operationId
        && current.token.sourceIncarnation === checkpoint.sourceIncarnation
        && current.token.lifecycleEpoch === checkpoint.lifecycleEpoch;
      if (current && !sourceTokenEquals(current.token, token) && !preservesParkedPredecessor) throw new Error('github_source_conflict');
      this.requireCleanupOwner(outbox.canonical_subject, preservesParkedPredecessor ? current!.operation_id : operationId);
      if (!preservesParkedPredecessor) {
        this.sql.exec('DELETE FROM github_source_controls WHERE canonical_subject=? AND operation_id=? AND token_json=?', outbox.canonical_subject, operationId, outbox.token_json);
        if (this.sql.exec('DELETE FROM github_source_cleanup_bundles WHERE canonical_subject=? AND operation_id=?', outbox.canonical_subject, operationId).rowsWritten !== 1)
          throw new Error('github_source_conflict');
      }
      const receipt = checkedRequestJson({ status: 'refused', reason: 'authority_changed' });
      // Treat the exact immutable readback as the commit proof, not rowsWritten:
      // a zero count is acceptable only when this still-pending operation now
      // contains precisely this receipt and terminal timestamp. The preflight
      // claim/token checks and exact-claim outbox deletion prevent stale replay.
      this.sql.exec('UPDATE github_source_operations SET result_json=?,terminal_at=? WHERE operation_id=? AND result_json IS NULL', receipt, now, operationId);
      const settledOperation = this.operation(operationId);
      if (settledOperation?.result_json !== receipt || settledOperation.terminal_at !== now)
        throw new Error('github_source_conflict');
    } else {
      const checkpoint = operation?.kind === 'adopt' ? requestExpectedControl(JSON.parse(operation.request_json)) : null;
      const predecessor = current && current.state === 'parked' && checkpoint
        && current.token.operationId === checkpoint.operationId
        && current.token.sourceIncarnation === checkpoint.sourceIncarnation
        && current.token.lifecycleEpoch === checkpoint.lifecycleEpoch ? current : null;
      if (current && !sourceTokenEquals(current.token, token) && !predecessor) throw new Error('github_source_conflict');
      this.requireCleanupOwner(outbox.canonical_subject, current?.operation_id ?? operationId);
      if (current && predecessor) {
        if (this.sql.exec("UPDATE github_source_controls SET subject_json=?,token_json=?,state='parked',operation_id=?,updated_at=? WHERE canonical_subject=? AND state='parked' AND operation_id=? AND token_json=?",
          JSON.stringify(token.subject), outbox.token_json, operationId, now, outbox.canonical_subject, current.operation_id, JSON.stringify(current.token)).rowsWritten !== 1)
          throw new Error('github_source_conflict');
        this.transferCleanupBundle(outbox.canonical_subject, current.operation_id, operationId);
      } else if (current) {
        if (this.sql.exec("UPDATE github_source_controls SET state='parked',updated_at=? WHERE canonical_subject=? AND operation_id=? AND token_json=?", now, outbox.canonical_subject, operationId, outbox.token_json).rowsWritten !== 1)
          throw new Error('github_source_conflict');
      } else this.sql.exec("INSERT INTO github_source_controls(canonical_subject,subject_json,token_json,state,operation_id,updated_at) VALUES (?,?,?,'parked',?,?)", outbox.canonical_subject, JSON.stringify(token.subject), outbox.token_json, operationId, now);
      const parkedReceipt = checkedRequestJson({ status: 'parked', token });
      this.sql.exec('UPDATE github_source_operations SET result_json=?,terminal_at=? WHERE operation_id=? AND result_json IS NULL', parkedReceipt, now, operationId);
      if (this.operation(operationId)?.result_json !== parkedReceipt)
        throw new Error('github_source_conflict');
    }
    if (this.sql.exec('DELETE FROM github_source_outbox WHERE operation_id=? AND claim_id=? AND phase=\'park\'', operationId, claimId).rowsWritten !== 1)
      throw new Error('github_source_conflict');
    this.assertCapacity();
    return true;
  }
  settleRevalidation(operationId: string, claimId: string, now: number): boolean {
    const outbox = this.outbox(operationId);
    if (!outbox || outbox.phase !== 'revalidate' || outbox.claim_id !== claimId || outbox.claim_until === null || outbox.claim_until <= now) return false;
    const token = GitHubSourceControlTokenSchema.parse(JSON.parse(outbox.token_json));
    const operation = this.operation(operationId);
    if (!operation) throw new Error('github_source_conflict');
    const checkpoint = requestExpectedControl(JSON.parse(operation.request_json));
    const current = this.control(token.subject);
    if (!current || current.state !== 'parked' || !checkpoint
      || current.token.operationId !== checkpoint.operationId
      || current.token.sourceIncarnation !== checkpoint.sourceIncarnation
      || current.token.lifecycleEpoch !== checkpoint.lifecycleEpoch
      || token.sourceIncarnation !== current.token.sourceIncarnation || token.lifecycleEpoch !== current.token.lifecycleEpoch + 1
      || token.installationId !== current.token.installationId || token.principal !== current.token.principal || token.agent !== current.token.agent)
      throw new Error('github_source_conflict');
    this.requireCleanupOwner(outbox.canonical_subject, current.operation_id);
    if (this.sql.exec("UPDATE github_source_controls SET token_json=?,state='activation_pending',operation_id=?,updated_at=? WHERE canonical_subject=? AND state='parked' AND operation_id=? AND token_json=?",
      outbox.token_json, operationId, now, outbox.canonical_subject, current.operation_id, JSON.stringify(current.token)).rowsWritten !== 1)
      throw new Error('github_source_conflict');
    this.sql.exec("UPDATE github_source_outbox SET phase='activate',next_at=?,claim_id=NULL,claim_until=NULL,last_reason=NULL WHERE operation_id=? AND claim_id=? AND phase='revalidate'",
      now, operationId, claimId);
    const activation = this.outbox(operationId);
    if (!activation || activation.phase !== 'activate' || activation.claim_id !== null || activation.claim_until !== null)
      throw new Error('github_source_conflict');
    this.transferCleanupBundle(outbox.canonical_subject, current.operation_id, operationId);
    this.assertCapacity();
    return true;
  }
  retry(operationId: string, claimId: string, reason: string, nextAt: number, now = Date.now()): boolean {
    this.outbox(operationId);
    return this.sql.exec(`UPDATE github_source_outbox SET claim_id=NULL,claim_until=NULL,next_at=?,last_reason=?
      WHERE operation_id=? AND claim_id=? AND claim_until>?`, nextAt, reason.slice(0, 128), operationId, claimId, now).rowsWritten > 0;
  }
  nextAt(): number | null {
    return this.sql.exec<{ next_at: number | null }>(`SELECT min(next_at) AS next_at FROM (
      SELECT CASE WHEN claim_until>? THEN claim_until ELSE next_at END AS next_at FROM github_source_outbox
      UNION ALL SELECT updated_at+? AS next_at FROM github_source_controls WHERE state='active' ${this.sourceOnlyFilter()})`,
      Date.now(), GITHUB_SOURCE_CONTROL_LIMITS.activeAuthorityAuditIntervalMs).one().next_at;
  }
  prune(now: number): void {
    if(this.sourceOnlyFilter()) this.sql.exec('DELETE FROM github_watch_operations WHERE protected=0 AND terminal_at<=?',now-GITHUB_SOURCE_CONTROL_LIMITS.terminalRetentionMs);
    const expired = this.sql.exec<{ operation_id: string }>(`SELECT operation_id FROM github_source_operations
      WHERE terminal_at IS NOT NULL AND terminal_at<=? ORDER BY terminal_at,operation_id`, now - GITHUB_SOURCE_CONTROL_LIMITS.terminalRetentionMs).toArray();
    for (const item of expired) {
      if (this.sql.exec('SELECT 1 FROM github_source_outbox WHERE operation_id=? LIMIT 1', item.operation_id).toArray().length) continue;
      this.sql.exec('DELETE FROM github_source_operations WHERE operation_id=? AND terminal_at IS NOT NULL', item.operation_id);
    }
  }
  private assertCapacity(): void { assertMixedWatchCapacity(this.sql); }
  private reserveCleanupBundle(canonicalSubject: string, operationId: string, now: number): void {
    const existing = this.sql.exec<{ operation_id: string }>('SELECT operation_id FROM github_source_cleanup_bundles WHERE canonical_subject=?', canonicalSubject).toArray().at(0);
    if (existing) {
      if (existing.operation_id === operationId) return;
      throw new Error('github_source_conflict');
    }
    const count = this.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_source_cleanup_bundles').one().n;
    if (count >= GITHUB_SOURCE_CONTROL_LIMITS.protectedCleanupBundlesPerAgent) throw new Error('github_cleanup_capacity');
    this.sql.exec('INSERT INTO github_source_cleanup_bundles(canonical_subject,operation_id,protected_bytes,created_at) VALUES (?,?,?,?)', canonicalSubject, operationId, GITHUB_SOURCE_CONTROL_LIMITS.protectedCleanupBytes, now);
  }
  private requireCleanupOwner(canonicalSubject: string, operationId: string): void {
    const row = this.sql.exec<{ operation_id: string; protected_bytes: number }>('SELECT operation_id,protected_bytes FROM github_source_cleanup_bundles WHERE canonical_subject=?', canonicalSubject).toArray().at(0);
    if (!row || row.operation_id !== operationId || row.protected_bytes !== GITHUB_SOURCE_CONTROL_LIMITS.protectedCleanupBytes)
      throw new Error('github_source_conflict');
  }
  private transferCleanupBundle(canonicalSubject: string, predecessorOperationId: string, replacementOperationId: string): void {
    this.requireCleanupOwner(canonicalSubject, predecessorOperationId);
    if (predecessorOperationId === replacementOperationId) return;
    const changed = this.sql.exec('UPDATE github_source_cleanup_bundles SET operation_id=? WHERE canonical_subject=? AND operation_id=?',
      replacementOperationId, canonicalSubject, predecessorOperationId);
    if (changed.rowsWritten !== 1) throw new Error('github_source_conflict');
  }
}

export function assertMixedWatchCapacity(sql: SqlStorage): void {
    let count = sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_source_operations').one().n;
    let bytes = 0;
    for (const item of sql.exec<{ request_json: string; result_json: string | null }>('SELECT request_json,result_json FROM github_source_operations')) {
      bytes += new TextEncoder().encode(item.request_json).byteLength;
      if (item.result_json) bytes += new TextEncoder().encode(item.result_json).byteLength;
    }
    for (const item of sql.exec<{ operation_id: string; canonical_subject: string; token_json: string; phase: string; control_state: string | null; control_operation_id: string | null; control_token_json: string | null; cleanup_operation_id: string | null; protected_bytes: number | null }>(`SELECT b.operation_id,b.canonical_subject,b.token_json,b.phase,
      c.state AS control_state,c.operation_id AS control_operation_id,c.token_json AS control_token_json,
      x.operation_id AS cleanup_operation_id,x.protected_bytes FROM github_source_outbox b
      LEFT JOIN github_source_controls c ON c.canonical_subject=b.canonical_subject
      LEFT JOIN github_source_cleanup_bundles x ON x.canonical_subject=b.canonical_subject`)) {
      // Post-activation parking is covered by the pre-reserved protected cleanup
      // bundle. It must still settle if ordinary operation receipts have filled
      // the coordinator's separate retained-byte allowance.
      const isProtectedActivePark = item.phase === 'park' && item.control_state === 'active'
        && item.control_operation_id === item.operation_id && item.cleanup_operation_id === item.operation_id
        && item.protected_bytes === GITHUB_SOURCE_CONTROL_LIMITS.protectedCleanupBytes
        && item.control_token_json === item.token_json
        && new TextEncoder().encode(item.token_json).byteLength <= GITHUB_SOURCE_CONTROL_LIMITS.protectedCleanupBytes;
      if (isProtectedActivePark) continue;
      bytes += new TextEncoder().encode(item.token_json).byteLength;
    }
    for (const item of sql.exec<{ token_json: string; subject_json: string }>('SELECT token_json,subject_json FROM github_source_controls')) {
      const token = JSON.parse(item.token_json);
      bytes += (token.mode === 'watch' || token.mode === 'stopped' ? L.messageBytes : new TextEncoder().encode(item.token_json).byteLength) + new TextEncoder().encode(item.subject_json).byteLength;
    }
    // Admission reserves the exact maximum retained representation of each
    // unsettled operation before any host mutation: its eventual canonical
    // control token/subject (if not materialized yet), and whichever is larger
    // between the current outbox token and a supported terminal result. Outbox
    // token bytes are already included above, so reserve only the delta. This
    // models the phase transitions: prepare retains outbox+control; activation
    // replaces the outbox token with a terminal receipt atomically.
    const pending = sql.exec<{ operation_id: string; canonical_subject: string; kind: string; request_json: string; token_json: string | null; control_operation_id: string | null; control_token_json: string | null }>(`
      SELECT o.operation_id,o.canonical_subject,o.kind,o.request_json,b.token_json,c.operation_id AS control_operation_id,c.token_json AS control_token_json
      FROM github_source_operations o
      LEFT JOIN github_source_outbox b ON b.operation_id=o.operation_id
      LEFT JOIN github_source_controls c ON c.canonical_subject=o.canonical_subject
      WHERE o.result_json IS NULL`).toArray();
    for (const item of pending) {
      if (!item.token_json) throw new Error('github_source_conflict');
      const token = GitHubSourceControlTokenSchema.parse(JSON.parse(item.token_json));
      if (item.control_operation_id && item.control_operation_id !== item.operation_id) {
        let checkpoint: z.infer<typeof expectedControlSchema> | null = null;
        try { checkpoint = item.kind === 'adopt' ? requestExpectedControl(JSON.parse(item.request_json)) : null; } catch { /* malformed is a conflict */ }
        const oldToken = item.control_token_json ? GitHubSourceControlTokenSchema.safeParse(JSON.parse(item.control_token_json)) : null;
        if (!checkpoint || !oldToken?.success || oldToken.data.operationId !== checkpoint.operationId
          || oldToken.data.sourceIncarnation !== checkpoint.sourceIncarnation || oldToken.data.lifecycleEpoch !== checkpoint.lifecycleEpoch
          || token.sourceIncarnation !== oldToken.data.sourceIncarnation || token.lifecycleEpoch !== oldToken.data.lifecycleEpoch + 1)
          throw new Error('github_source_conflict');
        const currentControlBytes = new TextEncoder().encode(item.control_token_json!).byteLength;
        const replacementControlBytes = new TextEncoder().encode(item.token_json).byteLength;
        bytes += Math.max(0, replacementControlBytes - currentControlBytes);
      }
      if (!item.control_operation_id) {
        const subjectJson = JSON.stringify(token.subject);
        bytes += new TextEncoder().encode(item.token_json).byteLength + new TextEncoder().encode(subjectJson).byteLength;
      }
      const resultJson = checkedRequestJson({ status: 'active', token });
      const failureBytes = Math.max(
        new TextEncoder().encode(checkedRequestJson({ status: 'legacy', reason: 'legacy_source_present' })).byteLength,
        new TextEncoder().encode(checkedRequestJson({ status: 'refused', reason: 'authority_changed' })).byteLength,
        new TextEncoder().encode(checkedRequestJson({ status: 'refused', reason: 'source_checkpoint_changed' })).byteLength,
        new TextEncoder().encode(checkedRequestJson({ status: 'refused', reason: 'host_epoch_exhausted' })).byteLength,
      );
      const parkedResultJson = checkedRequestJson({ status: 'parked', token });
      const terminalBytes = Math.max(new TextEncoder().encode(resultJson).byteLength, new TextEncoder().encode(parkedResultJson).byteLength, failureBytes);
      const outboxTokenBytes = new TextEncoder().encode(item.token_json).byteLength;
      bytes += Math.max(0, terminalBytes - outboxTokenBytes);
    }
    if (sql.exec("SELECT 1 FROM sqlite_master WHERE name='github_watch_operations'").toArray().length) {
      count += sql.exec<{n:number}>('SELECT count(*) AS n FROM github_watch_operations WHERE protected=0').one().n;
      const queries = [
        "SELECT request_json AS value FROM github_watch_operations WHERE protected=0",
        "SELECT result_json AS value FROM github_watch_operations WHERE protected=0",

        "SELECT token_json AS value FROM github_watch_outbox WHERE phase='activate'",
        "SELECT predecessor_json AS value FROM github_watch_outbox WHERE predecessor_json IS NOT NULL",
        "SELECT token_json AS value FROM github_watch_history",
      ];
      for(const row of sql.exec<{value:string}>('SELECT value FROM github_delivery_watches')) bytes += JSON.parse(row.value).kernelVersion===1 ? L.messageBytes : new TextEncoder().encode(row.value).byteLength;
      for(const query of queries)for(const row of sql.exec<{value:string}>(query))bytes+=new TextEncoder().encode(row.value).byteLength;
    }
    if(sql.exec("SELECT 1 FROM sqlite_master WHERE name='github_watch_lease_receipts'").toArray().length){
      count+=sql.exec<{n:number}>('SELECT count(*) AS n FROM github_watch_lease_receipts').one().n;
      for(const row of sql.exec<{request_json:string;result_json:string}>('SELECT request_json,result_json FROM github_watch_lease_receipts'))
        bytes+=new TextEncoder().encode(row.request_json).byteLength+new TextEncoder().encode(row.result_json).byteLength;
    }
    if (count > GITHUB_SOURCE_CONTROL_LIMITS.retainedOperations || bytes > GITHUB_SOURCE_CONTROL_LIMITS.retainedBytes) throw new Error('github_capacity');
  }
