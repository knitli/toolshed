"""Explicit foreground Codex launcher with read-only, session-local presence."""

import hashlib
import fcntl
import json
import math
import os
from pathlib import Path
import pty
import signal
import socket
import stat
import subprocess  # nosec B404 - only the explicitly qualified executable is launched
import threading
import termios
import time
from datetime import datetime, timezone
from uuid import uuid4

from .native import validate_receipt
from .native_reader import IDENTITY, NativeBridge, unique, uuid, validate_start
from .native_terminal import run_terminal
from .security import ensure_private_directory

# Exact clean-build executable qualified by the native release checkpoint.
QUALIFIED_SHA256 = "763e5e2b574f60b766d0d1b73b74ecc32d09d46479afe24e164299ca3633717b"
QUALIFIED_CODE_MODE_HOST_SHA256 = "679eedaea70529aa1cffc9bc0a0788c186412663544fa76c09d63b57f383a65a"
BINDING_FIELDS = (
    "clientId", "connectionId", "backendPid", "threadId", "generation",
    "serverInstanceId", "serverGeneration",
)
NATIVE_COMMANDS = frozenset(("nativeStart", "nativeReceipt"))
NATIVE_OPERATION_SECONDS = 8


def _claim_terminal():
    # Popen has performed setsid before this callback. Launch happens before
    # this module creates any threads; fd 0 is the already opened PTY slave.
    fcntl.ioctl(0, termios.TIOCSCTTY, 0)


class LaunchError(ValueError):
    """A bounded failure code, never child output or configuration."""


def launch_environment(environment):
    """Keep user Codex configuration, refusing injected native/loader authority."""
    if any(key.startswith(("LD_", "DYLD_", "CODEX_NATIVE_BRIDGE_", "CODEX_BRIDGE_ADOPTION_"))
           or key in ("CODEX_SELECTION_WITNESS_FD", "CODEX_CODE_MODE_HOST",
                      "CODEX_CODE_MODE_HOST_PATH") for key in environment):
        raise LaunchError("unsafe_launch_environment")
    return dict(environment)


def qualified_binary(binary, digest):
    """Require an explicit regular executable matching the reviewed prototype."""
    binary = Path(binary)
    if not binary.is_absolute() or digest != QUALIFIED_SHA256:
        raise LaunchError("unqualified_native_binary")
    _qualified_executable(binary, digest)
    companion = binary.with_name("codex-code-mode-host")
    _qualified_executable(companion, QUALIFIED_CODE_MODE_HOST_SHA256)
    # Pinned InstallContext prefers package resources; admit only sibling layouts.
    directory = binary.parent
    package = directory.parent if directory.name in ("bin", "codex-resources") else None
    if (directory.name == "MacOS" and directory.parent.name == "Contents"
            and directory.parent.parent.name == "CodexCLI.app"):
        package = directory.parent.parent.parent
    if ((package is not None and (package / "codex-package.json").exists())
            or (directory / "codex-resources" / companion.name).exists()):
        raise LaunchError("unsafe_native_binary_layout")
    return binary


def _qualified_executable(binary, digest):
    """Apply the same filesystem and content checks to each native executable."""
    if any(part.is_symlink() for part in (binary, *binary.parents)):
        raise LaunchError("unsafe_native_binary")
    for directory in binary.parents:
        info = directory.stat()
        # A root-owned sticky temporary directory cannot let another user
        # replace our owned entry; other writable ancestors are not accepted.
        sticky_root = info.st_uid == 0 and bool(info.st_mode & stat.S_ISVTX)
        if (info.st_uid not in (0, os.getuid())
                or (info.st_mode & 0o022 and not sticky_root)):
            raise LaunchError("unsafe_native_binary")
    descriptor = os.open(binary, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(descriptor)
        if (not stat.S_ISREG(info.st_mode) or info.st_mode & 0o022
                or info.st_uid not in (0, os.getuid()) or not info.st_mode & 0o111):
            raise LaunchError("unsafe_native_binary")
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            if hashlib.file_digest(stream, "sha256").hexdigest() != digest:
                raise LaunchError("native_binary_hash_mismatch")
    finally:
        os.close(descriptor)


def session_path(state_dir, session_id):
    if not uuid(session_id):
        raise LaunchError("invalid_session_id")
    return Path(state_dir) / ("c-" + session_id + ".sock")


def session_status(state_dir, session_id):
    """Query one explicitly identified live launcher; never discover clients."""
    return _session_request(state_dir, session_id, {"command": "status"})


def session_binding(state_dir, session_id):
    """Read the exact local selection tuple for a later cloud challenge."""
    value = _session_request(state_dir, session_id, {"command": "binding"})
    if not _valid_binding(value):
        raise LaunchError("invalid_client_binding")
    return value


def session_challenge(state_dir, session_id, challenge_id, expected_binding):
    """Obtain a fresh witness correlated with one cloud-issued challenge."""
    if not _valid_challenge_id(challenge_id) or not _valid_binding(expected_binding):
        raise LaunchError("invalid_client_challenge")
    value = _session_request(state_dir, session_id, {
        "command": "challenge", "challengeId": challenge_id,
        "expectedBinding": expected_binding,
    })
    if (not isinstance(value, dict)
            or set(value) != {"challengeId", "observedAt", "validUntilMonotonic", "witness"}
            or value["challengeId"] != challenge_id
            or not _valid_observed_at(value["observedAt"])
            or not isinstance(value["validUntilMonotonic"], (int, float))
            or isinstance(value["validUntilMonotonic"], bool)
            or not math.isfinite(value["validUntilMonotonic"])
            or time.monotonic() >= value["validUntilMonotonic"]
            or not _valid_native_witness(value["witness"])
            or _binding(value["witness"]) != expected_binding
            or value["validUntilMonotonic"] - time.monotonic()
            > min(value["witness"]["leaseMs"], 750) / 1000):
        raise LaunchError("invalid_client_challenge")
    return {key: value[key] for key in ("observedAt", "validUntilMonotonic", "witness")}


def _valid_challenge_id(value):
    return uuid(value)


def _valid_observed_at(value):
    if not isinstance(value, str) or len(value) != 24 or not value.endswith("Z"):
        return False
    try:
        parsed = datetime.fromisoformat(value[:-1] + "+00:00")
    except ValueError:
        return False
    return parsed.isoformat(timespec="milliseconds").replace("+00:00", "Z") == value


def _valid_binding(value):
    return (isinstance(value, dict) and set(value) == set(BINDING_FIELDS)
            and all(uuid(value[key]) for key in (
                "clientId", "connectionId", "threadId", "serverInstanceId",
            ))
            and isinstance(value["backendPid"], int) and not isinstance(value["backendPid"], bool)
            and 0 < value["backendPid"] <= 2**32 - 1
            and isinstance(value["generation"], int) and not isinstance(value["generation"], bool)
            and 0 <= value["generation"] <= 2**53 - 1
            and isinstance(value["serverGeneration"], int) and not isinstance(value["serverGeneration"], bool)
            and 0 <= value["serverGeneration"] <= 2**53 - 1)


def _binding(witness):
    return {key: witness[key] for key in BINDING_FIELDS}


def _valid_native_witness(value):
    return (isinstance(value, dict)
            and set(value) == {
                "version", "nonce", "clientId", "backendPid", "connectionId", "threadId",
                "generation", "eligible", "sequence", "cause", "serverInstanceId",
                "serverGeneration", "leaseMs", "nativeCoreTurnState",
            }
            and isinstance(value["version"], int) and not isinstance(value["version"], bool)
            and value["version"] == 2
            and isinstance(value["nonce"], int) and not isinstance(value["nonce"], bool)
            and 0 <= value["nonce"] <= 2**53 - 1
            and value["eligible"] is True
            and value["nativeCoreTurnState"] in ("busy", "idle", "unknown")
            and isinstance(value["cause"], str) and len(value["cause"]) <= 128
            and isinstance(value["sequence"], int) and not isinstance(value["sequence"], bool)
            and 0 < value["sequence"] <= 2**53 - 1
            and isinstance(value["leaseMs"], int) and not isinstance(value["leaseMs"], bool)
            and 0 < value["leaseMs"] <= 2**53 - 1
            and _valid_binding(_binding(value)))


def _reject_constant(_):
    raise ValueError


def _session_request(state_dir, session_id, request, *, native_request=None):
    state_dir = Path(state_dir).absolute()
    if any(part.is_symlink() for part in (state_dir, *state_dir.parents)):
        raise LaunchError("unsafe_client_state")
    directory = state_dir.lstat()
    if (not stat.S_ISDIR(directory.st_mode) or directory.st_uid != os.getuid()
            or stat.S_IMODE(directory.st_mode) != 0o700):
        raise LaunchError("unsafe_client_state")
    path = session_path(state_dir, session_id)
    info = path.lstat()
    if (not stat.S_ISSOCK(info.st_mode) or info.st_uid != os.getuid()
            or stat.S_IMODE(info.st_mode) != 0o600):
        raise LaunchError("unsafe_client_socket")
    payload = json.dumps(request, separators=(",", ":"), allow_nan=False).encode() + b"\n"
    if len(payload) > 1024:
        raise LaunchError("invalid_client_request")
    if native_request is not None:
        if request.get("command") not in NATIVE_COMMANDS:
            raise LaunchError("invalid_client_request")
        frame = json.dumps(native_request, separators=(",", ":"), allow_nan=False).encode() + b"\n"
        if len(frame) > 4096:
            raise LaunchError("invalid_client_request")
        payload += frame
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as channel:
        deadline = (request["deadlineMonotonic"] if native_request is not None
                    else time.monotonic() + 2)
        _remaining(channel, deadline)
        channel.connect(str(path))
        _remaining(channel, deadline)
        channel.sendall(payload)
        data = bytearray()
        while b"\n" not in data and len(data) <= 4096:
            _remaining(channel, deadline)
            chunk = channel.recv(4097 - len(data))
            if not chunk:
                break
            data.extend(chunk)
        if len(data) > 4096 or not data.endswith(b"\n"):
            raise LaunchError("invalid_client_response")
        try:
            value = json.loads(data, object_pairs_hook=unique, parse_constant=_reject_constant)
        except (ValueError, TypeError, RecursionError):
            raise LaunchError("invalid_client_response") from None
        if not isinstance(value, dict):
            raise LaunchError("invalid_client_response")
        return value


def session_native_operation(state_dir, session_id, binding, operation, request):
    """Send one bounded exact native operation to an explicitly selected launcher."""
    if operation not in NATIVE_COMMANDS or not _valid_binding(binding):
        raise LaunchError("invalid_native_operation")
    return _session_request(state_dir, session_id, {
        "command": operation, "expectedBinding": binding,
        "deadlineMonotonic": time.monotonic() + NATIVE_OPERATION_SECONDS,
    }, native_request=request)


def _remaining(channel, deadline):
    seconds = deadline - time.monotonic()
    if seconds <= 0:
        raise TimeoutError("client_status_timeout")
    channel.settimeout(seconds)


class NativeClient:
    """Own one private v3 bridge for local selection proof and later admission."""

    def __init__(self, bridge, *, expected_thread=None):
        """Track one explicit bridge and optional exact resume selection."""
        if expected_thread is not None and not uuid(expected_thread):
            raise LaunchError("invalid_resume_thread")
        self.bridge = bridge
        self.expected_thread = expected_thread
        self.ready = False
        self.lock = threading.Lock()

    def synchronize(self):
        # Startup response is deliberately discarded; it grants no selection.
        with self.lock:
            self.bridge.exchange({}, 30)
            self.ready = True

    def status(self):
        value = {"automaticWakeEnabled": False, "attached": False,
                 "receiptVersion": 3, "selection": "unavailable"}
        if not self.ready:
            return value
        with self.lock:
            try:
                witness = self.bridge.challenge_readonly()
                observation_valid_until = self.bridge.observation_valid_until
            except ValueError:
                return value
        if (not isinstance(witness, dict)
                or not isinstance(witness.get("eligible"), bool)
                or not isinstance(witness.get("cause"), str) or len(witness["cause"]) > 128
                or not all(key in witness for key in BINDING_FIELDS)
                or not _valid_binding(_binding(witness))
                or time.monotonic() >= observation_valid_until
                or (witness["eligible"] and time.monotonic() >= self.bridge.valid_until)
                or (self.expected_thread is not None
                    and witness["threadId"] != self.expected_thread)):
            return value
        value["nativeObservation"] = {
            "eligible": witness["eligible"], "cause": witness["cause"],
            "binding": _binding(witness),
        }
        if witness["eligible"] and time.monotonic() < self.bridge.valid_until:
            value.update(selection="selected", threadId=witness["threadId"],
                         clientId=witness["clientId"],
                         serverInstanceId=witness["serverInstanceId"],
                         serverGeneration=witness["serverGeneration"],
                         generation=witness["generation"])
        return value

    def binding(self):
        """Return only the observed binding tuple; this grants no Start eligibility."""
        if not self.ready:
            raise LaunchError("native_client_not_ready")
        with self.lock:
            try:
                witness = self.bridge.challenge_readonly()
            except ValueError:
                raise LaunchError("native_binding_unavailable") from None
        if (not _valid_native_witness(witness)
                or time.monotonic() >= self.bridge.valid_until
                or (self.expected_thread is not None
                    and witness.get("threadId") != self.expected_thread)):
            raise LaunchError("native_binding_unavailable")
        return _binding(witness)

    def challenge(self, challenge_id, expected_binding):
        """Return a fresh exact native witness for one cloud operation intent."""
        if not self.ready:
            raise LaunchError("native_client_not_ready")
        if not _valid_challenge_id(challenge_id) or not _valid_binding(expected_binding):
            raise LaunchError("invalid_client_challenge")
        with self.lock:
            observed_at = datetime.fromtimestamp(time.time(), timezone.utc).isoformat(
                timespec="milliseconds").replace("+00:00", "Z")
            try:
                witness = self.bridge.challenge()
            except ValueError:
                raise LaunchError("native_binding_unavailable") from None
        if (not _valid_native_witness(witness)
                or time.monotonic() >= self.bridge.valid_until
                or (self.expected_thread is not None
                    and witness.get("threadId") != self.expected_thread)
                or _binding(witness) != expected_binding
                or any(type(witness[key]) is not type(expected_binding[key])
                       for key in BINDING_FIELDS)):
            raise LaunchError("native_binding_changed")
        return {"challengeId": challenge_id, "observedAt": observed_at,
                "validUntilMonotonic": self.bridge.valid_until, "witness": dict(witness)}

    def native_operation(self, operation, binding, request, deadline):
        """Serialize exact conditional Start or read-only recovery on the owned reader."""
        if (not self.ready or operation not in NATIVE_COMMANDS
                or not _valid_binding(binding) or self.bridge.receipt_version != 3):
            raise LaunchError("native_operation_unavailable")
        validate_start(request)
        if any(type(request[key]) is not type(binding[key]) or request[key] != binding[key]
               for key in ("clientId", "serverInstanceId", "serverGeneration", "threadId", "generation")):
            raise LaunchError("native_binding_changed")
        if not self.lock.acquire(timeout=max(0, deadline - time.monotonic())):
            raise LaunchError("native_operation_timeout")
        try:
            if time.monotonic() >= deadline:
                raise LaunchError("native_operation_timeout")
            if operation == "nativeReceipt":
                self.bridge.restore_attempt(request)
                outcome = self.bridge.receipt(request)
            else:
                # Presence calls clear reader eligibility; reacquire and consume it under one lock.
                witness = self.bridge.challenge()
                if (not _valid_native_witness(witness) or _binding(witness) != binding
                        or time.monotonic() >= min(deadline, self.bridge.valid_until)
                        or (self.expected_thread is not None
                            and witness["threadId"] != self.expected_thread)):
                    outcome = {"status": "notStarted", "reason": "selectionChanged"}
                else:
                    outcome = self.bridge.start(request)
            receipt = {**{key: request[key] for key in (*IDENTITY, "generation")}, "outcome": outcome}
            validate_receipt({**request, "receiptVersion": 3}, receipt,
                             allow_input_recorded=operation == "nativeReceipt")
            return receipt
        finally:
            self.lock.release()


def _native_control(channel, client, header, buffered, started):
    if (set(header) != {"command", "expectedBinding", "deadlineMonotonic"}
            or not _valid_binding(header["expectedBinding"])
            or type(header["deadlineMonotonic"]) not in (int, float)
            or not math.isfinite(header["deadlineMonotonic"])):
        raise LaunchError("invalid_native_operation")
    deadline = min(started + NATIVE_OPERATION_SECONDS, header["deadlineMonotonic"])
    data = bytearray(buffered)
    while b"\n" not in data and len(data) < 4096:
        _remaining(channel, deadline)
        chunk = channel.recv(4096 - len(data))
        if not chunk:
            break
        data.extend(chunk)
    if len(data) > 4096 or not data.endswith(b"\n") or data.count(b"\n") != 1:
        raise LaunchError("invalid_native_operation")
    request = json.loads(data, object_pairs_hook=unique, parse_constant=_reject_constant)
    _remaining(channel, deadline)
    value = client.native_operation(header["command"], header["expectedBinding"], request, deadline)
    _remaining(channel, deadline)
    return value


def _control(listener, client, stop):
    while not stop.is_set():
        try:
            channel, _ = listener.accept()
        except TimeoutError:
            continue
        except OSError:
            return
        with channel:
            started = time.monotonic()
            deadline = started + 2
            try:
                data = bytearray()
                while b"\n" not in data and len(data) < 1024:
                    _remaining(channel, deadline)
                    chunk = channel.recv(1024 - len(data))
                    if not chunk:
                        break
                    data.extend(chunk)
                header, newline, buffered = bytes(data).partition(b"\n")
                if not newline or len(header) + 1 > 1024:
                    raise ValueError("invalid_client_request")
                request = json.loads(header, object_pairs_hook=unique, parse_constant=_reject_constant)
                if isinstance(request, dict) and request.get("command") in NATIVE_COMMANDS:
                    value = _native_control(channel, client, request, buffered, started)
                    channel.sendall(json.dumps(value, separators=(",", ":"), allow_nan=False).encode() + b"\n")
                    continue
                if buffered:
                    raise ValueError("invalid_client_request")
                if request == {"command": "status"}:
                    value = client.status()
                elif request == {"command": "binding"}:
                    value = client.binding()
                elif (isinstance(request, dict)
                      and set(request) == {"command", "challengeId", "expectedBinding"}
                      and request["command"] == "challenge"):
                    value = client.challenge(request["challengeId"], request["expectedBinding"])
                else:
                    value = {"reason": "unsupported_command"}
                _remaining(channel, deadline)
                channel.sendall(json.dumps(value, separators=(",", ":"), allow_nan=False).encode() + b"\n")
            except LaunchError as error:
                try:
                    channel.sendall(json.dumps({"reason": str(error)}).encode() + b"\n")
                except OSError:
                    pass
            except (OSError, ValueError, TypeError, RecursionError):
                pass


def _watch_child(pid, stop):
    # Observe exit without reaping: the owned PID must stay reserved until the
    # cleanup signal. PTY EOF alone is not reliable for an unreaped macOS child.
    while not stop.is_set():
        try:
            result = os.waitid(os.P_PID, pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
        except ChildProcessError:
            # Cleanup may already have reaped after stop was set.
            stop.set()
            return
        if result is not None:
            stop.set()
            return
        stop.wait(0.1)


def _stop_process(process):
    # No poll/wait occurs before this sole group signal: the unreaped child
    # retains its PID, preventing reuse from targeting another process group.
    if process is not None:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        except PermissionError:
            # Darwin can return EPERM for a zombie-only group. Keep
            # the child unreaped while checking this exact identity;
            # a still-running leader remains a cleanup failure.
            exited = os.waitid(os.P_PID, process.pid,
                               os.WEXITED | os.WNOHANG | os.WNOWAIT)
            if exited is None:
                raise
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            raise LaunchError("native_process_cleanup_timeout") from None


def _start_worker(target, arguments):
    worker = threading.Thread(target=target, args=arguments, daemon=True)
    try:
        worker.start()
    except RuntimeError:
        raise LaunchError("native_worker_start_failed") from None
    return worker


def _validate_launch(state_dir, cwd, resume):
    if threading.current_thread() is not threading.main_thread() or threading.active_count() != 1:
        raise LaunchError("launch_requires_single_thread")
    if not os.isatty(0) or not os.isatty(1):
        raise LaunchError("interactive_terminal_required")
    env = launch_environment(os.environ)
    if resume is not None and not uuid(resume):
        raise LaunchError("invalid_resume_thread")
    cwd = Path(cwd).resolve(strict=True)
    if not cwd.is_dir():
        raise LaunchError("invalid_client_directory")
    ensure_private_directory(state_dir)
    return env, cwd


def launch(state_dir, binary, digest, cwd, *, resume=None):
    """Run a visible native TUI; expose only bounded local status and witness control."""
    env, cwd = _validate_launch(state_dir, cwd, resume)
    session_id = str(uuid4())
    path = session_path(state_dir, session_id)
    parent = child = listener = bridge = process = None
    master = slave = None
    workers = []
    stop = threading.Event()
    interrupted = threading.Event()
    startup_failed = threading.Event()
    previous = {}

    def stop_launch(signum, _frame):
        if signum == signal.SIGINT:
            interrupted.set()
        stop.set()

    def check_stop():
        if stop.is_set():
            if interrupted.is_set():
                raise KeyboardInterrupt
            raise LaunchError("native_launch_interrupted")

    try:
        for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
            previous[sig] = signal.signal(sig, stop_launch)
        listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        listener.bind(str(path))
        os.chmod(path, 0o600)
        listener.listen(4)
        listener.settimeout(0.2)
        parent, child = socket.socketpair()
        bridge = NativeBridge(parent, receipt_version=3)
        master, slave = pty.openpty()
        env.update(CODEX_NATIVE_BRIDGE_FD=str(child.fileno()),
                   CODEX_NATIVE_BRIDGE_RECEIPT_VERSION="3")
        binary = qualified_binary(binary, digest)
        check_stop()
        command = [str(binary), "--no-daemon", "--no-alt-screen", "-C", str(cwd)]
        if resume:
            command += ["resume", resume]
        process = subprocess.Popen(  # nosec B603 - qualified absolute native executable
            command, env=env, cwd=cwd, stdin=slave, stdout=slave, stderr=slave,
            pass_fds=(child.fileno(),), start_new_session=True,
            preexec_fn=_claim_terminal,
        )
        check_stop()
        child.close()
        os.close(slave)
        slave = None
        client = NativeClient(bridge, expected_thread=resume)

        def synchronize():
            try:
                client.synchronize()
            except (OSError, ValueError):
                startup_failed.set()
                stop.set()

        for target, arguments in (
            (synchronize, ()), (_control, (listener, client, stop)),
            (_watch_child, (process.pid, stop)),
        ):
            workers.append(_start_worker(target, arguments))
        print("Local Codex session: " + session_id + " (automatic delivery disabled)", flush=True)
        run_terminal(master, stop_event=stop)
    finally:
        stop.set()
        try:
            if bridge is not None:
                bridge.close()
            elif parent is not None:
                parent.close()
            if child is not None:
                child.close()
            if listener is not None:
                listener.close()
            try:
                _stop_process(process)
            finally:
                for worker in workers:
                    worker.join(timeout=1)
                for fd in (master, slave):
                    if fd is not None:
                        os.close(fd)
                path.unlink(missing_ok=True)
        finally:
            for sig, handler in previous.items():
                signal.signal(sig, handler)
    if interrupted.is_set():
        raise KeyboardInterrupt
    if startup_failed.is_set():
        raise LaunchError("native_bridge_startup_failed")
    return process.returncode if process.returncode >= 0 else 128 - process.returncode
