import { z } from "zod";
import {
  EVENT_CLOCK_SKEW_MS,
  EVENT_FRESHNESS_LIFETIME_MS,
  MAX_PROTOCOL_MESSAGE_BYTES,
} from "../policy.js";
import { AssignedStockRuntimeProfileSchema, decodeProtocolJson, EventProtocolError, isUuidV4OrV7 } from "../protocol.js";

/** Contract only: no producer, transport, or native capability is enabled. */
export const MESSAGING_PROTOCOL_VERSION = 2;

const uuidSchema = z.string().refine(isUuidV4OrV7);
const generationSchema = z.number().int().min(1).max(Number.MAX_SAFE_INTEGER);
const sourceVersionSchema = z.string().regex(/^msg:[a-f0-9]{64}$/);
const timestampSchema = z.iso.datetime({ precision: 3 });
const principalSchema = z.string().max(254).regex(
  /^(?=[^@]{1,64}@)[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/,
);
const destinationShape = {
  nodeId: uuidSchema,
  runtimeId: uuidSchema,
  nodeGeneration: generationSchema,
  runtimeGeneration: generationSchema,
  attachmentGeneration: generationSchema,
  consumerGeneration: generationSchema,
  routingGeneration: generationSchema,
};
const attemptShape = {
  schemaVersion: z.literal(MESSAGING_PROTOCOL_VERSION),
  eventId: uuidSchema,
  deliveryId: z.string().regex(/^dly_[0-9a-f]{64}$/),
  attemptId: uuidSchema,
  principal: principalSchema,
  agent: z.string().regex(/^[a-z0-9-]{1,32}$/),
  ...destinationShape,
};

function consumerMatchesAttachment(value: {
  consumerGeneration: number;
  attachmentGeneration: number;
}): boolean {
  return value.consumerGeneration === value.attachmentGeneration;
}

/** Strict metadata: publication-tuple authenticity is checked by the caller. */
export const MessagingEnvelopeV2Schema = z.strictObject({
  ...attemptShape,
  source: z.literal("messaging"),
  eventKind: z.literal("message"),
  reasonCode: z.literal("inbox_message"),
  runtimeProfile: AssignedStockRuntimeProfileSchema.optional(),
  canonicalSubject: z.strictObject({
    kind: z.literal("message"),
    namespace: z.string().min(1).max(256).refine(
      // eslint-disable-next-line no-control-regex -- The contract expressly forbids ASCII controls.
      value => !/[\u0000-\u001f\u007f]/.test(value),
      { message: "namespace must not contain ASCII controls" },
    ),
    messageId: uuidSchema,
    agentIncarnation: z.number().int().min(0).max(Number.MAX_SAFE_INTEGER),
  }),
  sourceStateVersion: sourceVersionSchema,
  policyRevision: generationSchema,
  eventReference: z.string().refine(
    value => value.startsWith("ref_") && isUuidV4OrV7(value.slice(4)),
  ),
  observedAt: timestampSchema,
  issuedAt: timestampSchema,
  expiresAt: timestampSchema,
}).refine(value => consumerMatchesAttachment(value) && (!value.runtimeProfile || value.consumerGeneration === value.attachmentGeneration), {
  message: "consumerGeneration must equal attachmentGeneration",
});

const acknowledgmentShape = {
  ...attemptShape,
  deliveredSourceStateVersion: sourceVersionSchema,
  acknowledgedAt: timestampSchema,
};
const submittedSchema = z.strictObject({
  ...acknowledgmentShape,
  status: z.literal("submitted"),
  nativeCorrelation: z.strictObject({
    kind: z.literal("native_turn_started"),
    permitId: uuidSchema,
    turnId: uuidSchema,
  }),
}).refine(consumerMatchesAttachment);
const observedSchema = z.strictObject({
  ...acknowledgmentShape,
  status: z.literal("observed"),
  nativeCorrelation: z.strictObject({
    kind: z.literal("native_input_recorded"),
    permitId: uuidSchema,
    turnId: uuidSchema,
    itemId: uuidSchema,
  }).refine(value => value.itemId !== value.turnId, {
    message: "itemId must differ from turnId",
  }),
}).refine(consumerMatchesAttachment);
const stockCommandAcceptedSchema = z.strictObject({
  ...acknowledgmentShape,
  runtimeProfile: AssignedStockRuntimeProfileSchema,
  permitId: uuidSchema,
  status: z.literal("command_accepted"),
}).refine(consumerMatchesAttachment);

export const MessagingObservationAckV2Schema = z.union([
  submittedSchema,
  observedSchema,
  stockCommandAcceptedSchema,
]);
export const MessagingStockCommandAcceptedAckV2Schema = stockCommandAcceptedSchema;
export const MessagingProtocolMessageV2Schema = z.union([
  MessagingEnvelopeV2Schema,
  MessagingObservationAckV2Schema,
]);
export type MessagingEnvelopeV2 = z.infer<typeof MessagingEnvelopeV2Schema>;
export type MessagingObservationAckV2 = z.infer<typeof MessagingObservationAckV2Schema>;

function canonicalTimestampMs(value: string): number | null {
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)) return null;
  const milliseconds = Date.parse(value);
  return Number.isFinite(milliseconds) && new Date(milliseconds).toISOString() === value
    ? milliseconds : null;
}

function fitsMessageLimit(value: unknown): boolean {
  try {
    const json = JSON.stringify(value);
    return typeof json === "string"
      && new TextEncoder().encode(json).byteLength <= MAX_PROTOCOL_MESSAGE_BYTES;
  } catch {
    return false;
  }
}

/** Already-decoded DTO only; this is not a duplicate-key-safe wire parser. */
export function validateMessagingEnvelopeV2(
  value: unknown,
  nowMs = Date.now(),
): value is MessagingEnvelopeV2 {
  const parsed = MessagingEnvelopeV2Schema.safeParse(value);
  if (!parsed.success || !fitsMessageLimit(value) || !Number.isFinite(nowMs)) return false;
  const { issuedAt, expiresAt, observedAt } = parsed.data;
  const issued = canonicalTimestampMs(issuedAt);
  const expires = canonicalTimestampMs(expiresAt);
  const observed = canonicalTimestampMs(observedAt);
  return issued !== null && expires !== null && observed !== null
    && expires > issued
    && expires - issued <= EVENT_FRESHNESS_LIFETIME_MS
    && issued <= nowMs + EVENT_CLOCK_SKEW_MS
    && nowMs <= expires + EVENT_CLOCK_SKEW_MS
    && observed <= issued + EVENT_CLOCK_SKEW_MS
    && observed <= nowMs + EVENT_CLOCK_SKEW_MS;
}

/** Already-decoded DTO only; authenticate the runtime before accepting it. */
export function validateMessagingObservationAckV2(
  value: unknown,
  nowMs = Date.now(),
): value is MessagingObservationAckV2 {
  const parsed = MessagingObservationAckV2Schema.safeParse(value);
  if (!parsed.success || !fitsMessageLimit(value) || !Number.isFinite(nowMs)) return false;
  const acknowledged = canonicalTimestampMs(parsed.data.acknowledgedAt);
  return acknowledged !== null && acknowledged <= nowMs + EVENT_CLOCK_SKEW_MS;
}

/** Decode exact wire input before schema validation; signature verification stays external. */
function decodeMessagingWireV2(raw: string | Uint8Array): unknown {
  if (typeof raw !== "string" && !(raw instanceof Uint8Array)) throw new EventProtocolError("invalid_json");
  if (raw.length > MAX_PROTOCOL_MESSAGE_BYTES) throw new EventProtocolError("message_too_large");
  let json: string;
  try {
    // Preserve a BOM so JSON parsing rejects it; never replace malformed UTF-8.
    const decoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });
    if (typeof raw === "string") {
      const bytes = new TextEncoder().encode(raw);
      if (bytes.byteLength > MAX_PROTOCOL_MESSAGE_BYTES) throw new EventProtocolError("message_too_large");
      if (decoder.decode(bytes) !== raw) throw new EventProtocolError("invalid_json");
      json = raw;
    } else json = decoder.decode(raw);
  } catch (error) {
    if (error instanceof EventProtocolError) throw error;
    throw new EventProtocolError("invalid_json");
  }
  return decodeProtocolJson(json);
}

/** Dormant wire parser. Before persistence, separately authenticate bytes and verify delivery identity/authority. */
export function parseMessagingEnvelopeV2(raw: string | Uint8Array, nowMs = Date.now()): MessagingEnvelopeV2 {
  const parsed = MessagingEnvelopeV2Schema.safeParse(decodeMessagingWireV2(raw));
  if (!parsed.success) throw new EventProtocolError("invalid_envelope");
  if (!validateMessagingEnvelopeV2(parsed.data, nowMs)) throw new EventProtocolError("stale_message");
  return parsed.data;
}

/** Dormant ACK wire parser; parsing never authenticates native receipt provenance. */
export function parseMessagingObservationAckV2(raw: string | Uint8Array, nowMs = Date.now()): MessagingObservationAckV2 {
  const parsed = MessagingObservationAckV2Schema.safeParse(decodeMessagingWireV2(raw));
  if (!parsed.success) throw new EventProtocolError("invalid_acknowledgment");
  if (!validateMessagingObservationAckV2(parsed.data, nowMs)) throw new EventProtocolError("stale_message");
  return parsed.data;
}

const identitySchema = z.strictObject({
  eventId: uuidSchema,
  ...destinationShape,
}).refine(consumerMatchesAttachment);
export type MessagingDeliveryIdentityV2 = z.infer<typeof identitySchema>;

/** Versioned canonical array, stable across retry attempts and timestamps. */
export async function deriveMessagingDeliveryIdV2(
  identity: MessagingDeliveryIdentityV2,
): Promise<string> {
  const parsed = identitySchema.safeParse({
    eventId: identity.eventId,
    nodeId: identity.nodeId,
    runtimeId: identity.runtimeId,
    nodeGeneration: identity.nodeGeneration,
    runtimeGeneration: identity.runtimeGeneration,
    attachmentGeneration: identity.attachmentGeneration,
    consumerGeneration: identity.consumerGeneration,
    routingGeneration: identity.routingGeneration,
  });
  if (!parsed.success) throw new EventProtocolError("invalid_delivery_identity");
  const value = parsed.data;
  const canonical = JSON.stringify([
    MESSAGING_PROTOCOL_VERSION, value.eventId, value.nodeId, value.runtimeId,
    value.nodeGeneration, value.runtimeGeneration, value.attachmentGeneration,
    value.consumerGeneration, value.routingGeneration,
  ]);
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonical));
  return `dly_${Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("")}`;
}

export async function matchesMessagingDeliveryIdV2(envelope: MessagingEnvelopeV2): Promise<boolean> {
  try {
    return envelope.deliveryId === await deriveMessagingDeliveryIdV2(envelope);
  } catch {
    return false;
  }
}

/** Call with validated DTOs; every destination/routing/attempt field is fenced. */
export function messagingAcknowledgmentMatchesDeliveryV2(
  envelope: MessagingEnvelopeV2,
  acknowledgment: MessagingObservationAckV2,
): boolean {
  return acknowledgment.schemaVersion === envelope.schemaVersion
    && acknowledgment.eventId === envelope.eventId
    && acknowledgment.deliveryId === envelope.deliveryId
    && acknowledgment.attemptId === envelope.attemptId
    && acknowledgment.principal === envelope.principal
    && acknowledgment.agent === envelope.agent
    && acknowledgment.nodeId === envelope.nodeId
    && acknowledgment.runtimeId === envelope.runtimeId
    && acknowledgment.nodeGeneration === envelope.nodeGeneration
    && acknowledgment.runtimeGeneration === envelope.runtimeGeneration
    && acknowledgment.attachmentGeneration === envelope.attachmentGeneration
    && acknowledgment.consumerGeneration === envelope.consumerGeneration
    && acknowledgment.routingGeneration === envelope.routingGeneration
    && acknowledgment.deliveredSourceStateVersion === envelope.sourceStateVersion
    && ("runtimeProfile" in envelope
      ? acknowledgment.status === "command_accepted" && "runtimeProfile" in acknowledgment
        && JSON.stringify(acknowledgment.runtimeProfile) === JSON.stringify(envelope.runtimeProfile)
      : acknowledgment.status !== "command_accepted");
}

