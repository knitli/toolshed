// verifyHumanProof (R4 plan 6.7): one function the Workers and the bundled offline verifier share, over WebCrypto only. It takes rpId, origin, aud, the anchors
// and the assurance floors from `pinned`, the verifier's own configuration, and never from the act or the evidence (AT-22): a bundle that carried its own
// anchor would verify itself. Every refusal is one reason code; a proof that passes says a person touched a pinned or chained key over this exact act, and
// nothing about whether it is wise or still in force (INV1). Pure TypeScript: no Worker types, no I/O.
//
// Recovery (a break-glass key enrolling a replacement for another person, plan F4) is not here: it lands in 5a-2 with a pinned break-glass rule. A chain link
// of any kind but enroll-credential is chain_broken.
//
// Limits of the proof, stated here because a reader of a verdict cannot see them:
//  - evidence.credentialId is a hint and no part of the trust path. The signing key is chain[0].credential, bound to a pin by the chain and to the
//    assertion by the signature; a credentialId that names another credential changes nothing.
//  - Offline verification cannot see revocation (an order's or a credential's), and cannot see a clock but the broker's.
//  - Offline, the activation delay of a chained credential is measured with the issuedAt that Messaging wrote into each enroll act. That time is not
//    broker-signed, so a compromised Messaging could backdate an enrollment to skip the delay. It still needs both keys' touches over the act, and
//    the chain must still end at a pin, so it can shorten a waiting period and nothing else.
import { actChallenge, isActKind, type Act, type ActKind, type Assurance } from "./act.ts";
import { snapshot } from "./snapshot.ts";
import { effectiveFloor, needsUserVerification } from "./floor.ts";
import { isoTime } from "./contract-kit.ts";
import { readAct, verifyCredentialChain, type ChainLink, type ChainReason, type ShapeReason } from "./credential-chain.ts";
import { checkAssertion, pinSetOf, readPinned, samePinSet, type AssertionReason, type Evidence, type PinnedPresence } from "./webauthn.ts";

type FixedReason = ShapeReason | AssertionReason | ChainReason | "assurance_below_floor" | "expired_window" | "clock" | "credential_inactive" | "counter_replay" | "expectation_missing" | "signer_is_subject" | "signer_not_parent" | "not_pinned";
/** Every fixed reason, once: the contract's closed reason set is this list, and the check below fails to compile if a reason is added to the union and not here. */
export const PROOF_REASONS = [
  "act_malformed", "aud_mismatch", "rp_mismatch",
  "evidence_malformed", "bad_type", "challenge_mismatch", "origin_mismatch", "cross_origin", "rp_hash_mismatch", "up_missing", "uv_missing", "be_set", "flags", "bad_signature",
  "chain_broken", "unanchored", "credential_revoked",
  "assurance_below_floor", "expired_window", "clock", "credential_inactive", "counter_replay", "expectation_missing", "signer_is_subject", "signer_not_parent", "not_pinned",
] as const satisfies readonly FixedReason[];
export const PROOF_REASONS_COMPLETE: Exclude<FixedReason, (typeof PROOF_REASONS)[number]> extends never ? true : never = true;

export type ProofReason = FixedReason | `order_mismatch:${string}` | `subject_mismatch:${string}`;

type Subject = (subject: Act["subject"]) => string | null;
/**
 * What the caller independently holds, all of it required: a caller that forgot a part would verify a proof of some act, which is not a proof of the act
 * it is about to apply. `subject` returns the name of the first field that differs, or null; every kind has a subject to bind, so every kind passes one.
 * For an order, `taskType` and `declaredMinAssurance` (the receiver's declared minimum, which may raise the pinned floor and never lower it) are required
 * too, since omitting the declaration would silently drop the receiver's floor.
 */
export type ProofExpect = { principal: string; subject: Subject } & (
  | { kind: "order"; taskType: string; declaredMinAssurance: Assurance }
  | { kind: Exclude<ActKind, "order">; declaredMinAssurance?: Assurance }
);

/**
 * Online, the live state of the signing credential from the Mailbox's own store (`live.thumbprint` names whose, and must be the signer's); offline, the broker-signed time of the receipt the act rides on.
 * `brokerIssuedAt` must come from a receipt the caller has already verified (signature and chain); this function does not check where it came from,
 * and binding it to the act (the receipt's id and digest against the act's) is the offline verifier's job in 5b-1.
 */
export type ProofFreshness =
  | { online: true; now: number; live: { thumbprint: string; active: boolean; counter: number }; revoked: readonly string[] } // revoked: required, so leaving it out is a compile error and not a silent skip
  | { online: false; brokerIssuedAt: string };

export type ProofResult =
  | { valid: true; credential: string; anchored: true; attestation: "not claimed"; uv: boolean; draftedBy: string; counter: number }
  | { valid: false; reason: ProofReason };

export type ProofInput = { act: unknown; evidence: Evidence; chain: readonly ChainLink[]; pinned: PinnedPresence; expect: ProofExpect; fresh: ProofFreshness };

const OFFLINE_SKEW_MS = 30_000;
const no = (reason: ProofReason): ProofResult => ({ valid: false, reason });

/**
 * Steps 1 to 9. `act` is the stored act as parsed JSON (the challenge is recomputed from it, not taken from anywhere); `evidence` carries the raw
 * clientDataJSON; `chain` starts with the signing credential. Revocation and counters are online-only: an offline pass says so by `online: false`.
 */
export async function verifyHumanProof(input: ProofInput): Promise<ProofResult> {
  try {
    return await verify(input);
  } catch {
    return no("evidence_malformed"); // the evidence is a bundle's: whatever shape it has, a throw is a refusal and never a pass
  }
}

type Expectation = { kind: ActKind; principal: string; subject: (subject: Act["subject"]) => string | null; taskType?: string; declaredMinAssurance?: Assurance };

/** The caller's expectation as a value, read once: its scalars are copied and its comparator taken, so nothing is asked of the caller's object twice. Null when it is not a whole expectation (a JS or offline caller, or a JSON round trip that dropped a function, must not read as "nothing to compare"). */
function expectationOf(given: unknown): Expectation | null {
  if (given === null || typeof given !== "object") return null;
  const e = given as Partial<{ kind: unknown; principal: unknown; subject: unknown; taskType: unknown; declaredMinAssurance: unknown }>;
  const { kind, principal, subject, taskType, declaredMinAssurance } = e;
  if (!isActKind(kind) || typeof principal !== "string" || typeof subject !== "function") return null;
  if (declaredMinAssurance !== undefined && declaredMinAssurance !== "hw-uv" && declaredMinAssurance !== "hw-up") return null;
  if (kind === "order" && (typeof taskType !== "string" || declaredMinAssurance === undefined)) return null;
  return { kind, principal, subject: subject as Expectation["subject"], ...(typeof taskType === "string" && { taskType }), ...(declaredMinAssurance !== undefined && { declaredMinAssurance }) };
}

const deepFreeze = <T>(value: T): T => {
  if (value !== null && typeof value === "object") for (const entry of Object.values(value)) deepFreeze(entry);
  return Object.freeze(value);
};

async function verify(input: ProofInput): Promise<ProofResult> {
  // Each member of the input is read once. The expectation's scalars are copied, and everything else is a plain-data copy: what the checks below see is
  // what was read, so a getter that answers differently the second time cannot split the credential that is checked from the one that signs.
  const { act: givenAct, evidence: givenEvidence, chain: givenChain, pinned: givenPinned, expect: givenExpect, fresh: givenFresh } = input;
  const expect = expectationOf(givenExpect);
  if (!expect) return no("expectation_missing");
  const actRead = snapshot(givenAct);
  const read = snapshot({ evidence: givenEvidence, chain: givenChain, fresh: givenFresh });
  const pinned = readPinned(givenPinned, "full");
  if (!pinned) return no("expectation_missing"); // the verifier's own configuration is not one a pinned file could hold
  if (!actRead) return no("act_malformed");
  if (!read) return no("evidence_malformed");
  const { evidence, chain: inputChain, fresh } = read.value as { evidence: Evidence; chain: readonly ChainLink[]; fresh: ProofFreshness };
  // The caller's freshness is a value, not a type: only the two real spellings are a freshness at all.
  if (fresh === null || typeof fresh !== "object" || (fresh.online !== true && fresh.online !== false)) return no("expectation_missing");

  // 1 shape
  const parsed = await readAct(actRead.value, pinned);
  if (!parsed.ok) return no(parsed.reason);
  const act = parsed.act;
  const signer = Array.isArray(inputChain) ? inputChain[0] : undefined;

  // 2 challenge: recomputed from the act, here
  const challenge = await actChallenge(act);

  // 4 (floor half) the pinned floor for this kind and type, raised by a declaration, never lowered by the act
  const type = act.kind === "order" ? (act.subject as { taskType: string }).taskType : undefined;
  const floor = effectiveFloor(act, pinned.floors, expect.declaredMinAssurance);
  if (floor === "hw-uv" && act.assurance !== "hw-uv") return no("assurance_below_floor");
  const requireUv = needsUserVerification(act, pinned.floors, expect.declaredMinAssurance);

  // 3, 4, 5 clientData, authData, signature
  if (!signer) return no("chain_broken");
  const assertion = await checkAssertion({ challenge, evidence, key: signer.credential, pinned, requireUv });
  if (!assertion.ok) return no(assertion.reason);

  // 6 chain to a pinned anchor
  const chain = await verifyCredentialChain({ principal: act.principal, chain: inputChain, at: isoTime(act.issuedAt), pinned, revoked: fresh.online ? fresh.revoked : null });
  if (!chain.ok) return no(chain.reason);

  // A revocation that needs a proof needs another credential's: a key does not sign away its own revocation (plan 6.3).
  if (act.kind === "revoke-credential" && (act.subject as { credentialThumbprint: string }).credentialThumbprint === chain.signer) return no("signer_is_subject");

  // The relationship an act implies between its subject and the key that signs it (plan 6.3): a credential is enrolled by its named parent, and a liveness
  // proof is made by one of the keys it lists. Otherwise the ceremony would store evidence that no chain or liveness check could ever accept.
  if (act.kind === "enroll-credential" && (act.subject as { parentThumbprint: string }).parentThumbprint !== chain.signer) return no("signer_not_parent");
  // A liveness proof is made by a pinned anchor itself (no chain), one of the keys the act lists, and the act lists exactly what the deployment pins for this person.
  if (act.kind === "anchor-liveness") {
    const listed = (act.subject as { thumbprints: string[] }).thumbprints;
    if (chain.links !== 0 || !listed.includes(chain.signer) || !samePinSet(listed, pinSetOf(pinned.anchors, act.principal))) return no("not_pinned");
  }

  // 7 binding to what the caller independently holds. The comparator gets a frozen copy: it can read the subject and nothing it does changes what was proved.
  const mismatch = `${act.kind === "order" ? "order" : "subject"}_mismatch` as const;
  const differs =
    act.kind !== expect.kind ? "kind"
    : act.principal !== expect.principal ? "principal"
    : expect.kind === "order" && expect.taskType !== type ? "taskType"
    : expect.subject(deepFreeze(structuredClone(act.subject)));
  if (differs !== null) return no(`${mismatch}:${differs}`);

  // A clock that is not a finite number compares false with everything, so it would read as "in the window": it is no clock.
  if (fresh.online && !Number.isFinite(fresh.now)) return no("clock");

  // 8 freshness: the broker-signed time offline, the clock online; a WebAuthn assertion carries no timestamp, so the nonce is all there is
  const opened = isoTime(act.issuedAt);
  const closes = isoTime(act.windowExpiresAt);
  if (fresh.online) {
    if (fresh.now < opened) return no("clock");
    if (fresh.now > closes) return no("expired_window");
  } else {
    const at = isoTime(fresh.brokerIssuedAt);
    if (Number.isNaN(at) || at < opened) return no("clock");
    if (at > closes + OFFLINE_SKEW_MS) return no("expired_window");
  }

  // 9 online only: the credential is live, and a non-synced counter moves forward (a clone repeats or falls back)
  if (fresh.online) {
    // The live state is only evidence about the credential it names: another credential's (active, higher counter) says nothing about this signer.
    if (fresh.live.thumbprint !== chain.signer || fresh.live.active !== true) return no("credential_inactive");
    // A counter that is not a non-negative integer compares false with everything, so a replay would read as fresh: it is no counter.
    if (!Number.isSafeInteger(fresh.live.counter) || fresh.live.counter < 0) return no("counter_replay");
    if ((assertion.counter !== 0 || fresh.live.counter !== 0) && assertion.counter <= fresh.live.counter) return no("counter_replay");
  }

  return { valid: true, credential: chain.signer, anchored: true, attestation: "not claimed", uv: assertion.uv, draftedBy: act.draftedBy === "human" ? "human" : `agent:${act.draftedBy.agent}`, counter: assertion.counter };
}
