// The activation policy (R4 plan 8.2): which messages may start a turn for an agent without its person typing. One pure function,
// `wakeAllowed`, decides; the Mailbox's wake path (`#fire`) is the one call site, and the Event bridge will be the second (P5b).
//
// OBSERVE ONLY in this phase (plan 15, P4a): the function runs on every wake that reaches it, and what it WOULD have decided is counted
// for the owner (D7 depends on those counts), but the wake itself is exactly what it was. Enforcement, the `not_ordered` and `off` outcomes
// and the order lookup arrive with orders in P5b, so `order` below is always null today: no order can exist yet. Delivery is never blocked by
// this policy (plan 8.2): a message that does not wake is still filed.
//
// Plain synchronous functions over the Mailbox's SQLite and kv; the Mailbox is the only caller, and its callers authorize.

import { MAX_SENDERS } from "authority/src/contract-kit.ts";
import { parseAddress, wireOf, fail } from "./model.ts";
import { hasAgent } from "./registry.ts";

export const MODES = ["order-only", "granted", "off"] as const;
export type Mode = (typeof MODES)[number];
export const TRANSPORTS = ["os-hook", "oauth-webhook", "event"] as const;
export type Transport = (typeof TRANSPORTS)[number];

export { MAX_SENDERS };

/**
 * An agent's policy as stored (plan 5.5). `senders` null: any sender whose live grant covers the message (the behavior of every hook enabled before
 * this phase, which the Mailbox only delivers under a grant); a list narrows that. `legacy`: the row existed before activation policy did.
 * `transports` is what the owner chose; the agent wakes through the OS hook until it says otherwise.
 */
export type ActivationPolicy = { agent: string; mode: Mode; senders: string[] | null; transports: Transport[]; legacy: boolean };

/** Why a message did or did not start a turn (plan 8.2). */
export type ActivationVerdictV1 = Readonly<{
  allowed: boolean;
  reason: "owner_direct" | "order" | "wake_grant" | "granted" | "no_order" | "policy_off" | "suspended" | "budget" | "transport";
  orderDigest?: string;
  root?: boolean;
}>;

/** A live order covering the message, as the Mailbox will find it from P5b: in this agent's own Mailbox, never a receipt's claim (VS-07). Always null before then. */
export type LiveOrder = Readonly<{ digest: string; root: boolean }>;

export type WakeFacts = {
  /** The sender, as a wire address ("principal/agent"). */
  sender: string;
  transport: Transport;
  order: LiveOrder | null;
  /** A live hardware-signed grant from the sender to this agent carries the `wake` right for this message's inform-class type (F5, P5c-b). Nothing computes it before 5b-2; absent means false. */
  wakeGrant?: boolean;
  /** Set only from a canonical, owner-authorized manual Event source. */
  ownerDirect?: boolean;
  suspended: boolean;
  /** The wake allowance (10 an hour, one pending) is spent. */
  overBudget: boolean;
};

/**
 * Whether a message may start a turn for `policy`'s agent. Pure: the facts come in, a verdict goes out, and the same facts always give the same
 * verdict. The order of the reasons is the order a person would ask them in: is the agent able to act at all (suspended, off), does the transport
 * count, is there an order, is there a granted sender, and last the wake allowance, which an unordered message never reaches.
 */
export function wakeAllowed(policy: ActivationPolicy, facts: WakeFacts): ActivationVerdictV1 {
  if (facts.suspended) return { allowed: false, reason: "suspended" };
  if (policy.mode === "off") return { allowed: false, reason: "policy_off" };
  if (!policy.transports.includes(facts.transport)) return { allowed: false, reason: "transport" };
  let verdict: ActivationVerdictV1;
  if (facts.ownerDirect === true) verdict = { allowed: true, reason: "owner_direct" };
  else if (facts.order !== null) verdict = { allowed: true, reason: "order", orderDigest: facts.order.digest, root: facts.order.root };
  else if (facts.wakeGrant === true) verdict = { allowed: true, reason: "wake_grant" };
  else if (policy.mode === "granted" && (policy.senders === null || policy.senders.includes(facts.sender))) verdict = { allowed: true, reason: "granted" };
  else return { allowed: false, reason: "no_order" };
  return facts.overBudget ? { allowed: false, reason: "budget" } : verdict;
}

// --- storage (columns of `agents`) ------------------------------------------------------------------------

type Row = { name: string; activation_mode: Mode; activation_senders: string | null; activation_transports: string | null; activation_legacy: number };

/** The transports an agent wakes through until its owner chooses others: what exists today. */
const DEFAULT_TRANSPORTS: readonly Transport[] = ["os-hook"];

const listOf = <T extends string>(json: string | null, allowed: readonly T[] | null): T[] | null => {
  if (json === null) return null;
  try {
    const parsed: unknown = JSON.parse(json);
    return Array.isArray(parsed) && parsed.every((item) => typeof item === "string" && (allowed === null || allowed.includes(item as T))) ? (parsed as T[]) : null;
  } catch {
    return null;
  }
};

/** `agent`'s policy, or null when there is no such agent. A transports or senders list that does not read back as a list of the known kind reads as the default (the OS hook) or as no list. */
export function policyOf(sql: SqlStorage, agent: string): ActivationPolicy | null {
  const row = sql.exec<Row>("SELECT name, activation_mode, activation_senders, activation_transports, activation_legacy FROM agents WHERE name = ?", agent).toArray()[0];
  if (!row) return null;
  return {
    agent: row.name,
    mode: row.activation_mode, // the column's CHECK keeps it one of the three
    senders: row.activation_mode === "granted" ? listOf<string>(row.activation_senders, null) : null,
    transports: listOf<Transport>(row.activation_transports, TRANSPORTS) ?? [...DEFAULT_TRANSPORTS],
    legacy: row.activation_legacy === 1,
  };
}

/** Whether a policy is more than a new agent's default (plan 5.11): it lets an agent start a turn without an order, or through more than the OS hook. */
export const beyondDefault = (policy: Pick<ActivationPolicy, "mode" | "transports">): boolean => policy.mode === "granted" || policy.transports.some((t) => !DEFAULT_TRANSPORTS.includes(t));

/**
 * Whether setting `next` lets more start a turn than `current` does (plan 5.11): to `granted`, another transport, or a sender list that grows (null is
 * any sender). The opposite direction is narrowing, and the session may do it.
 */
export function activationWidens(current: Pick<ActivationPolicy, "mode" | "senders" | "transports">, next: ReturnType<typeof parseActivation>): boolean {
  if (next.mode === "granted" && current.mode !== "granted") return true;
  if (next.transports.some((t) => !current.transports.includes(t))) return true;
  return next.mode === "granted" && current.senders !== null && (next.senders === null || next.senders.some((sender) => !current.senders!.includes(sender)));
}

/** What an owner may set: the mode, and for `granted` the senders; `transports` default to the OS hook. */
export type ActivationInput = { mode: Mode; senders?: string[] | null; transports?: Transport[] | null };

/** A policy from owner input, or a refusal. `senders` apply only to `granted` (plan 8.2), so naming them for another mode is refused rather than stored and ignored. */
export function parseActivation(input: unknown): { mode: Mode; senders: string[] | null; transports: Transport[] } {
  if (input === null || typeof input !== "object" || Array.isArray(input)) throw fail("invalid", "activation is { mode, senders?, transports? }");
  const { mode, senders, transports, ...rest } = input as Record<string, unknown>;
  if (Object.keys(rest).length > 0) throw fail("invalid", "activation is { mode, senders?, transports? }");
  if (!(MODES as readonly unknown[]).includes(mode)) throw fail("invalid", `mode is one of ${MODES.join(", ")}`);
  if (senders != null && mode !== "granted") throw fail("invalid", "senders apply only to granted mode");
  let list: string[] | null = null;
  if (senders != null) {
    if (!Array.isArray(senders) || senders.length > MAX_SENDERS) throw fail("invalid", `senders lists at most ${MAX_SENDERS} agents`);
    list = [...new Set(senders.map((sender) => {
      const address = parseAddress(sender);
      if (address === null || address.agent === null) throw fail("invalid", 'a sender is an agent, as "email/name"');
      return wireOf(address);
    }))].toSorted();
  }
  if (transports != null && (!Array.isArray(transports) || transports.length < 1 || !transports.every((t) => (TRANSPORTS as readonly unknown[]).includes(t)))) throw fail("invalid", `transports lists at least one of ${TRANSPORTS.join(", ")}`);
  return { mode: mode as Mode, senders: list, transports: transports == null ? [...DEFAULT_TRANSPORTS] : ([...new Set(transports as Transport[])].toSorted() as Transport[]) };
}

/** Stores a policy. A legacy row stays marked legacy until P5b says otherwise: setting it is the owner's choice, not a migration. */
export function setPolicy(sql: SqlStorage, agent: string, policy: ReturnType<typeof parseActivation>): ActivationPolicy {
  if (!hasAgent(sql, agent)) throw fail("not_found", `no agent named ${agent}`);
  sql.exec(
    "UPDATE agents SET activation_mode = ?, activation_senders = ?, activation_transports = ? WHERE name = ?",
    policy.mode, policy.senders === null ? null : JSON.stringify(policy.senders), JSON.stringify(policy.transports), agent,
  );
  return policyOf(sql, agent)!;
}

// --- the observe record -----------------------------------------------------------------------------------

/**
 * What the policy would have done, counted per agent in the Mailbox's kv (one small record, so it cannot grow): how many wakes reached it, how
 * many it would have let through, and how many of the rest it would have suppressed by policy (not by suspension or the allowance, which
 * stop a wake today without it). D7 decides from `suppressed`.
 */
export type Observed = {
  since: number;
  total: number;
  allowed: number;
  suppressed: number;
  byReason: Partial<Record<ActivationVerdictV1["reason"], number>>;
  last: { at: number; allowed: boolean; reason: ActivationVerdictV1["reason"] };
};

export const observedKey = (agent: string): string => `activation-observe:${agent}`;
/** Reasons that mean the policy itself would have kept the wake from starting. */
const BY_POLICY: readonly ActivationVerdictV1["reason"][] = ["no_order", "policy_off", "transport"];

export function observe(kv: Pick<SyncKvStorage, "get" | "put">, agent: string, verdict: ActivationVerdictV1, now: number): Observed {
  const before = kv.get<Observed>(observedKey(agent));
  const next: Observed = {
    since: before?.since ?? now,
    total: (before?.total ?? 0) + 1,
    allowed: (before?.allowed ?? 0) + (verdict.allowed ? 1 : 0),
    suppressed: (before?.suppressed ?? 0) + (!verdict.allowed && BY_POLICY.includes(verdict.reason) ? 1 : 0),
    byReason: { ...before?.byReason, [verdict.reason]: (before?.byReason?.[verdict.reason] ?? 0) + 1 },
    last: { at: now, allowed: verdict.allowed, reason: verdict.reason },
  };
  kv.put<Observed>(observedKey(agent), next);
  return next;
}

export const observedOf = (kv: Pick<SyncKvStorage, "get">, agent: string): Observed | null => kv.get<Observed>(observedKey(agent)) ?? null;
