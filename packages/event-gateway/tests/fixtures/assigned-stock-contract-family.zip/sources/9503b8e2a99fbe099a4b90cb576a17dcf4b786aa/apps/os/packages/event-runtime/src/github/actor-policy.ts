import { z } from 'zod';
import type { GitHubObservationV1 } from './state';

const actorId = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);
const canonicalIds = z.array(actorId).min(1).max(64).transform(ids => [...new Set(ids)].toSorted((a, b) => a - b));
export const GitHubActorPolicySchema = z.object({ version: z.literal(1), userIds: canonicalIds, appIds: z.array(actorId).max(64).transform(ids => [...new Set(ids)].toSorted((a, b) => a - b)) }).strict();
export type GitHubActorPolicyV1 = z.infer<typeof GitHubActorPolicySchema>;

const canonicalDecimal = (id: string | null): string | null => id !== null && /^[1-9]\d*$/.test(id) && Number.isSafeInteger(Number(id)) ? id : null;
export const allowsGitHubUser = (policy: GitHubActorPolicyV1, id: string | null): boolean => {
  const value = canonicalDecimal(id);
  return value !== null && policy.userIds.some(allowed => String(allowed) === value);
};
export const allowsGitHubApp = (policy: GitHubActorPolicyV1, id: string | null): boolean => {
  const value = canonicalDecimal(id);
  return value !== null && policy.appIds.some(allowed => String(allowed) === value);
};

export interface GitHubActorExclusionCountsV1 {
  review: number;
  comment: number;
  thread: number;
  check: number;
  status: number;
  workflow: number;
  reviewRequest: number;
  terminal: number;
}
export const emptyGitHubActorExclusionCounts = (): GitHubActorExclusionCountsV1 => ({ review: 0, comment: 0, thread: 0, check: 0, status: 0, workflow: 0, reviewRequest: 0, terminal: 0 });
export function validGitHubActorExclusionCounts(value: unknown): value is GitHubActorExclusionCountsV1 {
  if (value === undefined) return true;
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const counts = value as Record<string, unknown>, expected = Object.keys(emptyGitHubActorExclusionCounts()).toSorted();
  return Object.keys(counts).toSorted().join(',') === expected.join(',') && expected.every(key => Number.isSafeInteger(counts[key]) && (counts[key] as number) >= 0);
}

/** Filters an already selected provider snapshot; callers must choose latest CI records first. */
export function filterGitHubObservation(observation: GitHubObservationV1, policy: GitHubActorPolicyV1): GitHubObservationV1 {
  const counts = emptyGitHubActorExclusionCounts();
  if (!validGitHubActorExclusionCounts(observation.actorExclusionCounts)) throw new TypeError('github_actor_exclusion_counts');
  for (const key of Object.keys(counts) as (keyof GitHubActorExclusionCountsV1)[]) counts[key] = observation.actorExclusionCounts?.[key] ?? 0;
  const increment = (key: keyof GitHubActorExclusionCountsV1, amount = 1) => {
    if (!Number.isSafeInteger(amount) || amount < 0 || counts[key] > Number.MAX_SAFE_INTEGER - amount) throw new TypeError('github_actor_exclusion_counts');
    counts[key] += amount;
  };
  const findings = observation.findings.filter(finding => {
    const allowed = allowsGitHubUser(policy, finding.actorId) || allowsGitHubApp(policy, finding.appId);
    if (!allowed) increment(finding.kind);
    return allowed;
  });
  const allowedMaterials = new Map(findings.map(finding => [finding.sourceId, finding.fingerprint]));
  const findingMaterials = observation.findingMaterials?.filter(material => allowedMaterials.get(material.sourceId) === material.fingerprint);
  const runs = observation.runs.filter(run => {
    // Run actor fields and check App ownership do not identify who cancelled the run.
    const allowed = run.conclusion !== 'cancelled' && (run.kind === 'check' ? allowsGitHubApp(policy, run.appId) : allowsGitHubUser(policy, run.actorId));
    if (!allowed) increment(run.kind);
    return allowed;
  });
  // The existing requested-reviewers endpoint identifies targets only, never the requester.
  increment('reviewRequest', observation.reviewRequests.length);
  const terminalActorAllowed = observation.stateActorId != null && allowsGitHubUser(policy, observation.stateActorId);
  const stateActorId = terminalActorAllowed ? observation.stateActorId : null;
  if (observation.state !== 'open' && !terminalActorAllowed && (observation.stateActorId != null || counts.terminal === 0)) {
    // Null or malformed attribution is also excluded: terminal activity without a proven allowed actor must not gain authority.
    // A positive count marks this observation as already filtered, so rechecking it cannot count it again.
    increment('terminal');
  }
  return { ...observation, stateActorId, findings, ...(findingMaterials === undefined ? {} : { findingMaterials }), runs, reviewRequests: [], actorExclusionCounts: counts };
}
