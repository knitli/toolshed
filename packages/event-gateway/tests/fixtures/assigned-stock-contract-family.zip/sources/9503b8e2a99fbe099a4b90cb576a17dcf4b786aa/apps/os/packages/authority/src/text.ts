// Text a person or an agent cannot see (R4 plan 6.2, 7.2, AT-11): one predicate for everything that is read by a person who signs, approves or
// relies on it, so no two checks disagree about what is invisible. Pure TypeScript: no Worker types, no I/O.
//
// Control characters other than LF and TAB, U+2028/2029, and every default-ignorable code point (zero-width and bidi characters, the soft hyphen,
// variation selectors, Unicode tag characters, the Hangul fillers, the combining grapheme joiner, ...) render as nothing or reorder text, so a
// reader could not vouch for what they read, and a tag character is invisible text an LLM still reads (instruction smuggling).

const CONTROLS = "\\u0000-\\u0008\\u000B-\\u001F\\u007F-\\u009F\\u2028\\u2029";
const IGNORABLE = "\\p{Default_Ignorable_Code_Point}";
// What screen() keeps (see below): the few default-ignorables real text is spelled with, and CONTROLS but CR (CRLF is ordinary text).
const KEEP = "\\u200C-\\u200F\\u061C\\uFE00-\\uFE0F\\u{E0100}-\\u{E01EF}\\u180B-\\u180D\\u180F";
const SCREEN_CONTROLS = "\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F\\u007F-\\u009F\\u2028\\u2029"; // CONTROLS but CR: CRLF is ordinary text
const INVISIBLE = new RegExp(`[${CONTROLS}${IGNORABLE}]`, "u");

/** Whether `text` holds a character that renders as nothing, reorders text, or is a control other than LF and TAB. */
export const hasInvisibleText = (text: string): boolean => INVISIBLE.test(text);

/** The text rule as stored rows were written under it (no lone-surrogate check): NFC and nothing hidden. Stored text is read back with this one; a new write uses isPlainText. */
export const isStoredPlainText = (text: string): boolean => text.normalize("NFC") === text && !hasInvisibleText(text);

/** Text a person or an agent may be shown and a person may sign: well formed (no lone surrogate, which JSON can carry and UTF-8 cannot), NFC, and nothing hidden (AT-11). Messaging's declarations and field text and the act parser read this one. */
export const isPlainText = (text: string): boolean => text.isWellFormed() && text.normalize("NFC") === text && !hasInvisibleText(text);

// --- screening: what an agent is shown (R4 J1 item 4B) ---------------------------------------------------------------------------------------
// Where hasInvisibleText refuses, screen() cleans: for free text that crosses into an agent's context (a message read, a send before it is signed).
// What screen() guarantees is its output: no control or escape byte is left in it (but TAB, LF and CRLF), so any terminal shows exactly the text an agent
// reads. It does not emulate a terminal to predict how the raw input would have displayed (a CR or cursor move overwriting text, VT52 mode): raw input
// is never shown to a person unescaped, and removing a sequence whole is about not leaving its parameters behind as stray text.
// Pure and linear: every pattern below is a single pass with no nested quantifier, and an unterminated sequence never rescans past the next ESC.
//
// screen() strips EVERY default-ignorable code point and control except an explicit allowlist, KEEP: ZWNJ and ZWJ (Persian, Devanagari, emoji sequences), LRM,
// RLM and ALM (Hebrew, Arabic), variation selectors (VS16 in a heart, keycaps, CJK ideographs) and the Mongolian free variation selectors. Text is stored and
// signed after a send, and those are how real text is spelled. A denylist would let any unlisted invisible character through, so the rule is the allowlist.
// KEEP characters can still carry a payload when they come in runs (a variation selector per bit), so no more than two may follow each other: real text
// needs at most two (ZWJ + VS16 in a heart on fire). The strict AT-11 rule above is unchanged and still governs signed text.

const ESC = "\\u001B";
// A whole terminal sequence: CSI (ESC [ or C1 0x9B, parameters, intermediates, final), a string sequence (OSC, DCS, SOS, PM, APC) ended by BEL or ST,
// then any other two-character ESC sequence. An unterminated string sequence is left to the control strip below, so it never swallows the text after it.
// An escape sequence with intermediates (ESC, 0x20-0x2F bytes, one final 0x30-0x7E: ESC ( B selects a character set) is whole too: the final byte is
// part of it, never text. Only when no final byte follows does the two-character fallback take ESC and the next byte.
// GNU Screen's title string, ESC k, is a whole sequence ending at ST like DCS: Screen consumes the payload as a window title.
// The 8-bit C1 forms are whole sequences too: 0x9B is CSI, 0x9D is OSC, and 0x90, 0x98, 0x9E, 0x9F are DCS, SOS, PM, APC, ending at ST (ESC then backslash, or 0x9C) only.
// Only OSC ends at BEL or ST; DCS, SOS, PM and APC end at ST (ESC \\ or the C1 0x9C) alone, so a BEL inside them cannot end the sequence early and leave a payload visible.
// A string sequence is a mode, not a match: an ESC that does not start ST, any C1 introducer, or CAN or SUB inside it aborts it (xterm resets its parser), so
// the payload before the abort is dropped with the opener, and an aborting ESC or introducer then starts the next sequence. Payloads stop at every one of
// these, so no scan runs past the next introducer: a run of openers is linear, and only the last, unterminated one may scan to the end.
// Every C1 control, not only the introducers: a terminal leaves any sequence on one (IND, NEL, ST and the rest), so each is a boundary.
const INTRO = "\\u0080-\\u009F";
const ABORT = `[\\u0018\\u001A]|(?=${ESC}|[${INTRO}])`;
// A CSI runs to its final byte whatever order its parameters and intermediates come in: a parameter after an intermediate sends a terminal to its
// ignore state, which still consumes every 0x20-0x3F byte through the final (VT500 csi_ignore), so one class covers them all.
// CAN, SUB, an ESC or a C1 introducer aborts a CSI or an intermediate sequence as it does a string (ABORT): the parameters and intermediates already read
// are dropped with it, as a terminal drops them, and an aborting ESC or introducer starts the next sequence.
// A C0 control (but ESC, CAN and SUB) or DEL inside an escape sequence is executed or ignored and the sequence goes on (the VT500 parser's "execute" in
// the escape and CSI states), so `ESC [ NUL i` still ends at `i`: every such byte may sit between ESC and what follows it, and among parameters and intermediates.
const SEQ_C0 = "\\u0000-\\u0017\\u0019\\u001C-\\u001F\\u007F";
const ESCX = `${ESC}[${SEQ_C0}]*`;
const ANSI = new RegExp(`(?:${ESCX}\\[|\\u009B)[\\u0020-\\u003F${SEQ_C0}]*(?:[\\u0040-\\u007E]|${ABORT})|(?:${ESCX}\\]|\\u009D)[^\\u0007${ESC}\\u009C${INTRO}\\u0018\\u001A]*(?:\\u0007|\\u009C|${ESCX}\\\\|${ABORT})|(?:${ESCX}[PX^_k]|[\\u0090\\u0098\\u009E\\u009F])[^${ESC}\\u009C${INTRO}\\u0018\\u001A]*(?:\\u009C|${ESCX}\\\\|${ABORT})|${ESC}[\\u0020-\\u002F${SEQ_C0}]*(?:[\\u0030-\\u007E]|${ABORT})|${ESC}[\\u0020-\\u007E]`, "g");
const CONTROL_ONLY = new RegExp(`[${SCREEN_CONTROLS}]`, "gu");
const BARE_CR = /\r(?!\n)/g;
const STRIPPED_IGNORABLE = new RegExp(`(?![${KEEP}])${IGNORABLE}`, "gu");
// A variation selector is kept only right after a base: not at the start, after whitespace or a control, or after a default-ignorable (which covers another KEEP character).
const SELECTOR_WITHOUT_BASE = new RegExp(`(?<![^\\s\\p{Cc}${IGNORABLE}])[\\uFE00-\\uFE0F\\u{E0100}-\\u{E01EF}\\u180B-\\u180D\\u180F]`, "gu");
const KEEP_RUN_EXCESS = new RegExp(`(?<=[${KEEP}]{2})[${KEEP}]`, "gu");
const KEEP_ONLY = new RegExp(`[${KEEP}]`, "gu");
const IGNORABLE_ONLY = new RegExp(IGNORABLE, "gu");
const LONE_SURROGATE = /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g;

/** Phrases that read like an instruction to the model, matched on lowercased text with whitespace collapsed. A tripwire, not a guarantee: it flags, never removes or blocks. */
const PHRASES: readonly [id: string, pattern: RegExp][] = [
  ["ignore-previous", /\b(?:ignore|disregard|forget)(?: (?:all|any|the|your|my|of)){0,3} (?:previous|prior|above|earlier|preceding) (?:instructions?|prompts?|rules|directions|context)/],
  ["system-prompt", /\bsystem prompt/],
  ["jailbreak", /\bjailbreak/],
  ["chat-template", /<\|(?:im_start|im_end|system|user|assistant|endoftext)\|>|\[\/?inst\]|<<\/?sys>>/],
  ["begin-system", /\bbegin system\b/],
  ["new-instructions", /\bnew instructions?:/],
];

/** The ids a report's `phrases` can hold. */
export const PHRASE_IDS: readonly string[] = PHRASES.map(([id]) => id);

/** Whether `kept` KEEP characters among `visible` others are a channel rather than spelling: over eight, and over a quarter. Messaging recomputes it on a whole message. */
export const isDense = (kept: number, visible: number): boolean => kept > 8 && kept * 4 > visible;

/** The version of the screening algorithm (what is stripped, the KEEP rules, the tripwire patterns). Bump it whenever strip or tripwire behaviour changes: a consumer that re-runs screen() pins it. Receipts sign a screened digest under it (Messaging, R4 5b-2c) that a verifier recomputes from the shown text, so any change to what screening strips, keeps or reports must bump it, or older receipts stop matching their own reads. */
export const SCREEN_VERSION = 1;

export type ScreenReport = {
  /** SCREEN_VERSION when the report was made. */
  version: number;
  /** What was removed or replaced: `ansi` counts whole terminal sequences, the rest count code points. */
  removed: { ansi: number; control: number; invisible: number; surrogate: number };
  /** KEEP characters left in place because real text uses them (ZWNJ, ZWJ, direction marks, variation selectors). */
  kept: number;
  /** Code points of the output that are not KEEP characters (whitespace counts): what density is measured against. */
  visible: number;
  /** Whether KEEP characters are more than a quarter of the visible characters, and more than eight: a joiner or selector after nearly every character. */
  dense: boolean;
  /** Whether the subject had surrounding whitespace trimmed (set by Messaging, which trims; screen() itself never does). */
  trimmed: boolean;
  /** Whether a derived subject was cut to the subject limit after screening (set by Messaging; screen() itself never does). */
  shortened: boolean;
  /** Whether a body was withheld whole because its JSON decodes to hidden text (set by Messaging; screen() itself never does). */
  withheld: boolean;
  /** Whether NFC changed the text. */
  normalized: boolean;
  /** Ids of the instruction-like patterns that matched, once each. */
  phrases: string[];
  /** Whether `text` differs from the input. */
  changed: boolean;
};

/**
 * `text` made safe to put in front of an agent, and what was done. Lone surrogates become U+FFFD FIRST, so no later strip can join a stranded high and
 * low half into a character (a tag character) that was not in the input. Then whole ANSI/terminal sequences, controls but LF, TAB and CRLF, and every
 * default-ignorable not in KEEP are removed, then any third and later KEEP character in a row, and the result is NFC. Then the phrase tripwire runs. Invariants:
 * the output holds no default-ignorable outside KEEP and no run of three KEEP characters, and screen(screen(x).text).text equals screen(x).text.
 */
export function screen(text: string): { text: string; report: ScreenReport } {
  const removed = { ansi: 0, control: 0, invisible: 0, surrogate: 0 };
  const strip = (input: string, pattern: RegExp, key: keyof typeof removed, to = ""): string => input.replace(pattern, () => (removed[key]++, to));
  const whole = strip(text, LONE_SURROGATE, "surrogate", "\uFFFD");
  let out = strip(whole, ANSI, "ansi");
  out = strip(out, SELECTOR_WITHOUT_BASE, "invisible"); // before the control and ignorable strips, which would hide what the selector followed
  out = strip(out, CONTROL_ONLY, "control");
  out = strip(out, BARE_CR, "control"); // CRLF survives; a CR alone returns the cursor and overwrites what a person sees (rm -rf ~\recho ok)
  out = strip(out, STRIPPED_IGNORABLE, "invisible");
  out = strip(out, KEEP_RUN_EXCESS, "invisible");
  const normal = out.normalize("NFC");
  const kept = normal.match(KEEP_ONLY)?.length ?? 0;
  // The tripwire reads the text twice: with every default-ignorable (kept ones too) removed, and with everything that was or would be stripped (ANSI, controls,
  // every default-ignorable) turned into a space, so neither a ZWJ inside a word nor an invisible character in place of a space hides a phrase. The output text is unaffected.
  const removal = normal.replace(IGNORABLE_ONLY, "").toLowerCase();
  const spaced = whole.replace(ANSI, " ").replace(CONTROL_ONLY, " ").replace(BARE_CR, " ").replace(IGNORABLE_ONLY, " ").normalize("NFC").toLowerCase();
  const copies = [removal, spaced].map((copy) => copy.replace(/\s+/g, " "));
  const phrases = PHRASES.filter(([, pattern]) => pattern.test(copies[0]!) || pattern.test(copies[1]!)).map(([id]) => id);
  // Kept characters are real text up to a point: a joiner or selector after nearly every character is a channel, so a dense run is reported (never removed beyond the run cap).
  const visible = [...normal].length - kept;
  const dense = isDense(kept, visible);
  return { text: normal, report: { version: SCREEN_VERSION, removed, kept, visible, dense, trimmed: false, shortened: false, withheld: false, normalized: normal !== out, phrases, changed: normal !== text } };
}

const plural = (n: number, one: string, many: string): string => `${n} ${n === 1 ? one : many}`;

/** The report in one plain line, or null when screening found nothing to say. */
export function describeScreen(report: ScreenReport): string | null {
  const { ansi, control, invisible, surrogate } = report.removed;
  // A terminal sequence is counted whole (an OSC title is one, however long), so it is reported apart from single hidden characters.
  const hidden = control + invisible;
  const parts = [
    ...(report.withheld ? ["body withheld: its JSON decodes to hidden text"] : []),
    ...(hidden > 0 ? [`${plural(hidden, "hidden character", "hidden characters")} removed`] : []),
    ...(ansi > 0 ? [`${plural(ansi, "terminal sequence", "terminal sequences")} removed`] : []),
    ...(surrogate > 0 ? [`${plural(surrogate, "broken character", "broken characters")} replaced`] : []),
    ...(report.dense ? [`${plural(report.kept, "joiner, direction mark or selector", "joiners, direction marks or selectors")} kept`] : []),
    ...(report.trimmed ? ["whitespace trimmed from the subject"] : []),
    ...(report.shortened ? ["subject shortened to fit"] : []),
    ...(report.normalized ? ["text normalized"] : []),
    ...(report.phrases.length > 0 ? [`${plural(report.phrases.length, "instruction-like phrase", "instruction-like phrases")} flagged`] : []),
  ];
  return parts.length > 0 ? parts.join("; ") : null;
}

// --- the owner's view of the original (R4 5b-2c) ---------------------------------------------------------------------------------------------
// An agent is shown screen()'s output; the owner is shown the original with every character that renders as nothing spelled as a visible code point,
// so nothing hidden is ever raw on the page and the owner-side verifier can read the original back from it. Not encrypted: withholding is enough.
// shortcut: characters that are blank but not default-ignorable (U+00A0, U+2003, U+3000, ...) stay raw, as screen() keeps them; escape them too if an owner is ever misled by one.
const HIDDEN = new RegExp(`[${CONTROLS}${IGNORABLE}\\p{Cs}]`, "gu");
// Up to U+10FFFF: a longer or larger token is not an escape (it is escaped as a literal, so it reads back exactly).
const TOKEN = /\[U\+(10[0-9A-F]{4}|[0-9A-F]{4,5})\]/g;
const LITERAL_TOKEN = /\[(?=U\+[0-9A-F]{4,6}\])/g;
const token = (code: number): string => `[U+${code.toString(16).toUpperCase().padStart(4, "0")}]`;

/**
 * `text` with every control but LF, TAB and the CR of a CRLF, every default-ignorable and every lone surrogate written as `[U+XXXX]` (upper-case hex, at least
 * four digits), and a literal `[` that starts such a token written as one too, so unescapeHidden gives back exactly `text`. Escaping is the inverse of reading, not a
 * sanitiser: it never removes anything.
 */
export const escapeHidden = (text: string): string =>
  text
    .replace(LITERAL_TOKEN, token(0x5b))
    .replace(HIDDEN, (char, at: number, whole: string) => (char === "\r" && whole[at + 1] === "\n" ? char : token(char.codePointAt(0)!)));

/** The text escapeHidden spelled, exactly. A token that spells a lone surrogate is read back as one. */
export const unescapeHidden = (text: string): string => text.replace(TOKEN, (_, hex: string) => String.fromCodePoint(Number.parseInt(hex, 16)));
