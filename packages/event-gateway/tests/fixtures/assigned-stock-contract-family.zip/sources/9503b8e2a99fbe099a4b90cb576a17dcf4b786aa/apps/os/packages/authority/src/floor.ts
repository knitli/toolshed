// The assurance an act needs (plan 6.7, VS-12), in one place: the verifier applies it to a proof, and the presence Worker applies it to the options it hands the
// browser, so what the key is asked for and what the verifier will accept cannot drift. Pure TypeScript.
import type { Act, Assurance } from "./act.ts";
import { isHighTerm } from "./render.ts";
import { floorFor, stricter, type Floors } from "./webauthn.ts";

/**
 * The least assurance `act` may claim: the pinned floor for its kind and type, raised by the receiver's declaration (never lowered), and raised to hw-uv
 * for an order that starts code or hands the task on, or whose type is exec/*: the type is a label, the terms are what it can do.
 */
export function effectiveFloor(act: Act, floors: Floors, declared?: Assurance): Assurance {
  const type = act.kind === "order" ? (act.subject as { taskType: string }).taskType : undefined;
  const pinnedFloor = floorFor(floors, act.kind, type, declared);
  return act.scope?.some(isHighTerm) || type?.startsWith("exec/") ? stricter(pinnedFloor, "hw-uv") : pinnedFloor;
}

/** Whether the key must verify the user (PIN) for `act`: its floor or its own claim says hw-uv. */
export const needsUserVerification = (act: Act, floors: Floors, declared?: Assurance): boolean => stricter(effectiveFloor(act, floors, declared), act.assurance) === "hw-uv";
