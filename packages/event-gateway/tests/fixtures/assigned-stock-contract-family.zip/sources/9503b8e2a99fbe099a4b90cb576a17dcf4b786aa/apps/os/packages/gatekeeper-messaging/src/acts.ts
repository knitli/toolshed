// The act host (R4 plan 6.2, 6.4, 6.6, 6.7, F03): drafts, the open act, and its single completion, inside the Mailbox that holds the credentials, so consuming an
// act and applying its effect are ONE transactionSync. The owning service composes every act from stored state: the browser submits only an assertion, and
// the bytes that are signed are the ones stored at open (INV4).
//
// A draft is inert and lives 24 hours. The nonce is minted when the act is OPENED, and the window is 300 seconds; opening again replaces the open act and so
// invalidates the nonce before it (AT-22). Completion verifies first (WebCrypto is async) and then, in one synchronous step, consumes the act with a
// conditional UPDATE that must change exactly one row, re-reads the signing credential, and applies the effect. Two concurrent completions with one
// assertion apply once; a credential revoked between the verify and the consume is refused; an act re-opened between them is refused.
//
// Only the kinds in HOSTED_KINDS can be drafted. P5a-2 hosts the credential acts and P5c-a 5c-1 the five that widen an agent's authority (core-acts.ts) and P5c-b `grant` and `agent-scope` (grant-acts.ts); the
// order with its effect (P5b 5b-2a, order-acts.ts); a kind with no effect cannot be signed here, because a touch that applies nothing would be spent for nothing.

import { WINDOW_SECONDS, actDigest, actChallenge, isAgentAddress, type Act, type ActKind, type Assurance, type DraftedBy } from "authority/src/act.ts";
import { b64u, canonicalJson } from "authority/src/canonical.ts";
import { readAct } from "authority/src/credential-chain.ts";
import { needsUserVerification } from "authority/src/floor.ts";
import { isoTime } from "authority/src/contract-kit.ts";
import { snapshot } from "authority/src/snapshot.ts";
import { floorFor, type Evidence } from "authority/src/webauthn.ts";
import { MAX_RETURN_TO, type PublicKeyCredentialRequestOptionsJSON, type ReasonCode } from "authority/src/contracts.ts";
import { verifyEnrollmentAssertion } from "authority/src/credential-chain.ts";
import { verifyHumanProof, type ProofExpect } from "authority/src/human-proof.ts";
import { appendLog } from "./authority-log.ts";
import { canBeEnrolled, canEnrollUnder } from "authority/src/credential-chain.ts";
import { Refuse, markSigned, activeRows, chainFor, chainLookup, counterReplayed, keyOf, markRevoked, readRows, recordEnrollment, revokedList, statusOf, type CredentialRow } from "./credentials.ts";
import { pinDigestOf, pinsFor, refreshLatches, widening } from "./enforcement.ts";
import { actNotice, agentDraftNotice, queueNotice } from "./notify.ts";
import type { PresenceConfig } from "./presence.ts";
import { LIVENESS_GUARDED } from "./stepup-marks.ts";
import { addressOf, fail, wireOf, type Stored } from "./model.ts";
import * as registry from "./registry.ts";
import { applyCore, isCoreDraft, subjectOf, type CoreDraft } from "./core-acts.ts";
import { applyGrantAct, grantSubjectOf, isGrantDraft, type GrantDraft } from "./grant-acts.ts";
import { agentOrderSubjectOf, applyOrder, declaredMinAssurance, drafterStillMay, isOrderDraft, limitsAt, orderSubjectOf, prepareRoot, type AgentOrderRequest, type OrderDraft, type OrderExtra, type PreparedRoot } from "./order-acts.ts";
import type { KeyRing } from "./receipts.ts";

export type Host = {
  sql: SqlStorage; tx<T>(work: () => T): T; now(): number;
  /** Drops an agent's wake hook with its workspace binding (kv, not SQL): the one effect of a core act that lives outside the tables. Absent in a host that applies no core act. */
  forgetWake?: (agent: string) => void;
  /** Whether ENROLL_PRINCIPALS lets this person add computers: an `agent-enroll` act is a key, so the list that narrows between draft and touch is asked again at the effect. Absent: fail closed. */
  enrollAllowed?: (principal: string) => boolean;
  /** Orders (P5b): whether one may be drafted and applied (authority.orderEmission), the broker's receipt keys its root is signed with, and the wake started
   * once the root is filed. Absent: no order can be drafted or applied. */
  orderEmission?: () => boolean;
  receiptKeys?: () => Promise<Pick<KeyRing, "kid" | "signer">>;
  rootFiled?: (agent: string, envelope: { id: string; from: string }, order: { digest: string; root: boolean }) => void;
  /** What a delivery does around filing an inbox row (Mailbox #armInbound before the transaction, #stageInbound inside it), run for an order's root too. */
  inbound?: { arm(message: Stored): Promise<void>; stage(message: Stored, now: number): void };
};

const DAY = 24 * 3600 * 1000;
const HOUR = 3600 * 1000;
export const DRAFT_MS = DAY;
/** The ceremony window, in the one place it is defined (the verifier checks the same 300 seconds). */
export const WINDOW_MS = WINDOW_SECONDS * 1000;
export const HUMAN_DRAFTS_PER_HOUR = 20;
/** Flow B (plan 7.5, VS-13): drafts an agent may have waiting (not yet signed, cancelled or lapsed), and all agents of one person together. */
export const AGENT_OPEN_DRAFTS = 10;
export const PRINCIPAL_OPEN_DRAFTS = 20;
/**
 * Rolling 24 hours, counting EVERY draft made, whatever became of it (cancelled and signed ones free the waiting quota at once, so a hostile agent could otherwise ask, have it
 * cancelled, and ask again to flood the person's notices). One agent gets 10 of the person's 40, a quarter: the waiting quotas stop one agent filling the list, this stops it
 * using up the day, and it takes four such agents to exhaust the person's day.
 */
export const AGENT_DRAFTS_PER_DAY = 10;
export const PRINCIPAL_DRAFTS_PER_DAY = 40;

/** Every kind that can be drafted and signed here has its effect; a kind not listed is not available yet. */
export const HOSTED_KINDS = ["enroll-credential", "revoke-credential", "agent-enroll", "bind-existing", "activation", "declare-task", "key-inventory", "grant", "agent-scope", "order"] as const;
export type HostedKind = (typeof HOSTED_KINDS)[number];

type ActRow = {
  id: string; kind: string; body: string; drafted_by: string; return_to: string | null; state: string; created_at: number; draft_expires_at: number;
  open_act: string | null; open_digest: string | null; open_expires_at: number | null; consumed_at: number | null; evidence: string | null;
};

const iso = (ms: number): string => new Date(ms).toISOString().replace(".000Z", "Z");
export const newId = (): string => b64u(crypto.getRandomValues(new Uint8Array(16)));

const refused = (reason: ReasonCode): { status: "refused"; reason: ReasonCode } => ({ status: "refused", reason });

/** The stored body of a draft: the kind and the closed subject, with no nonce and no time (an order's terms and limits beside it). Read back as data, never trusted as an act. */
function bodyOf(row: ActRow): { kind: ActKind; subject: Record<string, unknown>; order?: OrderExtra } | null {
  try {
    const read = snapshot(JSON.parse(row.body));
    const body = read?.value as { kind?: unknown; subject?: unknown; order?: unknown } | undefined;
    if (!body || typeof body.kind !== "string" || body.subject === null || typeof body.subject !== "object") return null;
    if ((body.kind === "order") !== (body.order !== undefined)) return null;
    return { kind: body.kind as ActKind, subject: body.subject as Record<string, unknown>, ...(body.order !== undefined && { order: body.order as OrderExtra }) };
  } catch {
    return null;
  }
}

/** Who composed a draft, as the act spells it: a person, or the agent whose address `agent:<address>` the row names (null when the row names neither). */
const drafterOf = (row: ActRow, jkt: string | null): DraftedBy | null => {
  if (row.drafted_by === "human") return "human";
  const agent = row.drafted_by.startsWith("agent:") ? row.drafted_by.slice(6) : "";
  return isAgentAddress(agent) ? { agent, jkt } : null;
};

/** The act `row` is, opened at `now` with `nonce`: parsed, complete under its renderer, and addressed to this deployment, or null. */
export async function compose(config: PresenceConfig, principal: string, row: ActRow, now: number, nonce: string): Promise<Act | null> {
  const body = bodyOf(row);
  // No agent drafts a credential act (INV4): only an order may name an agent as its drafter, and the act parser holds it to that (crossChecks).
  const draftedBy = body && drafterOf(row, body.order?.draftedJkt ?? null);
  if (!body || !draftedBy) return null;
  const issued = Math.floor(now / 1000) * 1000;
  const raw = {
    v: 1, kind: body.kind, principal, aud: config.pinned.aud, rpId: config.pinned.rpId, nonce, issuedAt: iso(issued), windowExpiresAt: iso(issued + WINDOW_MS),
    // An order's floor is its type's, raised by the receiver's declared minimum (kept with the draft); its terms and limits ride on the act, and it lives
    // from when it is opened.
    assurance: body.order?.assurance ?? floorFor(config.pinned.floors, body.kind), draftedBy, renderer: "r1", subject: body.subject,
    ...(body.order && { scope: body.order.scope, limits: limitsAt(body.order, issued) }),
  };
  const read = await readAct(raw, config.pinned);
  return read.ok ? read.act : null;
}

/**
 * Only what was never signed goes, a month on: an act that is still a draft or open (past its day, it can no longer be signed), expired or cancelled, and the
 * touches of a liveness ceremony that never finished. A consumed act is evidence (a revocation's proof, a liveness record's act) and stays.
 */
export function clearOld(sql: SqlStorage, now: number): void {
  sql.exec("DELETE FROM acts WHERE state IN ('draft', 'open', 'expired', 'cancelled') AND draft_expires_at < ?", now - 30 * DAY);
  sql.exec("DELETE FROM liveness_touches WHERE act_id NOT IN (SELECT id FROM acts)");
}

// --- drafting ------------------------------------------------------------------------------------------------

const findByThumbprint = (rows: readonly CredentialRow[], thumbprint: string): CredentialRow | undefined => rows.find((r) => r.thumbprint === thumbprint);

/** Where a draft may send the browser afterwards: an https origin on the allowlist, stored with the draft and never read from a query string. */
function returnToOf(value: string | null | undefined, allowed: readonly string[]): string | null {
  if (value == null) return null;
  try {
    const url = new URL(value);
    if (url.protocol === "https:" && !url.username && !url.password && allowed.includes(url.origin) && value === url.href && value.length <= MAX_RETURN_TO) return value;
  } catch {
    // falls through to the refusal
  }
  throw fail("invalid", "the return address is not one of this deployment's pages");
}

export type DraftInput = { kind: "enroll-credential"; credential: string; parent: string } | { kind: "revoke-credential"; credential: string } | CoreDraft | GrantDraft | OrderDraft;

/** The subject of a credential act, from the stored credential rows: the label and claimed model are the stored ones, never the caller's. */
function credentialSubject(host: Host, config: PresenceConfig, principal: string, input: Extract<DraftInput, { kind: "enroll-credential" | "revoke-credential" }>, now: number): Record<string, unknown> {
  const rows = readRows(host.sql);
  const target = findByThumbprint(rows, input.credential);
  if (!target) throw fail("not_found", "no such security key");
  const status = statusOf(rows, target, config.pinned, principal, now);
  let subject: Record<string, unknown>;
  if (input.kind === "enroll-credential") {
    const parent = findByThumbprint(rows, input.parent);
    if (!parent || statusOf(rows, parent, config.pinned, principal, now) !== "active") throw fail("invalid", "a key is enrolled by a key that is already a signer");
    if (!canBeEnrolled({ status, via: target.via, parent: target.parent_thumbprint }) || target.thumbprint === parent.thumbprint) throw fail("conflict", "only a newly registered key that has not been enrolled can be enrolled, and a key registered in a window is pinned by a deploy instead");
    if (!canEnrollUnder(parent.thumbprint, chainLookup(rows, config.pinned, principal))) throw fail("conflict", "that key is already as far from a pinned key as an enrollment chain can reach: enroll under a key closer to a pin");
    subject = { credentialThumbprint: target.thumbprint, label: target.label, parentThumbprint: parent.thumbprint, aaguidClaimed: target.aaguid };
  } else {
    if (status === "revoked") throw fail("conflict", "that key is already revoked");
    // Another key must be left to sign it: a proof of one's own revocation does not exist (signer_is_subject).
    if (activeRows(rows, config.pinned, principal, now, target.thumbprint).length === 0) throw fail("forbidden", "revocation_floor: the last key cannot be revoked; recovery is a deploy-opened enroll window");
    subject = { credentialThumbprint: target.thumbprint, label: target.label };
  }
  return subject;
}

/**
 * A human's draft of an act, from references only. The subject comes from stored state (the credential rows, an enrollment, the key and agent tables): what is
 * shown and signed is what is stored, never what the caller says. Throws coded errors (the admin API's refusals).
 */
export async function draft(host: Host, config: PresenceConfig, principal: string, input: DraftInput, returnTo: string | null | undefined, allowedReturns: readonly string[]): Promise<{ id: string; expiresAt: number }> {
  const now = host.now();
  if (isOrderDraft(input) && host.orderEmission?.() !== true) throw fail("unavailable", "orders are not enabled on this deployment (authority.orderEmission)");
  const order = isOrderDraft(input) ? orderSubjectOf(host.sql, input, principal, (type, declared) => floorFor(config.pinned.floors, "order", type, declared)) : null;
  const subject = order ? order.subject : isCoreDraft(input) ? await subjectOf(host.sql, input, principal, now) : isGrantDraft(input) ? grantSubjectOf(host.sql, input, principal, now) : credentialSubject(host, config, principal, input as Extract<DraftInput, { kind: "enroll-credential" | "revoke-credential" }>, now);
  const row: ActRow = { id: newId(), kind: input.kind, body: canonicalJson({ kind: input.kind, subject, ...(order && { order: order.extra }) } as never), drafted_by: "human", return_to: returnToOf(returnTo, allowedReturns), state: "draft", created_at: now, draft_expires_at: now + DRAFT_MS, open_act: null, open_digest: null, open_expires_at: null, consumed_at: null, evidence: null };
  // The draft must be an act, here, so that opening it later cannot fail for a reason this call could have named.
  if ((await compose(config, principal, row, now, newId())) === null) throw fail("invalid", "that is not an act this deployment can host");
  host.tx(() => {
    const recent = host.sql.exec<{ n: number }>("SELECT count(*) AS n FROM acts WHERE drafted_by = 'human' AND created_at > ?", now - HOUR).one().n;
    if (recent >= HUMAN_DRAFTS_PER_HOUR) throw fail("over_budget", `at most ${HUMAN_DRAFTS_PER_HOUR} drafts an hour`);
    clearOld(host.sql, now);
    host.sql.exec("INSERT INTO acts (id, kind, body, drafted_by, return_to, state, created_at, draft_expires_at) VALUES (?, ?, ?, ?, ?, 'draft', ?, ?)", row.id, row.kind, row.body, row.drafted_by, row.return_to, row.created_at, row.draft_expires_at);
  });
  return { id: row.id, expiresAt: row.draft_expires_at };
}

/**
 * An agent's request for an order (Flow B, plan 6.4): a draft like a person's, but composed under the agent's own name. It is inert (nothing is signed or sent), lives
 * 24 hours, and is limited to AGENT_OPEN_DRAFTS waiting per agent and PRINCIPAL_OPEN_DRAFTS per person. The person is told through the notice channel, rendered from the
 * stored draft. Every refusal is a coded error and spends nothing: the checks run before the insert, and the quota inside the inserting transaction.
 */
export async function draftByAgent(host: Host, config: PresenceConfig, principal: string, agent: string, jkt: string | null, request: AgentOrderRequest, stillBound: () => void = () => {}): Promise<{ id: string; expiresAt: number; screening: string[] }> {
  const now = host.now();
  if (host.orderEmission?.() !== true) throw fail("unavailable", "orders are not enabled on this deployment (authority.orderEmission)");
  if (!registry.hasAgent(host.sql, agent)) throw fail("not_found", `no agent named ${agent}`);
  if (registry.isSuspended(host.sql, agent)) throw fail("suspended", `${agent} is suspended`);
  const by = `agent:${wireOf({ principal, agent })}`;
  const order = agentOrderSubjectOf(host.sql, agent, request, principal, jkt, (type, declared) => floorFor(config.pinned.floors, "order", type, declared));
  const row: ActRow = { id: newId(), kind: "order", body: canonicalJson({ kind: "order", subject: order.subject, order: order.extra } as never), drafted_by: by, return_to: null, state: "draft", created_at: now, draft_expires_at: now + DRAFT_MS, open_act: null, open_digest: null, open_expires_at: null, consumed_at: null, evidence: null };
  // The draft must be an act, here, so that opening it later cannot fail for a reason this call could have named. What the person is told is this act, composed from the stored row.
  const probe = await compose(config, principal, row, now, newId());
  if (probe === null) throw fail("invalid", "that is not an order this deployment can host");
  host.tx(() => {
    // The state read above, again: compose awaited, and the agent may have been suspended or removed meanwhile, or the caller's workspace unbound or key revoked (the caller's own recheck).
    stillBound();
    if (!registry.hasAgent(host.sql, agent)) throw fail("not_found", `no agent named ${agent}`);
    if (registry.isSuspended(host.sql, agent)) throw fail("suspended", `${agent} is suspended`);
    // The right and the envelope too: the owner may have taken back msg.draft or narrowed the declaration meanwhile, and a draft open() would refuse spends no quota.
    if (!drafterStillMay(host.sql, probe)) throw fail("draft_not_allowed", `${agent} may no longer ask for this order: its msg.draft right or ${order.subject.to as string}'s declaration changed while it was being composed`);
    // `drafted_by = ?` for one agent (an address can hold `_`, a LIKE wildcard), and the fixed prefix for all of the person's agents.
    const waiting = (match: string, who: string) => host.sql.exec<{ n: number }>(`SELECT count(*) AS n FROM acts WHERE kind = 'order' AND state IN ('draft', 'open') AND draft_expires_at >= ? AND ${match}`, now, who).one().n;
    if (waiting("drafted_by = ?", by) >= AGENT_OPEN_DRAFTS) throw fail("over_budget", `${agent} already has ${AGENT_OPEN_DRAFTS} orders waiting for you to sign; one has to be signed, cancelled or lapse first`);
    if (waiting("drafted_by LIKE ?", "agent:%") >= PRINCIPAL_OPEN_DRAFTS) throw fail("over_budget", `your agents already have ${PRINCIPAL_OPEN_DRAFTS} orders waiting for you to sign; some have to be signed, cancelled or lapse first`);
    const day = (match: string, who: string) => host.sql.exec<{ n: number }>(`SELECT count(*) AS n FROM acts WHERE kind = 'order' AND created_at > ? AND ${match}`, now - DAY, who).one().n;
    if (day("drafted_by = ?", by) >= AGENT_DRAFTS_PER_DAY) throw fail("over_budget", `${agent} has asked for ${AGENT_DRAFTS_PER_DAY} orders in the last day, whatever became of them; it can ask again later`);
    if (day("drafted_by LIKE ?", "agent:%") >= PRINCIPAL_DRAFTS_PER_DAY) throw fail("over_budget", `your agents have asked for ${PRINCIPAL_DRAFTS_PER_DAY} orders in the last day; they can ask again later`);
    clearOld(host.sql, now);
    host.sql.exec("INSERT INTO acts (id, kind, body, drafted_by, return_to, state, created_at, draft_expires_at) VALUES (?, ?, ?, ?, ?, 'draft', ?, ?)", row.id, row.kind, row.body, row.drafted_by, row.return_to, row.created_at, row.draft_expires_at);
    queueNotice(host.sql, agentDraftNotice(probe, row.id, row.draft_expires_at), now);
  });
  return { id: row.id, expiresAt: row.draft_expires_at, screening: order.screening };
}

/** Cancels a draft or an open act that has not been used. Narrowing, so the session may. False when there is nothing to cancel. */
export function cancel(host: Host, actId: string): boolean {
  return host.tx(() => host.sql.exec("UPDATE acts SET state = 'cancelled' WHERE id = ? AND state IN ('draft', 'open') RETURNING id", actId).toArray().length === 1);
}

// --- opening --------------------------------------------------------------------------------------------------

/** The credential ids the browser is offered for `act`: the keys that could sign it (and, for an enrollment, the key being enrolled too). */
export function allowFor(rows: readonly CredentialRow[], act: Act, config: PresenceConfig, now: number): string[] {
  const principal = act.principal;
  const subject = act.subject as { credentialThumbprint?: string; parentThumbprint?: string };
  if (act.kind === "enroll-credential") return rows.filter((r) => [subject.parentThumbprint, subject.credentialThumbprint].includes(r.thumbprint)).map((r) => r.id);
  const active = activeRows(rows, config.pinned, principal, now);
  return (act.kind === "revoke-credential" ? active.filter((r) => r.thumbprint !== subject.credentialThumbprint) : active).map((r) => r.id).slice(0, 16);
}

export function requestOptions(act: Act, challenge: Uint8Array, config: PresenceConfig, ids: readonly string[]): PublicKeyCredentialRequestOptionsJSON {
  return {
    challenge: b64u(challenge), rpId: act.rpId, timeout: WINDOW_MS,
    userVerification: needsUserVerification(act, config.pinned.floors) ? "required" : "preferred",
    ...(ids.length > 0 && { allowCredentials: ids.map((id) => ({ type: "public-key" as const, id })) }),
  };
}

export type OpenResult = { status: "ok"; act: Act; options: PublicKeyCredentialRequestOptionsJSON } | { status: "not_found" | "expired" | "consumed" | "unavailable" };

/**
 * Opens a draft: mints the nonce and the window, stores the finalized act, and returns it with the options the key is asked to answer. Opening an act again
 * replaces the one before it, so the earlier nonce can no longer be completed.
 */
export async function open(host: Host, config: PresenceConfig, principal: string, actId: string): Promise<OpenResult> {
  const now = host.now();
  const row = host.sql.exec<ActRow>("SELECT * FROM acts WHERE id = ?", actId).toArray()[0];
  if (!row || !(HOSTED_KINDS as readonly string[]).includes(row.kind)) return { status: "not_found" };
  if (row.state === "consumed") return { status: "consumed" };
  if (row.state === "cancelled") return { status: "not_found" };
  if (row.state === "expired" || now > row.draft_expires_at) {
    host.sql.exec("UPDATE acts SET state = 'expired' WHERE id = ? AND state IN ('draft', 'open')", actId);
    return { status: "expired" };
  }
  const act = await compose(config, principal, row, now, newId());
  if (act === null) return { status: "unavailable" };
  // An agent's draft is not offered for signing once its agent is stopped, has lost the right, or the receiver's defaults no longer hold it (applyOrder asks again at the touch).
  if (!drafterStillMay(host.sql, act)) return { status: "unavailable" };
  const challenge = await actChallenge(act);
  const digest = await actDigest(act);
  const rows = readRows(host.sql);
  const options = requestOptions(act, challenge, config, allowFor(rows, act, config, now));
  const opened = host.tx(() =>
    host.sql.exec(
      "UPDATE acts SET state = 'open', open_act = ?, open_digest = ?, open_expires_at = ? WHERE id = ? AND state IN ('draft', 'open') AND draft_expires_at >= ? RETURNING id",
      canonicalJson(act), digest, isoTime(act.windowExpiresAt), actId, now,
    ).toArray().length === 1,
  );
  return opened ? { status: "ok", act, options } : { status: "consumed" }; // consumed or cancelled between the read and the write
}

// --- completing -------------------------------------------------------------------------------------------

export function livenessRefused(sql: SqlStorage, config: PresenceConfig, principal: string, kind: ActKind, now: number, pinDigest: string): boolean {
  return LIVENESS_GUARDED[kind].some((k) => {
    const verdict = widening(sql, config, principal, k, now, pinDigest);
    return verdict.widening === "refused" && verdict.reason === "liveness_missing";
  });
}

export type CompleteResult = { status: "applied"; result: { kind: ActKind; ref: string }; returnTo?: string } | { status: "refused"; reason: ReasonCode };

export type Applied = {
  /** The counter of the new key's own touch of an enrollment, to be judged and kept like the signer's. */
  secondCounter: number; act: Act; digest: string; signer: CredentialRow; evidence: Evidence; second: Evidence | null; now: number; config: PresenceConfig; pinDigest: string;
  /** An order's root, built and signed before the transaction (order-acts.ts prepareRoot), and the declared minimum assurance its proof was verified against. */
  root?: PreparedRoot; declaredMin?: Assurance };

/** What each hosted kind does, in the consuming transaction. A thrown Refuse rolls the consumption back, so the touch is not spent on a refusal. */
function enrollEffect(host: Host, a: Applied): void {
  const subject = a.act.subject as { credentialThumbprint: string; label: string; parentThumbprint: string; aaguidClaimed: string | null };
  const rows = readRows(host.sql);
  const target = findByThumbprint(rows, subject.credentialThumbprint);
  // The key being enrolled is the registered one the draft named, still inert and never enrolled; what it was named by is what is stored.
  if (!target || !canBeEnrolled({ status: statusOf(rows, target, a.config.pinned, a.act.principal, a.now), via: target.via, parent: target.parent_thumbprint }) || target.label !== subject.label || target.aaguid !== subject.aaguidClaimed)
    throw new Refuse("credential_unknown");
  if (!a.second) throw new Refuse("second_assertion_missing");
  // Judged again here, on the rows as they are in this transaction: a parent too deep to chain is refused before anything is recorded (nothing is consumed either).
  if (!canEnrollUnder(subject.parentThumbprint, chainLookup(rows, a.config.pinned, a.act.principal))) throw new Refuse("chain_broken");
  // The new key's own touch is judged and kept as the signer's is: a clone of it that reuses this counter on its first act is a replay.
  if (counterReplayed(target.counter, a.secondCounter)) throw new Refuse("counter_replay");
  host.sql.exec("UPDATE human_credentials SET counter = ? WHERE thumbprint = ?", a.secondCounter, target.thumbprint);
  const activeAt = isoTime(a.act.issuedAt) + a.config.pinned.activationDelayHours * HOUR; // the verifier's own measure of the delay (credential-chain.ts)
  if (!recordEnrollment(host.sql, { thumbprint: target.thumbprint, parent: subject.parentThumbprint, act: canonicalJson(a.act), evidence: canonicalJson({ signer: a.evidence, newCredential: a.second }), activeAt }))
    throw new Refuse("credential_unknown");
}

function revokeEffect(host: Host, a: Applied): void {
  const subject = a.act.subject as { credentialThumbprint: string; label: string };
  const rows = readRows(host.sql);
  const target = findByThumbprint(rows, subject.credentialThumbprint);
  if (!target || target.label !== subject.label || statusOf(rows, target, a.config.pinned, a.act.principal, a.now) === "revoked") throw new Refuse("credential_unknown");
  // The signer, and whatever is chained through the target, are judged after the revocation: it must leave a signer.
  if (activeRows(rows, a.config.pinned, a.act.principal, a.now, target.thumbprint).length === 0) throw new Refuse("revocation_floor");
  markRevoked(host.sql, target.thumbprint, a.now);
}

/** Runs the effect of the act's kind. Exhaustive over the hosted kinds (the five core kinds are core-acts.ts's, grant and agent-scope grant-acts.ts's), and any other fails closed: a kind with no effect here is refused, never applied as nothing. */
export function applyEffect(host: Host, a: Applied): void {
  switch (a.act.kind) {
    case "enroll-credential":
      return enrollEffect(host, a);
    case "revoke-credential":
      return revokeEffect(host, a);
    case "agent-enroll":
    case "bind-existing":
    case "activation":
    case "declare-task":
    case "key-inventory":
      return applyCore({ sql: host.sql, now: a.now, act: a.act, digest: a.digest, forgetWake: host.forgetWake, enrollAllowed: host.enrollAllowed });
    case "grant":
    case "agent-scope":
      return applyGrantAct({ sql: host.sql, now: a.now, act: a.act, digest: a.digest });
    case "order":
    {
      if (!a.root || !a.declaredMin) throw new Refuse("order_refused");
      // A fresh time, not a.now: the root was signed after the proof's awaits, and is filed only while its deadline is still ahead.
      const at = host.now();
      applyOrder(host.sql, a.act, a.digest, a.root, at, a.declaredMin);
      return host.inbound?.stage(a.root.stored, at);
    }
    default:
      throw new Refuse("act_malformed");
  }
}

/** The subject the caller independently holds: the stored draft's, which the open act must carry unchanged (step 7). */
const sameSubject = (stored: Record<string, unknown>) => (subject: Readonly<Record<string, unknown>>): string | null => (canonicalJson(subject) === canonicalJson(stored) ? null : "subject");

export async function complete(host: Host, config: PresenceConfig, principal: string, actId: string, evidence: Evidence, second: Evidence | null): Promise<CompleteResult> {
  const now = host.now();
  const row = host.sql.exec<ActRow>("SELECT * FROM acts WHERE id = ?", actId).toArray()[0];
  if (!row || !(HOSTED_KINDS as readonly string[]).includes(row.kind)) return refused("not_found");
  if (row.state === "consumed") return refused("draft_used");
  if (row.state === "expired" || now > row.draft_expires_at) return refused("draft_expired");
  if (row.state !== "open" || row.open_act === null || row.open_digest === null || row.open_expires_at === null) return refused("not_found"); // a draft that was never opened, or cancelled
  if (now > row.open_expires_at) return refused("expired_window");
  const stored = bodyOf(row);
  if (!stored) return refused("act_malformed");
  // The open act as it was stored, re-read: its digest is the one recorded at open, so a row edited since is not an act anyone was shown.
  let openAct: unknown;
  try {
    openAct = JSON.parse(row.open_act);
  } catch {
    return refused("act_malformed");
  }
  const read = await readAct(openAct, config.pinned);
  if (!read.ok) return refused(read.reason);
  const act = read.act;
  const digest = await actDigest(act);
  if (digest !== row.open_digest || act.kind !== stored.kind || act.principal !== principal) return refused("act_malformed");
  if ((act.kind === "enroll-credential") !== (second !== null)) return refused(second === null ? "second_assertion_missing" : "denied");

  const rows = readRows(host.sql);
  const signer = rows.find((r) => r.id === evidence.credentialId); // a hint only: the signature must verify under this row's key, and the chain must reach a pin
  if (!signer) return refused("credential_unknown");
  const chain = chainFor(rows, signer, config.pinned, principal);
  if (chain === null) return refused("chain_broken");
  // An order is also bound to its type and the receiver's declared minimum assurance (which may raise the floor, never lower it); with the declaration gone it cannot be applied.
  const declared = act.kind === "order" ? declaredMinAssurance(host.sql, act) : null;
  if (act.kind === "order" && declared === null) return refused("keys_changed");
  const expect: ProofExpect = act.kind === "order"
    ? { kind: "order", principal, subject: sameSubject(stored.subject), taskType: (act.subject as { taskType: string }).taskType, declaredMinAssurance: declared! }
    : { kind: act.kind, principal, subject: sameSubject(stored.subject) };
  const proof = await verifyHumanProof({
    act: openAct, evidence, chain, pinned: config.pinned, expect,
    fresh: { online: true, now, live: { thumbprint: signer.thumbprint, active: statusOf(rows, signer, config.pinned, principal, now) === "active", counter: signer.counter }, revoked: revokedList(rows, config.pinned, principal, now) },
  });
  if (!proof.valid) return refused(proof.reason);

  let secondCounter = 0;
  if (act.kind === "enroll-credential") {
    // The new key touched this same act (VS-09): only a key in the signer's hand can be enrolled.
    const target = findByThumbprint(rows, (act.subject as { credentialThumbprint: string }).credentialThumbprint);
    if (!target) return refused("credential_unknown");
    const second2 = await verifyEnrollmentAssertion({ act: openAct, newCredential: { credential: keyOf(target), evidence: second! }, pinned: config.pinned });
    if (!second2.ok) return refused(second2.reason);
    secondCounter = second2.counter;
  }

  const pinDigest = await pinDigestOf(pinsFor(config, principal));
  // An order's root is signed by the broker's key, which is async: built and signed here, filed in the transaction below (or not at all).
  let root: PreparedRoot | undefined;
  if (act.kind === "order") {
    if (host.orderEmission?.() !== true || !host.receiptKeys) return refused("unavailable");
    // A refusal or a signing failure here is the act's answer, never a throw over RPC; nothing is consumed yet.
    try {
      const keys = await host.receiptKeys();
      // The deadline runs from when the root is signed, not from `now`, which was read before the proof's awaits.
      root = await prepareRoot(keys, act, digest, proof.credential, host.now());
      await host.inbound?.arm(root.stored);
    } catch (error) {
      return refused(error instanceof Refuse ? error.reason : "unavailable");
    }
  }
  try {
    const ref = host.tx(() => {
      // The one consuming step (F03): exactly one row changes, and only for the act that was opened and verified (a re-open since is a different digest).
      const consumed = host.sql.exec("UPDATE acts SET state = 'consumed', consumed_at = ?, evidence = ? WHERE id = ? AND state = 'open' AND open_digest = ? AND open_expires_at >= ? RETURNING id", now, canonicalJson({ evidence, second }), actId, digest, now).toArray();
      if (consumed.length !== 1) throw new Refuse(host.sql.exec<{ state: string }>("SELECT state FROM acts WHERE id = ?", actId).one().state === "consumed" ? "draft_used" : "challenge_mismatch");
      // The signer, re-read: revoked, or no longer chained, since the verify above is refused here, and so is a counter that moved.
      const fresh = readRows(host.sql);
      const live = findByThumbprint(fresh, signer.thumbprint);
      if (!live) throw new Refuse("credential_unknown");
      const status = statusOf(fresh, live, config.pinned, principal, now);
      if (status === "revoked") throw new Refuse("credential_revoked");
      if (status !== "active") throw new Refuse("credential_inactive");
      if (counterReplayed(live.counter, proof.counter)) throw new Refuse("counter_replay");
      markSigned(host.sql, live.thumbprint, proof.counter);
      refreshLatches(host.sql, config, principal, now, pinDigest); // before the effect, which may revoke: a rule met until now is latched first
      if (livenessRefused(host.sql, config, principal, act.kind, now, pinDigest)) throw new Refuse("liveness_missing"); // rolls the consumption back: the touch is not spent
      applyEffect(host, { act, digest, signer: live, evidence, second, secondCounter, now, config, pinDigest, ...(root && { root, declaredMin: declared! }) });
      appendLog(host.sql, { kind: `act.${act.kind}`, actor: principal, detail: { actDigest: digest, credential: live.thumbprint } }, now);
      queueNotice(host.sql, actNotice(act, live, digest), now);
      refreshLatches(host.sql, config, principal, now, pinDigest);
      return digest;
    });
    // The root is filed: wake its agent as a delivery does, after the commit and never failing the act.
    if (root) host.rootFiled?.(addressOf(root.stored.recipient).agent!, { id: root.stored.id, from: principal }, { digest: root.claim.actDigest, root: true });
    return { status: "applied", result: { kind: act.kind, ref }, ...(row.return_to !== null && { returnTo: row.return_to }) };
  } catch (error) {
    if (error instanceof Refuse) return refused(error.reason);
    throw error;
  }
}
