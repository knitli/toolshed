// Canonical JSON and the domain-separated digest an act is signed under (R4 plan 6.2). Acts hold only strings, safe integers, booleans, null, arrays and plain
// objects, so this is the strict subset of @knitli/openapi-mcp's canonicalJson that they use, written here so the offline verifier needs no dependency (G21):
// a differential test requires the two to produce the same bytes on every value both accept, and this to refuse the floats that one allows. It is looser in one
// place, on purpose: the library refuses the keys constructor and prototype, which an order body may have as field names (an act's digest is this file's alone).
// Pure TypeScript: WebCrypto only, no Worker types.

// Only __proto__: assigned from JSON it is an own key that a careless copy turns into a prototype. "constructor" and "prototype" are own data keys like any other (an order body may have fields so named).
const FORBIDDEN_KEYS: readonly string[] = ["__proto__"];
const encoder = new TextEncoder();

function serialize(value: unknown, ancestors: Set<object>): string {
  if (value === null) return "null";
  if (typeof value === "boolean") return value ? "true" : "false";
  if (typeof value === "number") {
    // -0 prints as 0 under JSON.stringify but is a different number to Object.is and to arithmetic: two acts with one digest and two values.
    if (!Number.isSafeInteger(value) || Object.is(value, -0)) throw new TypeError("canonical JSON in an act holds integers only");
    return JSON.stringify(value);
  }
  if (typeof value === "string") {
    if (!value.isWellFormed()) throw new TypeError("canonical JSON string holds an unpaired surrogate");
    return JSON.stringify(value);
  }
  if (typeof value !== "object") throw new TypeError("canonical JSON value is invalid");
  if (ancestors.has(value)) throw new TypeError("canonical JSON does not allow cycles");
  ancestors.add(value);
  try {
    if (Array.isArray(value)) {
      if (Object.getPrototypeOf(value) !== Array.prototype || Reflect.ownKeys(value).length !== value.length + 1) throw new TypeError("canonical JSON array is not plain");
      return `[${Array.from({ length: value.length }, (_, i) => serialize(dataOf(value, String(i)), ancestors)).join(",")}]`;
    }
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== null && prototype !== Object.prototype) throw new TypeError("canonical JSON object has an invalid prototype");
    const keys = Reflect.ownKeys(value);
    if (keys.some((key) => typeof key !== "string" || FORBIDDEN_KEYS.includes(key) || !key.isWellFormed())) throw new TypeError("canonical JSON object has a forbidden key");
    return `{${(keys as string[]).toSorted().map((key) => `${JSON.stringify(key)}:${serialize(dataOf(value, key), ancestors)}`).join(",")}}`;
  } finally {
    ancestors.delete(value);
  }
}

/** The own data property `key` of `value`, refusing an accessor or a non-enumerable one: a getter could answer one way here and another when it is stored. */
function dataOf(value: object, key: string): unknown {
  const descriptor = Object.getOwnPropertyDescriptor(value, key);
  if (descriptor === undefined || !("value" in descriptor) || !descriptor.enumerable) throw new TypeError("canonical JSON property is not plain data");
  return descriptor.value;
}

/** Deterministic JSON text of `value` (keys sorted by code unit, no whitespace); throws on anything an act may not hold. */
export const canonicalJson = (value: unknown): string => serialize(value, new Set());

const hex = (bytes: Uint8Array): string => Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
// `Uint8Array` as TextEncoder returns it: its buffer type differs between the Node and Worker libs, and digest takes either.
export async function sha256(bytes: Uint8Array): Promise<Uint8Array<ArrayBuffer>> {
  return new Uint8Array(await crypto.subtle.digest("SHA-256", bytes as Uint8Array<ArrayBuffer>));
}

/** `sha256(`${domain}\0${canonicalJson(value)}`)` as raw bytes: the domain stops a digest of one kind of value standing for another. */
export function domainDigest(domain: string, value: unknown): Promise<Uint8Array<ArrayBuffer>> {
  if (domain === "" || domain.includes("\0")) throw new TypeError("a digest domain is non-empty and NUL-free");
  return sha256(encoder.encode(`${domain}\0${canonicalJson(value)}`));
}

/** The same digest as lowercase hex, the form every stored digest takes (receipts.ts digest(), @knitli/openapi-mcp sha256). */
export async function domainDigestHex(domain: string, value: unknown): Promise<string> {
  return hex(await domainDigest(domain, value));
}

export function b64u(data: Uint8Array): string {
  let text = "";
  for (const byte of data) text += String.fromCharCode(byte);
  return btoa(text).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/** Canonical unpadded base64url only, else null: atob alone takes padding and stray bits, so one signature would have several encodings that all verify. */
export function unb64u(text: unknown): Uint8Array<ArrayBuffer> | null {
  if (typeof text !== "string" || !/^[A-Za-z0-9_-]*$/.test(text) || text.length % 4 === 1) return null;
  const data = Uint8Array.from(atob(text.replace(/-/g, "+").replace(/_/g, "/")), (c) => c.charCodeAt(0));
  return b64u(data) === text ? data : null;
}
