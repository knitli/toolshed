// The parts of a closed V1 contract that every service's parsers share (R4 plan 9.2, 7.6): the exact-keys object check, the anchored patterns for the
// names that cross the boundary, the three refusal words, and the one ISO 8601 time grammar. Pure TypeScript: no Worker types, no imports. Messaging's Execution contract and the
// Memory contract (memory-contract.ts) both read through it, so a name has one grammar on both sides.

/** The refusals every answer may be: a consumer treats each as no. */
export const REFUSALS: readonly unknown[] = ["denied", "unavailable", "invalid"];

export const WORKSPACE = /^[A-Za-z0-9._-]{1,128}$/;
export const AGENT = /^[a-z0-9-]{1,32}$/;
/** An OAuth profile (Messaging's registry binds one to an agent): 1-32 of a-z, 0-9 and hyphen. A bind-existing act that binds one reads this. */
export const OAUTH_PROFILE = /^[a-z0-9-]{1,32}$/;
/** A relying party id or host as a verifier is configured with it. */
export const HOST = /^[a-z0-9.-]{1,253}$/;
/** An origin as a browser sends it in client data: https, a host, an optional port. */
export const ORIGIN = /^https:\/\/[a-z0-9.-]{1,253}(?::\d{1,5})?$/;
/** A deployment: "knitli-os/<namespace>". */
export const AUD = /^knitli-os\/[a-z0-9-]{1,64}$/;
/** Agent addresses a `granted` agent wakes for without an order (the activation policy's `senders`). */
export const MAX_SENDERS = 32;
/** A label a person gave a key or a device: ASCII letters, digits, space, dot, underscore, hyphen, starting with a letter or digit, at most 40. Registration, the acts and the pins read this one. */
export const LABEL = /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,39}$/;
/** A ledger run id (P6a): `run-` and 32 lowercase hex digits. Execution names a run by it, and an exec-approve act that names one reads this. */
export const LEDGER_RUN_ID = /^run-[0-9a-f]{32}$/;
/** A message id: a lowercase UUID. One grammar on both sides of the Messaging/Execution contract, and in an order act's root id. */
export const MESSAGE_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
/** A digest in either spelling: Messaging's own are bare hex, Execution's `sha256:`-prefixed. */
export const DIGEST = /^(?:sha256:)?[0-9a-f]{64}$/;
/** A digest in Execution's one spelling for an image: `sha256:` and 64 lowercase hex digits. */
export const PREFIXED_DIGEST = /^sha256:[0-9a-f]{64}$/;
/**
 * A profile id: 1-63 of a-z, 0-9 and "-", not starting with "-". A character loop rather than a regex, so static analysis does not read a catalog or URL
 * value tested against a pattern as a ReDoS risk. Execution's catalog and the acts that name a profile use this one.
 */
export function isProfileId(value: unknown): value is string {
  if (typeof value !== "string" || value.length < 1 || value.length > 63 || value[0] === "-") return false;
  for (const c of value) if (!((c >= "a" && c <= "z") || (c >= "0" && c <= "9") || c === "-")) return false;
  return true;
}
/** The closed ASCII charset of a device name, which ends up in a sentence on the confirmation page and in a signed act (VS-25). One grammar for enrollment and for the acts. */
export const DEVICE = /^[A-Za-z0-9._-]{1,64}$/;
/** The most pinned anchors one principal may have: the liveness ceremony touches every one, in one act. */
export const MAX_ANCHORS_PER_PRINCIPAL = 8;
/** The fewest anchors a person may have pinned: the liveness ceremony needs two keys to show that more than one still works, and the deployment refuses a count below it. */
export const MIN_ANCHORS_PER_PRINCIPAL = 2;
/** Public keys one agent may hold at once: rotation adds the new one, then removes the old. The registry enforces it and a key inventory in an act is bounded by it. */
export const MAX_AGENT_KEYS = 5;
/** Starting grants one agent enrollment may carry (the enrollment contract's ENROLLMENT.grants, and the most an agent-enroll act lists). */
export const MAX_ENROLLMENT_GRANTS = 8;
/** A whole number an act can carry: a safe integer, and not -0 (which JSON prints as 0, so two values would share a digest). Messaging reads its integer inputs through this one. */
export const isActInteger = (value: unknown): value is number => typeof value === "number" && Number.isSafeInteger(value) && !Object.is(value, -0);
/** The farthest out a grant's expiry may be (Messaging LIMITS.grantMs, which imports this): 90 days. */
export const GRANT_MAX_MS = 90 * 24 * 60 * 60 * 1000;
/** The states a stored agent key has (agent_keys.state, plan 9.2): provisional until a human act lists it (INV14), then active. A removed key is gone, not marked. */
export const KEY_STATES = ["provisional", "active"] as const;
/** How long an Execution approval stays open (Execution proposes with approvalExpiresMs = now + this; an exec-approve act ends within one window of its issue). */
export const APPROVAL_WINDOW_MS = 30 * 60_000;
/** An enrollment id: 13 base32 characters, 65 bits drawn (gatekeeper-messaging newCodeId). */
export const CODE_ID = /^[a-z2-7]{13}$/;
export const THUMBPRINT = /^[A-Za-z0-9_-]{43}$/;
/**
 * A key thumbprint (or a 32-byte EC or OKP coordinate) in its one canonical spelling: 43 base64url characters whose last one carries no stray bits.
 * thumbprintOf emits only that spelling, so an alias with nonzero trailing bits would name a credential no key can have. Every place an act, a pin or a
 * bundle names a key by thumbprint reads this, never the bare pattern.
 */
export const isThumbprint = (value: unknown): value is string =>
  typeof value === "string" && THUMBPRINT.test(value) && (("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".indexOf(value[42]!)) & 3) === 0;
/** exec/<id> is the type of the messages that ask for a profile's runs, and a task type is at most 64 characters: the longest profile id (Execution's catalog reads this one). */
export const MAX_PROFILE_ID_LENGTH = 59;
// Shape only. ALLOWED_PRINCIPALS (canonicalEmail) is what decides whether a principal is anyone.
export const PRINCIPAL = /^[^\s@]{1,64}@[^\s@]{1,189}$/;

/** A sha256 digest as Messaging writes one: 64 lowercase hex digits, no prefix. Acts and receipts read this one. */
export const HEX64 = /^[0-9a-f]{64}$/;

/** `value` as a plain object whose own string keys are exactly `required` plus any of `optional`, or null. */
export function plain(value: unknown, required: readonly string[], optional: readonly string[] = []): Record<string, unknown> | null {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return null;
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) return null;
  const keys = Object.keys(value);
  if (keys.some((key) => !required.includes(key) && !optional.includes(key)) || required.some((key) => !Object.hasOwn(value, key))) return null;
  return value as Record<string, unknown>;
}

// Every pattern is anchored and bounded, so its quantifiers are the size limits.
export const matches = (value: unknown, pattern: RegExp): value is string => typeof value === "string" && pattern.test(value);
export const principal = (value: unknown): value is string => matches(value, PRINCIPAL) && value === value.toLowerCase();

const ISO_TIME = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2})(?:\.\d{1,3})?)?(?:Z|[+-](\d{2}):(\d{2}))$/;

/**
 * Epoch ms for an ISO 8601 date-time with a zone, or NaN. Date.parse alone also takes engine
 * formats ("October 1, 2026") and rolls a date like 2026-02-31 over into March, a time like 24:00 into the next day, and a second like :60 into the next minute.
 */
export function isoTime(text: string): number {
  const match = ISO_TIME.exec(text);
  if (!match) return Number.NaN;
  const [year, month, day] = [Number(match[1]), Number(match[2]), Number(match[3])];
  const date = new Date(Date.UTC(year, month - 1, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) return Number.NaN;
  // The clock and the zone offset are in range too: Date.parse takes 24:00 (and a leap second) and rolls them over, so two spellings would be one time.
  const [hour, minute, second, offsetHour, offsetMinute] = [match[4], match[5], match[6], match[7], match[8]].map((part) => (part === undefined ? 0 : Number(part)));
  if (hour! > 23 || minute! > 59 || second! > 59 || offsetHour! > 23 || offsetMinute! > 59) return Number.NaN;
  return Date.parse(text);
}
