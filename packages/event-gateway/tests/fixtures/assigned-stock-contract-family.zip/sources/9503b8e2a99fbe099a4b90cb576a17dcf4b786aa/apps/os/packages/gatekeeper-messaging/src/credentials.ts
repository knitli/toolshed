// The credential registry inside the Mailbox (R4 plan 6.3): a person's hardware credentials, which of them count as signers, and the chain that carries a
// signature back to a deploy-pinned anchor. Plain synchronous functions over the Mailbox's SQLite, called inside a caller's transactionSync where a change
// must stand or fall with the act that makes it.
//
// What counts as a signer is recomputed on every use and never read from a stored word: a credential is `active` when its thumbprint is pinned in the
// DEPLOYED configuration for its principal (an anchor, INV5), or when an active credential and it both signed an `enroll-credential` act naming it and the
// activation delay has passed. The `state` column is a record of revocation and nothing else: a row forced to 'active' by hand is still `registered`.
// Free of Worker types besides SqlStorage.

import type { ChainLink } from "authority/src/credential-chain.ts";
import { MAX_CHAIN_LINKS, type ChainNode } from "authority/src/credential-chain.ts";
import { MAX_ANCHORS_PER_PRINCIPAL } from "authority/src/contract-kit.ts";
import type { CredentialKey, Evidence, PinnedPresence } from "authority/src/webauthn.ts";
import type { ReasonCode } from "authority/src/contracts.ts";

// These tables are new in the release that has never been deployed, so CREATE TABLE IF NOT EXISTS is the whole migration. A column added to any of them LATER needs a
// guarded ALTER TABLE in mailbox.ts migrate() (check PRAGMA table_info first), because IF NOT EXISTS leaves an existing table as it is.
export const PRESENCE_SCHEMA = `
CREATE TABLE IF NOT EXISTS human_credentials (
  id TEXT PRIMARY KEY,
  thumbprint TEXT NOT NULL UNIQUE,
  jwk TEXT NOT NULL,
  alg INTEGER NOT NULL,
  aaguid TEXT,
  attestation TEXT NOT NULL CHECK (attestation IN ('verified-packed', 'self', 'none', 'unverified')),
  be INTEGER NOT NULL,
  bs INTEGER NOT NULL,
  counter INTEGER NOT NULL,
  label TEXT NOT NULL,
  state TEXT NOT NULL CHECK (state IN ('registered', 'active', 'revoked')),
  parent_act TEXT,
  enroll_evidence TEXT,
  parent_thumbprint TEXT,
  via TEXT CHECK (via IN ('window', 'session')),
  window_until INTEGER,
  signed INTEGER NOT NULL DEFAULT 0,
  registered_at INTEGER NOT NULL,
  active_at INTEGER,
  revoked_at INTEGER,
  access_sub TEXT
);
CREATE TABLE IF NOT EXISTS presence_user (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  user_id TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS registration_challenges (
  id TEXT PRIMARY KEY,
  challenge TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  used_at INTEGER
);
CREATE TABLE IF NOT EXISTS acts (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  body TEXT NOT NULL,
  drafted_by TEXT NOT NULL,
  return_to TEXT,
  state TEXT NOT NULL CHECK (state IN ('draft', 'open', 'consumed', 'expired', 'cancelled')),
  created_at INTEGER NOT NULL,
  draft_expires_at INTEGER NOT NULL,
  open_act TEXT,
  open_digest TEXT,
  open_expires_at INTEGER,
  consumed_at INTEGER,
  evidence TEXT
);
CREATE TABLE IF NOT EXISTS liveness_touches (
  act_id TEXT NOT NULL,
  thumbprint TEXT NOT NULL,
  at INTEGER NOT NULL,
  evidence TEXT NOT NULL,
  PRIMARY KEY (act_id, thumbprint)
);
CREATE TABLE IF NOT EXISTS liveness_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  pin_set_digest TEXT NOT NULL,
  epoch INTEGER NOT NULL,
  act_id TEXT NOT NULL,
  completed_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS pin_epoch (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  digest TEXT NOT NULL,
  n INTEGER NOT NULL,
  pins TEXT
);
CREATE TABLE IF NOT EXISTS enforcement_latch (
  kind TEXT PRIMARY KEY,
  latched_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS notices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at INTEGER NOT NULL,
  kind TEXT NOT NULL,
  ref TEXT NOT NULL,
  credential_thumbprint TEXT,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  state TEXT NOT NULL CHECK (state IN ('pending', 'sending', 'sent', 'failed', 'unsent')),
  attempts INTEGER NOT NULL DEFAULT 0,
  claimed_at INTEGER,
  retry_at INTEGER,
  last_error TEXT
);`;

export type CredentialRow = {
  id: string; thumbprint: string; jwk: string; alg: number; aaguid: string | null; attestation: string; be: number; bs: number; counter: number; label: string;
  state: string; parent_act: string | null; enroll_evidence: string | null; parent_thumbprint: string | null; registered_at: number; active_at: number | null; revoked_at: number | null;
  /** How it was registered: through an enroll window and its secret, or by the signed-in session alone. Absent on a row older than the column. */
  via?: "window" | "session" | null;
  signed?: number;
  /** The `until` of the window whose secret registered it (a `window` key), so a key is tied to its window and not to a time near it. Null on a row older than the column. */
  window_until?: number | null;
};

/** `registered`: inert. `pending`: enrolled, waiting out the delay. `active`: counts as a signer. `revoked`: itself, or a key it was chained through. */
export type Status = "registered" | "pending" | "active" | "revoked";

export const readRows = (sql: SqlStorage): CredentialRow[] => sql.exec<CredentialRow>("SELECT * FROM human_credentials ORDER BY registered_at, id").toArray();

export const isPinned = (pinned: Pick<PinnedPresence, "anchors">, principal: string, thumbprint: string): boolean =>
  pinned.anchors.some((a) => a.principal === principal && a.thumbprint === thumbprint);

/**
 * One credential's status now. `alsoRevoked` names a thumbprint to treat as revoked as well (the floor's "what if"), and everything chained through it
 * goes with it, as the verifier refuses a chain with a revoked link (credential_revoked).
 */
export function statusOf(rows: readonly CredentialRow[], row: CredentialRow, pinned: Pick<PinnedPresence, "anchors">, principal: string, now: number, alsoRevoked: string | null = null, depth = 0): Status {
  if (row.revoked_at !== null || row.state === "revoked" || row.thumbprint === alsoRevoked) return "revoked";
  if (isPinned(pinned, principal, row.thumbprint)) return "active";
  // A chained credential is one with its enrollment on record: the act and both touches that made it, which chainFor hands the verifier. A row without them is inert.
  if (row.parent_thumbprint === null || row.active_at === null || row.parent_act === null || row.enroll_evidence === null || depth >= MAX_CHAIN_LINKS) return "registered";
  const parent = rows.find((r) => r.thumbprint === row.parent_thumbprint);
  if (!parent) return "registered";
  const above = statusOf(rows, parent, pinned, principal, now, alsoRevoked, depth + 1);
  if (above === "revoked") return "revoked";
  if (above !== "active") return "registered";
  return now >= row.active_at ? "active" : "pending";
}

/** The rows as the chain-depth rule (authority's enrollmentDepth) reads them. */
export const chainLookup = (rows: readonly CredentialRow[], pinned: Pick<PinnedPresence, "anchors">, principal: string) => (thumbprint: string): ChainNode | undefined => {
  const row = rows.find((r) => r.thumbprint === thumbprint);
  return row ? { pinned: isPinned(pinned, principal, row.thumbprint), parent: row.parent_thumbprint } : undefined;
};

export const activeRows = (rows: readonly CredentialRow[], pinned: Pick<PinnedPresence, "anchors">, principal: string, now: number, alsoRevoked: string | null = null): CredentialRow[] =>
  rows.filter((row) => statusOf(rows, row, pinned, principal, now, alsoRevoked) === "active");

export const keyOf = (row: CredentialRow): CredentialKey => ({ jwk: JSON.parse(row.jwk) as Record<string, unknown>, alg: row.alg as -7 | -8 });

/**
 * The chain a bundle would carry for a signature by `row`: its own credential first, then (while it is not itself pinned) the enrollment that made it and
 * the credential that signed that. Built from stored evidence, and handed to verifyHumanProof, which is what decides: a chain that does not reach a pin is
 * `unanchored` there, whatever the database says. Null only when a stored link cannot be read.
 */
export function chainFor(rows: readonly CredentialRow[], row: CredentialRow, pinned: Pick<PinnedPresence, "anchors">, principal: string): ChainLink[] | null {
  const chain: ChainLink[] = [];
  let at: CredentialRow | undefined = row;
  for (let i = 0; at && i <= MAX_CHAIN_LINKS; i++) {
    if (isPinned(pinned, principal, at.thumbprint) || at.parent_thumbprint === null || at.parent_act === null || at.enroll_evidence === null) {
      chain.push({ credential: keyOf(at) });
      return chain;
    }
    let link: { enrollAct: unknown; enrollEvidence: { signer: Evidence; newCredential: Evidence } };
    try {
      link = { enrollAct: JSON.parse(at.parent_act), enrollEvidence: JSON.parse(at.enroll_evidence) };
    } catch {
      return null;
    }
    chain.push({ credential: keyOf(at), ...link });
    const parent: CredentialRow | undefined = rows.find((r) => r.thumbprint === at!.parent_thumbprint);
    at = parent;
  }
  return chain.length > 0 ? chain : null;
}

/** The thumbprints that are revoked, as verifyHumanProof's live list: itself revoked, or chained through a revoked key. */
export const revokedList = (rows: readonly CredentialRow[], pinned: Pick<PinnedPresence, "anchors">, principal: string, now: number): string[] =>
  rows.filter((row) => statusOf(rows, row, pinned, principal, now) === "revoked").map((row) => row.thumbprint);

export const MAX_CREDENTIALS = MAX_ANCHORS_PER_PRINCIPAL;
/**
 * The most rows that may be not revoked when a key is registered with an open window's secret. A session may register only while fewer than MAX_CREDENTIALS are, so a
 * person who has lost keys whose pins are still deployed (each counts as not revoked) can still register the replacements the window is for: the secret, a reviewed
 * deploy and the window's 72 hours bound this, and the replacements are pinned by a second reviewed deploy that drops the dead pins.
 */
export const WINDOW_MAX_CREDENTIALS = 2 * MAX_CREDENTIALS;

/**
 * A window root left over from a window that is over: not revoked (a revoked row is in the revoked history, judged by statusOf), registered with a window's secret, never pinned, never signed, never enrolled, and its window has ended or is no
 * longer on the configuration. Nothing can make it a signer except a reviewed deploy that pins it (then it is active, and counts), and a window with the same end
 * that is already past opens nothing, so it cannot come back by being listed again. It stays on record and can be revoked; it takes up no room.
 */
export const isStaleWindowRoot = (row: CredentialRow, pinned: Pick<PinnedPresence, "anchors">, principal: string, now: number, windows: readonly { principal: string; until: number }[]): boolean =>
  row.revoked_at === null && row.state !== "revoked" && row.via === "window" && !row.signed && row.window_until != null && row.parent_thumbprint === null && row.active_at === null && !isPinned(pinned, principal, row.thumbprint)
  && (row.window_until <= now || !windows.some((w) => w.principal === principal && w.until === row.window_until));

/** The credentials that take up room: every one that is not revoked by the same judgment everything else uses, so a key whose parent was revoked has gone with it, and not a stale window root. */
export const liveRows = (rows: readonly CredentialRow[], pinned: Pick<PinnedPresence, "anchors">, principal: string, now: number, windows: readonly { principal: string; until: number }[]): CredentialRow[] =>
  rows.filter((row) => statusOf(rows, row, pinned, principal, now) !== "revoked" && !isStaleWindowRoot(row, pinned, principal, now, windows));

/** At most this many registrations in a rolling day, revoked ones counted: register-and-revoke from a session cannot churn the registry faster than this. */
export const REGISTRATIONS_PER_DAY = MAX_CREDENTIALS;
/** A revoked key that never became a signer is kept this long past its revocation, then deleted. */
export const INERT_RETENTION_MS = 30 * 24 * 3600 * 1000;

/** How many credentials registered in the last day, revoked ones included. */
/**
 * Registrations in the last day, counted apart by how they were made: those with an enroll window's secret and the rest (the signed-in session's, and a row with no
 * record of how). They have their own allowance each, so a session that registers keys until its allowance is gone cannot use up the owner's window. The window's
 * allowance is that of one window, counted by the end recorded on a key: keys registered through an earlier window (and perhaps lost since) do not count against a new one.
 */
export const registeredToday = (rows: readonly CredentialRow[], now: number, scope: "session" | { windowUntil: number }): number =>
  rows.filter((row) => row.registered_at > now - 24 * 3600 * 1000 && (scope === "session" ? row.via !== "window" : row.via === "window" && row.window_until === scope.windowUntil)).length;

/**
 * Deletes the credentials that were revoked and left no record of authority, a month after their revocation. Decided from facts written when they happened, never from
 * the deployment's current pins (a pin rotated out is still a key that signed): the key was registered by the signed-in session (`via` = 'session', not through a
 * window and its secret), never enrolled (no active_at), never signed (`signed` = 0), and is nobody's parent. A row with no `via` (older) is kept. A key that was ever a
 * signer stays as a record; each of those took a touch of the owner's keys, so they are owner-bounded. With the daily registration quota the rows that can be deleted
 * stay within quota x (day + retention).
 */
export function dropInert(sql: SqlStorage, now: number): void {
  sql.exec(
    `DELETE FROM human_credentials WHERE via = 'session' AND signed = 0 AND active_at IS NULL AND parent_thumbprint IS NULL AND revoked_at IS NOT NULL AND revoked_at < ?
       AND NOT EXISTS (SELECT 1 FROM human_credentials child WHERE child.parent_thumbprint = human_credentials.thumbprint)`,
    now - INERT_RETENTION_MS,
  );
}

/** Notes that the credential signed something (an act, or a liveness touch): from then on its row is a record, whatever happens to its standing. */
export const markSigned = (sql: SqlStorage, thumbprint: string, counter: number): void =>
  void sql.exec("UPDATE human_credentials SET counter = ?, signed = 1 WHERE thumbprint = ?", counter, thumbprint);

/** A refusal thrown inside a consuming transaction so that it rolls back (the touch is not spent), and caught outside it. */
export class Refuse extends Error {
  constructor(readonly reason: ReasonCode) {
    super(reason);
  }
}

export type NewCredential = {
  id: string; key: CredentialKey; thumbprint: string; aaguid: string | null; counter: number; label: string;
  /** How it was registered: through a deploy-opened window and its secret, or by the signed-in session once the person has a signer. */
  via: "window" | "session";
  /** For a `window` key: the `until` of the window it was registered in. */
  windowUntil: number | null;
};

/** Inserts a registered (inert) credential. Rows are never deleted and are not capped in all: each one took a physical touch of a pinned or parent key (or the window secret), so growth is owner-bounded, and a lifetime cap would be a permanent lockout. Throws a UNIQUE error on a repeated id or thumbprint: the caller maps it to a refusal. */
export function insertCredential(sql: SqlStorage, c: NewCredential, now: number): void {
  sql.exec(
    "INSERT INTO human_credentials (id, thumbprint, jwk, alg, aaguid, attestation, be, bs, counter, label, state, via, window_until, registered_at) VALUES (?, ?, ?, ?, ?, 'none', 0, 0, ?, ?, 'registered', ?, ?, ?)",
    c.id, c.thumbprint, JSON.stringify(c.key.jwk), c.key.alg, c.aaguid, c.counter, c.label, c.via, c.windowUntil, now,
  );
}

/** Marks a credential revoked (itself; the ones chained through it follow by statusOf). */
export function markRevoked(sql: SqlStorage, thumbprint: string, now: number): boolean {
  return sql.exec("UPDATE human_credentials SET state = 'revoked', revoked_at = ? WHERE thumbprint = ? AND revoked_at IS NULL RETURNING thumbprint", now, thumbprint).toArray().length === 1;
}

/** Records the enrollment that makes `thumbprint` a signer once the delay has passed. Only a `registered`, never-enrolled, unrevoked credential is enrolled. */
export function recordEnrollment(sql: SqlStorage, args: { thumbprint: string; parent: string; act: string; evidence: string; activeAt: number }): boolean {
  return sql.exec(
    "UPDATE human_credentials SET parent_thumbprint = ?, parent_act = ?, enroll_evidence = ?, active_at = ? WHERE thumbprint = ? AND revoked_at IS NULL AND parent_thumbprint IS NULL AND active_at IS NULL RETURNING thumbprint",
    args.parent, args.act, args.evidence, args.activeAt, args.thumbprint,
  ).toArray().length === 1;
}

/** The counter rule (plan 6.7 step 9): BE=0, and a non-zero counter must strictly increase. */
export const counterReplayed = (stored: number, seen: number): boolean => (seen !== 0 || stored !== 0) && seen <= stored;
