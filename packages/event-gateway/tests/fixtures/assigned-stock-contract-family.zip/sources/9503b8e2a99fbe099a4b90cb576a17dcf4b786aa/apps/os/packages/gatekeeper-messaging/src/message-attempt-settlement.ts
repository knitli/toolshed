import { z } from "zod";
import { parseActivationClaimV1, parseEventMessageConsumer } from "./event-authority-contract.ts";
import type { WakeBudget } from "./mailbox.ts";

export const MESSAGE_SETTLEMENT_CAPACITY = 1000;
export const MESSAGE_SETTLEMENT_BYTE_CAPACITY = 1_048_576;
const AUTHORITY_DEADLINE_MS = 10_000;
const uuid = z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[47][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
const integer = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER);
const factSchema = z.strictObject({
  kind: z.literal("native_terminal_no_start"),
  // Namespace is an opaque source identifier; ASCII controls are forbidden.
  // eslint-disable-next-line no-control-regex
  namespace: z.string().min(1).max(256).regex(/^[^\x00-\x1f\x7f]+$/),
  principal: z.email().max(254).refine(value => value === value.toLowerCase()),
  agent: z.string().regex(/^[a-z0-9-]{1,32}$/),
  agentIncarnation: integer,
  messageId: uuid,
  keyThumbprint: z.string().regex(/^[A-Za-z0-9_-]{43}$/),
  routingGeneration: integer.min(1),
  consumer: z.unknown().transform((value, context) => {
    const parsed = parseEventMessageConsumer(value);
    if (parsed && parsed.consumerGeneration === parsed.attachmentGeneration) return parsed;
    context.addIssue({ code: "custom", message: "invalid consumer" });
    return z.NEVER;
  }),
  attemptId: uuid,
  reservedAt: integer,
  deliveryId: z.string().regex(/^dly_[0-9a-f]{64}$/),
  permitId: uuid,
  receiptId: uuid,
});
export type MessageTerminalFact = Readonly<Omit<z.infer<typeof factSchema>, "consumer"> & {
  consumer: Readonly<z.infer<typeof factSchema>["consumer"]>;
}>;

/** Trusted deployment port, not a request field. No production caller installs it.
 * The verifier must bind this exact fact to committed coordinator admission and
 * terminal native evidence. Current Mailbox rows cannot prove permit/delivery identity.
 * assertCurrent synchronously rechecks the verifier's proof/configuration fences;
 * it must throw if they changed, including on a historical replay. */
export interface MessageTerminalAuthority {
  verifyTerminalNoStart(fact: MessageTerminalFact): Promise<{ assertCurrent(): void } | null>;
}
type Result = { status: "not_started"; attemptId: string; replayed: boolean };
type Reservation = { agent: string; identity: string; reserved_at: number; activation_json: string | null };

/** Dormant module-only transition. No Worker/RPC exports or default verifier. */
export async function settleMessageAttempt(
  storage: DurableObjectStorage, selfName: string | undefined, input: unknown, authority?: MessageTerminalAuthority,
): Promise<Result> {
  const parsed = factSchema.safeParse(input);
  if (!parsed.success) throw new Error("invalid");
  const fact: MessageTerminalFact = Object.freeze({ ...parsed.data, consumer: Object.freeze(parsed.data.consumer) });
  if (selfName !== JSON.stringify([fact.namespace, fact.principal])) throw new Error("denied");
  const verify = authority?.verifyTerminalNoStart;
  if (typeof verify !== "function") throw new Error("denied");
  const factJson = JSON.stringify(fact);
  if (new TextEncoder().encode(factJson).byteLength > 4096) throw new Error("invalid");
  const publication = JSON.stringify([fact.namespace, fact.principal, fact.agent, fact.agentIncarnation, fact.messageId]);
  const identity = JSON.stringify([publication, fact.agent, fact.keyThumbprint, fact.routingGeneration, fact.consumer]);
  const requireReservation = (): void => {
    const row = storage.sql.exec<Reservation>(
      "SELECT agent,identity,reserved_at,activation_json FROM message_wake_attempts WHERE attempt_id=?", fact.attemptId,
    ).toArray()[0];
    if (!row || row.agent !== fact.agent || row.identity !== identity || row.reserved_at !== fact.reservedAt)
      throw new Error("conflict");
    if (row.activation_json !== null) {
      let value: unknown;
      try { value = JSON.parse(row.activation_json); } catch { throw new Error("conflict"); }
      const activation = parseActivationClaimV1(value);
      if (!activation || activation.principal !== fact.principal || activation.agent !== fact.agent ||
        activation.agentIncarnation !== fact.agentIncarnation || activation.source.kind !== "message" ||
        activation.source.namespace !== fact.namespace || activation.source.messageId !== fact.messageId ||
        activation.source.routeGeneration !== fact.routingGeneration || JSON.stringify(activation.source.consumer) !== JSON.stringify(fact.consumer) ||
        JSON.stringify(activation) !== row.activation_json) throw new Error("conflict");
    }
  };
  const settlement = (): string | null => storage.sql.exec<{ fact_json: string }>(
    "SELECT fact_json FROM message_attempt_settlements WHERE attempt_id=?", fact.attemptId,
  ).toArray()[0]?.fact_json ?? null;
  const recorded = settlement();
  if (recorded !== null) {
    if (recorded !== factJson) throw new Error("conflict");
  } else requireReservation();
  let timer: ReturnType<typeof setTimeout> | undefined;
  let proof: { assertCurrent(): void } | null;
  try {
    proof = await Promise.race([
      verify.call(authority, fact),
      new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error("unavailable")), AUTHORITY_DEADLINE_MS); }),
    ]);
  } catch { throw new Error("unavailable"); }
  finally { if (timer !== undefined) clearTimeout(timer); }
  if (!proof || typeof proof.assertCurrent !== "function") throw new Error("denied");
  return storage.transactionSync(() => {
    if (authority?.verifyTerminalNoStart !== verify) throw new Error("denied");
    // TypeScript permits async functions in void-returning slots. Reject one at
    // runtime: a deferred fence must never authorize the synchronous commit.
    const asserted: unknown = proof.assertCurrent();
    if (asserted !== undefined) throw new Error("denied");
    const previous = settlement();
    if (previous !== null) {
      if (previous !== factJson) throw new Error("conflict");
      return { status: "not_started", attemptId: fact.attemptId, replayed: true };
    }
    // A terminal receipt is independently retained history. Its replay never
    // needs a live reservation, but a disappeared receipt cannot be recreated.
    if (recorded !== null) throw new Error("conflict");
    requireReservation();
    if (storage.sql.exec("SELECT attempt_id FROM message_attempt_settlements WHERE receipt_id=?", fact.receiptId).toArray().length)
      throw new Error("conflict");
    // The logical byte budget adds 8 for settled_at; route receipts have two numeric fields and add 16.
    const usage = storage.sql.exec<{ count: number; bytes: number }>(`SELECT count(*) AS count,
      coalesce(sum(length(CAST(attempt_id AS BLOB))+length(CAST(receipt_id AS BLOB))+length(CAST(fact_json AS BLOB))+8),0) AS bytes
      FROM message_attempt_settlements`).one();
    const bytes = new TextEncoder().encode(fact.attemptId + fact.receiptId + factJson).byteLength + 8;
    if (usage.count >= MESSAGE_SETTLEMENT_CAPACITY || usage.bytes + bytes > MESSAGE_SETTLEMENT_BYTE_CAPACITY)
      throw new Error("capacity");
    storage.sql.exec("INSERT INTO message_attempt_settlements(attempt_id,receipt_id,fact_json,settled_at) VALUES (?,?,?,?)",
      fact.attemptId, fact.receiptId, factJson, Date.now());
    const incarnation = storage.sql.exec<{ created_at: number }>("SELECT created_at FROM agents WHERE name=?", fact.agent).toArray()[0]?.created_at;
    const budgetKey = `wake-budget:${fact.agent}`;
    const budget = storage.kv.get<WakeBudget>(budgetKey);
    // Historical proof settles its old reservation, never a replacement agent or pending owner.
    // Keep all charged timestamps and reservation decisions, even after their rolling window.
    if (incarnation === fact.agentIncarnation && budget?.pendingToken === `event:${fact.attemptId}`)
      storage.kv.put<WakeBudget>(budgetKey, { ...budget, pendingSince: null, pendingToken: null });
    return { status: "not_started", attemptId: fact.attemptId, replayed: false };
  });
}
