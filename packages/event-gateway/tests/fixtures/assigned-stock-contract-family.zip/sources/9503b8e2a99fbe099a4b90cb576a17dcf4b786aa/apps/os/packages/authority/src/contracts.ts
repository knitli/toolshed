/**
 * The HumanProof contract (R4 plan 6.5): the presence Worker's only door to the Mailbox that hosts acts and credentials. Closed V1, parsed field by field as the
 * Memory contract is: an extra key is refused, an RPC result's own symbols are left behind, and a result that is not exactly one of the shapes below is
 * `unavailable`, which every caller treats as a refusal. The presence Worker never receives act bytes from the browser and never parses a JWT: it forwards the
 * caller's Access assertion in `UserCall` and the Mailbox re-verifies it. This file is types and parsers only; the entrypoint is Messaging's. Free of Worker
 * types and of imports but the kit and this package's own modules.
 */
import { B64U_128, ACT_KINDS, actChallenge, type Act, type ActKind } from "./act.ts";
import { b64u, canonicalJson, unb64u } from "./canonical.ts";
import { readAct } from "./credential-chain.ts";
import { effectiveFloor, needsUserVerification } from "./floor.ts";
import { draftedByText, renderR1 } from "./render.ts";
import { snapshot } from "./snapshot.ts";
import { LABEL, isThumbprint, matches, plain } from "./contract-kit.ts";
import { PROOF_REASONS, type ProofReason } from "./human-proof.ts";
import { MAX_EVIDENCE_CHARS, pinSetOf, readPinned, samePinSet, type Evidence, type PinnedPresence } from "./webauthn.ts";

// The WebAuthn JSON option shapes the browser helpers take (WebAuthn L3 `parse*OptionsFromJSON`), kept to what the ceremony script passes through untouched.
export type PublicKeyCredentialRequestOptionsJSON = { challenge: string; rpId: string; timeout?: number; allowCredentials?: { type: "public-key"; id: string }[]; userVerification: "required" | "preferred" | "discouraged" };
export type PublicKeyCredentialCreationOptionsJSON = {
  rp: { id: string; name: string };
  user: { id: string; name: string; displayName: string };
  challenge: string;
  pubKeyCredParams: { type: "public-key"; alg: number }[];
  timeout?: number;
  excludeCredentials?: { type: "public-key"; id: string }[];
  authenticatorSelection: { authenticatorAttachment: "cross-platform"; residentKey: "discouraged"; userVerification: "required" };
  attestation: "none";
  hints?: string[];
  extensions?: { credProps: true };
};

/** What the presence Worker forwards from the browser request: the Access assertion header, Origin, Sec-Fetch-Site and the CSRF value. The Mailbox re-verifies all four. */
export type UserCall = Readonly<{ accessAssertion: string; origin: string; secFetchSite: string; csrf: string }>;

/** Why a ceremony was refused: a proof's own reason (6.7) or one of the host's. The host's list is closed too; a new reason is a spec change. */
const HOST_REASONS = [
  "not_found", "draft_expired", "draft_used", "not_yours", "window_closed", "secret_wrong", "credential_unknown", "second_assertion_missing",
  "revocation_floor", "denied", "unavailable", "keys_changed", "order_refused", "liveness_missing",
] as const;
export type ReasonCode = ProofReason | (typeof HOST_REASONS)[number];
const PROOF_REASON = /^(?:order|subject)_mismatch:[A-Za-z0-9.[\]]{1,64}$/;
const FIXED_REASONS: readonly string[] = [...HOST_REASONS, ...PROOF_REASONS];
export const isReasonCode = (value: unknown): value is ReasonCode => typeof value === "string" && (FIXED_REASONS.includes(value) || PROOF_REASON.test(value));

/**
 * Revocation has no method of its own. Session-tier revocation (at least two active credentials remain, or a 24 h delay with a notice) is the admin API's;
 * the branch that needs another credential's proof is the `revoke-credential` act, drafted, opened and completed through `open`/`complete` like any other,
 * and verified with signer != subject (reason `signer_is_subject`).
 */
export interface HumanProofV1 {
  open(call: UserCall, actId: string): Promise<OpenResultV1>;
  complete(call: UserCall, actId: string, response: unknown, newCredentialResponse?: unknown): Promise<CompleteResultV1>;
  /** `intent`: whether the person will give the window's secret (`window`) or not (`session`, a later key beside one they have). Only that way's room is checked. `windowSecret`: required (not empty) when the intent is `window`, and checked before a challenge is issued, so a wrong secret never reaches a key touch; ignored for `session`. */
  beginRegistration(call: UserCall, intent: RegistrationIntent, windowSecret: string): Promise<BeginRegistrationResultV1>;
  finishRegistration(call: UserCall, challengeId: string, response: unknown, windowSecret: string): Promise<FinishRegistrationResultV1>;
  /** Opens (or continues) the liveness ceremony: the anchor-liveness act, its options, and which pinned keys have touched it. */
  liveness(call: UserCall): Promise<LivenessResultV1>;
  /** One pinned anchor's assertion over the liveness act `actId`, which `liveness` returned. Each key touches the same act; the last one completes it. */
  finishLiveness(call: UserCall, actId: string, response: unknown): Promise<FinishLivenessResultV1>;
}

/** How a registration will be made: with an enroll window's secret, or by the signed-in session alone. */
export type RegistrationIntent = "window" | "session";

export type OpenResultV1 =
  | { status: "ok"; act: unknown; options: PublicKeyCredentialRequestOptionsJSON }
  | { status: "not_found" | "expired" | "consumed" | "unavailable" };
/** `returnTo`: where the stored draft asked the browser to go afterwards. It is the Mailbox's, not the browser's; the presence Worker still checks it against its own allowlist. */
export type CompleteResultV1 = { status: "applied"; result: { kind: ActKind; ref: string }; returnTo?: string } | { status: "refused"; reason: ReasonCode };
export type BeginRegistrationResultV1 = { status: "ok"; options: PublicKeyCredentialCreationOptionsJSON; challengeId: string } | { status: "window_closed" | "secret_wrong" | "denied" | "unavailable" };
export type FinishRegistrationResultV1 = { status: "registered"; thumbprint: string; attestation: "none"; label: string } | { status: "refused"; reason: ReasonCode };
export type LivenessResultV1 =
  | { status: "ok"; actId: string; act: unknown; pinned: string[]; touched: string[]; options?: PublicKeyCredentialRequestOptionsJSON } // no options once every pinned key has touched
  | { status: "denied" | "unavailable" };
export type FinishLivenessResultV1 =
  // `credential`: the thumbprint of the key whose assertion this answer is for, one of `touched`; the presence Worker checks it against the pins it holds.
  | { status: "touched"; credential: string; touched: string[]; remaining: number }
  | { status: "complete"; credential: string; touched: string[] }
  | { status: "refused"; reason: ReasonCode };

// --- inputs --------------------------------------------------------------------------------------------------

/** An act or challenge id: 128 random bits, base64url. */
export const parseActId = (value: unknown): string | null => (matches(value, B64U_128) ? value : null);

export const MAX_ASSERTION_BYTES = 4096;

/**
 * The browser's `credential.toJSON()` for an assertion, as the Evidence the verifier takes, or null: exact keys, at most 4 KiB in all, canonical base64url
 * everywhere, `id` equal to `rawId`. The client data stays the raw bytes the authenticator signed over (as base64url); nothing is re-serialized.
 */
export function parseAssertionResponse(value: unknown): Evidence | null {
  const once = snapshot(value, { dropSymbols: true }); // read once, as plain data: no hole, getter or odd prototype reaches the checks below
  if (once === null) return null;
  value = once.value;
  // plain() reads own keys only and calls nothing on the value; each field is then read once, and the size is that of the accepted strings, so a hostile
  // object's toJSON or getters never run before the shape is known.
  const top = plain(value, ["id", "rawId", "type", "response"], ["authenticatorAttachment", "clientExtensionResults"]);
  const response = top && plain(top.response, ["authenticatorData", "clientDataJSON", "signature"], ["userHandle"]);
  if (!top || !response || top.type !== "public-key" || top.id !== top.rawId) return null;
  const id = top.id;
  const { authenticatorData, clientDataJSON, signature, userHandle } = response;
  const parts = [id, authenticatorData, clientDataJSON, signature, ...(userHandle === undefined || userHandle === null ? [] : [userHandle])];
  const sizes: [unknown, number][] = [[id, MAX_EVIDENCE_CHARS.credentialId], [authenticatorData, MAX_EVIDENCE_CHARS.authenticatorData], [clientDataJSON, MAX_EVIDENCE_CHARS.clientDataJSON], [signature, MAX_EVIDENCE_CHARS.signature]];
  if (sizes.some(([part, max]) => typeof part !== "string" || part.length > max)) return null;
  if (!parts.every((part) => typeof part === "string") || (parts as string[]).reduce((n, part) => n + part.length, 0) > MAX_ASSERTION_BYTES) return null;
  if (![id, authenticatorData, clientDataJSON, signature].every((field) => unb64u(field) !== null)) return null;
  if (userHandle !== undefined && userHandle !== null && unb64u(userHandle) === null) return null;
  const extensions = top.clientExtensionResults;
  if (extensions !== undefined && (plain(extensions, []) === null)) return null; // an assertion asks for no extension, so none comes back
  if (top.authenticatorAttachment !== undefined && !["platform", "cross-platform", null].includes(top.authenticatorAttachment as string | null)) return null;
  return { authenticatorData: authenticatorData as string, clientDataJSON: clientDataJSON as string, signature: signature as string, credentialId: id as string };
}

// --- results -------------------------------------------------------------------------------------------------

const unavailable = { status: "unavailable" } as const;
const LINE_LIMIT = 200;
/** Base64url that is at most `max` characters, checked before it is decoded. */
const bounded = (value: unknown, max: number): value is string => typeof value === "string" && value.length <= max && unb64u(value) !== null;
/** Base64url of exactly 32 bytes, checked before it is decoded. */
const bytes32 = (value: unknown): value is string => bounded(value, 43) && unb64u(value)!.length === 32;
const requestOptions = (value: unknown): PublicKeyCredentialRequestOptionsJSON | null => {
  const o = plain(value, ["challenge", "rpId", "userVerification"], ["timeout", "allowCredentials"]);
  // The challenge is an act's digest: exactly 32 bytes.
  if (!o || !bounded(o.challenge, 43) || unb64u(o.challenge)!.length !== 32 || !matches(o.rpId, /^[a-z0-9.-]{1,253}$/) || !["required", "preferred", "discouraged"].includes(o.userVerification as string)) return null;
  if (o.timeout !== undefined && !(Number.isSafeInteger(o.timeout) && (o.timeout as number) > 0 && (o.timeout as number) <= 600_000)) return null;
  let allow: { type: "public-key"; id: string }[] | undefined;
  if (o.allowCredentials !== undefined) {
    if (!Array.isArray(o.allowCredentials) || o.allowCredentials.length > 16) return null;
    allow = [];
    for (const entry of o.allowCredentials as unknown[]) {
      const c = plain(entry, ["type", "id"]);
      if (!c || c.type !== "public-key" || !bounded(c.id, MAX_EVIDENCE_CHARS.credentialId)) return null;
      allow.push({ type: "public-key", id: c.id as string });
    }
    if (repeats(allow)) return null;
  }
  return { challenge: o.challenge as string, rpId: o.rpId as string, userVerification: o.userVerification as "required", ...(o.timeout !== undefined && { timeout: o.timeout as number }), ...(allow && { allowCredentials: allow }) };
};

/**
 * The most an act may weigh as canonical JSON in an open result. The worst act of every kind (declare-task with 16 enum fields of 16 values in each of two
 * field lists and 8 largest default terms; agent-enroll with 32 largest terms, 16 grants of 16 types and 16 keys; an order with 32 largest terms and a 4 KiB
 * body) is under 100 KiB, which a test builds and renders; this leaves room and still stops a result that is only weight.
 */
export const MAX_ACT_BYTES = 128 * 1024;
/** The longest return address a draft may hold (the Mailbox's own bound). */
export const MAX_RETURN_TO = 512;
/** The size of a signed text is its UTF-8 bytes, which is what crosses the wire and what the bound is for: .length counts UTF-16 units and lets a multi-byte act through. */
export const utf8Length = (text: string): number => new TextEncoder().encode(text).length;

export function parseOpenResult(value: unknown): OpenResultV1 {
  const once = snapshot(value, { dropSymbols: true }); // read once, as plain data: no hole, getter or odd prototype reaches the checks below
  if (once === null) return unavailable;
  value = once.value;
  // The Mailbox sends the act itself and no text about it: what a person reads is rendered here from the act (reviewActForSigning), so a Mailbox cannot
  // show one thing and have another signed.
  const top = plain(value, ["status"], ["act", "options"]);
  if (!top) return unavailable;
  if (top.status !== "ok") return ["not_found", "expired", "consumed", "unavailable"].includes(top.status as string) && Object.keys(top).length === 1 ? { status: top.status as "not_found" } : unavailable;
  const options = requestOptions(top.options);
  if (!options || top.act === null || typeof top.act !== "object" || Array.isArray(top.act)) return unavailable;
  try {
    if (utf8Length(canonicalJson(top.act)) > MAX_ACT_BYTES) return unavailable;
    return { status: "ok", act: structuredClone(top.act), options };
  } catch {
    return unavailable; // not plain data
  }
}

export type ReviewResult =
  | { status: "ok"; act: Act; lines: string[]; risk: "normal" | "high"; draftedBy: string; expiresAt: string; options: PublicKeyCredentialRequestOptionsJSON }
  | { status: "refused"; reason: "act_malformed" | "aud_mismatch" | "rp_mismatch" | "challenge_mismatch" | "assurance_below_floor" | "user_verification_not_required" | "pinned_invalid" | "principal_mismatch" };

/**
 * What the presence Worker shows, from an open result and its own pinned aud and rpId: the act parsed and checked, its text rendered here with r1, and the
 * challenge the key will sign checked to be this act's digest. The lines a person reads are therefore a function of the bytes the key signs; nothing the
 * Mailbox says about the act is used. A mismatch is refused, and nothing is shown.
 */
export async function reviewActForSigning(given: Extract<OpenResultV1, { status: "ok" }>, givenPinned: Pick<PinnedPresence, "aud" | "rpId" | "floors">, signedInAs: string): Promise<ReviewResult> {
  const pinned = readPinned(givenPinned, "review"); // read once, and held to what a pinned file could hold
  if (!pinned) return { status: "refused", reason: "pinned_invalid" };
  const copy = snapshot(given);
  if (!copy) return { status: "refused", reason: "act_malformed" };
  const open = copy.value as typeof given;
  const read = await readAct(open.act, pinned);
  if (!read.ok) return { status: "refused", reason: read.reason };
  const act = read.act;
  // An act is the signed-in person's own: another principal's act is not shown. `signedInAs` is required, so no caller can skip this.
  if (act.principal !== signedInAs) return { status: "refused", reason: "principal_mismatch" };
  if (open.options.challenge !== b64u(await actChallenge(act))) return { status: "refused", reason: "challenge_mismatch" };
  if (open.options.rpId !== act.rpId) return { status: "refused", reason: "rp_mismatch" };
  // What the key is asked for must be what the verifier will demand: PIN whenever the pinned floor or the act itself says hw-uv.
  if (effectiveFloor(act, pinned.floors) === "hw-uv" && act.assurance !== "hw-uv") return { status: "refused", reason: "assurance_below_floor" };
  if (needsUserVerification(act, pinned.floors) && open.options.userVerification !== "required") return { status: "refused", reason: "user_verification_not_required" };
  const rendered = renderR1(act);
  return { status: "ok", act, lines: rendered.lines, risk: rendered.risk, draftedBy: draftedByText(act), expiresAt: act.windowExpiresAt, options: open.options };
}

export function parseCompleteResult(value: unknown): CompleteResultV1 {
  const once = snapshot(value, { dropSymbols: true }); // read once, as plain data: no hole, getter or odd prototype reaches the checks below
  if (once === null) return { status: "refused", reason: "unavailable" };
  value = once.value;
  const top = plain(value, ["status"], ["result", "reason", "returnTo"]);
  if (top?.status === "applied" && top.result !== undefined && top.reason === undefined) {
    const result = plain(top.result, ["kind", "ref"]);
    const returnTo = top.returnTo;
    if (returnTo !== undefined && (typeof returnTo !== "string" || returnTo.length > MAX_RETURN_TO)) return { status: "refused", reason: "unavailable" };
    return result && ACT_KINDS.includes(result.kind as ActKind) && typeof result.ref === "string" && result.ref.length <= LINE_LIMIT
      ? { status: "applied", result: { kind: result.kind as ActKind, ref: result.ref }, ...(returnTo !== undefined && { returnTo }) }
      : { status: "refused", reason: "unavailable" };
  }
  return top?.status === "refused" && Object.keys(top).length === 2 && isReasonCode(top.reason) ? { status: "refused", reason: top.reason } : { status: "refused", reason: "unavailable" };
}

export function parseFinishRegistrationResult(value: unknown): FinishRegistrationResultV1 {
  const once = snapshot(value, { dropSymbols: true }); // read once, as plain data: no hole, getter or odd prototype reaches the checks below
  if (once === null) return { status: "refused", reason: "unavailable" };
  value = once.value;
  const top = plain(value, ["status"], ["thumbprint", "attestation", "label", "reason"]);
  if (top?.status === "registered" && Object.keys(top).length === 4 && isThumbprint(top.thumbprint) && top.attestation === "none" && matches(top.label, LABEL))
    return { status: "registered", thumbprint: top.thumbprint, attestation: "none", label: top.label };
  return top?.status === "refused" && Object.keys(top).length === 2 && isReasonCode(top.reason) ? { status: "refused", reason: top.reason } : { status: "refused", reason: "unavailable" };
}

const TRANSPORTS: readonly unknown[] = ["usb", "nfc", "ble", "hybrid", "internal", "smart-card"];
const credentialIds = (list: unknown): { type: "public-key"; id: string; transports?: string[] }[] | null => {
  if (!Array.isArray(list) || list.length > 16) return null;
  const out: { type: "public-key"; id: string; transports?: string[] }[] = [];
  for (const entry of list as unknown[]) {
    const c = plain(entry, ["type", "id"], ["transports"]);
    const transports = c?.transports;
    if (!c || c.type !== "public-key" || !bounded(c.id, MAX_EVIDENCE_CHARS.credentialId) || (transports !== undefined && !(Array.isArray(transports) && transports.length <= 6 && transports.every((t) => TRANSPORTS.includes(t))))) return null;
    out.push({ type: "public-key", id: c.id as string, ...(transports !== undefined && { transports: [...(transports as string[])] }) });
  }
  return repeats(out) ? null : out;
};
const NAME_TEXT = /^[\x20-\x7e]{1,64}$/;

/** Registration options, rebuilt field by field: nothing the Mailbox composed reaches the browser unchecked. */
function creationOptions(value: unknown): PublicKeyCredentialCreationOptionsJSON | null {
  const o = plain(value, ["rp", "user", "challenge", "pubKeyCredParams", "authenticatorSelection", "attestation"], ["timeout", "excludeCredentials", "hints", "extensions"]);
  const rp = o && plain(o.rp, ["id", "name"]);
  const user = o && plain(o.user, ["id", "name", "displayName"]);
  const selection = o && plain(o.authenticatorSelection, ["authenticatorAttachment", "residentKey", "userVerification"]);
  if (!o || !rp || !user || !selection || !bytes32(o.challenge) || o.attestation !== "none") return null;
  if (selection.userVerification !== "required" || selection.authenticatorAttachment !== "cross-platform" || selection.residentKey !== "discouraged") return null;
  if (!matches(rp.id, /^[a-z0-9.-]{1,253}$/) || !matches(rp.name, NAME_TEXT) || !bytes32(user.id) || !matches(user.name, NAME_TEXT) || !matches(user.displayName, NAME_TEXT)) return null;
  const algs = Array.isArray(o.pubKeyCredParams) && o.pubKeyCredParams.length >= 1 && o.pubKeyCredParams.length <= 4 ? (o.pubKeyCredParams as unknown[]).map((p) => plain(p, ["type", "alg"])) : null;
  if (!algs || algs.some((p) => !p || p.type !== "public-key" || (p.alg !== -7 && p.alg !== -8))) return null;
  const exclude = o.excludeCredentials === undefined ? undefined : credentialIds(o.excludeCredentials);
  if (exclude === null) return null;
  if (o.timeout !== undefined && !(Number.isSafeInteger(o.timeout) && (o.timeout as number) > 0 && (o.timeout as number) <= 600_000)) return null;
  if (o.hints !== undefined && !(Array.isArray(o.hints) && o.hints.length <= 4 && o.hints.every((h) => h === "security-key"))) return null;
  const ext = o.extensions === undefined ? undefined : plain(o.extensions, ["credProps"]);
  if (o.extensions !== undefined && (!ext || ext.credProps !== true)) return null;
  return {
    rp: { id: rp.id as string, name: rp.name as string }, user: { id: user.id as string, name: user.name as string, displayName: user.displayName as string }, challenge: o.challenge as string,
    pubKeyCredParams: (algs as { alg: number }[]).map((p) => ({ type: "public-key" as const, alg: p.alg })),
    authenticatorSelection: { authenticatorAttachment: "cross-platform", residentKey: "discouraged", userVerification: "required" }, attestation: "none",
    ...(o.timeout !== undefined && { timeout: o.timeout as number }), ...(exclude && { excludeCredentials: exclude }), ...(o.hints !== undefined && { hints: [...(o.hints as string[])] }),
    ...(ext && { extensions: { credProps: true as const } }),
  };
}

export function parseBeginRegistrationResult(value: unknown): BeginRegistrationResultV1 {
  const once = snapshot(value, { dropSymbols: true }); // read once, as plain data: no hole, getter or odd prototype reaches the checks below
  if (once === null) return unavailable;
  value = once.value;
  const top = plain(value, ["status"], ["options", "challengeId"]);
  if (!top) return unavailable;
  if (top.status !== "ok") return ["window_closed", "secret_wrong", "denied", "unavailable"].includes(top.status as string) && Object.keys(top).length === 1 ? { status: top.status as "denied" } : unavailable;
  const options = creationOptions(top.options);
  return options && matches(top.challengeId, B64U_128) ? { status: "ok", options, challengeId: top.challengeId } : unavailable;
}

/** A list of thumbprints: bounded, each canonical and each once. The one reader of every such list in the HumanProof results (pinned, touched), so a repeat is refused for every consumer. */
const prints = (list: unknown): string[] | null => (Array.isArray(list) && list.length <= 16 && list.every(isThumbprint) && new Set(list).size === list.length ? [...(list as string[])] : null);
/** Whether a list of credential ids repeats one (the allow and exclude lists of the WebAuthn options). */
const repeats = (ids: readonly { id: string }[]): boolean => new Set(ids.map((c) => c.id)).size !== ids.length;

/** `act` as plain data of bounded weight, copied; the checks on what it says are reviewActForSigning's and reviewLiveness's. */
function actData(value: unknown): unknown {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return undefined;
  try {
    return utf8Length(canonicalJson(value)) <= MAX_ACT_BYTES ? structuredClone(value) : undefined;
  } catch {
    return undefined;
  }
}

export function parseLivenessResult(value: unknown): LivenessResultV1 {
  const once = snapshot(value, { dropSymbols: true }); // read once, as plain data: no hole, getter or odd prototype reaches the checks below
  if (once === null) return unavailable;
  value = once.value;
  const top = plain(value, ["status"], ["actId", "act", "pinned", "touched", "options"]);
  if (!top) return unavailable;
  if (top.status !== "ok") return top.status === "denied" && Object.keys(top).length === 1 ? { status: "denied" } : unavailable;
  const pinned = prints(top.pinned);
  const touched = prints(top.touched);
  const act = actData(top.act);
  const options = top.options === undefined ? undefined : requestOptions(top.options);
  if (!pinned || !touched || act === undefined || options === null || !matches(top.actId, B64U_128) || touched.some((t) => !pinned.includes(t))) return unavailable;
  return { status: "ok", actId: top.actId, act, pinned, touched, ...(options && { options }) };
}

export function parseFinishLivenessResult(value: unknown): FinishLivenessResultV1 {
  const once = snapshot(value, { dropSymbols: true }); // read once, as plain data: no hole, getter or odd prototype reaches the checks below
  if (once === null) return { status: "refused", reason: "unavailable" };
  value = once.value;
  const refused = { status: "refused", reason: "unavailable" } as const;
  const top = plain(value, ["status"], ["credential", "touched", "remaining", "reason"]);
  if (!top) return refused;
  const touched = top.touched === undefined ? null : prints(top.touched);
  const credential = prints([top.credential])?.[0] ?? null;
  if (credential !== null && !touched?.includes(credential)) return refused; // the signer is one of the keys touched
  if (top.status === "touched" && Object.keys(top).length === 4 && credential && touched && int(top.remaining, 1, 16)) return { status: "touched", credential, touched, remaining: top.remaining };
  if (top.status === "complete" && Object.keys(top).length === 3 && credential && touched) return { status: "complete", credential, touched };
  return top.status === "refused" && Object.keys(top).length === 2 && isReasonCode(top.reason) ? { status: "refused", reason: top.reason } : refused;
}

const int = (value: unknown, min: number, max: number): value is number => typeof value === "number" && Number.isSafeInteger(value) && value >= min && value <= max;

// --- the presence Worker's checks of the other ceremonies -----------------------------------------------------------

export type RegistrationReview =
  | { status: "ok"; options: PublicKeyCredentialCreationOptionsJSON; challengeId: string }
  | { status: "refused"; reason: "rp_mismatch" | "algorithms" };

/**
 * Registration options as the presence Worker may hand them to the browser: the relying party is exactly the pinned one (a parent domain such as knitli.app,
 * or any other id, is refused: the credential would be bound to it), and the algorithms are ES256 then EdDSA, as the plan fixes them (6.3). The rest of the
 * options (no attestation, cross-platform, UV required, no resident key) is already closed by parseBeginRegistrationResult.
 */
export function reviewRegistrationOptions(begin: Extract<BeginRegistrationResultV1, { status: "ok" }>, pinned: Pick<PinnedPresence, "rpId">): RegistrationReview {
  const options = begin.options;
  if (options.rp.id !== pinned.rpId) return { status: "refused", reason: "rp_mismatch" };
  if (options.pubKeyCredParams.length !== 2 || options.pubKeyCredParams[0]!.alg !== -7 || options.pubKeyCredParams[1]!.alg !== -8) return { status: "refused", reason: "algorithms" };
  return { status: "ok", options, challengeId: begin.challengeId };
}

export type LivenessReview =
  | { status: "ok"; act: Act; lines: string[]; pinned: string[]; touched: string[]; options?: PublicKeyCredentialRequestOptionsJSON; actId: string }
  | { status: "refused"; reason: "act_malformed" | "aud_mismatch" | "rp_mismatch" | "challenge_mismatch" | "user_verification_not_required" | "not_liveness" | "pin_set_mismatch" | "options_missing" | "touched_unpinned" | "assurance_below_floor" | "pinned_invalid" };

/**
 * The liveness ceremony as the presence Worker may show it: the act is an `anchor-liveness` for this person that names exactly the keys the presence Worker's own
 * pinned configuration names for them (not the Mailbox's idea of the pins), and the options' challenge is that act's digest, for the pinned relying party,
 * with the PIN required. A Mailbox that asks the owner to touch a different set of keys, or a different act, is refused.
 */
export async function reviewLiveness(givenResult: Extract<LivenessResultV1, { status: "ok" }>, givenPinned: PinnedPresence, principal: string): Promise<LivenessReview> {
  const pinned = readPinned(givenPinned, "full");
  if (!pinned || typeof principal !== "string") return { status: "refused", reason: "pinned_invalid" };
  const copy = snapshot(givenResult);
  if (!copy) return { status: "refused", reason: "act_malformed" };
  const result = copy.value as typeof givenResult;
  const read = await readAct(result.act, pinned);
  if (!read.ok) return { status: "refused", reason: read.reason };
  const act = read.act;
  // The same floor check as the act review, on every liveness result, completed ones included: an act claiming less than the floor is not shown.
  if (effectiveFloor(act, pinned.floors) === "hw-uv" && act.assurance !== "hw-uv") return { status: "refused", reason: "assurance_below_floor" };
  const own = pinSetOf(pinned.anchors, principal);
  const named = act.subject as { principal: string; thumbprints: string[] };
  const same = samePinSet;
  if (act.kind !== "anchor-liveness" || act.principal !== principal || named.principal !== principal) return { status: "refused", reason: "not_liveness" };
  if (!same(named.thumbprints, own) || !same(result.pinned.toSorted(), own)) return { status: "refused", reason: "pin_set_mismatch" };
  // What is shown as pinned is the presence Worker's own list, and the touched keys are the Mailbox's claim, accepted only where they are among those.
  if (result.touched.some((t) => !own.includes(t))) return { status: "refused", reason: "touched_unpinned" };
  const remaining = own.filter((t) => !result.touched.includes(t));
  if (remaining.length > 0 && !result.options) return { status: "refused", reason: "options_missing" }; // keys still to touch and nothing to touch them with
  const options = remaining.length > 0 ? result.options : undefined;
  if (options) {
    if (options.challenge !== b64u(await actChallenge(act))) return { status: "refused", reason: "challenge_mismatch" };
    if (options.rpId !== act.rpId) return { status: "refused", reason: "rp_mismatch" };
    if (needsUserVerification(act, pinned.floors) && options.userVerification !== "required") return { status: "refused", reason: "user_verification_not_required" };
  }
  return { status: "ok", act, lines: renderR1(act).lines, pinned: own, touched: result.touched, actId: result.actId, ...(options && { options }) };
}
