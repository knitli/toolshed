// Orders (R4 plan 6.6, 7.4, 5.4): the row a signed `order` act writes, the envelope every later hop of its thread is checked against in issue() and
// again in deliver(), and the consequence rule. An ordered thread is same-owner at every hop, so all of it lives in this one Mailbox and both checks read
// the same rows. The gate keys on the MESSAGE, not on a local row (VS-07): a hop whose root receipt is v3 is ordered, and with no order row here it is
// refused `order_unknown`. A receipt's `order` claim names the order; it is never evidence that the order is live.
//
// Plain synchronous functions over the Mailbox's SQLite, so the Mailbox runs them in the step that inserts. Its callers authorize.

import { printTerm, resCovers, type Term } from "authority/src/scope.ts";
import { screen } from "authority/src/text.ts";
import { canonicalJson } from "@knitli/openapi-mcp/runtime";
import { appendLog } from "./authority-log.ts";
import { readRows, statusOf } from "./credentials.ts";
import { LIMITS, statusAt, addressOf, checkedType, fail, partyAddress, wireOf, type Address, type Kind, type Stored } from "./model.ts";
import { decodeReceipt, type OrderClaim } from "./receipts.ts";
import type { LiveOrder } from "./activation.ts";
import type { Mode, PresenceConfig } from "./presence.ts";
import * as tasks from "./tasks.ts";

export const ORDERS_SCHEMA = `
CREATE TABLE IF NOT EXISTS orders (
  digest TEXT PRIMARY KEY,
  thread_id TEXT NOT NULL UNIQUE,
  agent TEXT NOT NULL,
  task_type TEXT NOT NULL,
  scope TEXT NOT NULL,
  max_depth INTEGER NOT NULL,
  allow_forward INTEGER NOT NULL CHECK (allow_forward IN (0, 1)),
  max_messages INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  drafted_by TEXT NOT NULL,
  credential TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  revoked_at INTEGER
);`;

/** An order as stored: `digest` is the act's (the order's id), `thread_id` its root message's id, `agent` the root addressee, `credential` the signing key. */
export type OrderRow = {
  digest: string; thread_id: string; agent: string; task_type: string; scope: string; max_depth: number; allow_forward: number; max_messages: number;
  expires_at: number; drafted_by: string; credential: string; created_at: number; revoked_at: number | null;
};

/** Whether the key that signed an order is still an active signer, from the Mailbox's credential rows and the deployed pins (VS-08: revoking it ends its orders). */
export type CredentialLive = (thumbprint: string) => boolean;

/** The order claim a message's thread carries: its root receipt's, when that is v3 (only an order's root is). Null for every other thread. */
export function claimOf(message: Pick<Stored, "chain" | "receipt">): OrderClaim | null {
  const root = decodeReceipt(message.chain[0] ?? message.receipt)?.payload;
  return root?.v === 3 ? root.order : null;
}

/** Whether a key is an active signer for `principal` now, under the deployed pins: with presence off or broken, none is (an order then has no live key). */
export function credentialLive(sql: SqlStorage, config: PresenceConfig | null, principal: string, now: number): CredentialLive {
  return (thumbprint) => {
    if (config === null) return false;
    const rows = readRows(sql);
    const row = rows.find((r) => r.thumbprint === thumbprint);
    return row !== undefined && statusOf(rows, row, config.pinned, principal, now) === "active";
  };
}

/** The one INSERT of a message row: Mailbox #insert (every send and delivery) and an order's root (order-acts.ts) both write through it. */
export function insertMessage(sql: SqlStorage, box: "in" | "out", message: Stored, counterpart: string, status: string, now: number, agent: string | null): void {
  sql.exec(
    "INSERT INTO messages (box, id, row, counterpart, created_at, expires_at, status, agent, thread_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
    box, message.id, JSON.stringify(message), counterpart, now, message.expiresAt ? Date.parse(message.expiresAt) : null, status, agent, message.threadId,
  );
}

export const orderOf = (sql: SqlStorage, digest: string): OrderRow | null => sql.exec<OrderRow>("SELECT * FROM orders WHERE digest = ?", digest).toArray()[0] ?? null;

const outOfEnvelope = (limit: string, why: string): Error => fail("out_of_envelope", `${limit}: ${why}`);

/** What a hop is, as the gate reads it: never the caller's claim of a type, always the one the message is checked under. */
export type Hop = { id: string; kind: Kind; threadId: string; from: Address; to: Address; type: string | null; depth: number; expiresAt: string | null };

/**
 * The envelope of plan 7.4, for one hop of an ordered thread: the order is known here and live, both ends are its person's, a forward is allowed and its
 * recipient covered by a signed `msg.forward` term (within its count), the type is the order's, the depth and the thread's message count are within its
 * limits, and the hop's deadline is not after the order's. Throws `order_unknown` or `out_of_envelope` naming the limit; returns the order.
 */
export function gate(sql: SqlStorage, claim: OrderClaim, hop: Hop, principal: string, live: CredentialLive, now: number): OrderRow {
  const order = orderOf(sql, claim.actDigest);
  if (!order || order.thread_id !== hop.threadId) throw fail("order_unknown", "this thread was started by an order this Mailbox does not hold");
  if (order.revoked_at !== null) throw outOfEnvelope("revoked", "the order was revoked");
  if (now >= order.expires_at) throw outOfEnvelope("expired", "the order has expired");
  if (!live(order.credential)) throw outOfEnvelope("credential", "the security key that signed the order is no longer active");
  if (hop.from.principal !== principal || hop.to.principal !== principal) throw outOfEnvelope("cross_owner", "every hop of an order is between its own person's agents");
  if (hop.type !== order.task_type) throw outOfEnvelope("type", `an order covers ${order.task_type} only`);
  if (hop.depth > order.max_depth || hop.depth > LIMITS.depth) throw outOfEnvelope("depth", `the order allows ${order.max_depth} hops`);
  // Every message of the thread but this one (each is in both boxes of this Mailbox, the outbox row and the inbox row: one message each).
  const prior = new Map(sql.exec<{ id: string; row: string }>("SELECT id, row FROM messages WHERE thread_id = ? AND id != ? ORDER BY created_at, id", hop.threadId, hop.id).toArray().map((r) => [r.id, JSON.parse(r.row) as Stored]));
  if (prior.size + 1 > order.max_messages) throw outOfEnvelope("count", `the order allows ${order.max_messages} messages`);
  if (hop.kind === "forward") {
    if (order.allow_forward !== 1) throw outOfEnvelope("forward", "the order does not allow forwarding");
    const scope = JSON.parse(order.scope) as Term[];
    const covers = (to: string) => scope.filter((t) => t.svc === "msg" && t.verb === "forward" && resCovers("msg", t.res, to) && (t.where?.type === undefined || t.where.type.includes(order.task_type)));
    const to = wireOf(hop.to);
    const covering = covers(to);
    if (covering.length === 0) throw outOfEnvelope("recipient", `the order does not let its task be handed to ${to}`);
    // The forwards already made, in the order they were filed, each spent against one covering term as the offline verifier spends them
    // (messaging-receipts.ts attenuate): an uncapped term if there is one, else the first with a forward left. A msg.forward term covers exactly one
    // address (authority resCovers), so terms that cover the same recipient are interchangeable and first fit gives the same totals in any order.
    const spent = new Map<Term, number>();
    for (const m of prior.values()) {
      if (m.kind !== "forward") continue;
      const terms = covers(m.recipient);
      const term = terms.find((t) => t.cap?.n === undefined) ?? terms.find((t) => (spent.get(t) ?? 0) < t.cap!.n!);
      if (term?.cap?.n !== undefined) spent.set(term, (spent.get(term) ?? 0) + 1);
    }
    if (!covering.some((t) => t.cap?.n === undefined || (spent.get(t) ?? 0) < t.cap.n)) throw outOfEnvelope("cap", `the order's forwards to ${to} are used up`);
  }
  if (hop.expiresAt === null || Date.parse(hop.expiresAt) > order.expires_at) throw outOfEnvelope("expiry", "a message in an order ends no later than the order");
  return order;
}

/** The hop a stored message is, for the gate: its sender and recipient, and the type it is checked under (the order's, for a forward or a reply). */
export function hopOf(message: Stored, type: string | null): Hop {
  return { id: message.id, kind: message.kind, threadId: message.threadId, from: partyAddress(message.sender), to: addressOf(message.recipient, "recipient"), type, depth: message.depth, expiresAt: message.expiresAt };
}

/**
 * The live order a canonical inbox message may activate under. The caller has already loaded the trusted inbox row; this checks its carried order
 * against this Mailbox's live order and current credential state. Null means the message has no order claim; an invalid claimed order throws the gate's
 * refusal, so callers must deny it and never fall back to ordinary activation.
 */
export function liveOrderFor(
  sql: SqlStorage,
  message: Stored,
  targetAgent: string,
  facts: { owner: string; live: CredentialLive },
  now: number,
): LiveOrder | null {
  const claim = claimOf(message);
  if (claim === null) return null;

  const order = gate(sql, claim, hopOf(message, checkedType(message)), facts.owner, facts.live, now);
  const root = message.id === order.thread_id;
  const recipient = addressOf(message.recipient, "recipient");
  if (recipient.agent !== targetAgent || (root && order.agent !== targetAgent)) {
    throw outOfEnvelope("recipient", "the message is not addressed to the target agent");
  }
  return { digest: order.digest, root };
}

/** Stable source identity carried by the GitHub watch task's owner-signed order. */
export type GitHubSourceIdentityV1 = Readonly<{
  installationId: number; repositoryId: number; prNumber: number; sourceIncarnation: number;
}>;

export const GITHUB_WATCH_TASK_TYPE = "event/github-watch/v1";
const SOURCE_FIELDS = ["installationId", "repositoryId", "prNumber", "sourceIncarnation"] as const;
const exactRecord = (value: unknown, keys: readonly string[]): value is Record<string, unknown> => {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return false;
  const got = Object.keys(value);
  return got.length === keys.length && keys.every((key) => Object.hasOwn(value, key));
};
const positiveSafeInteger = (value: unknown): value is number => Number.isSafeInteger(value) && (value as number) > 0;

/**
 * Resolve a live owner-ordered GitHub watch from this Mailbox's canonical root rows. Caller data is only the identity to match; it never supplies an
 * order digest or receipt. Historical dead orders are ignored, but two live, fully validated exact matches are ambiguous and deny admission.
 */
export function liveGitHubSourceOrderFor(
  sql: SqlStorage,
  targetAgent: string,
  source: GitHubSourceIdentityV1,
  facts: { owner: string; live: CredentialLive },
  now: number,
): LiveOrder | null {
  if (!exactRecord(source, SOURCE_FIELDS) || !SOURCE_FIELDS.every((key) => positiveSafeInteger(source[key]))) return null;
  const declaration = tasks.declaredType(sql, targetAgent, GITHUB_WATCH_TASK_TYPE);
  if (!declaration || declaration.class !== "inform" || declaration.payload.fields.length !== SOURCE_FIELDS.length ||
      SOURCE_FIELDS.some((name) => !declaration.payload.fields.some((f) => f.name === name && f.kind === "int" && f.required))) return null;

  const matches: LiveOrder[] = [];
  for (const order of sql.exec<OrderRow>("SELECT * FROM orders WHERE agent = ? AND task_type = ?", targetAgent, GITHUB_WATCH_TASK_TYPE).toArray()) {
    // Revoked/expired/inactive historical orders do not shadow a replacement. Gate validates remaining local liveness and the root envelope.
    if (order.revoked_at !== null || now >= order.expires_at || !facts.live(order.credential) || order.scope !== "[]" || order.allow_forward !== 0) continue;
    const rows = sql.exec<{ row: string }>("SELECT row FROM messages WHERE box = 'out' AND id = ? AND thread_id = ? AND agent IS NULL", order.thread_id, order.thread_id).toArray();
    if (rows.length !== 1) continue;
    let message: Stored;
    try { message = JSON.parse(rows[0]!.row) as Stored; } catch { continue; }
    try {
      if (message.id !== order.thread_id || message.threadId !== order.thread_id || message.kind !== "request" || message.depth !== 0 ||
          message.parents.length !== 0 || message.sender.principal !== facts.owner || message.sender.agent !== undefined || message.sender.client !== "order" ||
          !("cred" in message.sender) || message.sender.cred !== order.credential || message.applied !== "human-ordered" || message.taskType !== GITHUB_WATCH_TASK_TYPE ||
          message.recipient !== `${facts.owner}/${targetAgent}` || message.expiresAt === null || Date.parse(message.expiresAt) <= now) continue;
      const body = JSON.parse(message.body) as unknown;
      if (!exactRecord(body, ["v", "kind", "fields", "inputs", "deadlineSeconds"]) || body.v !== 1 || body.kind !== "task" ||
          !Array.isArray(body.inputs) || body.inputs.length !== 0 || !Number.isSafeInteger(body.deadlineSeconds) || (body.deadlineSeconds as number) < 1 ||
          !exactRecord(body.fields, ["objective", ...SOURCE_FIELDS])) continue;
      const fields = body.fields;
      if (typeof fields.objective !== "string" ||
          !SOURCE_FIELDS.every((key) => positiveSafeInteger(fields[key]) && fields[key] === source[key]) ||
          canonicalJson(body as never) !== message.body || tasks.bodyProblem(declaration, message.body, true) !== null) continue;
      const result = liveOrderFor(sql, message, targetAgent, facts, now);
      if (!result?.root || result.digest !== order.digest) continue;
      const receipt = decodeReceipt(message.receipt)?.payload;
      if (!receipt || receipt.v !== 3 || receipt.order.root !== true || receipt.order.actDigest !== order.digest || receipt.order.cred !== order.credential ||
          receipt.order.tier !== "anchored" || Date.parse(receipt.order.expiresAt) !== order.expires_at || receipt.order.draftedBy !== order.drafted_by ||
          receipt.id !== message.id || receipt.threadId !== message.threadId || receipt.kind !== "request" || receipt.depth !== 0 || receipt.parents.length !== 0 ||
          receipt.sender.principal !== facts.owner || receipt.sender.client !== "order" || !("cred" in receipt.sender) || receipt.sender.cred !== order.credential ||
          receipt.recipient.principal !== facts.owner || receipt.recipient.agent !== targetAgent ||
          receipt.applied !== "human-ordered" || receipt.issuedAt !== message.issuedAt || receipt.expiresAt !== message.expiresAt ||
          receipt.taskType !== GITHUB_WATCH_TASK_TYPE) continue;
      matches.push({ digest: result.digest, root: false });
    } catch {
      // A malformed local candidate is ineligible; never select it by recency or trust caller-supplied metadata.
    }
  }
  return matches.length === 1 ? matches[0]! : null;
}

/**
 * The consequence rule (plan 5.4 item 2): a request or forward of a type its recipient declares consequential is delivered only inside an ordered thread.
 * `off` lets it through; `observe` lets it through and, when `log` is given, records that it would have been refused; `enforce` refuses `order_required`.
 * A reply is a result, not a task. An undeclared type is `inform` (FC-03).
 */
const none = (): void => {};
export function consequence(sql: SqlStorage, mode: Mode, m: { kind: Kind; recipient: string; type: string | null; ordered: boolean; id: string }, log?: { actor: string; now: number }): () => void {
  if (mode === "off" || m.kind === "reply" || m.ordered || m.type === null) return none;
  const to = addressOf(m.recipient, "recipient");
  if (to.agent === null || tasks.declaredType(sql, to.agent, m.type)?.class !== "consequential") return none;
  if (mode === "enforce") throw fail("order_required", `${to.agent} declares ${m.type} consequential: it is delivered only inside a thread a person ordered`);
  // `observe`: the record is written by the caller once the message is filed, so a delivery refused later (a full inbox) counts nothing.
  return log ? () => appendLog(sql, { kind: "consequence.would_refuse", actor: log.actor, agent: to.agent, detail: { messageId: m.id, taskType: m.type } }, log.now) : none;
}

/**
 * deliver()'s check (plan 7.4, 5.4), in the recipient's Mailbox, which for an ordered thread is the same one issue() checked in: the hop's envelope,
 * when its thread was started by an order, and the consequence rule, which logs a would-be refusal under `observe`.
 */
export function atDelivery(sql: SqlStorage, message: Stored, facts: { owner: string; live: CredentialLive; rule: Mode }, now: number): () => void {
  const claim = claimOf(message);
  const type = checkedType(message);
  if (claim) gate(sql, claim, hopOf(message, type), facts.owner, facts.live, now);
  // What to record once the message is filed (an observed would-be refusal), in the inserting transaction.
  return consequence(sql, facts.rule, { kind: message.kind, recipient: message.recipient, type, ordered: claim !== null, id: message.id }, { actor: facts.owner, now });
}

/** Revokes an order (narrowing: a session may). Its next hop and its next wake are refused (the gate reads the row). False when it is unknown or already revoked. */
export function revoke(sql: SqlStorage, digest: string, now: number): boolean {
  return sql.exec("UPDATE orders SET revoked_at = ? WHERE digest = ? AND revoked_at IS NULL RETURNING digest", now, digest).toArray().length === 1;
}
/** Revokes every order still live (Stop everything), and says how many. */
export const revokeLive = (sql: SqlStorage, now: number): number => sql.exec("UPDATE orders SET revoked_at = ? WHERE revoked_at IS NULL AND expires_at > ? RETURNING digest", now, now).toArray().length;
/** How many orders revokeLive would revoke now. */
export const liveCount = (sql: SqlStorage, now: number): number => sql.exec<{ n: number }>("SELECT count(*) AS n FROM orders WHERE revoked_at IS NULL AND expires_at > ?", now).one().n;

/** Whether `message` is a reply to an order's root, which goes to the person's order view (an inbox row with no agent) and to no agent (plan 6.6). */
export function toOrderView(sql: SqlStorage, message: Pick<Stored, "kind" | "parents" | "threadId" | "chain" | "receipt" | "recipient">): boolean {
  const claim = message.kind === "reply" ? claimOf(message) : null;
  return claim !== null && message.parents[0] === message.threadId && addressOf(message.recipient, "recipient").agent === null && orderOf(sql, claim.actDigest)?.thread_id === message.threadId;
}

/**
 * Whether an inbox is at its limit: the whole Mailbox's live rows, or, given an agent, that agent's own live rows (G27: one flooded agent must not block the
 * rest). Both leave out only a read or answered row with no expiry (a reply, which is never deleted), so a Mailbox or agent that reads its mail is never shut
 * out for good (#940); a read request still counts until it expires, so one agent still holds at most its share. deliver() and an order's root refuse a new
 * row then, and Explain asks the same question.
 */
export function inboxFull(sql: SqlStorage, now: number, agent: string | null = null): boolean {
  const live = (where: string, ...args: SqlStorageValue[]) =>
    sql.exec<{ n: number }>(`SELECT count(*) AS n FROM messages WHERE box = 'in' AND (expires_at > ? OR (expires_at IS NULL AND status NOT IN ('read', 'answered')))${where}`, now, ...args).one().n;
  return live("") >= LIMITS.inbox || (agent !== null && live(" AND agent = ?", agent) >= LIMITS.inboxPerAgent);
}

// ---- reading (the owner's Orders pages: list and trace) ----

/** Where an order stands now: live, revoked by its owner, ended, or its signing key is no longer an active signer (VS-08). Revoked outranks the others. */
export type OrderState = "live" | "revoked" | "expired" | "key_inactive";
export const stateOf = (row: OrderRow, live: CredentialLive, now: number): OrderState =>
  row.revoked_at !== null ? "revoked" : now >= row.expires_at ? "expired" : live(row.credential) ? "live" : "key_inactive";

const iso = (ms: number): string => new Date(ms).toISOString().replace(".000Z", "Z");

/** An order as the owner's pages show it. `scope` is each term's exact text; `messages` counts the thread's messages, the root included. */
export type OrderView = {
  digest: string; root: string; agent: string; taskType: string; scope: string[]; maxDepth: number; allowForward: boolean; maxMessages: number;
  createdAt: string; expiresAt: string; revokedAt: string | null; draftedBy: string; credential: string; state: OrderState; messages: number;
};
export function viewOfOrder(row: OrderRow, messages: number, live: CredentialLive, now: number): OrderView {
  return {
    digest: row.digest, root: row.thread_id, agent: row.agent, taskType: row.task_type, scope: (JSON.parse(row.scope) as Term[]).map(printTerm), maxDepth: row.max_depth,
    allowForward: row.allow_forward === 1, maxMessages: row.max_messages, createdAt: iso(row.created_at), expiresAt: iso(row.expires_at),
    revokedAt: row.revoked_at === null ? null : iso(row.revoked_at), draftedBy: row.drafted_by, credential: row.credential, state: stateOf(row, live, now), messages,
  };
}

/** The newest orders, with each one's message count. `limit` bounds the page; the caller says when there may be more. */
export function listOrders(sql: SqlStorage, limit: number, live: CredentialLive, now: number): { orders: OrderView[]; cut: boolean } {
  // One row past the limit tells whether any order was left out.
  const rows = sql.exec<OrderRow & { n: number }>(
    "SELECT o.*, (SELECT count(*) FROM messages m WHERE m.box = 'out' AND m.thread_id = o.thread_id) AS n FROM orders o ORDER BY o.created_at DESC, o.digest LIMIT ?", limit + 1,
  ).toArray();
  return { orders: rows.slice(0, limit).map(({ n, ...row }) => viewOfOrder(row, n, live, now)), cut: rows.length > limit };
}

/**
 * One hop of an order's thread, from the sender's own row (each message is filed once in the outbox). `authoredBy` is "human-approved" for the root and
 * `agent:<name>` for every later hop, as the offline verifier says it. `view`: the reply went to the person's order view (no agent received it); `box` and
 * `agent` name the row the message page reads it from.
 */
export type OrderHopView = {
  id: string; kind: Kind; from: string; to: string; depth: number; issuedAt: string; expiresAt: string | null; status: string;
  authoredBy: string; view: boolean; box: "in" | "out"; agent: string | null;
};
export type OrderTraceView = { order: OrderView; hops: OrderHopView[]; cut: boolean };
/** Hops one trace lists. An order allows at most LIMITS.depth hops and max_messages messages, so this is a bound, not a page. */
export const TRACE_HOPS = 200;

export function traceOrder(sql: SqlStorage, digest: string, live: CredentialLive, now: number): OrderTraceView | null {
  const row = orderOf(sql, digest);
  if (!row) return null;
  // Every message with this thread_id is a hop of the order: a request's thread is its own id (root ids are fresh uuids), and any other message takes its
  // parent's thread (issue(): `threadId: parent ? parent.threadId : input.id`) and inherits the root's order claim, so issue() and deliver() gate it.
  const rows = sql.exec<{ row: string; status: string; agent: string | null; expires_at: number | null }>(
    "SELECT row, status, agent, expires_at FROM messages WHERE box = 'out' AND thread_id = ? ORDER BY created_at, id LIMIT ?", row.thread_id, TRACE_HOPS + 1,
  ).toArray();
  const hops = rows.slice(0, TRACE_HOPS).map((r): OrderHopView => {
    const m = JSON.parse(r.row) as Stored;
    // A reply to the root goes to the person's order view: it is read in the person's own inbox, not an agent's.
    // Its inbox row is cleaned up some time after it expires; the sender's outbox row stays, so the link falls back to that.
    const view = addressOf(m.recipient, "recipient").agent === null && sql.exec("SELECT 1 FROM messages WHERE box = 'in' AND id = ?", m.id).toArray().length > 0;
    return {
      id: m.id, kind: m.kind, from: wireOf(partyAddress(m.sender)), to: m.recipient, depth: m.depth, issuedAt: m.issuedAt, expiresAt: m.expiresAt, status: statusAt(r, now),
      authoredBy: m.applied === "human-ordered" ? "human-approved" : `agent:${m.sender.agent ?? "?"}`, view, box: view ? "in" : "out", agent: view ? null : r.agent,
    };
  });
  return { order: viewOfOrder(row, rows.length, live, now), hops, cut: rows.length > TRACE_HOPS };
}

// ---- the agent's side (R4 P5b 5b-2c, Flow B): its drafts, the orders it is inside, and the order a message belongs to ----

/** Where an agent's request stands. A refused or failed signing leaves the draft waiting (nothing is spent), so there is no `refused`: the person cancelling it is `cancelled`. */
export type DraftStatus = { status: "waiting" | "signed" | "expired" | "cancelled"; expiresAt: string; order: { id: string; root: string; state: OrderState } | null };

/** The status of the draft `draftId` made by `by` (`agent:<address>`), or null when this agent made no such draft (another agent's draft is not visible to it). */
export function draftStatus(sql: SqlStorage, by: string, draftId: string, live: CredentialLive, now: number): DraftStatus | null {
  const row = sql.exec<{ state: string; draft_expires_at: number; open_digest: string | null; body: string }>("SELECT state, draft_expires_at, open_digest, body FROM acts WHERE id = ? AND kind = 'order' AND drafted_by = ?", draftId, by).toArray()[0];
  if (!row) return null;
  const status = row.state === "consumed" ? "signed" : row.state === "cancelled" ? "cancelled" : row.state === "expired" || now > row.draft_expires_at ? "expired" : "waiting";
  const placed = status === "signed" && row.open_digest !== null ? orderOf(sql, row.open_digest) : null;
  return { status, expiresAt: iso(row.draft_expires_at), order: placed ? { id: placed.digest, root: placed.thread_id, state: stateOf(placed, live, now) } : null };
}

/** The objective an order's root carries, screened: it is the person's signed text (or an agent's, a person signed), shown to an agent as any message text is. */
function objectiveOf(sql: SqlStorage, threadId: string): string | null {
  const row = sql.exec<{ row: string }>("SELECT row FROM messages WHERE box = 'out' AND id = ? AND thread_id = ?", threadId, threadId).toArray()[0];
  try {
    const objective = (JSON.parse(JSON.parse(row?.row ?? "{}").body ?? "null") as { fields?: { objective?: unknown } } | null)?.fields?.objective;
    return typeof objective === "string" ? screen(objective).text : null;
  } catch {
    return null;
  }
}

/** An order as the agent inside it is told: what it was ordered, the envelope, and what is left of it. `left.messages` is the thread's messages the envelope still allows. */
export type AgentOrderView = {
  id: string; root: string; taskType: string; objective: string | null; scope: string[]; maxDepth: number; allowForward: boolean; maxMessages: number;
  expiresAt: string; draftedBy: string; left: { messages: number };
};
const messagesIn = (sql: SqlStorage, threadId: string): number => sql.exec<{ n: number }>("SELECT count(*) AS n FROM messages WHERE box = 'out' AND thread_id = ?", threadId).one().n;
const AGENT_ORDERS_LISTED = 50;
/** The live orders `agent` is inside: those with a message of its own in their thread (the root it was ordered with, a forward it was handed, a reply it sent). Newest first, at most 50; `truncated` when more are live. */
export function agentOrders(sql: SqlStorage, agent: string, live: CredentialLive, now: number): { orders: AgentOrderView[]; truncated: boolean } {
  const rows = sql.exec<OrderRow>(
    "SELECT o.* FROM orders o WHERE o.revoked_at IS NULL AND o.expires_at > ? AND o.thread_id IN (SELECT thread_id FROM messages WHERE agent = ?) ORDER BY o.created_at DESC, o.digest", now, agent,
  );
  // Filtered before the cut, so dead keys cannot fill the page; one extra live row says whether more exist.
  const kept: OrderRow[] = [];
  for (const row of rows) {
    if (stateOf(row, live, now) !== "live") continue;
    if (kept.push(row) > AGENT_ORDERS_LISTED) break;
  }
  const truncated = kept.length > AGENT_ORDERS_LISTED;
  return { truncated, orders: kept.slice(0, AGENT_ORDERS_LISTED).map((row) => ({
    id: row.digest, root: row.thread_id, taskType: row.task_type, objective: objectiveOf(sql, row.thread_id), scope: (JSON.parse(row.scope) as Term[]).map(printTerm), maxDepth: row.max_depth,
    allowForward: row.allow_forward === 1, maxMessages: row.max_messages, expiresAt: iso(row.expires_at), draftedBy: row.drafted_by, left: { messages: Math.max(0, row.max_messages - messagesIn(sql, row.thread_id)) },
  })) };
}

/**
 * The order a message belongs to, for provenance: from its root receipt's claim (the signed words) and this Mailbox's row (the live facts). `root` is whether this message is the
 * order's own root, the only message a person authored; every later hop is an agent's message inside the order (AT-04). `status` is `unknown` when this Mailbox holds no such order.
 */
export type OrderBrief = { status: OrderState | "unknown"; id: string; root: boolean; draftedBy: string; expiresAt: string; left: { messages: number } | null };
export function orderBrief(sql: SqlStorage, message: Pick<Stored, "id" | "threadId" | "chain" | "receipt">, live: CredentialLive, now: number): OrderBrief | null {
  const claim = claimOf(message);
  if (!claim) return null;
  const row = orderOf(sql, claim.actDigest);
  const held = row !== null && row.thread_id === message.threadId;
  return {
    status: held ? stateOf(row, live, now) : "unknown", id: claim.actDigest, root: held && message.id === row.thread_id, draftedBy: claim.draftedBy, expiresAt: claim.expiresAt,
    left: held ? { messages: Math.max(0, row.max_messages - messagesIn(sql, row.thread_id)) } : null,
  };
}

/** An order an agent asked for that no one has signed yet, as the owner's Orders page lists it. `objective` is the agent's text, screened; the page shows it as an agent's, quoted. */
export type WaitingOrderView = { id: string; by: string; to: string; taskType: string; objective: string; expiresAt: string };
/** The agents' requests still waiting for a signature, newest first (at most the per-person quota: more cannot be waiting). */
export function waitingDrafts(sql: SqlStorage, now: number, signable: (drafter: string, subject: { to: string; taskType: string; body: { objective: string; fields: Record<string, string | number>; inputs: never[]; deadlineSeconds: number } }, extra: { scope: Term[]; ttlHours: number; maxDepth: number; maxMessages: number; allowForward: boolean }) => boolean): WaitingOrderView[] {
  const rows = sql.exec<{ id: string; drafted_by: string; body: string; draft_expires_at: number }>(
    "SELECT id, drafted_by, body, draft_expires_at FROM acts WHERE kind = 'order' AND drafted_by LIKE 'agent:%' AND state IN ('draft', 'open') AND draft_expires_at >= ? ORDER BY created_at DESC, id LIMIT 20", now,
  ).toArray();
  return rows.flatMap((row) => {
    try {
      // One open() would refuse is not waiting for anyone to sign: its agent stopped or removed (voidDrafts cancels it; this agrees even if a path missed it), its
      // msg.draft right taken back, or the receiver's declaration narrowed below it.
      const { subject, order } = JSON.parse(row.body) as { subject: Parameters<typeof signable>[1]; order: Parameters<typeof signable>[2] };
      if (!signable(row.drafted_by.slice(6), subject, order)) return [];
      return [{ id: row.id, by: row.drafted_by.slice(6), to: subject.to, taskType: subject.taskType, objective: screen(subject.body.objective).text, expiresAt: iso(row.draft_expires_at) }];
    } catch {
      return []; // a row that is not a draft this code wrote is not listed
    }
  });
}

/** Cancels the waiting requests `agent` made: it was suspended or taken away, and a draft it left must not outlive it (nor come back with a new agent of the same name). */
export const voidDrafts = (sql: SqlStorage, agent: string): number =>
  sql.exec("UPDATE acts SET state = 'cancelled' WHERE kind = 'order' AND drafted_by LIKE 'agent:%/' || ? AND state IN ('draft', 'open') RETURNING id", agent).toArray().length;
