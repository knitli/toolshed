// The act (R4 plan 6.2): the one shape every human act takes, the closed subject of each kind, and the digest a security key signs. The owning service builds
// an act from stored state and the browser submits only an assertion, so parseAct is a strict reader of bytes someone else wrote: exact keys, bounded sizes,
// and a closed charset on every string a person reads, so a homoglyph or bidi name cannot reach a sentence (VS-25). Only the free text of an order body is
// anything but ASCII, and that is NFC and free of invisible text (AT-11). Pure TypeScript: no Worker types, no I/O.
import { canonicalJson, domainDigest, domainDigestHex } from "./canonical.ts";
import { AGENT, CODE_ID, DEVICE, GRANT_MAX_MS, KEY_STATES, DIGEST, LABEL, LEDGER_RUN_ID, HEX64, MAX_AGENT_KEYS, MAX_ANCHORS_PER_PRINCIPAL, MAX_ENROLLMENT_GRANTS, MAX_PROFILE_ID_LENGTH, MAX_SENDERS, APPROVAL_WINDOW_MS, AUD, HOST, OAUTH_PROFILE, MESSAGE_ID, PREFIXED_DIGEST, WORKSPACE, isActInteger, isProfileId, isThumbprint, isoTime, matches, plain, principal as isPrincipal } from "./contract-kit.ts";
import { ceilingProblem, draftsOwnAgent, isCanonicalPrincipal, ownerOfAddress, isEmail, isSegmentRef, isTerm, parseTerm, type Term } from "./scope.ts";
import { DECLARATION_SOURCE, ENUM_VALUE, FIELD_NAME, MAX_DEFAULT_SCOPE_TERMS, MAX_ENUM, MAX_FIELDS, MAX_ORDER_LIFETIME_HOURS, MAX_STRING, SUMMARY_MAX, TASK_TYPE, declarationProblem, isOrderTerm, orderScopeProblem } from "./task.ts";
import { isPlainText } from "./text.ts";
import { snapshot } from "./snapshot.ts";

export const ACT_KINDS = [
  "enroll-credential", "anchor-liveness", "revoke-credential",
  "order", "agent-scope", "grant", "agent-enroll", "bind-existing", "activation", "declare-task", "key-inventory",
  "exec-approve", // P6; a later kind (recover-credential in 5a-2, exec-admit in P7) is a spec change, never a free string
] as const;
export type ActKind = (typeof ACT_KINDS)[number];
export const isActKind = (value: unknown): value is ActKind => ACT_KINDS.includes(value as ActKind);

export type Assurance = "hw-uv" | "hw-up";
export type OrderLimits = { expiresAt: string; maxDepth: number; allowForward: boolean; maxMessages: number };
/** `jkt` is the agent's key thumbprint, or null for one that signs in with a session and holds none (OS agents, OAuth; Messaging mcp.ts, receipts.ts). Only an order has an agent drafter. */
export type DraftedBy = "human" | { agent: string; jkt: string | null };
export type Act = {
  v: 1;
  kind: ActKind;
  principal: string; // canonical lowercase email; also the Mailbox key
  aud: string; // "knitli-os/<namespace>": binds the act to this deployment
  rpId: string;
  nonce: string; // 128 bits, base64url, minted when the ceremony opens (AT-22)
  issuedAt: string; // ceremony open
  windowExpiresAt: string; // issuedAt + WINDOW_SECONDS
  assurance: Assurance;
  draftedBy: DraftedBy; // who composed the content (AT-04); signed
  renderer: "r1"; // a copy edit ships as r2 and verifiers select by this (F15)
  subject: Readonly<Record<string, unknown>>;
  scope?: Term[];
  limits?: OrderLimits;
};

export const ACT_DOMAIN = "knitli-act/v1";
export const KEYS_DOMAIN = "knitli-keys/v1";
export const SCOPE_DOMAIN = "knitli-scope/v1";
export const PINS_DOMAIN = "knitli-pins/v1";
export const WINDOW_SECONDS = 300;
export const MAX_BODY_BYTES = 4096;
export const MAX_TEXT_BYTES = 1024;
// The most terms an act lists. Equal to the Scope v1 ceiling rows an agent can hold (memory-contract.ts), but an act is signed text and must not move when that one does.
export const MAX_TERMS = 32;
/** The longest one order term, in characters, that a draft takes (the presence host's draft parser). */
export const MAX_TERM_CHARS = 512;
/** Messages one thread may carry (Messaging LIMITS.budget.thread; a parity test holds the two equal): the most a declared order may default to. */
export const MAX_THREAD_MESSAGES = 50;

/** challenge = sha256("knitli-act/v1", canonicalJson(act)): 32 bytes; its hex is the act's digest and an order's id. */
export const actChallenge = (act: Act): Promise<Uint8Array<ArrayBuffer>> => domainDigest(ACT_DOMAIN, act);
export const actDigest = (act: Act): Promise<string> => domainDigestHex(ACT_DOMAIN, act);

/** `scopeDigest` of an order claim (receipt v3, plan 6.8): sha256("knitli-scope/v1", scope), hex, over the act's terms exactly as the act lists them. */
export const scopeDigest = (scope: readonly Term[]): Promise<string> => domainDigestHex(SCOPE_DOMAIN, scope);

/**
 * The body text of an order's root message: the act's body as the `knitli.task/v1` request envelope (plan 7.2), canonical JSON, with the objective as one of
 * the envelope's fields. The one place that spells it: Messaging's `issueOrder` builds the root's body with this, and the offline verifier recomputes
 * the root's payloadDigest from the signed act with it, so "the person signed exactly the text that was sent" has one definition. Null for a body whose own
 * field is called `objective` (it would overwrite the signed objective), which no root can carry.
 */
export function orderRootBody(given: { objective: string; fields: Readonly<Record<string, unknown>>; inputs: readonly unknown[]; deadlineSeconds: number }): string | null {
  // One read of the caller's body (the guard and the envelope below must see the same fields); an accessor or any non-plain value in it is not a body.
  const read = snapshot(given);
  const body = read?.value as { objective: string; fields: Record<string, unknown>; inputs: unknown[]; deadlineSeconds: number } | null | undefined;
  if (!body || typeof body !== "object" || body.fields === null || typeof body.fields !== "object") return null;
  if (Object.hasOwn(body.fields, "objective")) return null;
  return canonicalJson({ v: 1, kind: "task", fields: { objective: body.objective, ...body.fields }, inputs: body.inputs, deadlineSeconds: body.deadlineSeconds });
}

// --- the closed charsets -------------------------------------------------------------------------------------

const ASCII_TOKEN = /^[\x21-\x7e]+$/;
export const B64U_128 = /^[A-Za-z0-9_-]{22}$/;
const DIGEST_REF = DIGEST;
const UUID = MESSAGE_ID; // an order's root id is the message id, one grammar
const NAME = /^[a-z0-9-]{1,32}$/;
const TIME = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/;
const ADDRESS_LOCAL = 64;
const ADDRESS_DOMAIN = 189;
const ADDRESS_AGENT = 32;
const ADDRESS = new RegExp(`^[^\\s@]{1,${ADDRESS_LOCAL}}@[^\\s@]{1,${ADDRESS_DOMAIN}}/[a-z0-9-]{1,${ADDRESS_AGENT}}$`);
/** The longest address ADDRESS accepts: local part, "@", domain, "/", agent. Built from the same three bounds as the pattern. */
export const MAX_ADDRESS_LENGTH = ADDRESS_LOCAL + 1 + ADDRESS_DOMAIN + 1 + ADDRESS_AGENT;
const SOURCE = DECLARATION_SOURCE; // Messaging's grammar, from authority

const ident = (value: unknown): value is string => isPrincipal(value) && isCanonicalPrincipal(value);
/** "principal/agent" in Messaging's canonical wire form: lowercase ASCII, the principal an email Scope v1 reads, the agent AGENT. */
const address = (value: unknown): value is string => {
  if (!matches(value, ADDRESS) || !ASCII_TOKEN.test(value) || value !== value.toLowerCase()) return false;
  const slash = value.indexOf("/", value.lastIndexOf("@"));
  return isEmail(value.slice(0, slash)) && matches(value.slice(slash + 1), AGENT);
};
/** An agent address as an act and a receipt's order claim spell one: the single definition (an order's `draftedBy.agent`, `subject.to`). */
export const isAgentAddress = address;
/** One spelling of a time: the text is what `new Date(ms).toISOString()` writes (".000" dropped for the whole-second form), so no alias such as 24:00, :60 or a rolled-over day reads as another time. */
const spelled = (value: string, ms: number, whole: boolean): boolean => !Number.isNaN(ms) && (whole ? new Date(ms).toISOString().replace(".000Z", "Z") : new Date(ms).toISOString()) === value;
const time = (value: unknown): value is string => matches(value, TIME) && spelled(value, isoTime(value), true);
const TIME_MS = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
/** A time as Messaging stores and projects one (`new Date(ms).toISOString()`, milliseconds and all), or the whole-second form the act's own times take. A grant's expiry and a key's first-seen time are stored times. */
const storedTime = (value: unknown): value is string => time(value) || (matches(value, TIME_MS) && spelled(value, isoTime(value), false));
const taskType = (value: unknown): value is string => matches(value, TASK_TYPE);
const int = (value: unknown, min: number, max: number): value is number => isActInteger(value) && value >= min && value <= max;
const oneOf = <T extends string>(value: unknown, options: readonly T[]): value is T => options.includes(value as T);
const bytes = (text: string): number => new TextEncoder().encode(text).length;

/** Free text of an order body (AT-11): NFC, no control, bidi or zero-width character, at most 1 KiB. LF and TAB are the only controls allowed. */
export const signedText = (value: unknown): value is string =>
  typeof value === "string" && isPlainText(value) && bytes(value) <= MAX_TEXT_BYTES;

type Rec = Record<string, unknown>;
/** `value` as a plain object with any keys (the caller checks them), or null. */
const dict = (value: unknown): Rec | null =>
  value !== null && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value)) ? (value as Rec) : null;
const list = <T>(value: unknown, max: number, item: (entry: unknown) => T | null, min = 0): T[] | null => {
  if (!Array.isArray(value) || value.length < min || value.length > max || Object.getPrototypeOf(value) !== Array.prototype) return null;
  const out: T[] = [];
  for (let i = 0; i < value.length; i++) {
    const entry = item(Object.getOwnPropertyDescriptor(value, String(i))?.value);
    if (entry === null) return null;
    out.push(entry);
  }
  return out;
};
const strings = (value: unknown, max: number, ok: (s: unknown) => boolean, sorted = false): string[] | null => {
  const out = list(value, max, (s) => (ok(s) ? (s as string) : null));
  return out && (!sorted || out.every((s, i) => i === 0 || out[i - 1]! < s)) ? out : null;
};
/** Terms an agent's ceiling may hold (Messaging's ceilingProblem, shared from scope.ts): memory verbs, and the typed msg.draft right. */
const ceiling = (value: unknown): Term[] | null => {
  const terms = list(value, MAX_TERMS, (t) => (ceilingProblem(t) === null ? structuredClone(t as Term) : null));
  return terms && new Set(terms.map((t) => canonicalJson(t))).size === terms.length ? terms : null; // a ceiling row is its term: one term is one row
};

/** A wake policy as Messaging stores it: senders are null (any sender whose grant covers the message) or a sorted list, only a granted agent has either, transports are a sorted list. */
function wakePolicy(s: Rec): { mode: string; senders: string[] | null; transports: string[] } | null {
  const senders = s.senders === null ? null : (strings(s.senders, MAX_SENDERS, address, true) ?? undefined); // undefined: not a valid list
  const transports = list(s.transports, 3, (t) => (oneOf(t, ["os-hook", "oauth-webhook", "event"]) ? t : null), 1);
  const sorted = transports && transports.every((t, i) => i === 0 || transports[i - 1]! < t);
  return senders !== undefined && transports && sorted && oneOf(s.mode, ["order-only", "granted", "off"]) && (s.mode === "granted" || senders === null) ? { mode: s.mode, senders, transports } : null;
}
/**
 * What an activation act was drafted against: the agent's policy then, and when its owner suspended it (null: not suspended). The time, not a flag, so an
 * unsuspension drafted for one suspension cannot be signed against a later one (suspended, restored, suspended again).
 */
function wakeWas(value: unknown): Rec | null {
  const w = plain(value, ["mode", "senders", "transports", "suspendedAt"]);
  const policy = w && wakePolicy(w);
  return w && policy && (w.suspendedAt === null || storedTime(w.suspendedAt)) ? { ...policy, suspendedAt: w.suspendedAt } : null;
}
/**
 * What a declare-task act replaces: the class and summary of the declaration it was drafted against, and a digest of all of it (the Mailbox compares); null: a
 * new type; `{unreadable, digest}`: a stored declaration that no longer parses, which the act still replaces and the Mailbox still compares by digest.
 */
function replacedOf(value: unknown): Rec | null | undefined {
  if (value === null) return null;
  const lost = plain(value, ["unreadable", "digest"]);
  if (lost) return lost.unreadable === true && matches(lost.digest, HEX64) ? { unreadable: true, digest: lost.digest } : undefined;
  const r = plain(value, ["class", "summary", "digest"]);
  const summary = r?.summary;
  return r && oneOf(r.class, ["inform", "consequential"]) && typeof summary === "string" && Array.from(summary).length >= 1 && Array.from(summary).length <= SUMMARY_MAX && isPlainText(summary) && matches(r.digest, HEX64)
    ? { class: r.class, summary, digest: r.digest }
    : undefined;
}

// --- subjects ------------------------------------------------------------------------------------------------

const GRANT_KEYS = ["direction", "from", "to", "mode", "expiresAt", "types"];
const GRANT_OPTIONAL = ["wake", "offerId"];
function grantOf(value: unknown): Rec | null {
  const g = plain(value, GRANT_KEYS, GRANT_OPTIONAL);
  const types = g && strings(g.types, 16, taskType, true);
  // The wake right (F5) is spelled one way: present only as true, for an outgoing grant and named types (the Mailbox checks they are inform and the grant same-owner).
  // `offerId` pins the exact offer an acceptance is for (its row id in the owner's registry): only an acceptance names one, and Messaging requires it there.
  const offered = g?.offerId === undefined || (g.direction === "in" && matches(g.offerId, UUID));
  const wake = g?.wake === undefined || (g.wake === true && types !== null && types !== undefined && types.length > 0 && g.direction === "out");
  // An incoming grant is an offer, stored standing and kept standing by acceptance (Messaging registry offer, acceptOffer): once is an outgoing mode.
  return g && oneOf(g.direction, ["in", "out"]) && (g.direction === "out" || g.mode === "standing") && address(g.from) && address(g.to) && oneOf(g.mode, ["once", "standing"]) && (g.expiresAt === null || storedTime(g.expiresAt)) && types && wake && offered
    ? { direction: g.direction, from: g.from, to: g.to, mode: g.mode, expiresAt: g.expiresAt, types, ...(g.wake === true && { wake: true }), ...(g.offerId !== undefined && { offerId: g.offerId }) }
    : null;
}

/** What a bind-existing act binds: a workspace id, an OAuth reference, or one key of the inventory it carries (a thumbprint listed exactly once). */
const bindRefOk = (what: unknown, ref: unknown, keys: Rec[]): boolean =>
  what === "key" ? isThumbprint(ref) && keys.filter((k) => k.thumbprint === ref).length === 1
  // Only an OS agent binds a workspace, and only an external agent holds keys: a workspace binding lists none. An external agent with no key may still bind an OAuth profile.
  : what === "workspace" ? matches(ref, WORKSPACE) && keys.length === 0
  : what === "oauth" && matches(ref, OAUTH_PROFILE);

/** The first address an order names that is not `principal`'s own, in words, or null: R4 orders are same-owner at every hop (the recipient and each forward's resource). parseAct and the Orders form both ask it. */
export function orderOwnerProblem(to: string, scope: readonly Term[], principal: string): string | null {
  const foreign = [to, ...scope.filter((t) => t.svc === "msg" && t.verb === "forward").map((t) => t.res)].find((addr) => ownerOfAddress(addr) !== principal);
  return foreign === undefined ? null : `${foreign} is not one of your own agents: an order, and everything under it, stays between your own agents`;
}

/**
 * Whether every address the subject names as this owner's own is under `principal`: R4 orders are same-owner at every hop (a recipient and each forward
 * resource), a grant is stored in its owner's Mailbox with the owner's agent as `from` (out) or `to` (in), a starting grant likewise, and a drafting agent
 * is checked against the principal Messaging independently verified.
 */
function crossChecks(kind: ActKind, subject: Rec, principal: string, scope: Term[] | undefined, limits: OrderLimits | undefined, draftedBy: DraftedBy, issuedAt: number, windowEnd: number): boolean {
  // Messaging grantExpiry: a grant's expiry, when it has one, is after now and at most 90 days out, and the act can be applied at any time in its window: the
  // expiry outlives the window (so it is still ahead when applied last) and is within 90 days of the issue (so it is when applied first).
  const expiryOk = (g: Rec): boolean => g.expiresAt === null || (isoTime(g.expiresAt as string) > windowEnd && isoTime(g.expiresAt as string) - issuedAt <= GRANT_MAX_MS);
  const drafts = (t: Term): boolean => draftsOwnAgent(principal, t);
  const mine = (addr: unknown): boolean => ownerOfAddress(addr as string) === principal;
  // An agent drafts only an order (an order is the one act an agent composes); a session agent holds no key.
  if (draftedBy !== "human" && (kind !== "order" || !mine(draftedBy.agent))) return false;
  if (kind === "order")
    return orderOwnerProblem(subject.to as string, scope ?? [], principal) === null &&
      orderScopeProblem(subject.taskType as string, scope ?? [], limits!.maxDepth, limits!.allowForward) === null;
  // A grant is stored in its owner's Mailbox: out, with the owner's agent as `from`; in, an offer from another owner's agent to the owner's (Messaging offer, admin-api).
  if (kind === "grant") return (subject.direction === "out" ? mine(subject.from) : mine(subject.to) && !mine(subject.from)) && expiryOk(subject);
  // A starting grant is the enrolled agent's own outgoing one (Messaging enrollment-store confirm: createGrant from the agent, to an agent of the owner's).
  if (kind === "agent-enroll")
    return (subject.terms as Term[]).every(drafts) && (subject.grants as Rec[]).every((g) => g.direction === "out" && g.from === `${principal}/${subject.agent}` && mine(g.to) && expiryOk(g));
  // Execution proposes with approvalExpiresMs = now + APPROVAL_WINDOW_MS: the approval ends after the issue and within one window of it (Execution's own online check decides whether it is still open when applied).
  if (kind === "exec-approve") return (subject.approvalExpiresMs as number) > issuedAt && (subject.approvalExpiresMs as number) - issuedAt <= APPROVAL_WINDOW_MS;
  // Every subject that names a person names the act's own: a liveness proof is for the principal that signs.
  if (kind === "anchor-liveness") return subject.principal === principal;
  if (kind === "agent-scope") return (subject.add as Term[]).every(drafts);
  if (kind === "declare-task") {
    const defaults = (subject.declaration as { defaults?: { scope: Term[]; maxDepth: number } } | null)?.defaults;
    return !defaults || ((defaults.scope.every((t) => !(t.svc === "msg" && t.verb === "forward") || mine(t.res))));
  }
  return true;
}

/** Agents one key inventory lists in each of its two lists (each agent at most MAX_AGENT_KEYS keys, and a key once in the whole act): the flip signs every agent that holds a key, so this bounds an owner's agents with keys. */
export const MAX_INVENTORY_AGENTS = 64;
const MAX_PRESET_VERSION = 1_000_000;
/** A preset as an act names it: `{id, n}`, the id a name and n a version, or false. */
function presetOf(value: unknown): { id: string; n: number } | false {
  const p = plain(value, ["id", "n"]);
  return p && matches(p.id, NAME) && int(p.n, 0, MAX_PRESET_VERSION) ? { id: p.id, n: p.n } : false;
}

/** What a binding replaces: the agent that held an OAuth profile, the workspace an agent was bound to, or null (nothing before it; a key replaces nothing). */
const replacesOk = (what: unknown, replaces: unknown): boolean =>
  replaces === null || (what === "oauth" ? matches(replaces, AGENT) : what === "workspace" ? matches(replaces, WORKSPACE) : false);

/** `keys` as a key inventory: each thumbprint once. */
const uniqueKeys = (keys: Rec[] | null): Rec[] | null => (keys && new Set(keys.map((k) => k.thumbprint)).size === keys.length ? keys : null);

const KEY_KEYS = ["thumbprint", "device", "firstSeen", "state"];
function keyOf(value: unknown): Rec | null {
  const k = plain(value, KEY_KEYS);
  return k && isThumbprint(k.thumbprint) && (k.device === null || matches(k.device, DEVICE)) && storedTime(k.firstSeen) && oneOf(k.state, KEY_STATES)
    ? { thumbprint: k.thumbprint, device: k.device, firstSeen: k.firstSeen, state: k.state }
    : null;
}

/** One agent of a key inventory: its name and every key it is listed with, sorted by thumbprint, and the digest of exactly that list. */
function inventoryAgentOf(value: unknown): Rec | null {
  const a = plain(value, ["agent", "keys", "keysDigest"]);
  const keys = a && uniqueKeys(list(a.keys, MAX_AGENT_KEYS, keyOf, 1));
  return a && keys && matches(a.agent, AGENT) && matches(a.keysDigest, HEX64) && keys.every((k, i) => i === 0 || (keys[i - 1]!.thumbprint as string) < (k.thumbprint as string))
    ? { agent: a.agent, keys, keysDigest: a.keysDigest }
    : null;
}

/** An order body (objective, fields, inputs, deadline) as the act accepts it, or the first reason it is not, in words that name the part. The one reader: parseAct and the Orders form both go through it. */
function bodyChecked(value: unknown): { body: Rec } | { problem: string } {
  const b = plain(value, ["objective", "fields", "inputs", "deadlineSeconds"]);
  const fields = b && dict(b.fields);
  if (!b || !fields) return { problem: "the body is not {objective, fields, inputs, deadlineSeconds}" };
  if (!signedText(b.objective) || b.objective === "") return { problem: `the objective is non-empty plain text (NFC, no control, direction or zero-width character) of at most ${MAX_TEXT_BYTES} bytes` };
  if (!int(b.deadlineSeconds, 1, 7 * 86400)) return { problem: "the answer deadline is from 1 second to 7 days" };
  const names = Object.keys(fields);
  // orderRootBody puts the objective among the message's fields, so a field of that name could never be sent: a person must not be able to sign an order that cannot be issued.
  if (names.includes("objective")) return { problem: "a field cannot be called objective: the objective is the order's own" };
  if (names.length > 16) return { problem: "an order carries at most 16 fields" };
  for (const name of names) {
    if (!matches(name, FIELD_NAME)) return { problem: `${name} is not a field name` };
    if (!(isActInteger(fields[name]) || (signedText(fields[name]) && fields[name] !== ""))) return { problem: `field ${name} is a whole number (a safe integer, not -0) or non-empty plain text of at most ${MAX_TEXT_BYTES} bytes` };
  }
  const inputs = list(b.inputs, 8, (entry) => {
    const receipt = plain(entry, ["kind", "digest"]);
    if (receipt) return receipt.kind === "receipt" && matches(receipt.digest, HEX64) ? { kind: "receipt", digest: receipt.digest } : null;
    const memory = plain(entry, ["kind", "ref"]);
    return memory && memory.kind === "memory" && isSegmentRef(memory.ref) ? { kind: "memory", ref: memory.ref } : null;
  });
  if (!inputs) return { problem: "inputs are at most 8 receipt or memory references" };
  const body = { objective: b.objective, fields: Object.fromEntries(names.map((name) => [name, fields[name]])), inputs, deadlineSeconds: b.deadlineSeconds };
  const size = bytes(canonicalJson(body));
  return size <= MAX_BODY_BYTES ? { body } : { problem: `the objective and the fields together are ${size} bytes once encoded; an order carries at most ${MAX_BODY_BYTES}` };
}
function bodyOf(value: unknown): Rec | null {
  const checked = bodyChecked(value);
  return "body" in checked ? checked.body : null;
}

/**
 * Why an order drafted from these words would not be an act this deployment could sign, or null. The same readers parseAct uses (the body, the terms, the limits, the
 * scope-against-limits rule, the answer inside the order's life), so a form cannot drift from them. Messaging adds what only it knows (the receiver's declaration).
 */
export function orderDraftProblem(d: { principal: string; to: string; taskType: string; objective: string; fields: Record<string, unknown>; inputs: unknown[]; deadlineSeconds: number; scope: readonly string[]; limits: { ttlHours: number; maxDepth: number; allowForward: boolean; maxMessages: number } }): string | null {
  const checked = bodyChecked({ objective: d.objective, fields: d.fields, inputs: d.inputs, deadlineSeconds: d.deadlineSeconds });
  if ("problem" in checked) return checked.problem;
  const l = d.limits;
  if (!int(l.ttlHours, 1, MAX_ORDER_LIFETIME_HOURS)) return `valid for is 1 to ${MAX_ORDER_LIFETIME_HOURS} hours`;
  // An order its agent cannot answer is no order: the answer is a reply, one hop deeper and one message more.
  if (!int(l.maxDepth, 1, 8)) return "hops deep is 1 to 8, so the agent can answer";
  if (!int(l.maxMessages, 2, MAX_THREAD_MESSAGES)) return `messages is 2 to ${MAX_THREAD_MESSAGES}, so the agent can answer`;
  if (typeof l.allowForward !== "boolean") return "forwarding is yes or no";
  if (d.scope.length > MAX_TERMS) return `an order carries at most ${MAX_TERMS} terms`;
  const terms: Term[] = [];
  for (const spelled of d.scope) {
    if (spelled.length > MAX_TERM_CHARS) return `a term is at most ${MAX_TERM_CHARS} characters`;
    const term = parseTerm(spelled);
    if (term === null) return `"${spelled}" is not a term`;
    if (!isOrderTerm(term)) return `"${spelled}" is not an order term: an order's terms are msg.forward and exec.request`;
    terms.push(term);
  }
  const owner = orderOwnerProblem(d.to, terms, d.principal);
  if (owner !== null) return owner;
  const scope = orderScopeProblem(d.taskType, terms, l.maxDepth, l.allowForward);
  if (scope !== null) return `terms: ${scope}`;
  if (d.deadlineSeconds * 1000 > l.ttlHours * 3600_000) return `the answer is due within the order's life: at most ${l.ttlHours * 60} minutes for an order valid for ${l.ttlHours} hours`;
  return null;
}

function fieldDecl(value: unknown): Rec | null {
  // Messaging's parseFields, with its grammar and bounds (task.ts): only a string has a max, only an enum has a list of 1 to MAX_ENUM distinct values.
  const f = plain(value, ["name", "kind", "required"], ["max", "enum"]);
  if (!f || !matches(f.name, FIELD_NAME) || !oneOf(f.kind, ["string", "int", "digest", "enum"]) || typeof f.required !== "boolean") return null;
  if (f.max !== undefined && (f.kind !== "string" || !int(f.max, 1, MAX_STRING))) return null;
  const choices = f.kind === "enum" ? list(f.enum, MAX_ENUM, (s) => (matches(s, ENUM_VALUE) ? s : null), 1) : f.enum === undefined ? undefined : null;
  if (choices === null || (choices && new Set(choices).size !== choices.length)) return null;
  return { name: f.name, kind: f.kind, required: f.required, ...(f.max !== undefined && { max: f.max }), ...(choices !== undefined && { enum: choices }) };
}

/** `{fields}` as Messaging's parseFields reads it: at most MAX_FIELDS, each a valid field, each name once. */
function fieldList(value: unknown): Rec[] | null {
  const holder = plain(value, ["fields"]);
  const fields = holder && list(holder.fields, MAX_FIELDS, fieldDecl);
  return fields && new Set(fields.map((f) => f.name)).size === fields.length ? fields : null;
}

/**
 * Messaging's stored declaration, exactly (tasks.ts parseDeclaration, less the type, class and source it keeps in columns and this subject carries beside it):
 * `{summary, payload: {fields}, reply?, minAssurance, defaults}`. A reply schema belongs to a consequential type only.
 */
function declarationOf(value: unknown, kind: unknown): Rec | null {
  const d = plain(value, ["summary", "payload", "minAssurance", "defaults"], ["reply"]);
  const summary = d?.summary;
  if (!d || typeof summary !== "string" || summary.length > SUMMARY_MAX * 2 || Array.from(summary).length < 1 || Array.from(summary).length > SUMMARY_MAX || !isPlainText(summary)) return null;
  const payload = fieldList(d.payload);
  const reply = d.reply === undefined ? undefined : kind === "consequential" ? fieldList(d.reply) : null;
  if (!payload || reply === null) return null;
  const defaults = d && plain(d.defaults, ["ttlHours", "maxDepth", "maxMessages", "scope"]);
  const scope = defaults && list(defaults.scope, MAX_DEFAULT_SCOPE_TERMS, (t) => (isTerm(t) && isOrderTerm(t) ? structuredClone(t) : null));
  if (!defaults || !scope || !oneOf(d.minAssurance, ["hw-uv", "hw-up"]) || !int(defaults.ttlHours, 1, MAX_ORDER_LIFETIME_HOURS) || !int(defaults.maxDepth, 0, 8) || !int(defaults.maxMessages, 1, MAX_THREAD_MESSAGES)) return null;
  return {
    summary, payload: { fields: payload }, ...(reply !== undefined && { reply: { fields: reply } }), minAssurance: d.minAssurance,
    defaults: { ttlHours: defaults.ttlHours, maxDepth: defaults.maxDepth, maxMessages: defaults.maxMessages, scope },
  };
}


type SubjectParser = (s: unknown) => Rec | null;
const SUBJECTS: Record<ActKind, SubjectParser> = {
  order(value) {
    const s = plain(value, ["rootMessageId", "to", "taskType", "subject", "body"]);
    const body = s && bodyOf(s.body);
    // The subject is derived from the type and never chosen (VS-01): a second spelling would be a second thing to sign.
    return s && body && matches(s.rootMessageId, UUID) && address(s.to) && taskType(s.taskType) && s.subject === `Order: ${s.taskType}`
      ? { rootMessageId: s.rootMessageId, to: s.to, taskType: s.taskType, subject: s.subject, body }
      : null;
  },
  "agent-scope"(value) {
    const s = plain(value, ["agent", "add", "remove"], ["preset"]);
    // A preset the rows were copied from (Messaging applyPreset tags them), when they were: absent, null, or {id, n} in the grammar of an enrollment's preset.
    const preset = s?.preset === undefined || s.preset === null ? s?.preset : presetOf(s.preset);
    const add = s && preset !== false && ceiling(s.add);
    const remove = s && ceiling(s.remove);
    const removed = remove && new Set(remove.map((t) => canonicalJson(t)));
    return s && add && remove && removed && !add.some((t) => removed.has(canonicalJson(t))) && matches(s.agent, AGENT) ? { agent: s.agent, add, remove, ...(preset !== undefined && { preset }) } : null;
  },
  grant: grantOf,
  "agent-enroll"(value) {
    const s = plain(value, ["agent", "agentKeyThumbprint", "deviceName", "enrollId", "presetId", "presetVersion", "terms", "grants", "keys", "keysDigest"]);
    const terms = s && ceiling(s.terms);
    const grants = s && list(s.grants, MAX_ENROLLMENT_GRANTS, grantOf);
    const keys = s && uniqueKeys(list(s.keys, MAX_AGENT_KEYS, keyOf, 1));
    return s && terms && grants && keys && matches(s.agent, AGENT) && isThumbprint(s.agentKeyThumbprint) && matches(s.deviceName, DEVICE) && matches(s.enrollId, CODE_ID) &&
      matches(s.presetId, NAME) && int(s.presetVersion, 0, MAX_PRESET_VERSION) && matches(s.keysDigest, HEX64) &&
      ((grants.length === 0 && terms.length === 0) || keys.length === 1) && // starting permissions, terms or grants, apply to an agent that holds nothing yet (Messaging holdsNothing)
      keys.filter((k) => k.thumbprint === s.agentKeyThumbprint).length === 1 && // the key being promoted is one of the listed keys, once
      keys.find((k) => k.thumbprint === s.agentKeyThumbprint)!.device === s.deviceName // and the device it names is the one being enrolled
      ? { agent: s.agent, agentKeyThumbprint: s.agentKeyThumbprint, deviceName: s.deviceName, enrollId: s.enrollId, presetId: s.presetId, presetVersion: s.presetVersion, terms, grants, keys, keysDigest: s.keysDigest }
      : null;
  },
  "bind-existing"(value) {
    const s = plain(value, ["agent", "what", "ref", "replaces", "keys", "keysDigest"]);
    const keys = s && uniqueKeys(list(s.keys, MAX_AGENT_KEYS, keyOf, 0));
    return s && keys && matches(s.agent, AGENT) && matches(s.keysDigest, HEX64) && bindRefOk(s.what, s.ref, keys) && replacesOk(s.what, s.replaces)
      ? { agent: s.agent, what: s.what, ref: s.ref, replaces: s.replaces, keys, keysDigest: s.keysDigest }
      : null;
  },
  "key-inventory"(value) {
    const s = plain(value, ["agents", "inert", "inventoryDigest"]);
    const agents = s && list(s.agents, MAX_INVENTORY_AGENTS, inventoryAgentOf, 1);
    const inert = s && list(s.inert, MAX_INVENTORY_AGENTS, inventoryAgentOf);
    // Sorted by agent and by thumbprint, each key once in the whole act: one inventory has one spelling, so one digest, and no key is both kept and made inert.
    const thumbprints = agents && inert ? [...agents, ...inert].flatMap((a) => (a.keys as Rec[]).map((k) => k.thumbprint as string)) : null;
    const sorted = (xs: Rec[]) => xs.every((a, i) => i === 0 || (xs[i - 1]!.agent as string) < (a.agent as string));
    return s && agents && inert && thumbprints && matches(s.inventoryDigest, HEX64) && sorted(agents) && sorted(inert) && new Set(thumbprints).size === thumbprints.length && thumbprints.length <= MAX_INVENTORY_AGENTS * MAX_AGENT_KEYS
      ? { agents, inert, inventoryDigest: s.inventoryDigest }
      : null;
  },
  activation(value) {
    // The operation is signed: a policy change, or the unsuspension of the agent (which restores its keys, bindings, grants and wake authority). The unsuspension commits no policy.
    // `was` is the policy and suspension the act was drafted against: the Mailbox compares it with its own before it applies, so an old draft cannot undo a newer narrowing.
    const op = plain(value, ["agent", "op", "was"]);
    if (op) {
      const was = wakeWas(op.was);
      return was && matches(op.agent, AGENT) && op.op === "unsuspend" ? { agent: op.agent, op: "unsuspend", was } : null;
    }
    const s = plain(value, ["agent", "op", "mode", "senders", "transports", "was"]);
    const policy = s && wakePolicy(s);
    const was = s && wakeWas(s.was);
    return s && policy && was && matches(s.agent, AGENT) && s.op === "set-policy" ? { agent: s.agent, op: s.op, mode: policy.mode, senders: policy.senders, transports: policy.transports, was } : null;
  },
  "declare-task"(value) {
    // The operation is signed: a declaration, or the deletion of one (which removes the consequential tombstone a deleted consequential declaration leaves). A deletion names the agent and the type and nothing else.
    const gone = plain(value, ["agent", "op", "type"]);
    if (gone) return matches(gone.agent, AGENT) && gone.op === "delete" && taskType(gone.type) ? { agent: gone.agent, op: "delete", type: gone.type } : null;
    const s = plain(value, ["agent", "op", "type", "class", "source", "declaration", "replaces"]);
    const replaces = s && replacedOf(s.replaces);
    if (!s || replaces === undefined || s.op !== "declare" || !matches(s.agent, AGENT) || !taskType(s.type) || !oneOf(s.class, ["inform", "consequential"]) || !matches(s.source, SOURCE)) return null;
    // A route assignment carries no declaration of its own; every other source carries the exact one.
    const declaration = String(s.source).startsWith("route:") ? (s.declaration === null ? null : undefined) : declarationOf(s.declaration, s.class);
    // What a declaration may be when written (exec/* and generated entries, and the order terms it defaults): task.ts, shared with Messaging's declare().
    if (declaration !== undefined && declarationProblem(s.type as string, s.class as string, s.source as string, declaration === null ? null : (declaration.defaults as { scope: Term[]; maxDepth: number })) !== null) return null;
    return declaration === undefined || (declaration === null && !String(s.source).startsWith("route:")) ? null : { agent: s.agent, op: s.op, type: s.type, class: s.class, source: s.source, declaration, replaces };
  },
  "enroll-credential"(value) {
    const s = plain(value, ["credentialThumbprint", "label", "parentThumbprint", "aaguidClaimed"]);
    // A key does not enroll itself: the signer and the new key are two keys (VS-09).
    return s && isThumbprint(s.credentialThumbprint) && matches(s.label, LABEL) && isThumbprint(s.parentThumbprint) && s.credentialThumbprint !== s.parentThumbprint && (s.aaguidClaimed === null || matches(s.aaguidClaimed, UUID))
      ? { credentialThumbprint: s.credentialThumbprint, label: s.label, parentThumbprint: s.parentThumbprint, aaguidClaimed: s.aaguidClaimed }
      : null;
  },
  "revoke-credential"(value) {
    // The proof branch of a revocation (plan 6.3): when fewer than two active credentials would remain, another credential must sign. The label is the stored one, shown.
    const s = plain(value, ["credentialThumbprint", "label"]);
    return s && isThumbprint(s.credentialThumbprint) && matches(s.label, LABEL) ? { credentialThumbprint: s.credentialThumbprint, label: s.label } : null;
  },
  "anchor-liveness"(value) {
    const s = plain(value, ["principal", "thumbprints", "pinSetDigest"]);
    const thumbprints = s && strings(s.thumbprints, MAX_ANCHORS_PER_PRINCIPAL, (t) => isThumbprint(t), true);
    return s && thumbprints && thumbprints.length > 0 && ident(s.principal) && matches(s.pinSetDigest, HEX64) ? { principal: s.principal, thumbprints, pinSetDigest: s.pinSetDigest } : null;
  },
  "exec-approve"(value) {
    // The shape of Execution's request commitment (gatekeeper-execution validation.ts requestDigestOf, origin.ts RunOrigin): a numeric native action id,
    // a run origin that is null or {messageId, receiptDigest, orderActDigest: null} (Execution commits no order digest until it can verify one, P5b/P6b), and the
    // ledger's runId (null until P6). The candidate digest is bare hex, as Execution computes it; the image digest is sha256:-prefixed, as it pins it.
    const s = plain(value, ["nativeActionId", "workspaceId", "profileId", "runId", "candidateDigest", "baseDigest", "imageDigest", "origin", "approvalExpiresMs"]);
    const o = s && s.origin !== null ? plain(s.origin, ["messageId", "receiptDigest", "orderActDigest"]) : null;
    const origin = s?.origin === null ? null : o && matches(o.messageId, UUID) && matches(o.receiptDigest, DIGEST_REF) && o.orderActDigest === null
      ? { messageId: o.messageId, receiptDigest: o.receiptDigest, orderActDigest: o.orderActDigest } : undefined;
    return s && origin !== undefined && int(s.nativeActionId, 1, Number.MAX_SAFE_INTEGER) && matches(s.workspaceId, WORKSPACE) && isProfileId(s.profileId) && s.profileId.length <= MAX_PROFILE_ID_LENGTH &&
      (s.runId === null || matches(s.runId, LEDGER_RUN_ID)) && matches(s.candidateDigest, HEX64) && matches(s.baseDigest, HEX64) && matches(s.imageDigest, PREFIXED_DIGEST) && int(s.approvalExpiresMs, 0, 2 ** 53 - 1)
      ? { nativeActionId: s.nativeActionId, workspaceId: s.workspaceId, profileId: s.profileId, runId: s.runId, candidateDigest: s.candidateDigest, baseDigest: s.baseDigest, imageDigest: s.imageDigest, origin, approvalExpiresMs: s.approvalExpiresMs }
      : null;
  },
};

/** Subject leaves that are ids or digests the renderer prints in its footer rather than in a sentence (6.2). Paths have array positions as `[]`. Closed: adding one is a review. */
export const RENDER_NONSEMANTIC: Record<ActKind, readonly string[]> = {
  order: ["subject.rootMessageId"],
  "agent-scope": [], grant: [], activation: [], "enroll-credential": [], "revoke-credential": [],
  "agent-enroll": ["subject.enrollId", "subject.keysDigest"],
  "bind-existing": ["subject.keysDigest"],
  "declare-task": ["subject.replaces.digest"],
  "key-inventory": ["subject.inventoryDigest", "subject.agents[].keysDigest", "subject.inert[].keysDigest"],
  "anchor-liveness": ["subject.pinSetDigest"],
  "exec-approve": ["subject.nativeActionId", "subject.workspaceId"],
};

function limitsOf(value: unknown): OrderLimits | null {
  const l = plain(value, ["expiresAt", "maxDepth", "allowForward", "maxMessages"]);
  return l && time(l.expiresAt) && int(l.maxDepth, 0, 8) && typeof l.allowForward === "boolean" && int(l.maxMessages, 1, MAX_THREAD_MESSAGES)
    ? { expiresAt: l.expiresAt, maxDepth: l.maxDepth, allowForward: l.allowForward, maxMessages: l.maxMessages }
    : null;
}

function draftedByOf(value: unknown): DraftedBy | null {
  if (value === "human") return "human";
  const d = plain(value, ["agent", "jkt"]);
  return d && address(d.agent) && (d.jkt === null || isThumbprint(d.jkt)) ? { agent: d.agent, jkt: d.jkt } : null;
}

/**
 * The act `value` spells, or null. Closed at every level, and a copy: nothing of the input's prototypes or accessors survives. Whether it is the act a
 * deployment would accept (its aud, rpId, floors) is the verifier's to decide against its own configuration; this decides only that it is well formed.
 */
export function parseAct(value: unknown): Act | null {
  try {
    const read = snapshot(value);
    return read === null ? null : readAct(read.value);
  } catch {
    return null; // a value whose own shape throws (a getter, a key canonical JSON forbids) is not an act; parseAct never throws
  }
}

function readAct(value: unknown): Act | null {
  const a = plain(value, ["v", "kind", "principal", "aud", "rpId", "nonce", "issuedAt", "windowExpiresAt", "assurance", "draftedBy", "renderer", "subject"], ["scope", "limits"]);
  if (!a || a.v !== 1 || !isActKind(a.kind) || !ident(a.principal) || !matches(a.aud, AUD) || !matches(a.rpId, HOST) || !matches(a.nonce, B64U_128) || !time(a.issuedAt) || !time(a.windowExpiresAt)) return null;
  if (isoTime(a.windowExpiresAt) - isoTime(a.issuedAt) !== WINDOW_SECONDS * 1000 || !oneOf(a.assurance, ["hw-uv", "hw-up"]) || a.renderer !== "r1") return null;
  const draftedBy = draftedByOf(a.draftedBy);
  const subject = SUBJECTS[a.kind](a.subject);
  if (!draftedBy || !subject) return null;
  // An order's terms and limits ride on the act itself; no other kind has them.
  const ordered = a.kind === "order";
  // An order's terms are msg.forward and exec.request only, as a declaration's defaults are (plan 5.8).
  const scope = a.scope === undefined ? undefined : list(a.scope, MAX_TERMS, (t) => (isTerm(t) && isOrderTerm(t) ? structuredClone(t) : null));
  const limits = a.limits === undefined ? undefined : limitsOf(a.limits);
  if (scope === null || limits === null || ordered !== (scope !== undefined) || ordered !== (limits !== undefined)) return null;
  if (!crossChecks(a.kind, subject, a.principal, scope, limits, draftedBy, isoTime(a.issuedAt), isoTime(a.windowExpiresAt))) return null;
  // An order outlives its signing window and ends within MAX_ORDER_LIFETIME_HOURS (plan 5.8): the act cannot claim a lifetime the declaration could not default to.
  if (limits) {
    const lifetime = isoTime(limits.expiresAt) - isoTime(a.issuedAt);
    if (!(isoTime(limits.expiresAt) > isoTime(a.windowExpiresAt) && lifetime <= MAX_ORDER_LIFETIME_HOURS * 3600_000)) return null; // alive through the window it is signed in
    // The order cannot ask for an answer later than the order lives.
    if (a.kind === "order" && (subject as { body: { deadlineSeconds: number } }).body.deadlineSeconds * 1000 > lifetime) return null;
  }
  return {
    v: 1, kind: a.kind, principal: a.principal, aud: a.aud, rpId: a.rpId, nonce: a.nonce, issuedAt: a.issuedAt, windowExpiresAt: a.windowExpiresAt,
    assurance: a.assurance, draftedBy, renderer: "r1", subject, ...(scope && { scope }), ...(limits && { limits }),
  };
}

/** The digests an act carries about its own content, recomputed: a subject that states a `keysDigest` or `pinSetDigest` that is not that of the list beside it is malformed. */
export async function subjectDigestsHold(act: Act): Promise<boolean> {
  const s = act.subject as { keys?: unknown; keysDigest?: string; thumbprints?: unknown; pinSetDigest?: string };
  if (act.kind === "agent-enroll" || act.kind === "bind-existing") return s.keysDigest === (await domainDigestHex(KEYS_DOMAIN, s.keys));
  if (act.kind === "key-inventory") {
    const inv = act.subject as { agents: { keys: unknown; keysDigest: string }[]; inert: { keys: unknown; keysDigest: string }[]; inventoryDigest: string };
    for (const a of [...inv.agents, ...inv.inert]) if (a.keysDigest !== (await domainDigestHex(KEYS_DOMAIN, a.keys))) return false;
    return inv.inventoryDigest === (await domainDigestHex(KEYS_DOMAIN, { agents: inv.agents, inert: inv.inert }));
  }
  if (act.kind === "anchor-liveness") return s.pinSetDigest === (await domainDigestHex(PINS_DOMAIN, s.thumbprints));
  return true;
}
