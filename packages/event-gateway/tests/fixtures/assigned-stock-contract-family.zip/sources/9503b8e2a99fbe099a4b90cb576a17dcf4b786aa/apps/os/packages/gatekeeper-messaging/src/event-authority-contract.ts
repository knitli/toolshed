import type { MessageRouteControlService } from "./message-route-control-contract.ts";
/**
 * Private Event Runtime → Messaging contract. Agent operations receive both original proofs so
 * Messaging verifies the fixed Event audiences and current credential on each call. Owner lookups
 * receive the original human UI assertion and a requested agent; Messaging derives its owner.
 */
export type EventAuthorityCredentialsV1 = Readonly<{
  accessAssertion: string;
  agentToken: string;
}>;

export type EventAuthorityAttemptV1 = EventAuthorityCredentialsV1 & Readonly<{
  attemptId: string;
  activation?: ActivationClaimV1;
}>;

export type EventAuthorityIdentityV1 = Readonly<{
  principal: string;
  agent: string;
  keyThumbprint: string;
}>;

export type EventAuthorityAuthResultV1 =
  | Readonly<{ status: "authorized"; identity: EventAuthorityIdentityV1 }>
  | Readonly<{ status: "denied" | "unavailable" | "invalid" }>;

export type EventAttemptBudgetV1 = Readonly<{
  used: number;
  remaining: number;
  limit: 10;
  windowMs: 3_600_000;
}>;

export type EventAttemptReservationResultV1 =
  | Readonly<{
      status: "reserved" | "over_budget";
      attemptId: string;
      reservedAt: number | null;
      idempotent: boolean;
      budget: EventAttemptBudgetV1;
    }>
  | Readonly<{ status: "denied" | "unavailable" | "invalid" }>;

export type EventAttemptStatusResultV1 =
  | Readonly<{
      status: "reserved" | "unknown";
      attemptId: string;
      reservedAt: number | null;
      budget: EventAttemptBudgetV1;
    }>
  | Readonly<{ status: "denied" | "unavailable" | "invalid" }>;

/** Existing stock claims are accepted for status/recovery only; they do not identify their source. */
export type StockWakeClaimV1 = Readonly<{ deliveryId: string; consumer: EventMessageConsumerV1; conversationId: string }>;
export type ActivationSourceV1 =
  | Readonly<{ kind: "manual"; subjectId: string; sourceStateVersion: string }>
  | Readonly<{ kind: "github"; installationId: number; repositoryId: number; prNumber: number; sourceIncarnation: number }>
  | Readonly<{ kind: "message"; namespace: string; messageId: string; sourceStateVersion: string; agentIncarnation: number; routeGeneration: number; consumer: EventMessageConsumerV1 }>;
export type ActivationClaimV1 = Readonly<{
  version: 1;
  principal: string;
  agent: string;
  agentIncarnation: number;
  source: ActivationSourceV1;
  verdict: Readonly<{ allowed: true; reason: "owner_direct" | "order" | "wake_grant" | "granted"; orderDigest?: string }>;
  policyFingerprint: string;
  snapshotDigest: string;
}>;
export type SourceBoundStockWakeClaimV1 = StockWakeClaimV1 & Readonly<{ activation: ActivationClaimV1 }>;
export type AnyStockWakeClaimV1 = StockWakeClaimV1 | SourceBoundStockWakeClaimV1;
export type StockWakeAttemptV1 = EventAuthorityAttemptV1 & AnyStockWakeClaimV1;
export type StockWakeSettlementInputV1 = StockWakeAttemptV1 & Readonly<{ reservedAt: number }>;
export type StockWakeReservationResultV1 = EventAttemptReservationResultV1 | Readonly<{ status: "pending" | "conflict" }>;
export type StockWakeSettlementResultV1 =
  | Readonly<{ status: "settled"; attemptId: string; settledAt: number; idempotent: boolean }>
  | Readonly<{ status: "unknown" | "conflict" | "denied" | "unavailable" | "invalid" }>;

/** Strict, credential-free stock-wake claim parser shared by Event and Mailbox boundaries. */
export function parseStockWakeClaimV1(value: unknown): AnyStockWakeClaimV1 | null {
  if (!exactObject(value, ["deliveryId", "consumer", "conversationId"]) &&
      !exactObject(value, ["deliveryId", "consumer", "conversationId", "activation"])) return null;
  const consumer = parseEventMessageConsumer(value.consumer);
  if (!consumer || typeof value.deliveryId !== "string" || !/^dly_[0-9a-f]{64}$/.test(value.deliveryId) ||
      typeof value.conversationId !== "string" || !UUID_V4_OR_V7.test(value.conversationId)) return null;
  if (!Object.hasOwn(value, "activation"))
    return { deliveryId: value.deliveryId, consumer, conversationId: value.conversationId };
  const activation = parseActivationClaimV1(value.activation);
  return activation && activation.source.kind !== "message"
    ? { deliveryId: value.deliveryId, consumer, conversationId: value.conversationId, activation }
    : null;
}

export function parseStockWakeSettlementInput(value: unknown): StockWakeSettlementInputV1 | null {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return null;
  const record = value as Record<string, unknown>;
  if (typeof record.reservedAt !== "number" || !Number.isSafeInteger(record.reservedAt) || record.reservedAt <= 0) return null;
  const { reservedAt, ...attemptInput } = record;
  const attempt = parseStockWakeAttempt(attemptInput);
  return attempt ? { ...attempt, reservedAt } : null;
}
export function parseStockWakeAttempt(value: unknown): StockWakeAttemptV1 | null {
  if (!exactObject(value, ["accessAssertion", "agentToken", "attemptId", "deliveryId", "consumer", "conversationId"]) &&
    !exactObject(value, ["accessAssertion", "agentToken", "attemptId", "deliveryId", "consumer", "conversationId", "activation"])) return null;
  const attempt = parseEventAuthorityInput({ accessAssertion: value.accessAssertion, agentToken: value.agentToken, attemptId: value.attemptId }, true);
  const claim = parseStockWakeClaimV1({ deliveryId: value.deliveryId, consumer: value.consumer, conversationId: value.conversationId,
    ...(Object.hasOwn(value, "activation") ? { activation: value.activation } : {}) });
  return attempt && claim ? { ...attempt, ...claim } : null;
}

export type EventSourceActivationInputV1 = Readonly<{
  namespace: string;
  principal: string;
  agent: string;
  source: Exclude<ActivationSourceV1, { kind: "message" }>;
  expectedSnapshot?: string;
}>;
export type EventSourceActivationResultV1 =
  | Readonly<{ status: "eligible"; claim: ActivationClaimV1 }>
  | Readonly<{ status: "denied" | "changed" | "unavailable" | "invalid" }>;

export function parseEventSourceActivationInputV1(value: unknown): EventSourceActivationInputV1 | null {
  if (!exactObject(value, ["namespace", "principal", "agent", "source"]) && !exactObject(value, ["namespace", "principal", "agent", "source", "expectedSnapshot"])) return null;
  if (typeof value.namespace !== "string" || value.namespace.length < 1 || value.namespace.length > 256 ||
    typeof value.principal !== "string" || value.principal.length < 3 || value.principal.length > 320 ||
    typeof value.agent !== "string" || !/^[a-z0-9-]{1,32}$/.test(value.agent)) return null;
  const source = value.source;
  let parsedSource: EventSourceActivationInputV1["source"] | null = null;
  if (exactObject(source, ["kind", "subjectId", "sourceStateVersion"]) && source.kind === "manual" &&
    typeof source.subjectId === "string" && source.subjectId.length > 0 && source.subjectId.length <= 256 &&
    typeof source.sourceStateVersion === "string" && source.sourceStateVersion.length > 0 && source.sourceStateVersion.length <= 256)
    parsedSource = { kind: "manual", subjectId: source.subjectId, sourceStateVersion: source.sourceStateVersion };
  else if (exactObject(source, ["kind", "installationId", "repositoryId", "prNumber", "sourceIncarnation"]) && source.kind === "github" &&
    [source.installationId, source.repositoryId, source.prNumber, source.sourceIncarnation].every(n => typeof n === "number" && Number.isSafeInteger(n) && n > 0))
    parsedSource = { kind: "github", installationId: source.installationId as number, repositoryId: source.repositoryId as number,
      prNumber: source.prNumber as number, sourceIncarnation: source.sourceIncarnation as number };
  if (!parsedSource || (Object.hasOwn(value, "expectedSnapshot") && !digest(value.expectedSnapshot))) return null;
  return { namespace: value.namespace, principal: value.principal, agent: value.agent, source: parsedSource,
    ...(typeof value.expectedSnapshot === "string" ? { expectedSnapshot: value.expectedSnapshot } : {}) };
}

export function parseEventSourceActivationResultV1(value: unknown): EventSourceActivationResultV1 | null {
  if (exactObject(value, ["status"]) && ["denied", "changed", "unavailable", "invalid"].includes(value.status as string))
    return { status: value.status } as EventSourceActivationResultV1;
  if (!exactObject(value, ["status", "claim"]) || value.status !== "eligible") return null;
  const claim = parseActivationClaimV1(value.claim);
  return claim && claim.source.kind !== "message" ? { status: "eligible", claim } : null;
}

export type EventOwnerAgentInputV1 = Readonly<{ accessAssertion: string; agent: string }>;
export type EventOwnerAgentResultV1 =
  | Readonly<{ status: "authorized"; identity: Readonly<{ principal: string; agent: string }> }>
  | Readonly<{ status: "not_registered" | "denied" | "unavailable" | "invalid" }>;

export interface EventAuthorityServiceV1 extends MessageRouteControlService {
  registeredOwnerAgent(input: EventOwnerAgentInputV1): Promise<EventOwnerAgentResultV1>;
  currentAuth(input: EventAuthorityCredentialsV1): Promise<EventAuthorityAuthResultV1>;
  prepareSourceActivation(input: EventSourceActivationInputV1): Promise<EventSourceActivationResultV1>;
  reserveNativeAttempt(input: EventAuthorityAttemptV1): Promise<EventAttemptReservationResultV1>;
  nativeAttemptStatus(input: EventAuthorityAttemptV1): Promise<EventAttemptStatusResultV1>;
}

export interface EventStockWakeAuthorityServiceV1 {
  reserveStockWakeAttempt(input: StockWakeAttemptV1): Promise<StockWakeReservationResultV1>;
  stockWakeAttemptStatus(input: StockWakeAttemptV1): Promise<EventAttemptStatusResultV1>;
  settleStockWakeAttempt(input: StockWakeSettlementInputV1): Promise<StockWakeSettlementResultV1>;
}

/** Same attempt ID for transport replay; a new native attempt gets a new ID. An over-budget
 * response is not retained because it is not a reservation; retries after that refusal are fresh claims. */

/** Reject extra keys so future claims cannot quietly become authority inputs. */
export function parseEventAuthorityInput(value: unknown, withAttempt: false): EventAuthorityCredentialsV1 | null;
export function parseEventAuthorityInput(value: unknown, withAttempt: true): EventAuthorityAttemptV1 | null;
export function parseEventAuthorityInput(value: unknown, withAttempt: boolean): EventAuthorityCredentialsV1 | EventAuthorityAttemptV1 | null {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return null;
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) return null;
  const keys = Object.keys(value);
  const expected = withAttempt ? ["accessAssertion", "agentToken", "attemptId"] : ["accessAssertion", "agentToken"];
  const hasActivation = withAttempt && Object.hasOwn(value, "activation");
  if (keys.length !== expected.length + Number(hasActivation) || expected.some((key) => !Object.hasOwn(value, key)) ||
    keys.some(key => !expected.includes(key) && key !== "activation")) return null;

  const input = value as Record<string, unknown>;
  if (typeof input.accessAssertion !== "string" || input.accessAssertion.length === 0 || input.accessAssertion.length > 16_384) return null;
  if (typeof input.agentToken !== "string" || input.agentToken.length === 0 || input.agentToken.length > 4_096) return null;
  if (!withAttempt) return { accessAssertion: input.accessAssertion, agentToken: input.agentToken };
  if (typeof input.attemptId !== "string" || !UUID_V4_OR_V7.test(input.attemptId)) return null;
  if (!hasActivation) return { accessAssertion: input.accessAssertion, agentToken: input.agentToken, attemptId: input.attemptId };
  const activation = parseActivationClaimV1(input.activation);
  if (!activation || activation.source.kind === "message") return null;
  return { accessAssertion: input.accessAssertion, agentToken: input.agentToken, attemptId: input.attemptId, activation };
}

const UUID_V4_OR_V7 = /^[0-9a-f]{8}-[0-9a-f]{4}-[47][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

/** Private Messaging-source admission; the coordinator must supply its canonical consumer tuple. */
export type EventMessageConsumerV1 = Readonly<{
  nodeId: string; runtimeId: string; nodeGeneration: number; runtimeGeneration: number; attachmentGeneration: number; consumerGeneration: number;
}>;
export type EventMessageRouteV1 = Readonly<{
  owner: "os" | "event"; generation: number; consumer: EventMessageConsumerV1 | null;
}>;
export type EventMessageClaimV1 = Readonly<{ attemptId: string; messageId: string; routingGeneration: number; consumer: EventMessageConsumerV1 }> |
  Readonly<{ attemptId: string; messageId: string; routingGeneration: number; consumer: EventMessageConsumerV1; activation: ActivationClaimV1 }>;
export type EventMessageAttemptV1 = EventAuthorityCredentialsV1 & EventMessageClaimV1;
export type EventMessageAttemptResultV1 =
  | Readonly<{ status: "reserved"; attemptId: string; reservedAt: number; idempotent: boolean; routingGeneration: number; budget: EventAttemptBudgetV1 }>
  | Readonly<{ status: "over_budget"; budget: EventAttemptBudgetV1 }>
  | Readonly<{ status: "unknown" | "pending" | "conflict" | "denied" | "invalid" | "unavailable" }>;

/** Reference metadata only; publicationId includes the canonical source agent incarnation. */
export type EventMessagePublicationV1 = Readonly<{
  publicationId: string; topic: "knitli.message.created"; namespace: string;
  principal: string; agent: string; messageId: string; storedAt: string;
}>;
export type EventMessagePublicationResultV1 =
  | Readonly<{ status: "eligible"; publication: EventMessagePublicationV1 }>
  | Readonly<{ status: "denied" | "invalid" | "unavailable" }>;

/** Separate extension keeps the established manual/GitHub authority contract closed. */
export interface EventMessageAuthorityServiceV1 extends EventAuthorityServiceV1 {
  readMessagePreparation(input: EventMessagePreparationInputV1): Promise<EventMessagePreparationResultV1>;
  validateMessagePublication(input: EventMessagePublicationV1): Promise<EventMessagePublicationResultV1>;
  reserveMessageAttempt(input: EventMessageAttemptV1): Promise<EventMessageAttemptResultV1>;
  messageAttemptStatus(input: EventMessageAttemptV1): Promise<EventMessageAttemptResultV1>;
}

function exactObject(value: unknown, keys: string[]): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value) &&
    [Object.prototype, null].includes(Object.getPrototypeOf(value)) &&
    Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key));
}
const positiveGeneration = (value: unknown): value is number => typeof value === "number" && Number.isSafeInteger(value) && value > 0;

export function parseEventMessageConsumer(value: unknown): EventMessageConsumerV1 | null {
  if (!exactObject(value, ["nodeId", "runtimeId", "nodeGeneration", "runtimeGeneration", "attachmentGeneration", "consumerGeneration"]) ||
    typeof value.nodeId !== "string" || !UUID_V4_OR_V7.test(value.nodeId) ||
    typeof value.runtimeId !== "string" || !UUID_V4_OR_V7.test(value.runtimeId) ||
    !positiveGeneration(value.nodeGeneration) || !positiveGeneration(value.runtimeGeneration) || !positiveGeneration(value.attachmentGeneration) || !positiveGeneration(value.consumerGeneration)) return null;
  return { nodeId: value.nodeId, runtimeId: value.runtimeId, nodeGeneration: value.nodeGeneration,
    runtimeGeneration: value.runtimeGeneration, attachmentGeneration: value.attachmentGeneration, consumerGeneration: value.consumerGeneration };
}

export function parseEventMessageClaim(value: unknown): EventMessageClaimV1 | null {
  if (!exactObject(value, ["attemptId", "messageId", "routingGeneration", "consumer"]) &&
      !exactObject(value, ["attemptId", "messageId", "routingGeneration", "consumer", "activation"])) return null;
  const consumer = parseEventMessageConsumer(value.consumer);
  if (!consumer || typeof value.attemptId !== "string" || !UUID_V4_OR_V7.test(value.attemptId) ||
    typeof value.messageId !== "string" || !UUID_V4_OR_V7.test(value.messageId) || !positiveGeneration(value.routingGeneration)) return null;
  const claim = { attemptId: value.attemptId, messageId: value.messageId, routingGeneration: value.routingGeneration, consumer };
  if (!Object.hasOwn(value, "activation")) return claim;
  const activation = parseActivationClaimV1(value.activation);
  if (!activation || activation.source.kind !== "message" || activation.source.messageId !== value.messageId ||
      activation.source.routeGeneration !== value.routingGeneration || JSON.stringify(activation.source.consumer) !== JSON.stringify(consumer)) return null;
  return { ...claim, activation };
}

export function parseEventMessageAttempt(value: unknown): EventMessageAttemptV1 | null {
  if (!exactObject(value, ["accessAssertion", "agentToken", "attemptId", "messageId", "routingGeneration", "consumer"]) &&
      !exactObject(value, ["accessAssertion", "agentToken", "attemptId", "messageId", "routingGeneration", "consumer", "activation"])) return null;
  const credentials = parseEventAuthorityInput({ accessAssertion: value.accessAssertion, agentToken: value.agentToken }, false);
  const claim = parseEventMessageClaim({ attemptId: value.attemptId, messageId: value.messageId, routingGeneration: value.routingGeneration,
    consumer: value.consumer, ...(Object.hasOwn(value, "activation") ? { activation: value.activation } : {}) });
  return credentials && claim ? { ...credentials, ...claim } : null;
}

/** Parse the full supplied reference; no extra fields or noncanonical timestamps. */
export function parseEventMessagePublication(value: unknown): EventMessagePublicationV1 | null {
  if (!exactObject(value, ["publicationId", "topic", "namespace", "principal", "agent", "messageId", "storedAt"]) ||
    value.topic !== "knitli.message.created" || typeof value.publicationId !== "string" || value.publicationId.length > 2048 ||
    typeof value.namespace !== "string" || value.namespace.length < 1 || value.namespace.length > 256 ||
    typeof value.principal !== "string" || value.principal.length < 1 || value.principal.length > 320 ||
    typeof value.agent !== "string" || !/^[a-z0-9-]{1,32}$/.test(value.agent) ||
    typeof value.messageId !== "string" || !UUID_V4_OR_V7.test(value.messageId) ||
    typeof value.storedAt !== "string" || !Number.isFinite(Date.parse(value.storedAt)) || new Date(value.storedAt).toISOString() !== value.storedAt) return null;
  return { publicationId: value.publicationId, topic: value.topic, namespace: value.namespace,
    principal: value.principal, agent: value.agent, messageId: value.messageId, storedAt: value.storedAt };
}

export type EventMessagePreparationInputV1 = Readonly<{ publication: EventMessagePublicationV1; expectedSnapshot?: string }>;
export type EventMessagePreparationResultV1 =
  | Readonly<{ status: "eligible"; publication: EventMessagePublicationV1;
      canonicalSubject: Readonly<{ kind: "message"; namespace: string; messageId: string; agentIncarnation: number }>;
      sourceStateVersion: string; policyFingerprint: string;
      route: Readonly<{ generation: number; consumer: EventMessageConsumerV1 }>;
      keyThumbprint: string; keyFingerprint: string; snapshotDigest: string; checkedAt: string; activation: ActivationClaimV1 }>
  | Readonly<{ status: "denied" | "changed" | "unavailable" | "invalid" }>;
const digest = (v: unknown): v is string => typeof v === "string" && /^[0-9a-f]{64}$/.test(v);
export function parseEventMessagePreparationInput(value: unknown): EventMessagePreparationInputV1 | null {
  if (!exactObject(value, ["publication"]) && !exactObject(value, ["publication", "expectedSnapshot"])) return null;
  const publication = parseEventMessagePublication(value.publication);
  if (!publication || (Object.hasOwn(value, "expectedSnapshot") && !digest(value.expectedSnapshot))) return null;
  return { publication, ...(typeof value.expectedSnapshot === "string" ? { expectedSnapshot: value.expectedSnapshot } : {}) };
}
export function parseEventMessagePreparationResult(value: unknown): EventMessagePreparationResultV1 | null {
  if (exactObject(value, ["status"]) && ["denied", "changed", "unavailable", "invalid"].includes(value.status as string))
    return { status: value.status } as EventMessagePreparationResultV1;
  if (!exactObject(value, ["status", "publication", "canonicalSubject", "sourceStateVersion", "policyFingerprint", "route", "keyThumbprint", "keyFingerprint", "snapshotDigest", "checkedAt", "activation"]) || value.status !== "eligible") return null;
  const publication = parseEventMessagePublication(value.publication), subject = value.canonicalSubject, route = value.route;
  if (!publication || !exactObject(subject, ["kind", "namespace", "messageId", "agentIncarnation"]) || subject.kind !== "message" ||
    subject.namespace !== publication.namespace || subject.messageId !== publication.messageId || !Number.isSafeInteger(subject.agentIncarnation) || (subject.agentIncarnation as number) < 0 ||
    publication.publicationId !== JSON.stringify([publication.namespace, publication.principal, publication.agent, subject.agentIncarnation, publication.messageId]) ||
    !exactObject(route, ["generation", "consumer"]) || !positiveGeneration(route.generation)) return null;
  const consumer = parseEventMessageConsumer(route.consumer);
  const activation = parseActivationClaimV1(value.activation);
  if (!consumer || consumer.consumerGeneration !== consumer.attachmentGeneration ||
    typeof value.sourceStateVersion !== "string" || !/^msg:[0-9a-f]{64}$/.test(value.sourceStateVersion) ||
    !digest(value.policyFingerprint) || !digest(value.keyFingerprint) || !digest(value.snapshotDigest) ||
    typeof value.keyThumbprint !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(value.keyThumbprint) ||
    typeof value.checkedAt !== "string" || !Number.isFinite(Date.parse(value.checkedAt)) || new Date(value.checkedAt).toISOString() !== value.checkedAt ||
    !activation || activation.source.kind !== "message" || activation.principal !== publication.principal || activation.agent !== publication.agent ||
    activation.source.namespace !== publication.namespace || activation.source.messageId !== publication.messageId ||
    activation.agentIncarnation !== subject.agentIncarnation || activation.source.agentIncarnation !== subject.agentIncarnation ||
    activation.source.sourceStateVersion !== value.sourceStateVersion || activation.source.routeGeneration !== route.generation ||
    JSON.stringify(activation.source.consumer) !== JSON.stringify(consumer) || activation.policyFingerprint !== value.policyFingerprint ||
    activation.snapshotDigest !== value.snapshotDigest) return null;
  return { status: "eligible", publication, canonicalSubject: { kind: "message", namespace: publication.namespace, messageId: publication.messageId, agentIncarnation: subject.agentIncarnation as number },
    sourceStateVersion: value.sourceStateVersion, policyFingerprint: value.policyFingerprint, route: { generation: route.generation, consumer },
    keyThumbprint: value.keyThumbprint, keyFingerprint: value.keyFingerprint, snapshotDigest: value.snapshotDigest, checkedAt: value.checkedAt, activation };
}

export function parseActivationClaimV1(value: unknown): ActivationClaimV1 | null {
  if (!exactObject(value, ["version", "principal", "agent", "agentIncarnation", "source", "verdict", "policyFingerprint", "snapshotDigest"]) || value.version !== 1 ||
    typeof value.principal !== "string" || value.principal.length < 3 || value.principal.length > 320 ||
    typeof value.agent !== "string" || !/^[a-z0-9-]{1,32}$/.test(value.agent) || !positiveGeneration(value.agentIncarnation) ||
    !digest(value.policyFingerprint) || !digest(value.snapshotDigest)) return null;
  const source = value.source;
  let parsedSource: ActivationSourceV1 | null = null;
  if (exactObject(source, ["kind", "subjectId", "sourceStateVersion"]) && source.kind === "manual" &&
    typeof source.subjectId === "string" && source.subjectId.length > 0 && source.subjectId.length <= 256 &&
    typeof source.sourceStateVersion === "string" && source.sourceStateVersion.length > 0 && source.sourceStateVersion.length <= 256) {
    parsedSource = { kind: "manual", subjectId: source.subjectId, sourceStateVersion: source.sourceStateVersion };
  } else if (exactObject(source, ["kind", "installationId", "repositoryId", "prNumber", "sourceIncarnation"]) && source.kind === "github" &&
    [source.installationId, source.repositoryId, source.prNumber, source.sourceIncarnation].every(n => typeof n === "number" && Number.isSafeInteger(n) && n > 0)) {
    parsedSource = { kind: "github", installationId: source.installationId as number, repositoryId: source.repositoryId as number,
      prNumber: source.prNumber as number, sourceIncarnation: source.sourceIncarnation as number };
  } else if (exactObject(source, ["kind", "namespace", "messageId", "sourceStateVersion", "agentIncarnation", "routeGeneration", "consumer"]) && source.kind === "message" &&
    typeof source.namespace === "string" && source.namespace.length > 0 && source.namespace.length <= 256 &&
    typeof source.messageId === "string" && UUID_V4_OR_V7.test(source.messageId) &&
    typeof source.sourceStateVersion === "string" && /^msg:[0-9a-f]{64}$/.test(source.sourceStateVersion) &&
    typeof source.agentIncarnation === "number" && Number.isSafeInteger(source.agentIncarnation) && source.agentIncarnation >= 0 && positiveGeneration(source.routeGeneration)) {
    const consumer = parseEventMessageConsumer(source.consumer);
    if (consumer) parsedSource = { kind: "message", namespace: source.namespace, messageId: source.messageId, sourceStateVersion: source.sourceStateVersion,
      agentIncarnation: source.agentIncarnation, routeGeneration: source.routeGeneration, consumer };
  }
  const verdict = value.verdict;
  if (!parsedSource || (parsedSource.kind === "message" && parsedSource.agentIncarnation !== value.agentIncarnation) ||
    typeof verdict !== "object" || verdict === null || Array.isArray(verdict)) return null;
  if (exactObject(verdict, ["allowed", "reason"]) && verdict.allowed === true && verdict.reason === "owner_direct" && parsedSource.kind === "manual") {
    return { version: 1, principal: value.principal, agent: value.agent, agentIncarnation: value.agentIncarnation, source: parsedSource,
      verdict: { allowed: true, reason: "owner_direct" }, policyFingerprint: value.policyFingerprint, snapshotDigest: value.snapshotDigest };
  }
  if (exactObject(verdict, ["allowed", "reason", "orderDigest"]) && verdict.allowed === true && verdict.reason === "order" && digest(verdict.orderDigest) &&
    (parsedSource.kind === "github" || parsedSource.kind === "message")) {
    return { version: 1, principal: value.principal, agent: value.agent, agentIncarnation: value.agentIncarnation, source: parsedSource,
      verdict: { allowed: true, reason: "order", orderDigest: verdict.orderDigest }, policyFingerprint: value.policyFingerprint, snapshotDigest: value.snapshotDigest };
  }
  if (exactObject(verdict, ["allowed", "reason"]) && verdict.allowed === true && ["wake_grant", "granted"].includes(verdict.reason as string) && parsedSource.kind === "message") {
    return { version: 1, principal: value.principal, agent: value.agent, agentIncarnation: value.agentIncarnation, source: parsedSource,
      verdict: { allowed: true, reason: verdict.reason as "wake_grant" | "granted" }, policyFingerprint: value.policyFingerprint, snapshotDigest: value.snapshotDigest };
  }
  return null;
}
