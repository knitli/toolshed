// Scope v1 (plan 5.2-5.7): one grammar, one attenuation function. Pure TypeScript: no Worker types, no I/O,
// no imports outside this package.
//
// Fail closed, everywhere. A value that is not a well-formed term covers nothing and is covered by nothing;
// an unknown service, verb, `where` key or resource refuses rather than being ignored; and parseTerm accepts
// exactly the text printTerm writes, so every term has one text (an act signs text, so a second spelling of
// the same term would be a second thing to sign). Every resource grammar below is a strict SUBSET of the
// service's own (see the cites), so a term this file accepts is one the service would accept too.
//
// Resources are compared as the raw strings they are, never percent-decoded or otherwise normalised: `%` is a
// legal character in an email local part, so `user/a%2fb@c.co/x` and `user/a/b@c.co/x` are two different
// principals, and a decoder anywhere in here would merge them.
//
// Where the plan left a choice, the narrower reading is taken and marked "Ambiguity" for the 3a report.
import { TASK_TYPE } from "./task.ts";

export type Svc = "msg" | "mem" | "exec";
export type Term = Readonly<{
  svc: Svc;
  verb: string; // closed per svc (5.3); an unknown verb refuses
  res: string; // exact id, or "<parent>/*" where the service has parents
  where?: Readonly<Record<string, readonly string[]>>; // closed keys per (svc, verb); sorted and deduplicated
  cap?: Readonly<{ n?: number; microUsd?: number }>; // upper bounds over the life of the order; absent means unbounded
}>;

const SVCS: readonly string[] = ["msg", "mem", "exec"];
const isSvc = (value: unknown): value is Svc => typeof value === "string" && SVCS.includes(value);

/**
 * svc -> verb -> the `where` keys that verb takes (5.3). Closed: a verb or key not listed refuses.
 * Ambiguity: `exec.cancel` and `exec.evidence` are not scope verbs in R4 (5.3) and `msg.receive`/`msg.draft`
 * take the same `type` key as send and forward; no verb takes a key the table does not give it.
 */
const WHERE_KEYS: Record<Svc, Record<string, readonly string[]>> = {
  msg: { send: ["type"], forward: ["type"], receive: ["type"], draft: ["type"] },
  mem: { read: [], propose: [], write: [] },
  exec: { request: [] },
};

/**
 * What a `where` key's values look like and how many it may hold. Ambiguity: 5.3 says "at most 16" for
 * `msg.send` and `msg.draft` only; the narrower reading applies it to every `type` key.
 */
const WHERE_VALUES: Record<string, { max: number; pattern: RegExp }> = {
  type: { max: 16, pattern: TASK_TYPE },
};

/**
 * `mem` verbs are a chain: write implies propose implies read, as LEVELS in gatekeeper-memory (5.3). Nothing
 * else implies anything. Kept transitively closed by hand: covers is transitive only because this is.
 */
const IMPLIES: Partial<Record<Svc, Record<string, readonly string[]>>> = {
  mem: { write: ["propose", "read"], propose: ["read"] },
};

// --- resource grammars ---------------------------------------------------------------------------------

// A principal is an email or `svc:<name>`, lowercase (gatekeeper-memory principals.ts / segments.ts isPrincipal,
// openapi-operator access.ts canonicalEmail). Ambiguity: canonicalEmail also allows `# { | } =` in the local
// part. Those are this grammar's own delimiters, so a principal holding one cannot be named by a term at all:
// it is unrepresentable here, which fails closed.
const LOCAL = /^[a-z0-9!$%&'*+/?^_`~-]+(?:\.[a-z0-9!$%&'*+/?^_`~-]+)*$/;
const LABEL = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
const SERVICE_PRINCIPAL = /^svc:[a-z0-9-]{1,64}$/;

// canonicalEmail also caps the domain at 253; that is implied here (254 in all, minus a local part of at least
// one character and the "@", leaves 252), so it is not repeated.
/** A principal as an act or a pin names one: lowercase ASCII, an email Scope v1 reads. Shared by the acts' principal fields and by the deployment's anchors. */
export const isCanonicalPrincipal = (value: unknown): value is string => typeof value === "string" && /^[\x21-\x7e]+$/.test(value) && value === value.toLowerCase() && isEmail(value);

/** An email as Scope v1 spells a principal: a strict subset of what Messaging's canonicalEmail takes (see the notes above), so a term or an act naming one is one Messaging reads. */
export function isEmail(value: string): boolean {
  const parts = value.split("@");
  if (value.length > 254 || parts.length !== 2) return false;
  const [local, domain] = parts as [string, string];
  return local.length <= 64 && LOCAL.test(local) && domain.includes(".") && domain.split(".").every((label) => LABEL.test(label));
}
const isPrincipal = (value: string): boolean => SERVICE_PRINCIPAL.test(value) || isEmail(value);

// mem: `team/<name>` or `user/<principal>/<name>`, or `<parent>/*` for every segment under a parent
// (gatekeeper-memory segments.ts parseSegmentId and parseSelector). A prefix is NOT a string prefix: the
// parent is parsed whole and compared whole, so `user/a@b.co/*` is not a parent of `user/a@b.com/x` (AT-23).
const SEGMENT_NAME = /^[a-z0-9][a-z0-9-]{0,62}$/;
type Segment = { parent: string; id: string | null }; // id null: the prefix `<parent>/*`

const isParent = (parent: string): boolean => parent === "team" || (parent.startsWith("user/") && isPrincipal(parent.slice(5)));

function parseSegment(res: string): Segment | null {
  if (res.endsWith("/*")) {
    const parent = res.slice(0, -2);
    return isParent(parent) ? { parent, id: null } : null;
  }
  const cut = res.lastIndexOf("/");
  return cut > 0 && isParent(res.slice(0, cut)) && SEGMENT_NAME.test(res.slice(cut + 1)) ? { parent: res.slice(0, cut), id: res } : null;
}

// msg: one exact agent, `principal/name` (gatekeeper-messaging model.ts parseAddress and AGENT): the name is
// what follows the first "/" after the last "@", since an email's local part may hold "/" and its domain never does.
// Ambiguity: 5.2 says "<parent>/*" where the service has parents, and a messaging agent has a principal for a
// parent, but names only exact agents in every example and says a cross-owner term "names one exact agent".
// Same-owner-versus-cross-owner is not knowable in a pure library, so v1 takes the narrow reading: msg has no
// prefix form. Adding `<principal>/*` later only widens what parses.
const AGENT = /^[a-z0-9-]{1,32}$/;

function isAgentAddress(res: string): boolean {
  const at = res.lastIndexOf("@");
  const slash = at < 0 ? -1 : res.indexOf("/", at);
  return slash > 0 && isEmail(res.slice(0, slash)) && AGENT.test(res.slice(slash + 1));
}

// exec: one exact profile id, at most 59 characters so `exec/<id>` fits the 64-character task type (5.2).
const PROFILE = /^[a-z0-9][a-z0-9-]{0,58}$/;

const isRes = (svc: Svc, res: unknown): res is string =>
  typeof res === "string" && (svc === "mem" ? parseSegment(res) !== null : svc === "msg" ? isAgentAddress(res) : PROFILE.test(res));

/**
 * Whether `parent` covers `child` as a resource of `svc`: equal, or `parent` is `<parent>/*` and `child` is a
 * segment under that same parent (or that same prefix). Grammar-aware, never a string prefix (5.2). False if
 * either side is not a well-formed resource of `svc`.
 */
export function resCovers(svc: Svc, parent: string, child: string): boolean {
  if (!isSvc(svc) || !isRes(svc, parent) || !isRes(svc, child)) return false;
  if (svc !== "mem") return parent === child;
  const p = parseSegment(parent)!;
  const c = parseSegment(child)!;
  return p.id === null ? c.parent === p.parent : p.id === c.id;
}

// --- term validity ---------------------------------------------------------------------------------------

const ascending = (values: readonly string[]): boolean => values.every((value, i) => i === 0 || values[i - 1]! < value);
// -0 is refused: it prints as `n=0` and parses back as 0, so parse(print(t)) would not equal t.
const isCount = (value: unknown): value is number => typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && !Object.is(value, -0);

/**
 * A plain data object, or null: Object.prototype or no prototype at all, and only own, enumerable, string-keyed
 * data properties. So nothing is inherited (`Object.create({cap})`), hidden (non-enumerable, symbol) or computed
 * (getters, which could answer differently when read again). The same shape JSON.parse gives.
 */
function plain(value: unknown): Record<string, unknown> | null {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return null;
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) return null;
  for (const key of Reflect.ownKeys(value)) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
    if (typeof key !== "string" || !descriptor.enumerable || !("value" in descriptor)) return null;
  }
  return value as Record<string, unknown>;
}

/**
 * An array and nothing more, or null: Array.prototype itself (an array can otherwise inherit its own `every` and
 * iterator, and answer with something other than what it holds), one own enumerable data property per element (no
 * hole, which `every` and `flatMap` would skip; no getter) and no stray property.
 */
function list(value: unknown): readonly unknown[] | null {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype) return null;
  if (Reflect.ownKeys(value).length !== value.length + 1) return null; // the elements and "length"; counted first, so a huge sparse array is not walked
  for (let i = 0; i < value.length; i++) {
    const descriptor = Object.getOwnPropertyDescriptor(value, i);
    if (descriptor === undefined || !descriptor.enumerable || !("value" in descriptor)) return null;
  }
  return value;
}

function isWhere(svc: Svc, verb: string, value: unknown): boolean {
  const where = plain(value);
  if (where === null) return false;
  const keys = Object.keys(where);
  if (keys.length === 0 || !ascending(keys)) return false; // a present `where` holds a key; sorted and unique
  return keys.every((key) => {
    const rule = WHERE_VALUES[key];
    const values: unknown = where[key];
    if (!WHERE_KEYS[svc][verb]!.includes(key) || rule === undefined) return false;
    const items = list(values);
    if (items === null || items.length === 0 || items.length > rule.max) return false;
    for (const v of items) if (typeof v !== "string" || !rule.pattern.test(v)) return false;
    return ascending(items as string[]);
  });
}

function isCap(value: unknown): boolean {
  const cap = plain(value);
  const entries = cap === null ? [] : Object.entries(cap);
  return entries.length > 0 && entries.every(([key, v]) => (key === "n" || key === "microUsd") && isCount(v));
}

/**
 * Whether `value` is a well-formed Scope v1 term in canonical form: known svc and verb, a resource of that
 * svc, only the `where` keys that verb takes (values sorted, unique, at most 16, task-type shaped), caps that
 * are safe integers, and no other key. Canonical form is part of validity so that parse(print(t)) equals t.
 * Only a plain data object is a term (see `plain` and `list`): anything JSON-shaped qualifies and nothing cleverer does.
 * This checks the value as it stands; the public functions below also decide on a copy (see `snapshot`).
 */
function validTerm(value: unknown): value is Term {
  const term = plain(value);
  if (term === null) return false;
  const { svc, verb, res, where, cap } = term;
  if (!Object.entries(term).every(([key, v]) => ["svc", "verb", "res", "where", "cap"].includes(key) && v !== undefined)) return false;
  if (!isSvc(svc) || typeof verb !== "string" || !Object.hasOwn(WHERE_KEYS[svc], verb) || !isRes(svc, res)) return false;
  return (where === undefined || isWhere(svc, verb, where)) && (cap === undefined || isCap(cap));
}

/**
 * A structured clone of `value`, or undefined if it cannot be copied (a Proxy, a function, a symbol), which is no
 * term and no list. The clone is made first, so a Proxy's traps are never run by the checks; it reads a getter once and
 * puts a real Array.prototype back on a swapped array. Everything the public functions decide, they decide on a
 * clone that passed validTerm/list, AND the original has to pass the same checks: the clone alone would
 * flatten a getter or a swapped array into something valid and let the original, read again later, say otherwise.
 */
function snapshot(value: unknown): unknown {
  try {
    return structuredClone(value);
  } catch {
    return undefined;
  }
}

/** `value` as a term, or null: the clone, once both it and `value` are valid terms. */
function termOf(value: unknown): Term | null {
  const copy = snapshot(value);
  return validTerm(copy) && validTerm(value) ? copy : null;
}

/** Whether `value` is a well-formed term, and plain data that a clone of it agrees with (see `validTerm`, `snapshot`). */
export function isTerm(value: unknown): value is Term {
  return termOf(value) !== null;
}

// --- canonical text: `svc.verb:res{key=a|b}#n=20,usd=1` ----------------------------------------------------

// A bound on the work done on an untrusted string, not a rule of the grammar: the longest valid term (a 254-character
// email and a 32-character agent, 16 type values of 64 characters, both caps) is about 1.4 KiB, so no valid text
// is ever refused for its length. A test builds that longest term and fails if this is lowered beneath it.
const MAX_TEXT = 4096;
const TEXT = /^([a-z]+)\.([a-z]+):([^{}#]+)(?:\{([^{}#]+)\})?(?:#([^{}#]+))?$/;
const MICRO = 1_000_000;

/** `microUsd` as dollars, integers only (acts forbid floats, VS-22): 1000000 is "1", 1500000 is "1.5", 1 is "0.000001". */
function printUsd(microUsd: number): string {
  const fraction = microUsd % MICRO;
  const whole = (microUsd - fraction) / MICRO; // both operands are whole numbers, so this is exact
  const digits = String(fraction).padStart(6, "0").replace(/0+$/, "");
  return digits === "" ? String(whole) : `${whole}.${digits}`;
}

/** The text of a term. Throws on anything that is not a valid term: nothing malformed is ever rendered or signed. */
export function printTerm(value: Term): string {
  const term = termOf(value);
  if (term === null) throw new TypeError("not a Scope v1 term");
  const where = term.where && `{${Object.keys(term.where).map((key) => `${key}=${term.where![key]!.join("|")}`).join(",")}}`;
  const caps = term.cap && [term.cap.n !== undefined && `n=${term.cap.n}`, term.cap.microUsd !== undefined && `usd=${printUsd(term.cap.microUsd)}`].filter(Boolean);
  return `${term.svc}.${term.verb}:${term.res}${where ?? ""}${caps ? `#${caps.join(",")}` : ""}`;
}

/**
 * Dollars as integer microUsd, or null if it is not `digits` or `digits.digits` with at most 6 decimals.
 * BigInt keeps it integer all the way; a value past the last safe integer comes out as a Number that
 * isCap then refuses.
 */
function parseUsd(text: string): number | null {
  const m = /^([0-9]+)(?:\.([0-9]{1,6}))?$/.exec(text);
  return m ? Number(BigInt(m[1]!) * BigInt(MICRO) + BigInt((m[2] ?? "").padEnd(6, "0"))) : null;
}

/**
 * The term a text spells, or null. Fails closed on anything unknown or malformed, and on any text that is not
 * the canonical spelling (unsorted or repeated values, `usd=1.0`, `n=01`, a cap after the wrong cap): the text
 * is read loosely into a term and accepted only if printing that term gives back exactly the text.
 */
export function parseTerm(text: string): Term | null {
  const m = typeof text === "string" && text.length <= MAX_TEXT ? TEXT.exec(text) : null;
  if (!m) return null;
  const [, svc, verb, res, whereText, capText] = m;
  const where = whereText === undefined ? undefined : Object.fromEntries(whereText.split(",").map((pair) => [pair.split("=", 1)[0]!, pair.slice(pair.indexOf("=") + 1).split("|")]));
  const caps = capText?.split(",").map((pair) => [pair.split("=", 1)[0]!, pair.slice(pair.indexOf("=") + 1)] as const);
  const cap =
    caps === undefined
      ? undefined
      : Object.fromEntries(caps.map(([name, value]) => [name === "usd" ? "microUsd" : name, name === "usd" ? parseUsd(value) : /^[0-9]+$/.test(value) ? Number(value) : null]));
  const term = { svc, verb, res, ...(where && { where }), ...(cap && { cap }) };
  // isTerm rejects a null cap value (not a count) and an unknown cap name; the round trip rejects the rest.
  return isTerm(term) && printTerm(term) === text ? term : null;
}

// --- attenuation (5.7) -----------------------------------------------------------------------------------

const subset = (child: readonly string[], parent: readonly string[]): boolean => child.every((value) => parent.includes(value));

/**
 * Whether the parent term `p` grants everything the child term `c` does. Reflexive and transitive on valid
 * terms; false if either is not a valid term. A child that omits a `where` key the parent set is broader and
 * fails, and so does a child that omits a cap the parent set.
 */
export function covers(parent: Term, child: Term): boolean {
  const p = termOf(parent);
  const c = termOf(child);
  return p !== null && c !== null && coversClean(p, c);
}

function coversClean(p: Term, c: Term): boolean {
  return (
    // Implied today, because no verb name is shared by two services (a test pins that); kept as the spec has it,
    // so the day two services share a verb name the service still has to match.
    p.svc === c.svc &&
    (p.verb === c.verb || IMPLIES[p.svc]?.[p.verb]?.includes(c.verb) === true) &&
    resCovers(p.svc, p.res, c.res) &&
    Object.keys(p.where ?? {}).every((k) => c.where?.[k] !== undefined && subset(c.where[k]!, p.where![k]!)) &&
    (p.cap?.n === undefined || (c.cap?.n !== undefined && c.cap.n <= p.cap.n)) &&
    (p.cap?.microUsd === undefined || (c.cap?.microUsd !== undefined && c.cap.microUsd <= p.cap.microUsd))
  );
}

/**
 * The terms of a list of terms, or null if `value` is not a list (null, an object, a sparse array, a swapped
 * prototype, a Proxy). A member that is not a term is null in the result: it covers nothing, and a child
 * holding one is not covered. Like `termOf`, this reads a clone and requires the original to pass too.
 */
function termsOf(value: unknown): (Term | null)[] | null {
  const copy = list(snapshot(value));
  const original = copy === null ? null : list(value); // not before the clone has passed: a Proxy's traps stay unrun
  return copy === null || original === null ? null : copy.map((t, i) => (validTerm(t) && validTerm(original[i]) ? t : null));
}

/**
 * Whether every child term sits inside some parent term, and no cap is spent twice. An empty child holds nothing,
 * so it attenuates any list that is a list; a parent or child that is not a list attenuates nothing.
 *
 * Caps are over the life of the order, so a child term covered by an uncapped parent term costs nothing, but
 * otherwise it is CHARGED to every capped parent term that covers it, and a capped parent term charged by two or
 * more child terms fails the whole call. Without this, `#n=1` could be split into `#n=1` and `#n=1` (or one
 * child per verb, or per `where` value), each inside the cap on its own and together over it.
 * Deliberate reading of 5.7/5.6, pending withinCaps: over-strict. A child that could be assigned to different
 * capped parents is still refused (and two children under one `#n=5` parent are refused though 2+3 would fit),
 * which fails closed; the exact accounting is the order's, not this grammar's.
 *
 * NOT TRANSITIVE at list level, because of that rule: attenuates(A, B) and attenuates(B, C) do not give
 * attenuates(A, C). A child can fit its parent list one way and, one step down, collide on a capped term that
 * the middle list kept apart (a test pins an instance). The failure is on the strict side, never the loose one,
 * so a caller must check every hop (each list against the list it was derived from) and treat the hops as
 * authoritative; checking the first list against the last is not a substitute. Per-term `covers` is transitive.
 */
export function attenuates(parent: readonly Term[], child: readonly Term[]): boolean {
  const parents = termsOf(parent);
  const children = termsOf(child);
  if (parents === null || children === null) return false;
  const charged = parents.map(() => 0);
  for (const c of children) {
    if (c === null) return false;
    const covering = parents.flatMap((p, i) => (p !== null && coversClean(p, c) ? [i] : []));
    if (covering.length === 0) return false;
    if (covering.some((i) => parents[i]!.cap === undefined)) continue;
    if (covering.some((i) => ++charged[i]! > 1)) return false;
  }
  return true;
}

/**
 * Whether `ref` names one memory segment an input may point at (never content, never a `<parent>/*` prefix): a `mem.read` term on it is a valid Scope v1 term.
 * Messaging's task-body check and the order act read this one predicate.
 */
export const isSegmentRef = (ref: unknown): ref is string => typeof ref === "string" && !ref.endsWith("/*") && isTerm({ svc: "mem", verb: "read", res: ref });

// --- an agent's ceiling (plan 5.5, 5.9): the terms an agent_scopes row, and an agent-scope act, may hold ----------------------------------

/** The `mem` verbs a ceiling row may name (a chain: write implies propose implies read, as Memory's levels). */
const CEILING_VERBS: readonly string[] = ["read", "propose", "write"];

/**
 * Why `term` is not a term an agent's ceiling may hold, or null when it is. A ceiling is a `mem` verb on a segment or `<parent>/*`, with
 * no `where` and no cap (a cap is an order's, plan 5.2), or the `msg.draft` right for one exact agent and at least one task type. The right
 * names its types: "may draft an order" for any type would be broader than anything the owner is shown to approve.
 */
export function ceilingProblem(term: unknown): string | null {
  if (!isTerm(term)) return "a scope row is a valid Scope v1 term, for example mem.read:team/marque";
  if (term.cap !== undefined) return "a scope row has no cap: a cap belongs to an order";
  if (term.svc === "mem") return CEILING_VERBS.includes(term.verb) && term.where === undefined ? null : "a memory scope row is mem.read, mem.propose or mem.write on a segment, with nothing after it";
  if (term.svc === "msg" && term.verb === "draft") return term.where?.type === undefined ? "msg.draft names the task types the agent may draft, for example msg.draft:you@example.com/janet{type=exec/marque}" : null;
  return "a scope row is a memory term (mem.read, mem.propose, mem.write) or the msg.draft right";
}

/** The principal of a canonical "principal/agent" address. */
export const ownerOfAddress = (address: string): string => address.slice(0, address.indexOf("/", address.lastIndexOf("@")));

/**
 * Whether `term` is fine for a ceiling held by `principal`'s agent as far as ownership goes: a msg.draft right names one of the owner's own agents, since an
 * order is same-owner at every hop (plan 5.8) and a right to draft one for another person's agent could never be used. Any other term names no agent.
 */
export const draftsOwnAgent = (principal: string, term: Term): boolean => !(term.svc === "msg" && term.verb === "draft") || ownerOfAddress(term.res) === principal;
