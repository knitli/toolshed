import { AccessDenied, AccessUnavailable, canonicalEmail, type AccessPorts } from "openapi-operator/src/access.ts";
import { configured, verifyAdminAssertionWithExpiry, verifyAdminMutation, type AdminSecurityVars } from "gatekeeper-memory/src/admin-security.ts";
import { productionPorts } from "gatekeeper-memory/src/auth.ts";
import { parseAllowedPrincipals, principalAllowed } from "gatekeeper-memory/src/principals.ts";
import { ACCESS_AUDIENCES, audienceShared, type AccessAudienceVar } from "./access-audiences.ts";
import { agentName } from "./model.ts";

export type MessageRouteOwnerCall = Readonly<{ token: string; origin?: string; fetchSite?: string; csrf?: string }>;
export type MessageRouteOwnerIdentity = Readonly<{ namespace: string; principal: string; agent: string }>;
export type MessageRouteOwnerOperation = "read" | "transfer" | "operation_readback";
export type MessageRouteOwnerEnvironment = AdminSecurityVars & Readonly<{
  MESSAGING_NAMESPACE: string;
  ALLOWED_PRINCIPALS: string;
}> & Partial<Readonly<Record<AccessAudienceVar, string>>>;
export type MessageRouteOwnerProof = Readonly<{
  identity: MessageRouteOwnerIdentity;
  operation: MessageRouteOwnerOperation;
  verifiedAtSeconds: number;
  verifiedExpiresAtSeconds: number;
  policySnapshot: MessageRouteOwnerEnvironment;
}>;

/** Process-local human consent only; Mailbox registration, incarnation and active-key checks remain required. */
export class MessageRouteOwnerProofVerifier {
  readonly #ports: AccessPorts;
  readonly #proofs = new WeakSet<MessageRouteOwnerProof>();
  constructor(private readonly env: MessageRouteOwnerEnvironment, ports?: AccessPorts) {
    this.#ports = ports ?? productionPorts(env.ACCESS_ISSUER);
  }

  #policy(): MessageRouteOwnerEnvironment {
    const snapshot = Object.freeze({ ACCESS_ISSUER: this.env.ACCESS_ISSUER, ACCESS_UI_AUD: this.env.ACCESS_UI_AUD,
      ADMIN_UI_ORIGIN: this.env.ADMIN_UI_ORIGIN, MESSAGING_NAMESPACE: this.env.MESSAGING_NAMESPACE,
      ALLOWED_PRINCIPALS: this.env.ALLOWED_PRINCIPALS,
      ...Object.fromEntries(ACCESS_AUDIENCES.map(key => [key, this.env[key]])) });
    configured(snapshot);
    parseAllowedPrincipals(snapshot.ALLOWED_PRINCIPALS);
    if (typeof snapshot.MESSAGING_NAMESPACE !== "string" || !snapshot.MESSAGING_NAMESPACE
      || audienceShared(snapshot, "ACCESS_UI_AUD")) throw new AccessUnavailable();
    return snapshot;
  }

  async requireOwner(call: MessageRouteOwnerCall, expected: MessageRouteOwnerIdentity,
    operation: MessageRouteOwnerOperation): Promise<MessageRouteOwnerProof> {
    if (!call || !expected || !["read", "transfer", "operation_readback"].includes(operation)) throw new AccessDenied();
    const original = Object.freeze({ token: call.token, origin: call.origin, fetchSite: call.fetchSite, csrf: call.csrf });
    const identity = Object.freeze({ namespace: expected.namespace, principal: expected.principal, agent: expected.agent });
    if (!canonicalEmail(identity.principal) || identity.principal !== identity.principal.toLowerCase()) throw new AccessDenied();
    try { agentName(identity.agent); } catch { throw new AccessDenied(); }
    if (typeof original.token !== "string" || !original.token || new TextEncoder().encode(original.token).length > 16384)
      throw new AccessDenied();
    const policySnapshot = this.#policy();
    const verifiedAtSeconds = this.#ports.now();
    if (!Number.isSafeInteger(verifiedAtSeconds) || identity.namespace !== policySnapshot.MESSAGING_NAMESPACE)
      throw new AccessDenied();
    const verified = await verifyAdminAssertionWithExpiry(original.token, policySnapshot, this.#ports);
    if (verified.principal.principal !== identity.principal || !principalAllowed(policySnapshot, identity.principal))
      throw new AccessDenied();
    if (operation === "transfer") {
      if (typeof original.origin !== "string" || original.origin.length > 512
        || typeof original.fetchSite !== "string" || original.fetchSite.length > 32
        || typeof original.csrf !== "string" || original.csrf.length > 128) throw new AccessDenied();
      await verifyAdminMutation(original.token,
        { origin: original.origin, fetchSite: original.fetchSite, csrf: original.csrf }, policySnapshot);
    }
    const proof = Object.freeze({ identity, operation, verifiedAtSeconds,
      verifiedExpiresAtSeconds: verified.expiresAtSeconds, policySnapshot });
    this.#proofs.add(proof);
    this.assertCurrent(proof);
    return proof;
  }

  /** Invoke synchronously after the final await, before commit or historical-result return. */
  assertCurrent(proof: MessageRouteOwnerProof): void {
    if (!this.#proofs.has(proof)) throw new AccessDenied();
    const now = this.#ports.now();
    if (!Number.isSafeInteger(now) || now < proof.verifiedAtSeconds || now >= proof.verifiedExpiresAtSeconds)
      throw new AccessDenied();
    const current = this.#policy();
    if (!principalAllowed(current, proof.identity.principal)
      || Object.keys(current).some(key => current[key as keyof MessageRouteOwnerEnvironment]
        !== proof.policySnapshot[key as keyof MessageRouteOwnerEnvironment])) throw new AccessDenied();
  }
}
