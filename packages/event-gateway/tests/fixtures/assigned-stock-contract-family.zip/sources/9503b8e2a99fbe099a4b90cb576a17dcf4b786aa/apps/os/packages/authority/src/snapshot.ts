// One read of an input, as plain data (R4 plan 6.7): the verifiers take values from callers, bundles and other Workers, and a getter, a proxy or a
// mutable object answers differently the second time it is asked. Everything here is read exactly once; the checks and the copies that follow see that
// one value. Pure TypeScript: no Worker types, no I/O.

const MAX_DEPTH = 12;
const MAX_NODES = 20_000;

/**
 * A deep copy of `value` as plain data, or null when it is not any. Only own enumerable data properties of Object.prototype / null-prototype objects and
 * of plain arrays are taken: an accessor, a symbol key, a non-enumerable property, a hole, a function, a bigint, an exotic prototype, a cycle or an oversized
 * value refuses the whole thing. Strings, numbers (NaN and infinities included, for the checks to judge), booleans, null and undefined are kept as they are.
 * `dropSymbols` leaves symbol-keyed members out instead of refusing them (a service result carries its own Symbol.dispose). The result is `{ value }` so that a null or undefined input is distinguishable from a refusal.
 */
export function snapshot(value: unknown, options: { dropSymbols?: boolean } = {}): { value: unknown } | null {
  let nodes = 0;
  const refused = Symbol("refused");
  const walk = (v: unknown, depth: number): unknown => {
    if (v === null || v === undefined || typeof v === "string" || typeof v === "boolean" || typeof v === "number") return v;
    if (typeof v !== "object" || depth > MAX_DEPTH || ++nodes > MAX_NODES) return refused;
    const array = Array.isArray(v);
    const prototype = Object.getPrototypeOf(v);
    if (array ? prototype !== Array.prototype : prototype !== Object.prototype && prototype !== null) return refused;
    const keys = Reflect.ownKeys(v);
    if (array && keys.length !== (v as unknown[]).length + 1) return refused; // the elements and "length": no hole, no extra property
    const entries: [string, unknown][] = [];
    for (const key of keys) {
      if (typeof key !== "string") {
        if (options.dropSymbols) continue; // an RPC result's own Symbol.dispose: no string-keyed read can see a symbol, so it is left behind, as the contract parsers always did
        return refused;
      }
      if (key === "length" && array) continue;
      const descriptor = Object.getOwnPropertyDescriptor(v, key)!;
      if (!descriptor.enumerable || !("value" in descriptor)) return refused;
      const entry = walk(descriptor.value, depth + 1);
      if (entry === refused) return refused;
      entries.push([key, entry]);
    }
    return array ? entries.map(([, entry]) => entry) : Object.fromEntries(entries);
  };
  const copy = walk(value, 0);
  return copy === refused ? null : { value: copy };
}
