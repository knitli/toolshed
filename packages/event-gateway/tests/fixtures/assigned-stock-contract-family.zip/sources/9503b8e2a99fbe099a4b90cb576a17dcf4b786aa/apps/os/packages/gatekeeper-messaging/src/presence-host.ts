// The Mailbox's human-presence methods, as functions over a small host (R4 P5a-2): parse what arrived (plain data, read once), read the configuration, run the
// module that holds the rule, and queue the push of any notice the change wrote. Mailbox keeps thin delegating methods (mailbox.ts is a hot file) and this
// is where its arguments are treated as the untrusted values they are.

import { B64U_128, MAX_INVENTORY_AGENTS, MAX_TERM_CHARS, MAX_TERMS } from "authority/src/act.ts";
import { isActInteger, isThumbprint, matches, MAX_AGENT_KEYS, plain } from "authority/src/contract-kit.ts";
import { parseAssertionResponse } from "authority/src/contracts.ts";
import type { BeginRegistrationResultV1, FinishLivenessResultV1, FinishRegistrationResultV1, LivenessResultV1 } from "authority/src/contracts.ts";
import { snapshot } from "authority/src/snapshot.ts";
import * as acts from "./acts.ts";
import { ENROLL_REFUSED } from "./auth.ts";
import { appendLog } from "./authority-log.ts";
import type { CredentialsView, CredentialView, EnforcementView, NoticeResultView, NoticesView } from "./admin-types.ts";
import { activeRows, isStaleWindowRoot, markRevoked, readRows, statusOf } from "./credentials.ts";
import * as enforcement_ from "./enforcement.ts";
import { fail } from "./model.ts";
import { flushNotices, linkOrigin, markUnsent, nextRetry, noticeChannel, noticeConfig, noticeRowById, noticeRows, queueNotice, revokedNotice, type NotifyVars } from "./notify.ts";
import { CREDENTIAL_VIEW } from "./credential-limits.ts";
import { presenceConfig, presenceVarsOf, type PresenceConfig, type PresenceVars } from "./presence.ts";
import * as liveness_ from "./liveness.ts";
import * as register from "./register.ts";
import { isPreset } from "./scopes.ts";
import type { OrderDraft } from "./order-acts.ts";
import type { AuthorityVars } from "./presence.ts";
import { parseRegistrationResponse } from "./registration.ts";
import { gateOf, type Gate } from "./stepup.ts";

export type PresenceHost = acts.Host & {
  principal: string;
  /** Whether ALLOWED_PRINCIPALS admits this Mailbox's owner now: nothing here works for anyone else. */
  admitted: boolean;
  /** The Worker's own deployed env: the one place the trust root (pins, floors, windows, flags) is read from. No caller supplies it. */
  env: NotifyVars & PresenceVars & AuthorityVars;
  /** Work to finish after the reply (a push): the Mailbox's waitUntil. */
  after(work: Promise<unknown>): void;
  /** Asks the Mailbox alarm to run at `at` unless it is already set sooner (the alarm also drains events). */
  schedule(at: number): Promise<void>;
  /** Drops an agent's wake hook when a signed act moves its workspace binding (the Mailbox's kv, in the same transaction). */
  forgetWake(agent: string): void;
  /** ENROLL_PRINCIPALS, from the Mailbox's own env. */
  enrollAllowed(principal: string): boolean;
};

const MAX_SECRET = 256;
const iso = (ms: number | null): string | null => (ms === null ? null : new Date(ms).toISOString());

/** The presence configuration of this deployment, from the Mailbox's own env, or null (off, malformed, or an owner ALLOWED_PRINCIPALS does not admit). */
function configOf(h: PresenceHost): PresenceConfig | null {
  return h.admitted ? presenceConfig(presenceVarsOf(h.env)) : null;
}

/**
 * The step-up gate for a widening call (stepup.ts), made before the call's transaction: the pin digest is async. The gate reads the facts when asked, inside
 * the transaction, so it sees the same rows the change writes.
 */
export async function stepUp(h: PresenceHost): Promise<Gate> {
  const config = configOf(h);
  const digest = config ? await enforcement_.pinDigestOf(enforcement_.pinsFor(config, h.principal)) : "";
  // Presence is off only when no relying party is named. One that is named and does not parse is a broken deployment, and the gate fails closed (INV7).
  return gateOf(h.sql, { config, digest, principal: h.principal, broken: config === null && h.admitted && Boolean(h.env.PRESENCE_RP_ID) }, h.now);
}

/** A change queued a notice: push what waits, after the reply, and never let a push change the answer. */
export function pushAfter(h: PresenceHost): void {
  h.after(flush(h)); // with no channel this marks the new notice unsent, so it never waits for a wake that will not come
}

/** Sends what is due and, for any push that failed, asks the Mailbox alarm to come back when its backoff ends (the alarm calls this too). Never throws. */
export async function flush(h: PresenceHost): Promise<void> {
  try {
    const channel = noticeConfig(h.env);
    // With no working channel nothing is retried and no alarm is asked for (a failed row's retry time is long past and would re-fire it every 100 ms); what is still pending
    // becomes unsent, and stays so if a channel is turned on later.
    if (channel === null) {
      markUnsent(h.sql, noticeChannel(h.env) === "misconfigured" ? "misconfigured" : "off", h.now());
      return;
    }
    await flushNotices(h.sql, channel, h.now(), h.schedule);
    const next = nextRetry(h.sql);
    if (next !== null) await h.schedule(Math.max(h.now() + 100, next));
  } catch {
    // a push is best effort; the rows say what was not sent
  }
}

const actIdOf = (value: unknown): string | null => (matches(value, B64U_128) ? value : null);

export async function beginCredential(h: PresenceHost, intent: unknown, windowSecret: unknown): Promise<BeginRegistrationResultV1> {
  const config = configOf(h);
  if (intent !== "window" && intent !== "session") throw fail("invalid", "a registration begins as a window's or a session's");
  if (typeof windowSecret !== "string" || windowSecret.length > 256 || (intent === "window" && windowSecret === "")) throw fail("invalid", "a window registration begins with the window's secret");
  return config ? await register.begin(h, config, h.principal, intent, windowSecret) : { status: "unavailable" };
}

export async function registerCredential(h: PresenceHost, challengeId: unknown, response: unknown, windowSecret: unknown): Promise<FinishRegistrationResultV1> {
  const config = configOf(h);
  if (!config) return { status: "refused", reason: "unavailable" };
  const id = actIdOf(challengeId);
  const parsed = parseRegistrationResponse(response);
  if (id === null) return { status: "refused", reason: "not_found" };
  if (parsed === null) return { status: "refused", reason: "evidence_malformed" };
  if (typeof windowSecret !== "string" || windowSecret.length > MAX_SECRET) return { status: "refused", reason: "secret_wrong" };
  const done = await register.finish(h, config, h.principal, id, parsed, windowSecret);
  if (done.status === "registered") pushAfter(h);
  return done;
}

export async function openAct(h: PresenceHost, actId: unknown): Promise<acts.OpenResult> {
  const config = configOf(h);
  if (!config) return { status: "unavailable" };
  const id = actIdOf(actId);
  return id === null ? { status: "not_found" } : acts.open(h, config, h.principal, id);
}

export async function completeAct(h: PresenceHost, actId: unknown, response: unknown, second: unknown): Promise<acts.CompleteResult> {
  const config = configOf(h);
  if (!config) return { status: "refused", reason: "unavailable" };
  const id = actIdOf(actId);
  const evidence = parseAssertionResponse(response);
  // The new key's assertion is present only for an enrollment (`undefined` over RPC is absent, and so is null); anything else present must be one.
  const other = second === undefined || second === null ? null : parseAssertionResponse(second);
  if (id === null) return { status: "refused", reason: "not_found" };
  if (evidence === null || (other === null && second !== undefined && second !== null)) return { status: "refused", reason: "evidence_malformed" };
  const done = await acts.complete(h, config, h.principal, id, evidence, other);
  if (done.status === "applied") pushAfter(h);
  return done;
}

export async function liveness(h: PresenceHost): Promise<LivenessResultV1> {
  const config = configOf(h);
  return config ? liveness_.start(h, config, h.principal) : { status: "unavailable" };
}

export async function finishLiveness(h: PresenceHost, actId: unknown, response: unknown): Promise<FinishLivenessResultV1> {
  const config = configOf(h);
  if (!config) return { status: "refused", reason: "unavailable" };
  const id = actIdOf(actId);
  const evidence = parseAssertionResponse(response);
  if (id === null) return { status: "refused", reason: "not_found" };
  if (evidence === null) return { status: "refused", reason: "evidence_malformed" };
  const done = await liveness_.touch(h, config, h.principal, id, evidence);
  if (done.status === "complete") pushAfter(h);
  return done;
}

// --- the admin's side -----------------------------------------------------------------------------------------------

const FIELDS = ["kind", "credential", "parent", "returnTo", "enrollment", "code", "agent", "what", "ref", "op", "policy", "declaration", "include", "leave", "to", "mode", "expires", "types", "wake", "offer", "add", "remove", "preset", "taskType", "objective", "fields", "inputs", "deadlineSeconds", "scope", "limits"] as const;
const ENROLLMENT_ID = /^[a-z0-9]{13}$/;
const intOrAbsent = (v: unknown, max: number): boolean => v === undefined || (isActInteger(v) && v >= 0 && v <= max);
const invalidDraft = (): Error => fail("invalid", "an act is drafted from a kind and the references it names");

/** An act's draft from plain data: exactly the fields its kind takes, each of the shape its kind takes, read once. */
function draftInputOf(value: unknown): acts.DraftInput & { returnTo: string | null } {
  const once = snapshot(value, { dropSymbols: true });
  const base = once && plain(once.value, ["kind"], FIELDS.filter((f) => f !== "kind"));
  if (!base || (base.returnTo !== undefined && base.returnTo !== null && typeof base.returnTo !== "string")) throw invalidDraft();
  const returnTo = (base.returnTo ?? null) as string | null;
  const given = Object.keys(base).filter((key) => key !== "kind" && key !== "returnTo" && base[key] !== undefined).toSorted();
  const only = (...names: string[]): void => {
    if (given.join() !== names.toSorted().join()) throw invalidDraft();
  };
  switch (base.kind) {
    case "enroll-credential":
      only("credential", "parent");
      if (isThumbprint(base.credential) && isThumbprint(base.parent)) return { kind: "enroll-credential", credential: base.credential, parent: base.parent, returnTo };
      break;
    case "revoke-credential":
      only("credential");
      if (isThumbprint(base.credential)) return { kind: "revoke-credential", credential: base.credential, returnTo };
      break;
    case "agent-enroll":
      only("enrollment", "code");
      if (matches(base.enrollment, ENROLLMENT_ID) && typeof base.code === "string" && base.code.length <= 32) return { kind: "agent-enroll", enrollment: base.enrollment, code: base.code, returnTo };
      break;
    case "bind-existing":
      only("agent", "what", "ref");
      if (typeof base.agent === "string" && (base.what === "workspace" || base.what === "oauth" || base.what === "key") && typeof base.ref === "string" && base.ref.length <= 128)
        return { kind: "bind-existing", agent: base.agent, what: base.what, ref: base.ref, returnTo };
      break;
    case "activation":
      if (typeof base.agent !== "string") break;
      if (base.op === "unsuspend") {
        only("agent", "op");
        return { kind: "activation", agent: base.agent, op: "unsuspend", returnTo };
      }
      if (base.op === "set-policy") {
        only("agent", "op", "policy");
        return { kind: "activation", agent: base.agent, op: "set-policy", policy: base.policy, returnTo };
      }
      break;
    case "declare-task":
      only("agent", "declaration");
      if (typeof base.agent === "string") return { kind: "declare-task", agent: base.agent, declaration: base.declaration, returnTo };
      break;
    case "grant": {
      const kinds = (names: string[], optional: string[]) => given.every((k) => names.includes(k) || optional.includes(k)) && names.every((k) => given.includes(k));
      const expires = base.expires === undefined ? null : base.expires;
      const types = base.types === undefined ? [] : base.types;
      const typed = Array.isArray(types) && types.length <= 16 && types.every((t) => typeof t === "string" && t.length <= 64);
      if ((expires !== null && typeof expires !== "string") || !typed) break;
      if (base.op === "create" && kinds(["op", "agent", "to", "mode"], ["expires", "types", "wake"]) && typeof base.agent === "string" && typeof base.to === "string" && (base.mode === "once" || base.mode === "standing") && (base.wake === undefined || typeof base.wake === "boolean"))
        return { kind: "grant", op: "create", agent: base.agent, to: base.to, mode: base.mode, expires: expires as string | null, types: types as string[], wake: base.wake === true, returnTo };
      if (base.op === "accept" && kinds(["op", "offer"], ["expires", "types"]) && typeof base.offer === "string" && base.offer.length <= 64)
        return { kind: "grant", op: "accept", offer: base.offer, expires: expires as string | null, types: types as string[], returnTo };
      break;
    }
    case "agent-scope": {
      const texts = (v: unknown): v is string[] => Array.isArray(v) && v.length <= 32 && v.every((t) => typeof t === "string" && t.length <= 512);
      const add = base.add ?? [];
      const remove = base.remove ?? [];
      if (given.some((key) => !["agent", "add", "remove", "preset"].includes(key)) || typeof base.agent !== "string" || !texts(add) || !texts(remove)) break;
      if (base.preset === undefined || base.preset === null) return { kind: "agent-scope", agent: base.agent, add, remove, preset: null, returnTo };
      if (isPreset(base.preset)) return { kind: "agent-scope", agent: base.agent, add, remove, preset: base.preset, returnTo };
      break;
    }
    case "order": {
      // The words and references of an order (order-acts.ts composes the act); their own grammar is the act parser's, checked when the draft is composed.
      const names = ["to", "taskType", "objective", "fields", "inputs", "deadlineSeconds"];
      const limits = base.limits === undefined ? undefined : plain(base.limits, [], ["ttlHours", "maxDepth", "allowForward", "maxMessages"]);
      const scope = base.scope;
      if (!given.every((k) => names.includes(k) || k === "scope" || k === "limits") || !names.every((k) => given.includes(k))) break;
      if (typeof base.to !== "string" || typeof base.taskType !== "string" || base.taskType.length > 64 || typeof base.objective !== "string" || !Array.isArray(base.inputs) || !Number.isSafeInteger(base.deadlineSeconds)) break;
      const fields = plain(base.fields, [], Object.keys((base.fields as object) ?? {}));
      if (!fields || (scope !== undefined && !(Array.isArray(scope) && scope.length <= MAX_TERMS && scope.every((t) => typeof t === "string" && t.length <= MAX_TERM_CHARS)))) break;
      if (base.limits !== undefined && (!limits || !intOrAbsent(limits.ttlHours, 168) || limits.ttlHours === 0 || !intOrAbsent(limits.maxDepth, 8) || !intOrAbsent(limits.maxMessages, 50) || (limits.allowForward !== undefined && typeof limits.allowForward !== "boolean"))) break;
      return {
        kind: "order", to: base.to, taskType: base.taskType, objective: base.objective, fields, inputs: base.inputs as unknown[], deadlineSeconds: base.deadlineSeconds as number,
        ...(scope !== undefined && { scope: scope as string[] }), ...(limits && { limits: limits as NonNullable<OrderDraft["limits"]> }), returnTo,
      };
    }
    case "key-inventory": {
      if (given.some((key) => key !== "include" && key !== "leave")) throw invalidDraft();
      // Each pick can name every key one inventory holds; the composer applies the agent limits.
      const lists = [base.include ?? [], base.leave ?? []];
      if (lists.every((list) => Array.isArray(list) && list.length <= MAX_INVENTORY_AGENTS * MAX_AGENT_KEYS && list.every((t) => isThumbprint(t)))) return { kind: "key-inventory", include: lists[0] as string[], leave: lists[1] as string[], returnTo };
      break;
    }
  }
  throw invalidDraft();
}

export async function draftAct(h: PresenceHost, input: unknown, returnOrigins: unknown): Promise<{ id: string; kind: string; expiresAt: string }> {
  const config = configOf(h);
  if (!config) throw fail("unavailable", "human presence is not configured");
  const draft = draftInputOf(input);
  // A computer is a key: the same list as for a code and a session confirmation (auth.ts enrollAllowed), asked early so the refusal is clear.
  if (draft.kind === "agent-enroll" && !h.enrollAllowed(h.principal)) throw fail("forbidden", ENROLL_REFUSED);
  const origins = snapshot(returnOrigins, { dropSymbols: true })?.value;
  if (!Array.isArray(origins) || origins.length > 4 || !origins.every((o) => typeof o === "string")) throw fail("invalid", "the return addresses are a short list of origins");
  const { returnTo, ...act } = draft;
  const made = await acts.draft(h, config, h.principal, act, returnTo, origins as string[]);
  return { id: made.id, kind: act.kind, expiresAt: new Date(made.expiresAt).toISOString() };
}

export function cancelAct(h: PresenceHost, actId: unknown): { cancelled: true } {
  const id = actIdOf(actId);
  if (id === null || !h.admitted || !acts.cancel(h, id)) throw fail("not_found", "no such act waiting to be signed");
  return { cancelled: true };
}

export async function credentials(h: PresenceHost): Promise<CredentialsView> {
  const config = configOf(h);
  if (!config) return { enabled: false, credentials: [], omittedRevoked: 0, omittedStale: 0, pinned: [], expectedAnchors: null, livenessCovered: false, windows: [] };
  const now = h.now();
  const rows = readRows(h.sql);
  const pins = enforcement_.pinsFor(config, h.principal);
  const list: CredentialView[] = rows.map((row) => ({
    thumbprint: row.thumbprint, label: row.label, status: statusOf(rows, row, config.pinned, h.principal, now),
    anchored: pins.includes(row.thumbprint), parent: row.parent_thumbprint, via: row.via === "window" || row.via === "session" ? row.via : null, windowUntil: iso(row.window_until ?? null), signed: row.signed === 1, registeredAt: new Date(row.registered_at).toISOString(), activeAt: iso(row.active_at), revokedAt: iso(row.revoked_at),
  }));
  // Bounded (credential-limits.ts): the rows that are not revoked, the revoked ones the pages need, and the newest few other revoked ones.
  const parents = new Set(list.filter((c) => c.status !== "revoked" && c.parent !== null).map((c) => c.parent));
  // A stale window root (the one predicate room is counted with too) has a bucket of its own: they pile up when recovery attempts are abandoned, and are the rows the owner revokes.
  const staleRows = new Set(rows.filter((row) => isStaleWindowRoot(row, config.pinned, h.principal, now, config.windows)).map((row) => row.thumbprint));
  const stale = list.filter((c) => c.status !== "revoked" && staleRows.has(c.thumbprint))
    .toSorted((a, b) => Date.parse(b.registeredAt) - Date.parse(a.registeredAt) || (a.thumbprint < b.thumbprint ? -1 : a.thumbprint > b.thumbprint ? 1 : 0)).slice(0, CREDENTIAL_VIEW.staleNewest);
  const keep = new Set(list.filter((c) => (c.status !== "revoked" && !staleRows.has(c.thumbprint)) || pins.includes(c.thumbprint) || parents.has(c.thumbprint)).map((c) => c.thumbprint));
  for (const c of stale) keep.add(c.thumbprint);
  const omittedStale = staleRows.size - stale.length;
  // Newest revoked first by when it was revoked, not when it was registered: a key registered long ago and revoked today is the one the owner just acted on. A key that is
  // revoked only because the key above it was has no time of its own in the view, so it takes its parent's (up the chain); ties break on the thumbprint, so the cut is the same every time.
  const byThumbprint = new Map(list.map((c) => [c.thumbprint, c]));
  const revokedAtOf = (c: CredentialView, depth = 0): number => {
    if (c.revokedAt !== null) return Date.parse(c.revokedAt);
    const parent = c.parent === null || depth >= 8 ? undefined : byThumbprint.get(c.parent);
    return parent ? revokedAtOf(parent, depth + 1) : 0;
  };
  const revokedOthers = list.filter((c) => c.status === "revoked" && !keep.has(c.thumbprint))
    .toSorted((a, b) => revokedAtOf(b) - revokedAtOf(a) || (a.thumbprint < b.thumbprint ? -1 : a.thumbprint > b.thumbprint ? 1 : 0));
  for (const c of revokedOthers.slice(0, CREDENTIAL_VIEW.revokedNewest)) keep.add(c.thumbprint);
  return {
    enabled: true, credentials: list.filter((c) => keep.has(c.thumbprint)), omittedRevoked: list.length - keep.size - omittedStale, omittedStale, pinned: pins, expectedAnchors: config.livenessAnchors[h.principal] ?? null,
    livenessCovered: enforcement_.livenessCovers(h.sql, await enforcement_.pinDigestOf(pins), { config, principal: h.principal, now }),
    windows: config.windows.filter((w) => w.principal === h.principal).map((w) => ({ principal: w.principal, until: new Date(w.until).toISOString(), open: now < w.until })),
  };
}

export async function revokeCredential(h: PresenceHost, thumbprint: unknown): Promise<{ revoked: true; thumbprint: string }> {
  const config = configOf(h);
  if (!config) throw fail("unavailable", "human presence is not configured");
  if (!isThumbprint(thumbprint)) throw fail("invalid", "a key is named by its thumbprint");
  const digest = await enforcement_.pinDigestOf(enforcement_.pinsFor(config, h.principal));
  h.tx(() => {
    const now = h.now();
    const rows = readRows(h.sql);
    const target = rows.find((r) => r.thumbprint === thumbprint);
    if (!target) throw fail("not_found", "no such security key");
    const status = statusOf(rows, target, config.pinned, h.principal, now);
    if (status === "revoked") throw fail("conflict", "that key is already revoked");
    // The floor (AT-14): a signed-in session may revoke a signer only while two remain. Below that it takes another key's touch (a revoke-credential act); the
    // last key is never revoked this way, and recovery is a deploy-opened enroll window. A key that does not sign yet (registered, pending) is not a signer.
    if (status === "active" && activeRows(rows, config.pinned, h.principal, now, thumbprint).length < 2)
      throw fail("forbidden", "revocation_floor: this would leave fewer than two active keys; revoke it by signing a revoke-credential act with another key");
    markRevoked(h.sql, thumbprint, now);
    appendLog(h.sql, { kind: "credential.revoked", actor: h.principal, detail: { thumbprint, via: "session" } }, now);
    queueNotice(h.sql, revokedNotice(target, now, "session"), now);
    enforcement_.refreshLatches(h.sql, config, h.principal, now, digest);
  });
  pushAfter(h);
  return { revoked: true, thumbprint };
}

export async function enforcement(h: PresenceHost): Promise<EnforcementView> {
  const config = configOf(h);
  if (!config) return { enabled: false, activeCredentials: 0, liveness: { covered: false, at: null, pinned: [], expected: null }, kinds: [] };
  const digest = await enforcement_.pinDigestOf(enforcement_.pinsFor(config, h.principal));
  // The GET writes no latch rows, except at a pin-set change, where currentEpoch records the epoch and stores latches for a rule that was met. Otherwise the latch is
  // taken at the write points (refreshLatches, before an act's effect and after a change that can raise the facts), and a rule met now but not stored yet is shown as
  // latched. No alarm: a pending key becoming active after its 24 hours writes nothing; the next write point or pin-set change latches first.
  const now = h.now();
  return enforcement_.view(h.sql, config, h.principal, now, digest);
}

/** One notice by its number (the page a pushed link opens), within the Mailbox's kept notices and not only the newest listed. */
export function notice(h: PresenceHost, id: unknown): NoticeResultView {
  if (typeof id !== "number" || !Number.isSafeInteger(id) || id < 1) throw fail("invalid", "a notice is named by its number");
  return { notice: noticeRowById(h.sql, id) };
}

export function notices(h: PresenceHost): NoticesView {
  const channel = noticeChannel(h.env);
  return { notices: noticeRows(h.sql), channel: typeof channel === "string" ? channel : "ntfy" };
}

// --- Flow B: an agent asks for an order (R4 P5b 5b-2c) --------------------------------------------------------------------------------------------------

/** What an agent may send to request_order, read once from plain data: the words of an order and an optional envelope. Their grammar is the act parser's, checked when the draft is composed. */
const badRequest = (): Error => fail("invalid", "request_order takes {to, taskType, objective, fields, deadlineSeconds}, and optionally inputs and a ceiling {scope, ttlHours, maxDepth, maxMessages, allowForward}");
function requestInputOf(value: unknown): OrderDraft {
  const bad = badRequest;
  const once = snapshot(value, { dropSymbols: true });
  const base = once && plain(once.value, ["to", "taskType", "objective", "deadlineSeconds"], ["fields", "inputs", "ceiling"]);
  if (!base || typeof base.to !== "string" || typeof base.taskType !== "string" || base.taskType.length > 64 || typeof base.objective !== "string" || !Number.isSafeInteger(base.deadlineSeconds)) throw bad();
  const fields = base.fields === undefined ? {} : plain(base.fields, [], Object.keys((base.fields as object) ?? {}));
  const inputs = base.inputs === undefined ? [] : base.inputs;
  const ceiling = base.ceiling === undefined ? undefined : plain(base.ceiling, [], ["scope", "ttlHours", "maxDepth", "maxMessages", "allowForward"]);
  if (!fields || !Array.isArray(inputs) || (base.ceiling !== undefined && !ceiling)) throw bad();
  const scope = ceiling?.scope;
  if (scope !== undefined && !(Array.isArray(scope) && scope.length <= MAX_TERMS && scope.every((t) => typeof t === "string" && t.length <= MAX_TERM_CHARS))) throw bad();
  if (ceiling && (!intOrAbsent(ceiling.ttlHours, 168) || ceiling.ttlHours === 0 || !intOrAbsent(ceiling.maxDepth, 8) || !intOrAbsent(ceiling.maxMessages, 50) || (ceiling.allowForward !== undefined && typeof ceiling.allowForward !== "boolean"))) throw bad();
  const { ttlHours, maxDepth, maxMessages, allowForward } = ceiling ?? {};
  return {
    kind: "order", to: base.to, taskType: base.taskType, objective: base.objective, fields, inputs, deadlineSeconds: base.deadlineSeconds as number,
    ...(scope !== undefined && { scope: scope as string[] }),
    ...(ceiling && { limits: { ...(ttlHours !== undefined && { ttlHours }), ...(maxDepth !== undefined && { maxDepth }), ...(maxMessages !== undefined && { maxMessages }), ...(allowForward !== undefined && { allowForward }) } as NonNullable<OrderDraft["limits"]> }),
  };
}

/** An agent's request for an order. Inert: it returns the draft's id and where the person signs it, and nothing is signed, sent or spent. */
export async function requestOrder(h: PresenceHost, agent: string, jkt: string | null, input: unknown, stillBound?: () => void): Promise<{ draftId: string; reviewUrl: string | null; expiresAt: string; screening?: string[] }> {
  const config = configOf(h);
  if (!config) throw fail("unavailable", "human presence is not configured");
  const made = await acts.draftByAgent(h, config, h.principal, agent, jkt, requestInputOf(input), stillBound);
  pushAfter(h);
  const origin = linkOrigin(h.env.NOTIFY_LINK_ORIGIN);
  return { draftId: made.id, reviewUrl: origin === null ? null : `${origin}/orders`, expiresAt: new Date(made.expiresAt).toISOString(), ...(made.screening.length > 0 && { screening: made.screening }) };
}
