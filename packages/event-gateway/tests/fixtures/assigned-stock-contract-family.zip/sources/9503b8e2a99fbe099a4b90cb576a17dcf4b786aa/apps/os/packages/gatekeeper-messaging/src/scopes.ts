// Agent scope rows (R4 plan 5.5, 5.9, 9.5): the ceiling an agent has under its person, kept in that person's Mailbox beside the agent. A row
// is a Scope v1 term, and only two kinds exist: a `mem` read, propose or write on a segment (Memory resolves them through AuthorityMemory and
// ANDs them with the person's own ACL, so a row can only narrow), and the `msg.draft` right (which request_order will need, P5b). A row never
// grants anything on its own, and an agent with no row has no ceiling at Memory (plan 5.6).
//
// Plain synchronous functions over the Mailbox's SQLite; the Mailbox is the only caller, and its callers authorize. A change that
// only narrows is the session's; one that adds a row needs a key once `agent-scope` is enforced (plan 5.11, P5c-b). setAgentScope asks the gate AFTER setScope (which
// calls planScope) has said what was added, inside the same transaction, and relies on the throw rolling the rows back. planScope is also what the `agent-scope` act asks at its draft.

import { canonicalJson } from "@knitli/openapi-mcp/runtime";
import { ceilingProblem, draftsOwnAgent, isTerm, printTerm, type Term } from "authority/src/scope.ts";
import { MAX_SCOPE_TERMS } from "./authority-contract.ts";
import { LIMITS, fail, type Address } from "./model.ts";
import { hasLiveGrantToOtherOwner } from "./registry.ts";

export const SCOPES_SCHEMA = `
CREATE TABLE IF NOT EXISTS agent_scopes (
  agent TEXT NOT NULL,
  term TEXT NOT NULL,
  preset TEXT,
  act_digest TEXT,
  created_at INTEGER NOT NULL,
  revoked_at INTEGER,
  PRIMARY KEY (agent, term)
);`;

/** A ceiling row's term, canonical JSON: the key of the row, so one term is one row however it was spelled. */
const keyOf = (term: Term): string => canonicalJson(term as unknown as Parameters<typeof canonicalJson>[0]);

export { ceilingProblem };

export type ScopeRow = { term: Term; text: string; preset: string | null; createdAt: string };
type Row = { term: string; preset: string | null; created_at: number };

/** Parses a stored term; a row that is no longer a valid term grants nothing (it is left out, not trusted). */
function termOf(json: string): Term | null {
  try {
    const parsed: unknown = JSON.parse(json);
    return isTerm(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

/** `agent`'s live rows, oldest first. */
export function liveRows(sql: SqlStorage, agent: string): ScopeRow[] {
  const rows = sql.exec<Row>("SELECT term, preset, created_at FROM agent_scopes WHERE agent = ? AND revoked_at IS NULL ORDER BY created_at, rowid", agent).toArray();
  return rows.flatMap((row) => {
    const term = termOf(row.term);
    return term === null ? [] : [{ term, text: printTerm(term), preset: row.preset, createdAt: new Date(row.created_at).toISOString() }];
  });
}

/**
 * Whether `agent` holds a live `msg.draft` right for an order of `type` to `to` (a wire address): the right names one exact agent and the types it covers,
 * and an agent with no such row may not ask for an order (default off, VS-13).
 */
export const mayDraft = (sql: SqlStorage, agent: string, to: string, type: string): boolean =>
  liveRows(sql, agent).some(({ term }) => term.svc === "msg" && term.verb === "draft" && term.res === to && term.where?.type?.includes(type) === true);

/** What Memory is told: the `mem` terms only. The `msg.draft` right is Messaging's own. */
export const memoryTerms = (sql: SqlStorage, agent: string): Term[] => liveRows(sql, agent).map((row) => row.term).filter((term) => term.svc === "mem");

/**
 * Whether `agent` has ever held a `mem` ceiling row, live or revoked (a revoked row stays in the table, plan 5.5). Memory's compatibility window for an agent
 * with no row (plan 13.5) is for one that was never given any: an agent whose last row was taken away is denied, so that removing a row refuses on the next call
 * (plan 5.6). The `msg.draft` right is not a memory row.
 */
export const everHeldMemoryRow = (sql: SqlStorage, agent: string): boolean =>
  sql.exec("SELECT 1 FROM agent_scopes WHERE agent = ? AND json_extract(term, '$.svc') = 'mem' LIMIT 1", agent).toArray().length > 0;

/** Whether a ceiling row reads a team segment: `team/` is what latches (a `user/` segment never does, plan 9.5 item 1). */
const readsTeam = (term: Term): boolean => term.svc === "mem" && term.res.startsWith("team/");

/**
 * Plan 9.5 item 4, both orders: an agent that reads a team segment may not also be allowed to send to another person, since that is the agent the taint
 * exists to stop, and the combination is refused where it would be made instead of caught later. Whether a segment is `non_sensitive` is Memory's to
 * know and Messaging cannot see it, so every read-capable row on a `team/` segment counts (a narrower rule needs Memory to answer, which is 4b's).
 * Narrowing is always allowed: only a change that ADDS a team read while a live cross-owner permission exists is refused here.
 */
function assertMayScope(sql: SqlStorage, agent: string, added: readonly Term[], principal: string, now: number): void {
  if (added.some(readsTeam) && hasLiveGrantToOtherOwner(sql, agent, principal, now))
    throw fail("restricted_taint", `${agent} holds a permission to send to another person's agent, so it cannot also read team memory: revoke that permission on the Let agents talk page, or scope ${agent} to your own segments`);
}

/**
 * The other order: a permission to send to another person is refused while the agent holds a live team read. Every creator of an `out` grant to another
 * person goes through Mailbox.grant (enrollment's starting permissions go to the owner's own agents only). A permission to the owner's own agents is
 * outside the rule.
 */
export function assertMayGrant(sql: SqlStorage, agent: string, to: Address, principal: string): void {
  if (to.principal !== principal.toLowerCase() && liveRows(sql, agent).some((row) => readsTeam(row.term)))
    throw fail("restricted_taint", `${agent} reads team memory, so it cannot also be given permission to send to another person's agent: remove its team memory scope rows first, or give it permission to send to your own agents only`);
}

export type ScopeChange = { added: Term[]; removed: Term[] };

/**
 * Everything that refuses a scope change, without making it: the agent exists, the rows are valid ceilings, an OS agent has no memory row, a new `msg.draft` names the
 * owner's own agent, and the taint rule (plan 9.5 item 4) allows what is added. setScope makes the change after it; the `agent-scope` act asks it at the draft too, so the
 * owner is refused before they sign and not after.
 */
export function planScope(sql: SqlStorage, agent: string, desired: readonly Term[], principal: string, now: number): { added: [string, Term][]; removed: [string, Term][] } {
  const kind = sql.exec<{ kind: string }>("SELECT kind FROM agents WHERE name = ?", agent).toArray()[0]?.kind;
  if (kind === undefined) throw fail("not_found", `no agent named ${agent}`);
  const wanted = new Map(desired.map((term) => [keyOf(term), term]));
  if (wanted.size > MAX_SCOPE_TERMS) throw fail("invalid", `an agent has at most ${MAX_SCOPE_TERMS} scope rows`);
  for (const term of wanted.values()) {
    const problem = ceilingProblem(term);
    if (problem !== null) throw fail("invalid", problem);
  }
  // An OS agent reads memory through its workspace's attach selectors and signs in with no key, so a memory row would never be read (plan 9.2 item 5, FC-11).
  if (kind === "os" && [...wanted.values()].some((term) => term.svc === "mem"))
    throw fail("invalid", `${agent} is an OS agent: its memory permission comes from its workspace's attach selectors, so it has no memory scope rows`);
  const live = new Map(liveRows(sql, agent).map((row) => [keyOf(row.term), row.term]));
  const added = [...wanted].filter(([key]) => !live.has(key));
  const removed = [...live].filter(([key]) => !wanted.has(key));
  // A new right to draft an order names one of this owner's own agents, since orders are same-owner (the rule the agent-scope and agent-enroll acts are held to).
  // Only a ROW BEING ADDED is held to it: a row stored before it existed is kept as it is, so an unrelated edit or a preset does not refuse a ceiling it holds.
  if (added.some(([, term]) => !draftsOwnAgent(principal.toLowerCase(), term))) throw fail("invalid", "msg.draft names one of your own agents: an order is same-owner at every hop");
  assertMayScope(sql, agent, added.map(([, term]) => term), principal, now);
  return { added, removed };
}

/**
 * Sets `agent`'s ceiling to exactly `desired`: rows not listed are revoked, new ones are added (an earlier revoked row comes back as a fresh
 * one). `tag` names the preset a new row came from (plan 5.9: rows are copied, never referenced), or null. Returns what changed.
 */
export function setScope(sql: SqlStorage, agent: string, desired: readonly Term[], principal: string, now: number, tag: string | null = null, actDigest: string | null = null): ScopeChange {
  const { added, removed } = planScope(sql, agent, desired, principal, now);
  for (const [key] of removed) sql.exec("UPDATE agent_scopes SET revoked_at = ? WHERE agent = ? AND term = ?", now, agent, key);
  for (const [key] of added)
    sql.exec(
      `INSERT INTO agent_scopes (agent, term, preset, act_digest, created_at, revoked_at) VALUES (?, ?, ?, ?, ?, NULL)
       ON CONFLICT (agent, term) DO UPDATE SET preset = excluded.preset, act_digest = excluded.act_digest, created_at = excluded.created_at, revoked_at = NULL`,
      agent, key, tag, actDigest, now,
    );
  return { added: added.map(([, term]) => term), removed: removed.map(([, term]) => term) };
}

// --- presets (plan 5.9) ---------------------------------------------------------------------------------

/**
 * Shipped in code and versioned, never user-defined. `n` is the version a row is tagged with, so a later change to a preset leaves the rows
 * an earlier application copied saying which version they came from. The Executor-client and Collaborator presets are cut (FC-17).
 */
export const PRESETS = {
  reader: { n: 1, terms: [{ svc: "mem", verb: "read", res: "team/*" }] },
  contributor: { n: 1, terms: [{ svc: "mem", verb: "read", res: "team/*" }, { svc: "mem", verb: "propose", res: "team/*" }] },
} as const satisfies Record<string, { n: number; terms: readonly Term[] }>;
export type PresetId = keyof typeof PRESETS;
export const PRESET_IDS = Object.keys(PRESETS) as PresetId[];
export const isPreset = (value: unknown): value is PresetId => typeof value === "string" && Object.hasOwn(PRESETS, value);
export const presetTag = (id: PresetId): string => `preset:${id}@${PRESETS[id].n}`;

export type PresetDiff = { preset: string; added: Term[]; alreadyHeld: Term[] };

/**
 * Copies `id`'s rows onto `agent`, keeping every row it already holds: the diff says which rows are new and which the agent had. It
 * never removes a row, so applying a preset cannot narrow what an owner set by hand.
 */
export function applyPreset(sql: SqlStorage, agent: string, id: PresetId, principal: string, now: number): PresetDiff {
  const rows = liveRows(sql, agent);
  const held = new Set(rows.map((row) => keyOf(row.term)));
  const preset: readonly Term[] = PRESETS[id].terms;
  // The rows already held stay as they were, with their own tags: set the union, and tag only what is new.
  const next = [...rows.map((row) => row.term), ...preset.filter((term) => !held.has(keyOf(term)))];
  setScope(sql, agent, next, principal, now, presetTag(id));
  return { preset: presetTag(id), added: preset.filter((term) => !held.has(keyOf(term))), alreadyHeld: preset.filter((term) => held.has(keyOf(term))) };
}

// --- the restricted-read taint (plan 9.5) -----------------------------------------------------------------

/** Whether `agent` read restricted memory in the last LIMITS.taintMs (the column `restricted_until` is the end of that time). */
export const isRestricted = (sql: SqlStorage, agent: string, now: number): boolean =>
  sql.exec("SELECT 1 FROM agents WHERE name = ? AND restricted_until IS NOT NULL AND restricted_until > ?", agent, now).toArray().length > 0;

/** Taints `agent` for LIMITS.taintMs from `now`, never shortening a taint it already has. False when there is no such agent. */
export function markRestricted(sql: SqlStorage, agent: string, now: number): boolean {
  return sql.exec(
    "UPDATE agents SET restricted_until = max(coalesce(restricted_until, 0), ?) WHERE name = ? RETURNING name",
    now + LIMITS.taintMs, agent,
  ).toArray().length > 0;
}

/** When `agent`'s taint ends (epoch ms), or null when it has none now. */
export const restrictedUntil = (sql: SqlStorage, agent: string, now: number): number | null =>
  sql.exec<{ until: number | null }>("SELECT restricted_until AS until FROM agents WHERE name = ? AND restricted_until IS NOT NULL AND restricted_until > ?", agent, now).toArray()[0]?.until ?? null;
