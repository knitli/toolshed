// The two acts that widen what an agent may reach without making it hold a key (R4 plan 6.2, 5.11, P5c-b): `grant` (a new permission to one of the owner's own
// agents, or the acceptance of another owner's offer) and `agent-scope` (rows added to or taken from an agent's ceiling). Shaped like core-acts.ts: the subject
// is composed FROM STORED STATE at the draft (the browser names references, never act bytes, INV4), and the effect, in the consuming transaction, first compares
// what was signed with what is stored now and refuses `keys_changed` if it moved (the touch is not spent). The effects call the store functions the session
// path calls, so a signed act and a session call leave the same rows. Synchronous, because the consuming step is.
//
// Not hosted: a permission to another owner's agent. Making one also files an offer in that owner's Mailbox, which is an await across Durable Objects, and the
// consuming step cannot wait. Cross-owner reach is not proven in R4 (plan 16.2), so under `enforce` such a grant is refused with that reason, never drafted.

import type { Act } from "authority/src/act.ts";
import { GRANT_MAX_MS } from "authority/src/contract-kit.ts";
import { printTerm, parseTerm, type Term } from "authority/src/scope.ts";
import { moved } from "./core-acts.ts";
import { Refuse } from "./credentials.ts";
import { addressOf, agentName, fail, taskTypesOf, wireOf } from "./model.ts";
import * as registry from "./registry.ts";
import * as scopes from "./scopes.ts";
import * as tasks from "./tasks.ts";

/** What a draft of each kind is made from: the owner's own words and references, never the bytes of an act. `expires` is an ISO time or null; `types` are task types (empty: any). */
export type GrantDraft =
  | { kind: "grant"; op: "create"; agent: string; to: string; mode: "once" | "standing"; expires: string | null; types: string[]; wake: boolean }
  | { kind: "grant"; op: "accept"; offer: string; expires: string | null; types: string[] }
  | { kind: "agent-scope"; agent: string; add: string[]; remove: string[]; preset: scopes.PresetId | null };
export const GRANT_KINDS = ["grant", "agent-scope"] as const;
export const isGrantDraft = (input: { kind: string }): input is GrantDraft => (GRANT_KINDS as readonly string[]).includes(input.kind);

type Subject = Record<string, unknown>;
const isoOf = (ms: number): string => new Date(ms).toISOString();
const sortedUnique = (xs: readonly string[]): string[] => [...new Set(xs)].toSorted();
const keyOf = (term: Term): string => printTerm(term);

function expiryOf(value: string | null, now: number): number | null {
  if (value === null) return null;
  const at = Date.parse(value);
  if (!Number.isFinite(at) || at <= now || at - now > GRANT_MAX_MS) throw fail("invalid", "an expiry must be an ISO 8601 time in the next 90 days");
  return at;
}
const typesOf = (types: readonly string[]): string[] => {
  const parsed = taskTypesOf(types.join(","));
  return parsed === null ? [] : sortedUnique(parsed);
};

/** Every listed type is one the receiving agent declares `inform`: a wake right never reaches consequential work (F5; consequential reach is an order's). */
function informOnly(sql: SqlStorage, agent: string, types: readonly string[]): boolean {
  return types.length > 0 && types.every((type) => tasks.declaredType(sql, agent, type)?.class === "inform");
}

// --- drafting: the subject, from stored state -------------------------------------------------------------------

export function grantSubjectOf(sql: SqlStorage, input: GrantDraft, principal: string, now: number): Subject {
  if (input.kind === "agent-scope") return scopeSubject(sql, input, principal, now);
  if (input.op === "accept") {
    const offer = sql.exec<{ agent: string; peer_principal: string; peer_agent: string; accepted_at: number | null; revoked_at: number | null; expires_at: number | null }>(
      "SELECT agent, peer_principal, peer_agent, accepted_at, revoked_at, expires_at FROM grants WHERE id = ? AND direction = 'in'", input.offer,
    ).toArray()[0];
    if (!offer || offer.accepted_at !== null || offer.revoked_at !== null || (offer.expires_at !== null && offer.expires_at <= now)) throw fail("conflict", "that is not an offer awaiting acceptance");
    const expiresAt = expiryOf(input.expires, now);
    return {
      direction: "in", from: wireOf({ principal: offer.peer_principal, agent: offer.peer_agent }), to: wireOf({ principal, agent: offer.agent }), mode: "standing",
      expiresAt: expiresAt === null ? null : isoOf(expiresAt), types: typesOf(input.types),
      offerId: input.offer, // the exact offer reviewed: a replacement the peer files before the touch is a different row, whatever its time
    };
  }
  const agent = agentName(input.agent);
  const to = addressOf(input.to);
  if (to.agent === null) throw fail("invalid", "a grant names an agent, as email/agent");
  if (to.principal !== principal.toLowerCase()) throw fail("unavailable", "a permission to another person's agent cannot be signed yet: only permissions between your own agents, and accepting an offer, can");
  if (!registry.hasAgent(sql, agent)) throw fail("not_found", `no agent named ${agent}`);
  if (!registry.hasAgent(sql, to.agent)) throw fail("not_found", `no agent named ${to.agent}`);
  const types = typesOf(input.types);
  if (input.wake && !informOnly(sql, to.agent, types)) throw fail("invalid", `the right to wake needs named task types that ${to.agent} declares as inform; a consequential type is reached only by an order`);
  const expiresAt = expiryOf(input.expires, now);
  scopes.assertMayGrant(sql, agent, to, principal);
  return {
    direction: "out", from: wireOf({ principal, agent }), to: wireOf(to), mode: input.mode, expiresAt: expiresAt === null ? null : isoOf(expiresAt), types,
    ...(input.wake && { wake: true }),
  };
}

const termsOf = (texts: readonly string[], what: string): Term[] =>
  texts.map((text) => {
    const term = parseTerm(text);
    if (term === null) throw fail("invalid", `${what} has a row that is not a scope term`);
    return term;
  });

function scopeSubject(sql: SqlStorage, input: Extract<GrantDraft, { kind: "agent-scope" }>, principal: string, now: number): Subject {
  const agent = agentName(input.agent);
  if (!registry.hasAgent(sql, agent)) throw fail("not_found", `no agent named ${agent}`);
  const held = new Set(scopes.liveRows(sql, agent).map((row) => row.text));
  const preset = input.preset === null ? null : scopes.PRESETS[input.preset];
  const wanted = preset === null ? termsOf(input.add, "add") : preset.terms.filter((term) => !held.has(printTerm(term)));
  if (preset !== null && input.add.length > 0) throw fail("invalid", "a preset adds its own rows: name either a preset or rows to add");
  const add = wanted.filter((term, i) => !held.has(printTerm(term)) && wanted.findIndex((other) => printTerm(other) === printTerm(term)) === i);
  const remove = termsOf(input.remove, "remove");
  if (remove.some((term) => !held.has(printTerm(term)))) throw fail("invalid", "remove names a row the agent does not hold");
  if (add.length === 0 && remove.length === 0) throw fail("invalid", "that changes nothing");
  // What the effect's setScope would refuse (a bad ceiling, an OS agent's memory row, a msg.draft to someone else's agent, the taint rule) is refused here, before the touch.
  const gone = new Set(remove.map(printTerm));
  scopes.planScope(sql, agent, [...scopes.liveRows(sql, agent).map((row) => row.term).filter((term) => !gone.has(printTerm(term))), ...add], principal, now);
  return { agent, add, remove, preset: input.preset === null ? null : { id: input.preset, n: scopes.PRESETS[input.preset].n } };
}

// --- the effects, in the consuming transaction ------------------------------------------------------------------

export type GrantHost = { sql: SqlStorage; now: number; act: Act; digest: string };

function grantEffect(h: GrantHost): void {
  const s = h.act.subject as { direction: "in" | "out"; from: string; to: string; mode: "once" | "standing"; expiresAt: string | null; types: string[]; wake?: true; offerId?: string };
  const principal = h.act.principal.toLowerCase();
  // The expiry outlives the act's window (authority crossChecks), so it is still ahead when applied.
  const expiresAt = s.expiresAt === null ? null : Date.parse(s.expiresAt);
  moved(() => {
    if (s.direction === "in") {
      const from = addressOf(s.from, "from");
      const to = addressOf(s.to);
      // The offer it was drafted against, and no other: that row (by its id; a time is not unique), still open and unexpired. A withdrawn or lapsed offer, or a replacement
      // the peer filed before the touch (even on the same terms), is a different row and moves the act.
      const open = h.sql.exec<{ id: string }>(
        `SELECT id FROM grants WHERE direction = 'in' AND agent = ? AND peer_principal = ? AND peer_agent = ? AND id = ? AND revoked_at IS NULL AND accepted_at IS NULL
         AND (expires_at IS NULL OR expires_at > ?) LIMIT 1`, to.agent!, from.principal, from.agent!, s.offerId ?? "", h.now, // an acceptance without it (never drafted) matches no row
      ).toArray();
      if (open.length === 0) throw new Refuse("keys_changed");
      registry.acceptOffer(h.sql, open[0]!.id, expiresAt, s.types.length === 0 ? null : s.types, h.now);
      return;
    }
    const from = addressOf(s.from, "from");
    const to = addressOf(s.to);
    // Both agents are still there, and only the owner's own: a permission to another owner is never applied from here.
    if (to.principal !== principal || from.principal !== principal || !registry.hasAgent(h.sql, from.agent!) || !registry.hasAgent(h.sql, to.agent!)) throw new Refuse("keys_changed");
    if (s.wake === true && !informOnly(h.sql, to.agent!, s.types)) throw new Refuse("keys_changed"); // a declaration moved since the draft
    scopes.assertMayGrant(h.sql, from.agent!, to, principal);
    registry.createGrant(h.sql, { agent: from.agent!, to, mode: s.mode, expiresAt, taskTypes: s.types.length === 0 ? null : s.types, wake: s.wake === true }, h.now);
  });
}

function scopeEffect(h: GrantHost): void {
  const s = h.act.subject as { agent: string; add: Term[]; remove: Term[]; preset?: { id: string; n: number } | null };
  moved(() => {
    const live = scopes.liveRows(h.sql, s.agent);
    const held = new Set(live.map((row) => row.text));
    // What was signed is what is stored: every row to remove is still held, and none to add already is (a row added or taken by hand since moves the act).
    if (s.remove.some((term) => !held.has(keyOf(term))) || s.add.some((term) => held.has(keyOf(term)))) throw new Refuse("keys_changed");
    const preset = s.preset ?? null;
    if (preset !== null && (!scopes.isPreset(preset.id) || scopes.PRESETS[preset.id].n !== preset.n)) throw new Refuse("keys_changed");
    // The rows the preset left out of `add` were held when it was drafted, and the signed text says the preset's other rows are already there: they still are.
    if (preset !== null) {
      const adding = new Set(s.add.map(keyOf));
      if (scopes.PRESETS[preset.id as scopes.PresetId].terms.some((term) => !adding.has(keyOf(term)) && !held.has(keyOf(term)))) throw new Refuse("keys_changed");
    }
    const gone = new Set(s.remove.map(keyOf));
    scopes.setScope(h.sql, s.agent, [...live.map((row) => row.term).filter((term) => !gone.has(keyOf(term))), ...s.add], h.act.principal, h.now, preset === null ? null : scopes.presetTag(preset.id as scopes.PresetId), h.digest);
  });
}

/** Applies a grant or scope act, or throws. A kind that is not one of the two is the caller's to refuse. */
export function applyGrantAct(h: GrantHost): void {
  switch (h.act.kind) {
    case "grant":
      return grantEffect(h);
    case "agent-scope":
      return scopeEffect(h);
    default:
      throw new Refuse("act_malformed");
  }
}
