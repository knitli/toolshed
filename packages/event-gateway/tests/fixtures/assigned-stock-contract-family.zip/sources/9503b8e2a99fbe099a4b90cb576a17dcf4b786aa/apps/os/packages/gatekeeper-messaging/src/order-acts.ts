// The `order` act (R4 plan 6.6, 5.8): a person's hardware-signed envelope over one root message to one of their own agents. Shaped like core-acts.ts and
// grant-acts.ts: the subject is composed FROM STORED STATE at the draft (the receiver's declaration, a fresh root id, the root's subject derived from the
// type; the browser names references and words, never act bytes, INV4), and the effect re-checks what it depends on in the consuming transaction.
//
// One difference: the root receipt is signed by the broker's key, which is async, and the consuming step is synchronous. So the root is built and signed
// after the proof verifies and before the transaction (prepareRoot, the shape issue() has, F03), and the transaction files it: the order row, the
// person's outbox row (no agent) and the recipient's inbox row, all or nothing. A refusal there rolls the consumption back, so the touch is not spent (VS-23).

import { orderDraftProblem, orderRootBody, scopeDigest, type Act, type OrderLimits } from "authority/src/act.ts";
import { canonicalJson } from "authority/src/canonical.ts";
import { attenuates, parseTerm, printTerm, type Term } from "authority/src/scope.ts";
import { describeScreen, screen } from "authority/src/text.ts";
import type { Assurance } from "authority/src/act.ts";
import type { TaskDeclaration } from "authority/src/task.ts";
import { Refuse } from "./credentials.ts";
import { LIMITS, NO_FLAGS, addressOf, codeOf, fail, messageBytes, wireOf, type Stored } from "./model.ts";
import * as orders from "./orders.ts";
import { receiptPayload, signReceipt, type KeyRing, type OrderClaim } from "./receipts.ts";
import * as registry from "./registry.ts";
import * as scopes from "./scopes.ts";
import * as tasks from "./tasks.ts";

/** A person's order, from words and references: the agent, the type it declares, the objective and fields of the root, and the envelope. Omitted limits are the declaration's defaults. */
export type OrderDraft = {
  kind: "order"; to: string; taskType: string; objective: string; fields: Record<string, unknown>; inputs: unknown[]; deadlineSeconds: number;
  scope?: string[]; limits?: { ttlHours?: number; maxDepth?: number; allowForward?: boolean; maxMessages?: number };
};
export const isOrderDraft = (input: { kind: string }): input is OrderDraft => input.kind === "order";

/** What a draft stores beside its subject: the act's terms, and the limits from which the expiry is set when the act is opened (an expiry fixed at the draft could end before the window it is signed in). */
export type OrderExtra = {
  scope: Term[]; ttlHours: number; maxDepth: number; allowForward: boolean; maxMessages: number; assurance: Assurance;
  /** An agent's draft: the thumbprint of the key its token was signed with (shown to the signer), or null for an agent that holds no key (a workspace, OAuth). */
  draftedJkt?: string | null;
};

const refused = (message: string): Error => fail("invalid", message);

/** The declaration an order of `type` to `agent` is drawn under, or a refusal: an order needs the receiver's own declaration of the type (plan 5.4). */
function declarationFor(sql: SqlStorage, agent: string, type: string) {
  const declared = tasks.declaredType(sql, agent, type);
  if (!declared) throw refused(`${agent} declares no task type ${type}: an order is drawn under the receiver's declaration`);
  return declared;
}

/** Forwarding is allowed by default exactly when the terms name a recipient to forward to and the depth leaves a hop for it. */
const forwardsBy = (scope: readonly Term[], maxDepth: number): boolean => maxDepth >= 1 && scope.some((t) => t.svc === "msg" && t.verb === "forward");

type Limits = { ttlHours: number; maxDepth: number; maxMessages: number; allowForward: boolean };
/** Whether terms and limits are at or inside a declaration's defaults: every term covered (attenuates, which also compares `where` and caps; an empty scope covers only an empty scope), no limit above, forwarding only if the defaults forward. */
function insideDefaults(decl: TaskDeclaration, scope: readonly Term[], limits: Limits): boolean {
  const d = decl.defaults;
  return attenuates(d.scope, scope) && limits.ttlHours <= d.ttlHours && limits.maxDepth <= d.maxDepth && limits.maxMessages <= d.maxMessages && (!limits.allowForward || forwardsBy(d.scope, d.maxDepth));
}

/**
 * Whether the agent that drafted `act` may still do it, on today's state: it exists and is not suspended, it still holds the msg.draft right for this receiver and type, and the order
 * is still inside the receiver's current defaults. A person's own act is always true. Asked when the draft is opened and again at the touch (a draft lives a day; the world moves).
 */
export function drafterStillMay(sql: SqlStorage, act: Act): boolean {
  if (act.draftedBy === "human") return true;
  const l = act.limits!;
  return draftStillMay(sql, act.draftedBy.agent, act.subject as DraftSubject, act.scope!, { ttlHours: (Date.parse(l.expiresAt) - Date.parse(act.issuedAt)) / 3600_000, maxDepth: l.maxDepth, maxMessages: l.maxMessages, allowForward: l.allowForward });
}

/** drafterStillMay on what a stored draft holds (its subject and envelope), with no act to compose: for the insert and the waiting list, which must agree with open(). */
type DraftSubject = { to: string; taskType: string; body: Parameters<typeof orderRootBody>[0] };
export function draftStillMay(sql: SqlStorage, drafterAddress: string, s: DraftSubject, scope: readonly Term[], limits: Limits): boolean {
  const drafter = addressOf(drafterAddress).agent;
  const to = addressOf(s.to);
  if (drafter === null || to.agent === null || !registry.hasAgent(sql, drafter) || registry.isSuspended(sql, drafter) || !scopes.mayDraft(sql, drafter, wireOf(to), s.taskType)) return false;
  // The receiver too: applyOrder() refuses a suspended or missing one, so a draft to it is not signable either (#957 round 4).
  if (!registry.hasAgent(sql, to.agent) || registry.isSuspended(sql, to.agent)) return false;
  const decl = tasks.declaredType(sql, to.agent, s.taskType);
  if (decl === null || !insideDefaults(decl, scope, limits)) return false;
  // And the fields still fit the declaration: applyOrder() refuses a body it no longer takes (keys_changed), so neither the list nor open() offers one (#957 round 5).
  const text = orderRootBody(s.body);
  return text !== null && tasks.bodyProblem(decl, text, true) === null;
}

/** The terms and limits an order is drawn with: what the draft names, else the declaration's defaults. */
function envelopeOf(decl: TaskDeclaration, input: OrderDraft): { scope: Term[]; limits: { ttlHours: number; maxDepth: number; maxMessages: number; allowForward: boolean } } {
  const scope = (input.scope ?? decl.defaults.scope.map(printTerm)).map((spelled) => {
    const term = parseTerm(spelled);
    if (term === null) throw refused(`${spelled} is not a term`);
    return term;
  });
  const maxDepth = input.limits?.maxDepth ?? decl.defaults.maxDepth;
  return { scope, limits: { ttlHours: input.limits?.ttlHours ?? decl.defaults.ttlHours, maxDepth, maxMessages: input.limits?.maxMessages ?? decl.defaults.maxMessages, allowForward: input.limits?.allowForward ?? forwardsBy(scope, maxDepth) } };
}

/**
 * The subject of an order and what the draft keeps beside it, from stored state. `floor` is the deployment's pinned floor for this kind and type, raised by
 * the receiver's declared minimum (authority floorFor).
 */
export function orderSubjectOf(sql: SqlStorage, input: OrderDraft, principal: string, floor: (type: string, declared: Assurance) => Assurance): { subject: Record<string, unknown>; extra: OrderExtra } {
  const to = addressOf(input.to);
  if (to.agent === null) throw refused("an order names an agent, as email/agent");
  if (to.principal !== principal.toLowerCase()) throw fail("unavailable", "an order is to one of your own agents: an order to another person's agent cannot be signed");
  if (!registry.hasAgent(sql, to.agent)) throw fail("not_found", `no agent named ${to.agent}`);
  if (registry.isSuspended(sql, to.agent)) throw fail("suspended", `${to.agent} is suspended`);
  const decl = declarationFor(sql, to.agent, input.taskType);
  const body = { objective: input.objective, fields: input.fields, inputs: input.inputs, deadlineSeconds: input.deadlineSeconds };
  const text = orderRootBody(body);
  if (text === null) throw refused("a field of an order cannot be called objective: the objective is the order's own");
  const problem = tasks.bodyProblem(decl, text, true);
  if (problem !== null) throw refused(tasks.bodyRefusal(to.agent, input.taskType, problem));
  const { scope, limits } = envelopeOf(decl, input);
  const { maxDepth, maxMessages } = limits;
  // An order its agent cannot answer is no order: the answer is a reply (one hop deeper, one message more), so it needs a depth of 1 and two messages.
  if (maxDepth < 1 || maxMessages < 2) throw refused("an order needs a depth of at least 1 and at least 2 messages, so its agent can answer it");
  const extra: OrderExtra = { scope, ttlHours: limits.ttlHours, maxDepth, maxMessages, allowForward: limits.allowForward, assurance: floor(input.taskType, decl.minAssurance) };
  const subject = { rootMessageId: crypto.randomUUID(), to: wireOf(to), taskType: input.taskType, subject: `Order: ${input.taskType}`, body };
  return { subject, extra };
}

/** The limits an opened order carries: the stored ones, with the expiry `ttlHours` after the act's own issue. */
export const limitsAt = (extra: OrderExtra, issuedMs: number): OrderLimits => ({
  expiresAt: new Date(issuedMs + extra.ttlHours * 3600_000).toISOString().replace(".000Z", "Z"), maxDepth: extra.maxDepth, allowForward: extra.allowForward, maxMessages: extra.maxMessages,
});

/** The receiver's declared minimum assurance for this order's type, for the verifier (it may raise the pinned floor, never lower it). Null when the declaration is gone. */
export function declaredMinAssurance(sql: SqlStorage, act: Act): Assurance | null {
  const s = act.subject as { to: string; taskType: string };
  const agent = addressOf(s.to).agent;
  return agent === null ? null : (tasks.declaredType(sql, agent, s.taskType)?.minAssurance ?? null);
}

/** The root as signed: the message, its v3 receipt and the order claim every later hop repeats. Built before the consuming transaction. */
export type PreparedRoot = { stored: Stored; claim: OrderClaim };

/** Builds and signs an order's root (plan 6.6, 6.8). `credential` is the thumbprint the proof verified; `now` is when it is signed, after the proof's awaits. */
export async function prepareRoot(keys: Pick<KeyRing, "kid" | "signer">, act: Act, digest: string, credential: string, now: number): Promise<PreparedRoot> {
  const s = act.subject as { rootMessageId: string; to: string; taskType: string; subject: string; body: Parameters<typeof orderRootBody>[0] };
  const limits = act.limits!;
  const message = {
    id: s.rootMessageId, threadId: s.rootMessageId, kind: "request" as const, parents: [], sender: { principal: act.principal, client: "order", cred: credential },
    recipient: s.to, subject: s.subject, body: orderRootBody(s.body)!, taskType: s.taskType, issuedAt: new Date(now).toISOString(),
    // The answer is due at the signed deadline or when the order ends, whichever is first (AT-16).
    expiresAt: new Date(Math.min(now + s.body.deadlineSeconds * 1000, Date.parse(limits.expiresAt))).toISOString(), depth: 0,
  };
  if (messageBytes(message) > LIMITS.message) throw new Refuse("order_refused");
  const claim: OrderClaim = {
    actDigest: digest, tier: "anchored", cred: credential, draftedBy: act.draftedBy === "human" ? "human" : `agent:${act.draftedBy.agent}`,
    expiresAt: limits.expiresAt, scopeDigest: await scopeDigest(act.scope!), root: true,
  };
  const receipt = await signReceipt(keys, await receiptPayload(message, null, "human-ordered", claim));
  return { stored: { ...message, audience: [act.principal], flags: NO_FLAGS, applied: "human-ordered", receipt, chain: [], requestDigest: digest }, claim };
}

/**
 * The effect, in the consuming transaction: what the root depends on is read again (the agent, its suspension, its declaration and the root's fit to it,
 * the inbox caps), then the order row, the person's outbox row and the recipient's inbox row are written. A missing agent is `not_found`, a declaration
 * that changed since the draft `keys_changed`, and any other refusal `order_refused`; each rolls the consumption back.
 */
export function applyOrder(sql: SqlStorage, act: Act, digest: string, root: PreparedRoot, now: number, verifiedMin: Assurance): void {
  const s = act.subject as { to: string; taskType: string };
  const to = addressOf(s.to);
  const agent = to.agent;
  const message = root.stored;
  try {
    // Same-owner, again here (the act parser refuses another owner's agent): an order's root is filed only in its own person's Mailbox (plan 6.6).
    if (to.principal !== act.principal || agent === null) throw new Refuse("order_refused");
    if (!registry.hasAgent(sql, agent)) throw new Refuse("not_found");
    if (registry.isSuspended(sql, agent)) throw fail("suspended", `${agent} is suspended`);
    // An agent's draft is void once its agent is stopped, loses the right, or the receiver narrows its defaults: it was inert until now, and is not signed on stale authority.
    if (!drafterStillMay(sql, act)) throw new Refuse("order_refused");
    // A completion slow enough that the root's deadline passed while it was signed files nothing (the touch is not spent).
    if (Date.parse(message.expiresAt!) <= now) throw new Refuse("order_refused");
    const decl = tasks.declaredType(sql, agent, s.taskType);
    // The declaration the proof was verified against (its minimum assurance) must still be the live one: a floor raised during the awaits is not met.
    if (!decl || decl.minAssurance !== verifiedMin || tasks.bodyProblem(decl, message.body, true) !== null) throw new Refuse("keys_changed");
    if (orders.inboxFull(sql, now, agent)) throw fail("inbox_full", `${agent}'s inbox is full`);
    const limits = act.limits!;
    sql.exec(
      "INSERT INTO orders (digest, thread_id, agent, task_type, scope, max_depth, allow_forward, max_messages, expires_at, drafted_by, credential, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
      digest, message.id, agent, s.taskType, canonicalJson(act.scope! as never), limits.maxDepth, limits.allowForward ? 1 : 0, limits.maxMessages, Date.parse(limits.expiresAt), root.claim.draftedBy, root.claim.cred, now,
    );
    // The rows a send writes, through the one INSERT Mailbox #insert uses: the person's, with no agent, and the recipient's (root delivery is part of this transaction, plan 6.6).
    orders.insertMessage(sql, "out", message, s.to, "sent", now, null);
    orders.insertMessage(sql, "in", message, act.principal, "unread", now, agent);
  } catch (error) {
    if (error instanceof Refuse || codeOf(error) === undefined) throw error;
    throw new Refuse("order_refused");
  }
}

// ---- Flow B: an agent asks for an order (plan 6.4, 7.5, D18 B) ---------------------------------------------------------------------------------------

/** What an agent asks for: the words of an order and, optionally, an envelope inside the receiver's defaults. It names no act bytes and no subject (INV4). */
export type AgentOrderRequest = OrderDraft;

/** The draft's text as the person will be shown it and sign it: the screening of authority/src/text.ts, and what it did in words. */
function screenedText(input: OrderDraft): { input: OrderDraft; report: string[] } {
  const report: string[] = [];
  const clean = (what: string, text: string): string => {
    const out = screen(text);
    const said = describeScreen(out.report);
    if (said !== null) report.push(`${what}: ${said}`);
    // Joiners and selectors kept in bulk are a channel in text a person signs; an agent has no reason to write them.
    if (out.report.dense) throw fail("invalid", `${what} carries a run of joiners, direction marks or selectors; write it as plain text`);
    return out.text;
  };
  const fields = Object.fromEntries(Object.entries(input.fields).map(([name, value]) => [name, typeof value === "string" ? clean(`field ${name}`, value) : value]));
  return { input: { ...input, objective: clean("objective", input.objective), fields }, report };
}

/**
 * The subject of an order an AGENT asked for. Everything a person's draft is held to, plus: the agent holds the msg.draft right for this receiver and type
 * (`draft_not_allowed`, default off), the envelope it names is at or inside the receiver's declared defaults (`out_of_envelope`, never wider: only a person widens
 * by drawing the order themselves), the text is screened before it is stored (what is signed is what is shown), and authority's own draft check (orderDraftProblem,
 * the readers the act parser uses) passes on the resolved envelope.
 */
export function agentOrderSubjectOf(
  sql: SqlStorage, agent: string, asked: AgentOrderRequest, principal: string, jkt: string | null, floor: (type: string, declared: Assurance) => Assurance,
): { subject: Record<string, unknown>; extra: OrderExtra; screening: string[] } {
  const to = addressOf(asked.to);
  if (to.agent === null) throw refused("an order names an agent, as email/agent");
  if (to.principal !== principal.toLowerCase()) throw fail("unavailable", "an order is to one of your own agents: an order to another person's agent cannot be signed");
  if (!scopes.mayDraft(sql, agent, wireOf(to), asked.taskType))
    throw fail("draft_not_allowed", `${agent} may not draft an order for ${to.agent} of task type ${asked.taskType}: ask its owner for the msg.draft right on the agent's scope page`);
  // Inputs name memory segments and receipts. The grammar is checked, but not whether the AGENT may read them, so the person would sign as a confused deputy for a
  // segment the agent cannot read. Until that readability check exists (deferred, plan 5b-2 item 17), they come only from a person's own order.
  if (asked.inputs.length > 0) throw fail("invalid", "inputs are not taken from an agent's request yet: they need an order a person drafts on the Orders page");
  const { input, report } = screenedText(asked);
  const decl = declarationFor(sql, to.agent, input.taskType);
  const { scope, limits } = envelopeOf(decl, input);
  if (!insideDefaults(decl, scope, limits)) throw fail("out_of_envelope", `ceiling: an order an agent asks for stays inside what ${to.agent} declares for ${input.taskType} (its terms, ${decl.defaults.ttlHours} hours, ${decl.defaults.maxDepth} hops deep, ${decl.defaults.maxMessages} messages); draw a wider order yourself`);
  const problem = orderDraftProblem({ principal, to: wireOf(to), taskType: input.taskType, objective: input.objective, fields: input.fields, inputs: input.inputs, deadlineSeconds: input.deadlineSeconds, scope: scope.map(printTerm), limits });
  if (problem !== null) throw refused(problem);
  const made = orderSubjectOf(sql, { ...input, scope: scope.map(printTerm), limits }, principal, floor);
  return { subject: made.subject, extra: { ...made.extra, draftedJkt: jkt }, screening: report };
}
