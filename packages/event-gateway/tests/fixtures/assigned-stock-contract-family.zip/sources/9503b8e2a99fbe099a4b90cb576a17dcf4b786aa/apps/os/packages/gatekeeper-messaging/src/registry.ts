// One principal's agents and grants (spec "Identity", "Grants"), kept in that principal's Mailbox so a
// `once` grant is spent in the same transaction as the outbox row it authorizes. Plain synchronous
// functions over the Mailbox's SQLite; the Mailbox is the only caller, and its callers authorize.
// An agent's registered public keys (agent_keys) are stored only as x.

import { MAX_AGENT_KEYS, OAUTH_PROFILE } from "authority/src/contract-kit.ts";
import { agentName, OAUTH_LEASE_MS, suspended, type AgentCredential, type OAuthBinding, fail, noGrant, typeNotAccepted, typeNotGranted, wireOf, type Address } from "./model.ts";

export const REGISTRY_SCHEMA = `
CREATE TABLE IF NOT EXISTS agents (
  name TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('os', 'external')),
  workspace_id TEXT UNIQUE,
  key_hash TEXT UNIQUE,
  created_at INTEGER NOT NULL,
  suspended_at INTEGER
);
CREATE TABLE IF NOT EXISTS grants (
  id TEXT PRIMARY KEY,
  direction TEXT NOT NULL CHECK (direction IN ('out', 'in')),
  agent TEXT NOT NULL,
  peer_principal TEXT NOT NULL,
  peer_agent TEXT NOT NULL,
  mode TEXT NOT NULL CHECK (mode IN ('once', 'standing')),
  expires_at INTEGER,
  created_at INTEGER NOT NULL,
  accepted_at INTEGER,
  revoked_at INTEGER,
  used_at INTEGER,
  used_message TEXT,
  task_types TEXT
);
CREATE INDEX IF NOT EXISTS grants_by_created ON grants (created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS grants_by_pair ON grants (direction, agent, peer_principal, peer_agent);
CREATE TABLE IF NOT EXISTS agent_keys (thumbprint TEXT PRIMARY KEY, agent TEXT NOT NULL, x TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS agent_keys_by_agent ON agent_keys (agent);
CREATE TABLE IF NOT EXISTS oauth_bindings (
  profile TEXT PRIMARY KEY,
  agent TEXT NOT NULL,
  generation TEXT NOT NULL,
  lease_expires_at INTEGER NOT NULL
);`;

export type AgentKind = "os" | "external";
/**
 * `keys`: the public keys an external agent signs its tokens with, newest first. `suspendedAt`: when its
 * owner suspended it (#596), or null: a suspended agent sends, receives and reads nothing.
 */
export type Agent = { name: string; kind: AgentKind; workspaceId: string | null; keys: AgentKey[]; createdAt: string; suspendedAt: string | null };
/** `state`: `provisional` is a key no act has listed (keys.ts, INV14): it names the agent and authenticates nothing. */
export type AgentKey = { thumbprint: string; createdAt: string; state: "active" | "provisional" };
export type GrantMode = "once" | "standing";
/** `out`: this principal's `agent` may send to `peer`. `in`: this principal accepts `peer` sending to `agent`. */
export type Grant = {
  id: string;
  direction: "out" | "in";
  agent: string;
  peer: string;
  mode: GrantMode;
  expiresAt: string | null;
  createdAt: string;
  /** In only: null while the other owner's grant is offered and not yet accepted. */
  acceptedAt: string | null;
  revokedAt: string | null;
  usedAt: string | null;
  /** Null: any task type, or none (#597). Else the only types it covers, sorted. */
  taskTypes: string[] | null;
  /** Present only when true: a hardware-signed grant carrying the right to wake the receiving agent (F5). Only a grant act sets it. */
  wake?: true;
};

type AgentRow = { name: string; kind: AgentKind; workspace_id: string | null; created_at: number; suspended_at: number | null };
type GrantRow = {
  id: string; direction: "out" | "in"; agent: string; peer_principal: string; peer_agent: string; mode: GrantMode;
  expires_at: number | null; created_at: number; accepted_at: number | null; revoked_at: number | null; used_at: number | null; used_message: string | null;
  task_types: string | null;
  wake?: number;
};

const iso = (ms: number | null): string | null => (ms === null ? null : new Date(ms).toISOString());
const agentOf = (r: AgentRow, keys: AgentKey[] = []): Agent => ({
  name: r.name, kind: r.kind, workspaceId: r.workspace_id, keys, createdAt: iso(r.created_at)!, suspendedAt: iso(r.suspended_at),
});
const grantOf = (r: GrantRow): Grant => ({
  id: r.id, direction: r.direction, agent: r.agent, peer: wireOf({ principal: r.peer_principal, agent: r.peer_agent }), mode: r.mode,
  expiresAt: iso(r.expires_at), createdAt: iso(r.created_at)!, acceptedAt: iso(r.accepted_at), revokedAt: iso(r.revoked_at), usedAt: iso(r.used_at),
  taskTypes: r.task_types === null ? null : (JSON.parse(r.task_types) as string[]),
  ...(r.wake === 1 && { wake: true as const }),
});
const WORKSPACE = /^[A-Za-z0-9._-]{1,128}$/;
/** Unanswered offers one Mailbox holds from any one other person, across all its agents. */
export const PENDING_OFFERS_PER_PEER = 10;

function agentRow(sql: SqlStorage, name: string): AgentRow {
  const found = sql.exec<AgentRow>("SELECT * FROM agents WHERE name = ?", name).toArray()[0];
  if (!found) throw fail("not_found", `no agent named ${name}`);
  return found;
}

function grantRow(sql: SqlStorage, id: string): GrantRow {
  const found = sql.exec<GrantRow>("SELECT * FROM grants WHERE id = ?", id).toArray()[0];
  if (!found) throw fail("not_found", "no such grant");
  return found;
}

export function registerAgent(sql: SqlStorage, name: string, kind: AgentKind, now: number): Agent {
  if (kind !== "os" && kind !== "external") throw fail("invalid", 'an agent is "os" (a workspace) or "external" (a key)');
  if (sql.exec("SELECT 1 FROM agents WHERE name = ?", name).toArray().length) throw fail("conflict", `an agent named ${name} already exists`);
  // A new agent wakes only for an order (plan 8.2); the agents that existed before the policy did read `granted`, marked legacy (mailbox.ts migrate).
  sql.exec("INSERT INTO agents (name, kind, created_at, activation_mode, activation_legacy) VALUES (?, ?, ?, 'order-only', 0)", name, kind, now);
  return agentOf(agentRow(sql, name));
}

export function listAgents(sql: SqlStorage): Agent[] {
  const keys = new Map<string, AgentKey[]>();
  for (const k of sql.exec<{ agent: string; thumbprint: string; created_at: number; state: AgentKey["state"] }>("SELECT agent, thumbprint, created_at, state FROM agent_keys ORDER BY created_at DESC, rowid DESC"))
    keys.set(k.agent, [...(keys.get(k.agent) ?? []), { thumbprint: k.thumbprint, createdAt: iso(k.created_at)!, state: k.state }]);
  return sql.exec<AgentRow>("SELECT * FROM agents ORDER BY name").toArray().map((r) => agentOf(r, keys.get(r.name)));
}
/** Admin-only page; canonical listAgents remains unpaged for existing callers. */
export function agentPage(sql: SqlStorage, cursor?: string | null): { agents: Agent[]; agentNextCursor: string | null; agentLimit: 100 } {
  const after = cursor == null ? null : agentName(cursor);
  const rows = sql.exec<AgentRow>(`SELECT * FROM agents ${after === null ? "" : "WHERE name > ?"} ORDER BY name LIMIT 101`, ...(after === null ? [] : [after])).toArray();
  const more = rows.length > 100;
  if (more) rows.pop();
  const agents = rows.map((row) => agentOf(row, keysOf(sql, row.name)));
  return { agents, agentNextCursor: more ? rows.at(-1)!.name : null, agentLimit: 100 };
}

// addAgentKey enforces MAX_AGENT_KEYS, including rotations; read only that many.
const keysOf = (sql: SqlStorage, name: string): AgentKey[] =>
  sql.exec<{ thumbprint: string; created_at: number; state: AgentKey["state"] }>(
    "SELECT thumbprint, created_at, state FROM agent_keys WHERE agent = ? ORDER BY created_at DESC, rowid DESC LIMIT ?", name, MAX_AGENT_KEYS,
  ).toArray().map((key) => ({ thumbprint: key.thumbprint, createdAt: iso(key.created_at)!, state: key.state }));

/** The named agents, each with its keys or null if there is none by that name, in the order asked: a direct lookup, not a walk of the pages. */
export function agentsNamed(sql: SqlStorage, names: string[]): (Agent | null)[] {
  return names.map((name) => {
    const row = sql.exec<AgentRow>("SELECT * FROM agents WHERE name = ?", name).toArray()[0];
    return row ? agentOf(row, keysOf(sql, name)) : null;
  });
}

export const hasAgent = (sql: SqlStorage, name: string): boolean => sql.exec("SELECT 1 FROM agents WHERE name = ?", name).toArray().length > 0;

/** A workspace binds to at most one agent, and an agent to one workspace: binding again moves it. */
export function bindWorkspace(sql: SqlStorage, name: string, workspaceId: string): void {
  if (agentRow(sql, name).kind !== "os") throw fail("invalid", "only an os agent binds to a workspace");
  if (!WORKSPACE.test(workspaceId)) throw fail("invalid", "a workspace id is what whoami() returns in that workspace");
  const other = sql.exec<{ name: string }>("SELECT name FROM agents WHERE workspace_id = ? AND name != ?", workspaceId, name).toArray()[0];
  if (other) throw fail("conflict", `that workspace is already bound to ${other.name}`);
  sql.exec("UPDATE agents SET workspace_id = ? WHERE name = ?", workspaceId, name);
}

export function unbind(sql: SqlStorage, name: string): void {
  agentRow(sql, name);
  sql.exec("UPDATE agents SET workspace_id = NULL WHERE name = ?", name);
}

/**
 * Suspends `name` (`at`: now) or unsuspends it (null), as its owner chose (#596). Suspending again keeps
 * the first time. Its binding, keys, grants and wake stay: unsuspending restores them all.
 */
export function setSuspended(sql: SqlStorage, name: string, at: number | null): void {
  agentRow(sql, name);
  if (at === null) sql.exec("UPDATE agents SET suspended_at = NULL WHERE name = ?", name);
  else sql.exec("UPDATE agents SET suspended_at = ? WHERE name = ? AND suspended_at IS NULL", at, name);
}

export const isSuspended = (sql: SqlStorage, name: string): boolean =>
  sql.exec("SELECT 1 FROM agents WHERE name = ? AND suspended_at IS NOT NULL", name).toArray().length > 0;

export const agentForWorkspace = (sql: SqlStorage, workspaceId: string): string | null =>
  sql.exec<{ name: string }>("SELECT name FROM agents WHERE workspace_id = ?", workspaceId).toArray()[0]?.name ?? null;

export { MAX_AGENT_KEYS }; // authority's: an act's key inventory is bounded by it

/** Registers an external agent's public key, validated and thumbprinted by the caller (agent-token.ts publicJwk). */
export function addAgentKey(sql: SqlStorage, name: string, x: string, thumbprint: string, now: number, state: "active" | "provisional" = "active"): void {
  if (agentRow(sql, name).kind !== "external") throw fail("invalid", "only an external agent holds a key");
  // Not saying whose: it may be another of this owner's agents', or the same key pasted twice.
  if (sql.exec("SELECT 1 FROM agent_keys WHERE thumbprint = ?", thumbprint).toArray().length) throw fail("conflict", "that key is already registered");
  if (sql.exec<{ n: number }>("SELECT count(*) AS n FROM agent_keys WHERE agent = ?", name).one().n >= MAX_AGENT_KEYS)
    throw fail("conflict", `an agent holds at most ${MAX_AGENT_KEYS} keys: remove one first`);
  sql.exec("INSERT INTO agent_keys (thumbprint, agent, x, created_at) VALUES (?, ?, ?, ?)", thumbprint, name, x, now);
  // Inserted active (the column's default) and then made inert, so the insert is the one the registry has always made (keys.ts: a key no act listed is provisional).
  if (state === "provisional") sql.exec("UPDATE agent_keys SET state = 'provisional' WHERE thumbprint = ?", thumbprint);
}

/**
 * Removes a key: tokens it signed are refused from the next lookup on, in-flight calls included.
 * Idempotent: no such key is not an error, and returns false so a caller need not report a removal.
 */
export function removeAgentKey(sql: SqlStorage, name: string, thumbprint: string): boolean {
  return sql.exec("DELETE FROM agent_keys WHERE agent = ? AND thumbprint = ? RETURNING thumbprint", name, thumbprint).toArray().length > 0;
}

/** The public key (x) `name` registered under `thumbprint`, or null. */
export const agentKey = (sql: SqlStorage, name: string, thumbprint: string): string | null =>
  sql.exec<{ x: string }>("SELECT x FROM agent_keys WHERE agent = ? AND thumbprint = ?", name, thumbprint).toArray()[0]?.x ?? null;

/** Whether `thumbprint` is a key no act has listed (keys.ts, INV14): it names an agent and authenticates nothing. */
export const isProvisional = (sql: SqlStorage, thumbprint: string): boolean =>
  sql.exec("SELECT 1 FROM agent_keys WHERE thumbprint = ? AND state = 'provisional'", thumbprint).toArray().length > 0;
/** The one refusal every door that reads a key gives for a provisional one. */
export const provisionalKey = (): Error => fail("key_provisional", "this computer's key is not activated yet: activate it with your security key on the owner's Security page");
export function assertActiveKey(sql: SqlStorage, thumbprint: string): void {
  if (isProvisional(sql, thumbprint)) throw provisionalKey();
}

/** A token caller must still be an active external agent holding this registered key: the last look of every door that verifies a token itself (Event, Memory). */
export function credentialActive(sql: SqlStorage, name: string, thumbprint: string): boolean {
  const row = sql.exec<{ kind: string; suspended_at: number | null }>(
    "SELECT kind, suspended_at FROM agents WHERE name = ?", name,
  ).toArray()[0];
  return row?.kind === "external" && row.suspended_at === null && agentKey(sql, name, thumbprint) !== null && !isProvisional(sql, thumbprint);
}

function profileName(profile: string): void {
  if (!OAUTH_PROFILE.test(profile)) throw fail("invalid", "an OAuth profile is 1-32 of lowercase a-z, 0-9 and hyphen");
}
export function oauthBinding(sql: SqlStorage, profile: string): OAuthBinding | null {
  profileName(profile);
  return sql.exec<OAuthBinding>("SELECT profile, agent, generation, lease_expires_at AS leaseExpiresAt FROM oauth_bindings WHERE profile = ?", profile).toArray()[0] ?? null;
}
export function oauthBindings(sql: SqlStorage): OAuthBinding[] {
  return sql.exec<OAuthBinding>("SELECT profile, agent, generation, lease_expires_at AS leaseExpiresAt FROM oauth_bindings ORDER BY profile").toArray();
}
/** Owner-only entry point. Even binding the same agent replaces the generation and resets the lease. */
export function bindOAuth(sql: SqlStorage, profile: string, agent: string): OAuthBinding {
  profileName(profile);
  if (agentRow(sql, agent).kind !== "external") throw fail("invalid", "only an external agent binds to an OAuth profile");
  const generation = crypto.randomUUID();
  sql.exec("INSERT INTO oauth_bindings VALUES (?, ?, ?, 0) ON CONFLICT(profile) DO UPDATE SET agent = excluded.agent, generation = excluded.generation, lease_expires_at = 0", profile, agent, generation);
  return { profile, agent, generation, leaseExpiresAt: 0 };
}
export function revokeOAuth(sql: SqlStorage, profile: string, generation: string): boolean {
  profileName(profile);
  return sql.exec("DELETE FROM oauth_bindings WHERE profile = ? AND generation = ? RETURNING profile", profile, generation).toArray().length > 0;
}
/** Only a currently authenticated front door calls this; background work cannot renew its lease. */
export function authorizeOAuth(sql: SqlStorage, profile: string, authenticatedUntil: number, now = Date.now()): OAuthBinding {
  if (!Number.isSafeInteger(authenticatedUntil) || authenticatedUntil <= now) throw fail("forbidden", "OAuth authentication has expired");
  const binding = oauthBinding(sql, profile);
  if (!binding) throw fail("forbidden", "this OAuth profile has no owner binding");
  if (isSuspended(sql, binding.agent)) throw suspended(binding.agent);
  const leaseExpiresAt = Math.max(binding.leaseExpiresAt, Math.min(authenticatedUntil, now + OAUTH_LEASE_MS));
  sql.exec("UPDATE oauth_bindings SET lease_expires_at = ? WHERE profile = ? AND generation = ?", leaseExpiresAt, profile, binding.generation);
  return { ...binding, leaseExpiresAt };
}
/** Synchronous final credential check, shared by foreground operations and background authorization. */
export function agentForCredential(sql: SqlStorage, credential: AgentCredential, now = Date.now()): string | null {
  if (credential.kind === "key") {
    assertActiveKey(sql, credential.thumbprint); // a key no act has listed authorizes nothing (INV14)
    return sql.exec<{ agent: string }>("SELECT agent FROM agent_keys WHERE thumbprint = ?", credential.thumbprint).toArray()[0]?.agent ?? null;
  }
  if (credential.kind !== "oauth" || !Number.isSafeInteger(credential.expiresAt) || credential.expiresAt <= now) return null;
  const binding = oauthBinding(sql, credential.profile);
  return binding && binding.generation === credential.generation && binding.leaseExpiresAt > now ? binding.agent : null;
}

/** `taskTypes`: parsed by the caller (taskTypesOf); null covers any type. */
export function createGrant(
  sql: SqlStorage,
  input: { agent: string; to: Address; mode: GrantMode; expiresAt: number | null; taskTypes: string[] | null; wake?: boolean },
  now: number,
): Grant {
  agentRow(sql, input.agent);
  if (input.to.agent === null) throw fail("invalid", "a grant names an agent to send to, as email/agent");
  if (input.mode !== "once" && input.mode !== "standing") throw fail("invalid", 'a grant is "once" or "standing"');
  const id = crypto.randomUUID();
  sql.exec(
    "INSERT INTO grants (id, direction, agent, peer_principal, peer_agent, mode, expires_at, created_at, task_types, wake) VALUES (?, 'out', ?, ?, ?, ?, ?, ?, ?, ?)",
    id, input.agent, input.to.principal, input.to.agent, input.mode, input.expiresAt, now, input.taskTypes === null ? null : JSON.stringify(input.taskTypes), input.wake === true ? 1 : 0,
  );
  return grantOf(grantRow(sql, id));
}

/**
 * Another owner's grant to one of this principal's agents, awaiting acceptance. One open offer per
 * pair: offering again changes nothing. It returns nothing, so the offerer learns only that the offer
 * stands, never whether it was accepted. The caller has checked that the offering agent exists.
 */
export function offer(sql: SqlStorage, input: { agent: string; from: Address; expiresAt: number | null }, now: number): void {
  agentRow(sql, input.agent);
  if (input.from.agent === null) throw fail("invalid", "a grant comes from an agent");
  const open = sql
    .exec<GrantRow>(
      "SELECT * FROM grants WHERE direction = 'in' AND agent = ? AND peer_principal = ? AND peer_agent = ? AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?)",
      input.agent, input.from.principal, input.from.agent, now,
    )
    .toArray()[0];
  if (open) return;
  // Anyone on ALLOWED_PRINCIPALS can offer: a bound, per offering person, on what they can pile onto
  // this owner's page, so one person cannot crowd out everyone else's offers.
  const pending = sql
    .exec<{ n: number }>(
      "SELECT count(*) AS n FROM grants WHERE direction = 'in' AND peer_principal = ? AND accepted_at IS NULL AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?)",
      input.from.principal, now,
    )
    .one().n;
  if (pending >= PENDING_OFFERS_PER_PEER) throw fail("inbox_full", "that person has too many of your grants awaiting their acceptance");
  const id = crypto.randomUUID();
  sql.exec(
    "INSERT INTO grants (id, direction, agent, peer_principal, peer_agent, mode, expires_at, created_at) VALUES (?, 'in', ?, ?, ?, 'standing', ?, ?)",
    id, input.agent, input.from.principal, input.from.agent, input.expiresAt, now,
  );
}

/**
 * Accepting keeps the earlier of the offer's expiry and the acceptance's own (spec "Grants"). `taskTypes`
 * (#597): the only types this owner accepts from that agent, or null for any; an offer carries none.
 */
export function acceptOffer(sql: SqlStorage, id: string, expiresAt: number | null, taskTypes: string[] | null, now: number): Grant {
  const g = grantRow(sql, id);
  if (g.direction !== "in" || g.revoked_at !== null || g.accepted_at !== null) throw fail("conflict", "that is not an offer awaiting acceptance");
  if (g.expires_at !== null && g.expires_at <= now) throw fail("expired", "that offer has expired; ask for it again");
  const until = g.expires_at === null ? expiresAt : expiresAt === null ? g.expires_at : Math.min(g.expires_at, expiresAt);
  sql.exec("UPDATE grants SET accepted_at = ?, expires_at = ?, task_types = ? WHERE id = ?", now, until, taskTypes === null ? null : JSON.stringify(taskTypes), id);
  return grantOf(grantRow(sql, id));
}

export function revokeGrant(sql: SqlStorage, id: string, now: number): Grant {
  grantRow(sql, id);
  sql.exec("UPDATE grants SET revoked_at = ? WHERE id = ? AND revoked_at IS NULL", now, id);
  return grantOf(grantRow(sql, id));
}

/** Whether `agent` still holds a live outbound grant to `peer` (other than `exceptId`): its offer in the peer's registry then still stands. */
export function hasActiveOutGrant(sql: SqlStorage, agent: string, peer: Address, now: number, exceptId: string | null = null): boolean {
  return sql.exec(
    `SELECT 1 FROM grants WHERE direction = 'out' AND agent = ? AND peer_principal = ? AND peer_agent = ?
     AND id IS NOT ? AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?)
     AND NOT (mode = 'once' AND used_at IS NOT NULL) LIMIT 1`,
    agent, peer.principal, peer.agent, exceptId, now,
  ).toArray().length > 0;
}

export function withdrawOffer(sql: SqlStorage, agent: string, from: Address, now: number): void {
  sql.exec(
    "UPDATE grants SET revoked_at = ? WHERE direction = 'in' AND accepted_at IS NULL AND revoked_at IS NULL AND agent = ? AND peer_principal = ? AND peer_agent = ?",
    now, agent, from.principal, from.agent,
  );
}

/** How many inactive grants (revoked, expired, or a spent once) listGrants() keeps: the most recent. */
export const RECENT_INACTIVE = 20;
const ACTIVE = "revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?) AND NOT (mode = 'once' AND used_at IS NOT NULL)";

/** Every live grant, and the RECENT_INACTIVE most recent inactive ones: history never grows the page without bound. */
export const listGrants = (sql: SqlStorage, now: number): Grant[] =>
  [
    ...sql.exec<GrantRow>(`SELECT * FROM grants WHERE ${ACTIVE} ORDER BY created_at DESC, rowid DESC`, now).toArray(),
    ...sql.exec<GrantRow>(`SELECT * FROM grants WHERE NOT (${ACTIVE}) ORDER BY created_at DESC, rowid DESC LIMIT ?`, now, RECENT_INACTIVE).toArray(),
  ]
    .toSorted((a, b) => b.created_at - a.created_at)
    .map(grantOf);

/** Bounded admin read; legacy listGrants retains its canonical all-live contract. */
export function permissionPage(sql: SqlStorage, now: number, cursor?: string | null): { grants: Grant[]; nextCursor: string | null } {
  let boundary: [number, string] | null = null;
  if (cursor != null) {
    try {
      if (typeof cursor !== "string" || cursor.length > 256) throw new Error();
      const parsed: unknown = JSON.parse(cursor);
      if (!Array.isArray(parsed) || parsed.length !== 2 || !Number.isSafeInteger(parsed[0]) || parsed[0] < 0 || typeof parsed[1] !== "string" || !parsed[1] || parsed[1].length > 128) throw new Error();
      boundary = parsed as [number, string];
    } catch { throw fail("invalid", "invalid permissions cursor"); }
  }
  const live = sql.exec<GrantRow>(
    `SELECT * FROM grants WHERE ${ACTIVE}${boundary ? " AND (created_at, id) < (?, ?)" : ""}
     ORDER BY created_at DESC, id DESC LIMIT 101`,
    now, ...(boundary ? [boundary[0], boundary[1]] : []),
  ).toArray();
  const more = live.length > 100;
  if (more) live.pop();
  const last = live.at(-1);
  const inactive = boundary === null ? sql.exec<GrantRow>(`SELECT * FROM grants WHERE NOT (${ACTIVE}) ORDER BY created_at DESC, rowid DESC LIMIT ?`, now, RECENT_INACTIVE).toArray() : [];
  return {
    grants: [...live, ...inactive].toSorted((a, b) => b.created_at - a.created_at).map(grantOf),
    nextCursor: more && last ? JSON.stringify([last.created_at, last.id]) : null,
  };
}

/**
 * One agent's grants for the admin's Agent page: every live grant of its own (newest first, at most 100, `truncated` when
 * there are more) and the RECENT_INACTIVE most recent inactive ones, as permissionPage() bounds the whole registry's.
 */
export function agentGrants(sql: SqlStorage, agent: string, now: number): { grants: Grant[]; truncated: boolean } {
  const live = sql.exec<GrantRow>(`SELECT * FROM grants WHERE agent = ? AND ${ACTIVE} ORDER BY created_at DESC, rowid DESC LIMIT 101`, agent, now).toArray();
  const truncated = live.length > 100;
  if (truncated) live.pop();
  const inactive = sql.exec<GrantRow>(`SELECT * FROM grants WHERE agent = ? AND NOT (${ACTIVE}) ORDER BY created_at DESC, rowid DESC LIMIT ?`, agent, now, RECENT_INACTIVE).toArray();
  return { grants: [...live, ...inactive].toSorted((a, b) => b.created_at - a.created_at).map(grantOf), truncated };
}

/** Ids Explain lists for one refusal: more than this are cut, and the cut is said. */
export const PAIR_GRANT_IDS_MAX = 20;

/**
 * Ids of the grants `agent` holds to `to` that confer something now (unrevoked, unexpired, a `once` unspent), oldest first, at most
 * PAIR_GRANT_IDS_MAX: what a refusal about the grant's type is about. An expired, spent or revoked grant is none of that, and a pair can
 * hold any number of them, so they are not listed. `truncated`: there were more.
 */
export function pairGrantIds(sql: SqlStorage, agent: string, to: Address, now: number): { ids: string[]; truncated: boolean } {
  if (to.agent === null) return { ids: [], truncated: false };
  const ids = sql
    .exec<{ id: string }>(
      `SELECT id FROM grants WHERE direction = 'out' AND agent = ? AND peer_principal = ? AND peer_agent = ? AND ${ACTIVE} ORDER BY created_at, rowid LIMIT ?`,
      agent, to.principal, to.agent, now, PAIR_GRANT_IDS_MAX + 1,
    )
    .toArray()
    .map((r) => r.id);
  return { ids: ids.slice(0, PAIR_GRANT_IDS_MAX), truncated: ids.length > PAIR_GRANT_IDS_MAX };
}

/** G12: the live grants that confer something (an `out` grant; an `in` grant once accepted) over the whole registry, and how many of them are standing and never end. */
export function grantTotals(sql: SqlStorage, now: number): { live: number; noExpiry: number } {
  const row = sql
    .exec<{ live: number; noExpiry: number | null }>(
      `SELECT count(*) AS live, sum(expires_at IS NULL AND mode = 'standing') AS noExpiry FROM grants WHERE ${ACTIVE} AND (direction = 'out' OR accepted_at IS NOT NULL)`,
      now,
    )
    .one();
  return { live: row.live, noExpiry: row.noExpiry ?? 0 };
}

/** The computers (registered keys) of `agent`, newest first: the key, the name its confirmation gave it, when it last authenticated and the device it reported. */
export type AgentComputer = { thumbprint: string; createdAt: string; state: AgentKey["state"]; label: string | null; lastSeen: string | null; device: { name: string; os: string; cli: string } | null };
export function agentComputers(sql: SqlStorage, agent: string): AgentComputer[] {
  return sql
    .exec<{ thumbprint: string; created_at: number; state: AgentKey["state"]; label: string | null; last_seen: number | null; name: string | null; os: string | null; cli: string | null }>(
      `SELECT k.thumbprint, k.created_at, k.state, k.label, k.last_seen, d.name, d.os, d.cli FROM agent_keys k LEFT JOIN devices d ON d.thumbprint = k.thumbprint
       WHERE k.agent = ? ORDER BY k.created_at DESC, k.rowid DESC LIMIT ?`,
      agent, MAX_AGENT_KEYS,
    )
    .toArray()
    .map((k) => ({
      thumbprint: k.thumbprint, createdAt: iso(k.created_at)!, state: k.state, label: k.label, lastSeen: iso(k.last_seen),
      device: k.name === null ? null : { name: k.name, os: k.os!, cli: k.cli! },
    }));
}

/**
 * Whether `agent` can be called at all: a workspace is bound to it (os), or it holds an ACTIVE key (a provisional one authenticates nothing) or an OAuth binding (external). Only a binding
 * of `oauthProfile`, the one profile the front door serves (auth.ts oauthProfile; null when it serves none), counts: any other can never authenticate.
 */
export function callable(sql: SqlStorage, name: string, oauthProfile: string | null): boolean {
  const row = sql.exec<AgentRow>("SELECT * FROM agents WHERE name = ?", name).toArray()[0];
  if (!row) return false;
  if (row.kind === "os") return row.workspace_id !== null;
  if (sql.exec("SELECT 1 FROM agent_keys WHERE agent = ? AND state = 'active' LIMIT 1", name).toArray().length > 0) return true;
  return oauthProfile !== null && sql.exec("SELECT 1 FROM oauth_bindings WHERE agent = ? AND profile = ? LIMIT 1", name, oauthProfile).toArray().length > 0;
}

/** A grant's task-type filter (#597): NULL lists none, so it covers any type; a list covers only its own, never an untyped message. */
const TYPED = "AND (task_types IS NULL OR EXISTS (SELECT 1 FROM json_each(task_types) WHERE value = ?))";
/** No task-type filter at all: only the refusal helpers ask whether a grant for the pair exists regardless of type. */
const ANY_TYPE = Symbol("any task type");
type TypeFilter = string | null | typeof ANY_TYPE;
function typed(type: TypeFilter): [string, SqlStorageValue[]] {
  if (type === ANY_TYPE) return ["", []];
  // Explicit, so a caller that passes nothing (undefined) fails loudly rather than skipping the check.
  if (type !== null && typeof type !== "string") throw new Error("a task-type filter is a type, null (untyped) or ANY_TYPE");
  return [TYPED, [type]];
}

/**
 * The grant a send from `agent` to `to` would use at `now`, or null: unrevoked, unexpired and, for
 * `once`, unused or already spent on `messageId` itself. A replay (`replay`: the message was already
 * issued) is covered only by a standing grant or the `once` it spent, never by another unused `once`.
 * Standing first, so a `once` is never spent while a standing grant covers the send. Only a grant
 * covering `type` (#597); ANY_TYPE matches any list, for the refusal helpers only.
 */
function usable(sql: SqlStorage, agent: string, to: Address, messageId: string | null, now: number, type: TypeFilter, replay = false, wakeOnly = false): GrantRow | null {
  if (to.agent === null) return null;
  const once = replay ? "used_message = ?" : "used_message IS NULL OR used_message = ?";
  const [filter, bind] = typed(type);
  const wake = wakeOnly ? "AND wake = 1" : "";
  return (
    sql
      .exec<GrantRow>(
        `SELECT * FROM grants WHERE direction = 'out' AND agent = ? AND peer_principal = ? AND peer_agent = ?
           AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?) AND (mode = 'standing' OR ${once}) ${filter} ${wake}
         ORDER BY mode = 'standing' DESC, used_message IS NULL, created_at LIMIT 1`,
        agent, to.principal, to.agent, now, messageId, ...bind,
      )
      .toArray()[0] ?? null
  );
}

/** Whether an already-issued message is still covered: a standing grant, or the `once` it spent. */
export const coversReplay = (sql: SqlStorage, agent: string, to: Address, messageId: string, now: number, type: string | null): boolean =>
  usable(sql, agent, to, messageId, now, type, true) !== null;

/**
 * Whether this exact issued message is covered by a live outbound grant that carries wake right.
 * This proves only the sender's grant right. A caller must independently require the recipient's
 * current declared `inform` capability before using it to wake.
 */
export const wakeGrantCovers = (sql: SqlStorage, agent: string, to: Address, messageId: string, now: number, type: string | null): boolean =>
  usable(sql, agent, to, messageId, now, type, true, true) !== null;

export const outboundMode = (sql: SqlStorage, agent: string, to: Address, now: number, type: string | null, messageId: string | null = null): GrantMode | null =>
  usable(sql, agent, to, messageId, now, type)?.mode ?? null;

/**
 * Why the sender's own grant refused a send: its type, when a grant for the pair exists at all; else no
 * grant. `forward`: the type is the forwarded request's, which the refusal then names as such.
 */
export const grantRefusal = (
  sql: SqlStorage, agent: string, to: Address, messageId: string | null, now: number, type: string | null, o: { replay?: boolean; forward?: boolean } = {},
): Error => (usable(sql, agent, to, messageId, now, ANY_TYPE, o.replay) ? typeNotGranted(type, o.forward) : noGrant());

/** Authorizes a send and spends a `once` grant on `messageId`. Synchronous: call it in the transaction that writes the outbox row. */
export function consumeGrant(sql: SqlStorage, agent: string, to: Address, messageId: string, now: number, type: string | null, forward: boolean): void {
  const g = usable(sql, agent, to, messageId, now, type);
  if (!g) throw grantRefusal(sql, agent, to, messageId, now, type, { forward });
  if (g.mode === "once" && g.used_message === null) sql.exec("UPDATE grants SET used_at = ?, used_message = ? WHERE id = ?", now, messageId, g.id);
}

/** Whether `agent` accepts `from` sending a message of `type` (ANY_TYPE: any list, for acceptRefusal only). */
export function accepts(sql: SqlStorage, agent: string, from: Address, now: number, type: TypeFilter): boolean {
  if (from.agent === null) return false;
  const [filter, bind] = typed(type);
  return (
    sql
      .exec(
        `SELECT 1 FROM grants WHERE direction = 'in' AND agent = ? AND peer_principal = ? AND peer_agent = ?
           AND accepted_at IS NOT NULL AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?) ${filter}`,
        agent, from.principal, from.agent, now, ...bind,
      )
      .toArray().length > 0
  );
}

/** Why the recipient's acceptance refused a delivery, never saying which types it accepts. */
export const acceptRefusal = (sql: SqlStorage, agent: string, from: Address, now: number): Error =>
  accepts(sql, agent, from, now, ANY_TYPE) ? typeNotAccepted() : noGrant();

/**
 * Whether `agent` holds a live `out` grant (the ACTIVE predicate: not revoked, not expired, not a spent `once`) to another person's agent.
 * An offer awaiting acceptance is an `in` grant and is not this. `principal` is the Mailbox's own person.
 */
export const hasLiveGrantToOtherOwner = (sql: SqlStorage, agent: string, principal: string, now: number): boolean =>
  sql.exec(`SELECT 1 FROM grants WHERE direction = 'out' AND agent = ? AND lower(peer_principal) != ? AND ${ACTIVE} LIMIT 1`, agent, principal.toLowerCase(), now).toArray().length > 0;

/** The agents `agent` holds a usable grant to, as wire addresses. */
export const grantTargets = (sql: SqlStorage, agent: string, now: number): string[] =>
  sql
    .exec<{ peer_principal: string; peer_agent: string }>(
      `SELECT DISTINCT peer_principal, peer_agent FROM grants WHERE direction = 'out' AND agent = ?
         AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?) AND (mode = 'standing' OR used_message IS NULL)
       ORDER BY peer_principal, peer_agent`,
      agent, now,
    )
    .toArray()
    .map((r) => wireOf({ principal: r.peer_principal, agent: r.peer_agent }));
