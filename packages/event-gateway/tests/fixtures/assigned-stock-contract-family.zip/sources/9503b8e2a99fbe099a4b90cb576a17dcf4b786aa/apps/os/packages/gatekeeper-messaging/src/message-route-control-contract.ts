import { canonicalEmail } from "openapi-operator/src/access.ts";
import { parseEventMessageConsumer, type EventMessageConsumerV1, type EventMessageRouteV1 } from "./event-authority-contract.ts";
import type { MessageRouteReceipt, MessageRouteTransfer } from "./event-bridge.ts";
import type { MessageRouteOwnerCall } from "./message-route-owner-proof.ts";

export type MessageRouteControlInput = Readonly<{ agent: string; request:
  | Readonly<{ operation: "read" }>
  | (MessageRouteTransfer & Readonly<{ operation: "transfer" }>)
  | Readonly<{ operation: "operation_readback"; operationId: string; agentCreatedAt: number }> }>;
export type MessageRouteControlResult =
  | Readonly<{ status: "ok"; agentCreatedAt: number; currentRoute: EventMessageRouteV1; receipt: MessageRouteReceipt | null }>
  | Readonly<{ status: "denied" | "invalid" | "unavailable" | "conflict" | "capacity" | "unknown" }>;
export type MessageConsumerQueryV1 = Readonly<{ principal: string; agent: string; keyThumbprint: string; consumer: EventMessageConsumerV1 }>;
export type MessageConsumerSnapshotV1 =
  | Readonly<{ status: "current"; consumer: EventMessageConsumerV1; checkedAt: string; leaseUntil: string }>
  | Readonly<{ status: "denied" | "invalid" | "unavailable" }>;
export interface MessageConsumerServiceV1 { verifyMessageConsumer(input: MessageConsumerQueryV1): Promise<MessageConsumerSnapshotV1> }
export interface MessageRouteControlService {
  messageRouteControl(call: MessageRouteOwnerCall, input: MessageRouteControlInput): Promise<MessageRouteControlResult>;
}
const integer = (v: unknown): v is number => typeof v === "number" && Number.isSafeInteger(v) && v >= 0;
const operationId = (v: unknown): v is string => typeof v === "string" && /^[A-Za-z0-9_-]{1,128}$/.test(v);
const key = (v: unknown): v is string => typeof v === "string" && /^[A-Za-z0-9_-]{43}$/.test(v);
function object(v: unknown): v is Record<string, unknown> {
  return v !== null && typeof v === "object" && !Array.isArray(v) && [Object.prototype, null].includes(Object.getPrototypeOf(v));
}
function exact(v: unknown, keys: string[]): v is Record<string, unknown> {
  return object(v) && Object.keys(v).length === keys.length && keys.every(k => Object.hasOwn(v, k));
}
export function parseMessageRouteOwnerCall(value: unknown): MessageRouteOwnerCall | null {
  if (!object(value) || Object.keys(value).some(k => !["token", "origin", "fetchSite", "csrf"].includes(k)) ||
    typeof value.token !== "string" || !value.token || new TextEncoder().encode(value.token).byteLength > 16384) return null;
  const result: { token: string; origin?: string; fetchSite?: string; csrf?: string } = { token: value.token };
  for (const [field, limit] of [["origin", 512], ["fetchSite", 32], ["csrf", 128]] as const) {
    const supplied = value[field];
    if (supplied == null) continue;
    if (typeof supplied !== "string" || supplied.length > limit) return null;
    result[field] = supplied;
  }
  return Object.freeze(result);
}
export function parseMessageRouteControlInput(value: unknown): MessageRouteControlInput | null {
  if (!exact(value, ["agent", "request"]) || typeof value.agent !== "string" || !/^[a-z0-9-]{1,32}$/.test(value.agent)) return null;
  const r = value.request;
  if (exact(r, ["operation"]) && r.operation === "read") return Object.freeze({ agent: value.agent, request: Object.freeze({ operation: "read" }) });
  if (exact(r, ["operation", "operationId", "agentCreatedAt"]) && r.operation === "operation_readback" && operationId(r.operationId) && integer(r.agentCreatedAt))
    return Object.freeze({ agent: value.agent, request: Object.freeze({ operation: "operation_readback", operationId: r.operationId, agentCreatedAt: r.agentCreatedAt }) });
  if (!exact(r, ["operation", "operationId", "agentCreatedAt", "expectedGeneration", "owner", "consumer", "keyThumbprint"]) || r.operation !== "transfer" ||
    !operationId(r.operationId) || !integer(r.agentCreatedAt) || !integer(r.expectedGeneration) || r.expectedGeneration >= Number.MAX_SAFE_INTEGER) return null;
  const consumer = parseEventMessageConsumer(r.consumer);
  if (r.owner === "event" ? !consumer || !key(r.keyThumbprint) : r.owner !== "os" || r.consumer !== null || r.keyThumbprint !== null) return null;
  return Object.freeze({ agent: value.agent, request: Object.freeze({ operation: "transfer", operationId: r.operationId, agentCreatedAt: r.agentCreatedAt,
    expectedGeneration: r.expectedGeneration, owner: r.owner, consumer: consumer && Object.freeze(consumer), keyThumbprint: r.keyThumbprint } as MessageRouteTransfer & { operation: "transfer" }) });
}
function route(value: unknown): EventMessageRouteV1 | null {
  if (!exact(value, ["owner", "generation", "consumer"]) || !integer(value.generation)) return null;
  const consumer = parseEventMessageConsumer(value.consumer);
  if (value.owner === "event" ? !consumer || value.generation === 0 : value.owner !== "os" || value.consumer !== null) return null;
  return { owner: value.owner as "event" | "os", generation: value.generation, consumer };
}
export function parseMessageRouteControlResult(value: unknown, input?: MessageRouteControlInput): MessageRouteControlResult | null {
  if (exact(value, ["status"]) && ["denied", "invalid", "unavailable", "conflict", "capacity", "unknown"].includes(value.status as string))
    return { status: value.status } as MessageRouteControlResult;
  if (!exact(value, ["status", "agentCreatedAt", "currentRoute", "receipt"]) || value.status !== "ok" || !integer(value.agentCreatedAt)) return null;
  const currentRoute = route(value.currentRoute);
  if (!currentRoute) return null;
  let receipt: MessageRouteReceipt | null = null;
  if (value.receipt !== null) {
    const r = value.receipt;
    if (!exact(r, ["operationId", "agentCreatedAt", "route", "replayed"]) || !operationId(r.operationId) || r.agentCreatedAt !== value.agentCreatedAt || typeof r.replayed !== "boolean") return null;
    const historical = route(r.route);
    if (!historical || historical.generation === 0) return null;
    receipt = { operationId: r.operationId, agentCreatedAt: value.agentCreatedAt, route: historical, replayed: r.replayed };
  }
  if (receipt && (currentRoute.generation < receipt.route.generation ||
    (currentRoute.generation === receipt.route.generation && JSON.stringify(currentRoute) !== JSON.stringify(receipt.route)))) return null;
  if (input) {
    const request = input.request;
    if (request.operation === "read") { if (receipt !== null) return null; }
    else {
      if (!receipt || receipt.operationId !== request.operationId || value.agentCreatedAt !== request.agentCreatedAt) return null;
      if (request.operation === "transfer" && (receipt.route.generation !== request.expectedGeneration + 1 ||
        receipt.route.owner !== request.owner || JSON.stringify(receipt.route.consumer) !== JSON.stringify(request.consumer))) return null;
    }
  }
  return { status: "ok", agentCreatedAt: value.agentCreatedAt, currentRoute, receipt };
}
export function parseMessageConsumerQuery(value: unknown): MessageConsumerQueryV1 | null {
  if (!exact(value, ["principal", "agent", "keyThumbprint", "consumer"]) || typeof value.principal !== "string" ||
    !canonicalEmail(value.principal) || value.principal !== value.principal.toLowerCase() || value.principal.length > 254 ||
    typeof value.agent !== "string" || !/^[a-z0-9-]{1,32}$/.test(value.agent) || !key(value.keyThumbprint)) return null;
  const consumer = parseEventMessageConsumer(value.consumer);
  return consumer ? Object.freeze({ principal: value.principal, agent: value.agent, keyThumbprint: value.keyThumbprint, consumer: Object.freeze(consumer) }) : null;
}
export function parseMessageConsumerSnapshot(value: unknown): MessageConsumerSnapshotV1 | null {
  if (exact(value, ["status"]) && ["denied", "invalid", "unavailable"].includes(value.status as string)) return { status: value.status } as MessageConsumerSnapshotV1;
  if (!exact(value, ["status", "consumer", "checkedAt", "leaseUntil"]) || value.status !== "current") return null;
  const consumer = parseEventMessageConsumer(value.consumer);
  for (const v of [value.checkedAt, value.leaseUntil]) if (typeof v !== "string" || !Number.isFinite(Date.parse(v)) || new Date(v).toISOString() !== v) return null;
  if (!consumer || Date.parse(value.leaseUntil as string) <= Date.parse(value.checkedAt as string)) return null;
  return { status: "current", consumer, checkedAt: value.checkedAt as string, leaseUntil: value.leaseUntil as string };
}
