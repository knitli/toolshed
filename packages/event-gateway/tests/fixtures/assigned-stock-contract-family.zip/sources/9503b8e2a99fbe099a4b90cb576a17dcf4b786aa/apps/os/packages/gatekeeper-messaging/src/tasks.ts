// Receiver-declared task types (R4 plan 5.4, 7.2, 7.3): the agent that RECEIVES a task owns what it accepts. A declaration gives a type a class
// (inform or consequential), a flat closed schema for the body, and the limits an order of that type is drawn inside. They live in the receiver's
// Mailbox, and the receiver's owner edits them; a sender can read them only through `recipients` (decision D19 A).
//
// What this phase does with them: a body for a type that declares fields must be exactly the envelope those fields describe, checked early in
// post() (so a refusal spends no `once` grant) and again in the recipient's deliver() (the authoritative check). A consequential class needs an
// ordered thread under authority.consequenceRule (orders.ts `consequence`, R4 P5b). An undeclared type is `inform` for good (FC-03).
//
// Plain synchronous functions over the Mailbox's SQLite, plus the pure parser and body check (no Worker types).

import { canonicalJson } from "@knitli/openapi-mcp/runtime";
import { DECLARATION_SOURCE, ENUM_VALUE, FIELD_NAME, MAX_DEFAULT_SCOPE_TERMS, MAX_ENUM, MAX_FIELDS, MAX_ORDER_LIFETIME_HOURS, MAX_STRING, SUMMARY_MAX, TASK_TYPE, declarationProblem, isOrderTerm, isReserved, type Field, type TaskDeclaration } from "authority/src/task.ts";
import { isActInteger } from "authority/src/contract-kit.ts";
import { attenuates, isSegmentRef, isTerm, type Term } from "authority/src/scope.ts";
import { stricter } from "authority/src/webauthn.ts";
import { isPlainText, isStoredPlainText } from "authority/src/text.ts";
import { codePoints, fail, LIMITS } from "./model.ts";
import { hasAgent } from "./registry.ts";

export const TASKS_SCHEMA = `
CREATE TABLE IF NOT EXISTS tasks (
  agent TEXT NOT NULL,
  type TEXT NOT NULL,
  class TEXT NOT NULL CHECK (class IN ('inform','consequential')),
  declaration TEXT NOT NULL,
  source TEXT NOT NULL,
  act_digest TEXT,
  created_at INTEGER NOT NULL,
  PRIMARY KEY (agent, type)
);`;

/** Agents one look at declarations (Mailbox.declaredFor) names: more is a refusal, never a silent cut. */
export const DECLARED_BATCH = 100;
/** Declarations one agent may hold. */
export const MAX_DECLARATIONS = 64;
// The field grammar and its bounds live in authority/src/task.ts, where the declare-task act reads them too. Flat and closed, so a body is short and every
// field is shown to the person who signs it; MAX_STRING counts code points, and LIMITS.body bounds the whole body in bytes besides.
export { MAX_FIELDS, MAX_STRING };
const MAX_INPUTS = 8;

const DIGEST = /^sha256:[0-9a-f]{64}$/;
const RECEIPT_DIGEST = /^[0-9a-f]{64}$/;
const SOURCE = DECLARATION_SOURCE;
const record = (value: unknown): value is Record<string, unknown> => {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
};
/** Whether `value` is a plain object whose keys are all among `allowed` and include every one of `required`. */
const keys = (value: Record<string, unknown>, required: readonly string[], allowed: readonly string[] = required): boolean =>
  required.every((key) => Object.hasOwn(value, key)) && Object.keys(value).every((key) => allowed.includes(key));

// --- declarations -----------------------------------------------------------------------------------------

function parseFields(value: unknown, what: string, stored: boolean): Field[] {
  if (!Array.isArray(value) || value.length > MAX_FIELDS) throw fail("invalid", `${what} lists at most ${MAX_FIELDS} fields`);
  const names = new Set<string>();
  return value.map((item: unknown) => {
    if (!record(item) || !keys(item, ["name", "kind", "required"], ["name", "kind", "required", "max", "enum"])) throw fail("invalid", `a field in ${what} is { name, kind, required } and, by kind, max or enum`);
    const { name, kind, required, max, enum: values } = item;
    if (typeof name !== "string" || !FIELD_NAME.test(name) || names.has(name)) throw fail("invalid", `a field name in ${what} is a lowercase word of letters and digits, at most 32, and used once`);
    names.add(name);
    if (typeof required !== "boolean") throw fail("invalid", `${name}: required is true or false`);
    if (kind !== "string" && kind !== "int" && kind !== "digest" && kind !== "enum") throw fail("invalid", `${name}: a field is a string, an int, a digest or an enum`);
    if (max !== undefined && (kind !== "string" || typeof max !== "number" || !Number.isInteger(max) || max < 1 || max > MAX_STRING)) throw fail("invalid", `${name}: only a string field has a max, from 1 to ${MAX_STRING}`);
    if (kind === "enum" ? !Array.isArray(values) || values.length < 1 || values.length > MAX_ENUM || !values.every((v) => typeof v === "string" && ENUM_VALUE.test(v)) || new Set(values).size !== values.length : values !== undefined)
      throw fail("invalid", `${name}: an enum field lists 1 to ${MAX_ENUM} distinct values of a-z, 0-9, ".", "_" and "-"; no other field has a list`);
    return { name, kind, required, ...(max === undefined ? {} : { max: max as number }), ...(kind === "enum" ? { enum: [...(values as string[])] } : {}) };
  });
}

/** The terms an order of this type may be drawn inside: an order's terms are msg.forward and exec.request only (plan 5.8). */
function parseScope(value: unknown): Term[] {
  if (!Array.isArray(value) || value.length > MAX_DEFAULT_SCOPE_TERMS) throw fail("invalid", `defaults.scope lists at most ${MAX_DEFAULT_SCOPE_TERMS} terms`);
  return value.map((term: unknown) => {
    if (!isTerm(term) || !isOrderTerm(term)) throw fail("invalid", "a term in defaults.scope is msg.forward or exec.request");
    return term;
  });
}

const whole = (value: unknown, min: number, max: number): value is number => isActInteger(value) && value >= min && value <= max;

/**
 * A declaration from owner input, rebuilt field by field (an unknown key is refused, so a future claim cannot ride in), or a refusal. `source` is
 * the caller's: an owner's declaration is always `owner`, and a `catalog:` or `route:` one is written only by the paths that own them.
 */
export function parseDeclaration(value: unknown, source: TaskDeclaration["source"], stored = false): TaskDeclaration {
  if (!record(value) || !keys(value, ["type", "class", "summary", "payload", "minAssurance", "defaults"], ["type", "class", "summary", "payload", "reply", "minAssurance", "defaults"]))
    throw fail("invalid", "a task declaration is { type, class, summary, payload, minAssurance, defaults }, and optionally a reply schema for a consequential type");
  const { type, class: kind, summary, payload, reply, minAssurance, defaults } = value;
  if (typeof type !== "string" || !TASK_TYPE.test(type)) throw fail("invalid", 'a task type is lowercase a-z, 0-9, "-" and "/", at most 64 characters');
  if (kind !== "inform" && kind !== "consequential") throw fail("invalid", 'class is "inform" or "consequential"');
  if (typeof summary !== "string" || codePoints(summary) < 1 || codePoints(summary) > SUMMARY_MAX || !(stored ? isStoredPlainText : isPlainText)(summary))
    throw fail("invalid", "summary is 1 to 200 characters of plain text");
  if (!record(payload) || !keys(payload, ["fields"])) throw fail("invalid", "payload is { fields }");
  if (reply !== undefined && (!record(reply) || !keys(reply, ["fields"]))) throw fail("invalid", "reply is { fields }");
  // Only a consequential type answers with a result (plan 5.4 `reply?`: consequential types; absent means knitli.result/v1).
  if (reply !== undefined && kind === "inform") throw fail("invalid", "only a consequential task type declares a reply schema");
  if (minAssurance !== "hw-uv" && minAssurance !== "hw-up") throw fail("invalid", 'minAssurance is "hw-uv" or "hw-up"');
  if (!record(defaults) || !keys(defaults, ["ttlHours", "maxDepth", "maxMessages", "scope"])) throw fail("invalid", "defaults is { ttlHours, maxDepth, maxMessages, scope }");
  // An order lives at most 7 days (plan 5.8), is at most the thread depth deep, and has at most the thread budget's messages.
  if (!whole(defaults.ttlHours, 1, MAX_ORDER_LIFETIME_HOURS) || !whole(defaults.maxDepth, 0, LIMITS.depth) || !whole(defaults.maxMessages, 1, LIMITS.budget.thread))
    throw fail("invalid", `defaults: ttlHours is 1 to ${MAX_ORDER_LIFETIME_HOURS}, maxDepth 0 to ${LIMITS.depth}, maxMessages 1 to ${LIMITS.budget.thread}`);
  const terms = parseScope(defaults.scope);
  if (!SOURCE.test(source)) throw fail("invalid", 'a declaration comes from "owner", "catalog:<id>" or "route:<id>"');
  return {
    type, class: kind, summary,
    payload: { fields: parseFields(payload.fields, "payload", stored) },
    ...(reply === undefined ? {} : { reply: { fields: parseFields((reply as Record<string, unknown>).fields, "reply", stored) } }),
    minAssurance,
    defaults: { ttlHours: defaults.ttlHours, maxDepth: defaults.maxDepth, maxMessages: defaults.maxMessages, scope: terms },
    source,
  };
}

export { isReserved }; // authority's: the declare-task act reads the same rule

// --- storage ----------------------------------------------------------------------------------------------

type Row = { type: string; class: TaskDeclaration["class"]; declaration: string; source: string };

/** What is stored: the canonical JSON of everything but the type, the class and the source, which have columns of their own. */
const bodyOf = (decl: TaskDeclaration): string => {
  const { type: _type, class: _class, source: _source, ...rest } = decl;
  return canonicalJson(rest as unknown as Parameters<typeof canonicalJson>[0]);
};

function declarationOf(row: Row): TaskDeclaration | null {
  try {
    const rest = JSON.parse(row.declaration) as Record<string, unknown>;
    // Read back through the same parser: a row that no longer parses declares nothing (an undeclared type is inform), and is not trusted.
    return parseDeclaration({ type: row.type, class: row.class, ...rest }, row.source as TaskDeclaration["source"], true);
  } catch {
    return null;
  }
}

/**
 * An owner's declaration of a type the catalog or a router wrote is refused, whatever door it comes by (the session RPC, a draft, a signed act). Run before any
 * widening check, so a managed type is refused as managed rather than with `proof_required`.
 */
export function refuseManaged(sql: SqlStorage, agent: string, decl: Pick<TaskDeclaration, "type" | "source">): void {
  const stored = sql.exec<{ source: string }>("SELECT source FROM tasks WHERE agent = ? AND type = ?", agent, decl.type).toArray()[0];
  if (stored !== undefined && stored.source !== "owner" && decl.source === "owner") throw fail("conflict", `${decl.type} is managed by the image catalog or a router (${stored.source}), not by an owner's declaration`);
}

/** Writes `decl` as `agent`'s declaration of its type, replacing any earlier one. The caller has authorized it; `exec/*` is the caller's to allow. */
export function declare(sql: SqlStorage, agent: string, decl: TaskDeclaration, now: number): void {
  if (!hasAgent(sql, agent)) throw fail("not_found", `no agent named ${agent}`);
  // Rules new to a write: a row stored before they existed is still read back, still a declaration, and still checks its bodies (declarationOf parses with the older grammar).
  const problem = declarationProblem(decl.type, decl.class, decl.source, decl.defaults);
  if (problem !== null) throw fail("invalid", problem);
  // A declaration the catalog or a router wrote is theirs: an owner's declaration of the same type does not replace it, whatever door it came by (the session RPC or a
  // signed act). The rules above make such a row an exec/* one, which an owner never writes; this holds for a row stored before they did.
  refuseManaged(sql, agent, decl);
  const held = sql.exec<{ n: number }>("SELECT count(*) AS n FROM tasks WHERE agent = ? AND type != ?", agent, decl.type).one().n;
  if (held >= MAX_DECLARATIONS) throw fail("invalid", `an agent declares at most ${MAX_DECLARATIONS} task types`);
  sql.exec(
    `INSERT INTO tasks (agent, type, class, declaration, source, act_digest, created_at) VALUES (?, ?, ?, ?, ?, NULL, ?)
     ON CONFLICT (agent, type) DO UPDATE SET class = excluded.class, declaration = excluded.declaration, source = excluded.source, created_at = excluded.created_at`,
    agent, decl.type, decl.class, bodyOf(decl), decl.source, now,
  );
}

/**
 * Whether the bodies a field list accepts are inside those the one before it accepted (VS-11). A body is closed to its fields, so: every field stays, of its kind,
 * no less required, no longer, with no more enum values; a field that goes was optional (its absence refuses more); and NO field is added, since a body with
 * it was refused before. The one exception is a list that had no fields, which accepts free text: any schema is inside that.
 */
function fieldsNoLooser(was: readonly Field[], now: readonly Field[]): boolean {
  const kept = new Map(now.map((field) => [field.name, field]));
  for (const field of was) {
    const next = kept.get(field.name);
    if (next === undefined) {
      if (field.required) return false;
      continue;
    }
    if (next.kind !== field.kind || (field.required && !next.required)) return false;
    if (field.kind === "string" && (next.max ?? MAX_STRING) > (field.max ?? MAX_STRING)) return false;
    if (field.kind === "enum" && !next.enum!.every((value) => field.enum!.includes(value))) return false;
  }
  // Every field gone turns a closed body into free text, which accepts what was refused (an empty `every` is true, so it is said here).
  if (was.length > 0 && now.length === 0) return false;
  return was.length === 0 || now.every((field) => was.some((old) => old.name === field.name));
}

/**
 * Whether writing `next` over `was` (null: nothing declared) widens what the agent accepts, which is a `declare-task` act once the kind is enforced; every
 * other edit narrows or changes nothing that matters, and the session may make it (plan 5.4 item 5, 5.11, VS-11). Widening: a type declared `inform`, a
 * consequential one flipped to `inform`, higher order defaults, a lower minimum assurance, a looser field, another reply schema, or any assignment from a router.
 */
export function declarationWidens(was: TaskDeclaration | null, next: TaskDeclaration): boolean {
  if (next.source.startsWith("route:")) return true;
  if (was === null) return next.class === "inform";
  if (was.source !== next.source || (was.class === "consequential" && next.class === "inform")) return true;
  const before = was.defaults;
  const after = next.defaults;
  if (after.ttlHours > before.ttlHours || after.maxDepth > before.maxDepth || after.maxMessages > before.maxMessages || !attenuates(before.scope, after.scope)) return true;
  if (was.minAssurance !== next.minAssurance && stricter(was.minAssurance, next.minAssurance) === was.minAssurance) return true;
  if (!fieldsNoLooser(was.payload.fields, next.payload.fields)) return true;
  return was.reply !== undefined && (next.reply === undefined || !fieldsNoLooser(was.reply.fields, next.reply.fields)) || (was.reply === undefined && next.reply !== undefined);
}

/** `agent`'s declaration of `type`, or null: undeclared (inform, free text). */
export function declaredType(sql: SqlStorage, agent: string, type: string): TaskDeclaration | null {
  const row = sql.exec<Row>("SELECT type, class, declaration, source FROM tasks WHERE agent = ? AND type = ?", agent, type).toArray()[0];
  return row ? declarationOf(row) : null;
}

/** Every declaration of `agent`, by type. */
export function declarationsOf(sql: SqlStorage, agent: string): TaskDeclaration[] {
  return sql.exec<Row>("SELECT type, class, declaration, source FROM tasks WHERE agent = ? ORDER BY type", agent).toArray().flatMap((row) => declarationOf(row) ?? []);
}

// --- bodies -----------------------------------------------------------------------------------------------

/** What a sender is told about a declared type: enough to form a valid message, and nothing about orders or limits. */
export type DeclaredTask = { type: string; class: TaskDeclaration["class"]; summary: string; fields: Field[] };
export const declaredTask = (decl: TaskDeclaration): DeclaredTask => ({ type: decl.type, class: decl.class, summary: decl.summary, fields: decl.payload.fields.map((field) => ({ ...field, ...(field.enum ? { enum: [...field.enum] } : {}) })) });

/** What a sender is told when its body does not fit what the recipient declared, at post() and at deliver() alike. */
export const bodyRefusal = (agent: string, type: string, problem: string): string => `the body does not fit what ${agent} declares for task type ${type}: ${problem}`;

const ENVELOPE = 'the body is a JSON object: {"v":1,"kind":"task","fields":{...}}, with an optional "inputs"';

/** Whether a string may reach a person or an agent as the text of a field: NFC, and nothing hidden (AT-11). */
const plainText = isPlainText; // a new message is a new write: a lone surrogate in it is refused

function checkField(field: Field, value: unknown): string | null {
  const bad = (reason: string): string => `field ${field.name} ${reason}`;
  switch (field.kind) {
    case "string":
      if (typeof value !== "string" || value.length === 0) return bad("is a non-empty string");
      if (codePoints(value) > (field.max ?? MAX_STRING)) return bad(`is at most ${field.max ?? MAX_STRING} characters`);
      return plainText(value) ? null : bad("holds a control, direction or zero-width character, or is not normalized (NFC)");
    case "int":
      return isActInteger(value) ? null : bad("is a whole number");
    case "digest":
      return typeof value === "string" && DIGEST.test(value) ? null : bad("is sha256: and 64 lowercase hex digits");
    case "enum":
      return typeof value === "string" && field.enum!.includes(value) ? null : bad(`is one of ${field.enum!.join(", ")}`);
  }
}

/**
 * Why `body` does not fit what `decl` declares, in words for the sender, or null when it fits. Applies only to a type that declares fields (a
 * declaration with none leaves the body free text). Closed: an unknown field, a missing required one, or a key the envelope does not have is a
 * refusal. The sender is told which declared field is wrong, which it can read from `recipients` already.
 */
export function bodyProblem(decl: TaskDeclaration, body: string, orderRoot = false): string | null {
  if (decl.payload.fields.length === 0) return null;
  let parsed: unknown;
  try {
    parsed = JSON.parse(body);
  } catch {
    return ENVELOPE;
  }
  // An order's root (authority orderRootBody) also carries the signed deadline, and the signed objective among its fields: the envelope's own, never a
  // declared field. Only the root: any other body that says either is refused as before (R4 P5b 5b-1 review).
  const allowed = orderRoot ? ["v", "kind", "fields", "inputs", "deadlineSeconds"] : ["v", "kind", "fields", "inputs"];
  if (!record(parsed) || !keys(parsed, ["v", "kind", "fields", ...(orderRoot ? ["inputs", "deadlineSeconds"] : [])], allowed) || parsed.v !== 1 || parsed.kind !== "task" || !record(parsed.fields)) return ENVELOPE;
  if (orderRoot && (!isActInteger(parsed.deadlineSeconds) || (parsed.deadlineSeconds as number) < 1 || (parsed.deadlineSeconds as number) > 7 * 86_400 || typeof parsed.fields.objective !== "string")) return ENVELOPE;
  const given = orderRoot ? Object.fromEntries(Object.entries(parsed.fields).filter(([name]) => name !== "objective")) : parsed.fields;
  const known = decl.payload.fields.map((field) => field.name);
  const unknown = Object.keys(given).find((name) => !known.includes(name));
  if (unknown !== undefined) return `field ${unknown} is not one ${decl.type} declares: ${known.join(", ")}`;
  for (const field of decl.payload.fields) {
    if (!Object.hasOwn(given, field.name)) {
      if (field.required) return `field ${field.name} is required`;
      continue;
    }
    const problem = checkField(field, given[field.name]);
    if (problem !== null) return problem;
  }
  if (parsed.inputs === undefined) return null;
  const inputs = parsed.inputs;
  if (!Array.isArray(inputs) || inputs.length > MAX_INPUTS) return `inputs lists at most ${MAX_INPUTS} references`;
  for (const input of inputs as unknown[]) {
    const ok = record(input) && ((keys(input, ["kind", "digest"]) && input.kind === "receipt" && typeof input.digest === "string" && RECEIPT_DIGEST.test(input.digest)) ||
      (keys(input, ["kind", "ref"]) && input.kind === "memory" && typeof input.ref === "string" && isSegmentRef(input.ref)));
    if (!ok) return 'an input is {"kind":"receipt","digest":<64 hex digits>} or {"kind":"memory","ref":<a segment id>}: references, never content';
  }
  return null;
}
