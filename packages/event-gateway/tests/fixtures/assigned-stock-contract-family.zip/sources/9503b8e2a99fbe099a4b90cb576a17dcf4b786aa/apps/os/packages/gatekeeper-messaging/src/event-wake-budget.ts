import { LIMITS } from "./model.ts";
import type { ActivationClaimV1 } from "./event-authority-contract.ts";

/** Keep transport replays idempotent beyond their 24-hour recovery horizon. */
export const EVENT_ATTEMPT_RETENTION_MS = 7 * 24 * 60 * 60 * 1000;

export type EventAttemptDecision = "reserved" | "over_budget";
export type EventAttemptRecord = Readonly<{
  attemptId: string;
  decision: "reserved";
  recordedAt: number;
  reservedAt: number;
  activation?: ActivationClaimV1;
}>;
export type StockWakeAttemptRecord = Readonly<{
  attemptId: string;
  recordedAt: number;
  reservedAt: number;
  thumbprint: string;
  claim: string;
  settledAt: number | null;
}>;

const EVENT_ATTEMPT_RECORD_LIMIT = LIMITS.wake.perHour * (EVENT_ATTEMPT_RETENTION_MS / LIMITS.wake.windowMs);

/** Shape persisted by Mailbox's existing per-agent wake ledger. */
export type EventWakeBudget = Readonly<{
  pendingSince: number | null;
  wakes: number[];
  eventAttempts?: EventAttemptRecord[];
  stockWakeAttempts?: StockWakeAttemptRecord[];
}>;

export type EventAttemptBudgetSnapshot = Readonly<{
  used: number;
  remaining: number;
  limit: 10;
  windowMs: 3_600_000;
}>;

export type EventAttemptStatus = Readonly<{
  status: "reserved" | "unknown";
  reservedAt: number | null;
  budget: EventAttemptBudgetSnapshot;
}>;

export type EventAttemptReservation = Readonly<{
  status: "reserved";
  reservedAt: number;
  budget: EventAttemptBudgetSnapshot;
  idempotent: boolean;
}>;

function liveWakes(budget: EventWakeBudget, now: number): number[] {
  return budget.wakes.filter((at) => at > now - LIMITS.wake.windowMs);
}

function liveAttempts(budget: EventWakeBudget, now: number): EventAttemptRecord[] {
  return (budget.eventAttempts ?? []).filter((row) => row.recordedAt > now - EVENT_ATTEMPT_RETENTION_MS);
}

function snapshot(wakes: number[]): EventAttemptBudgetSnapshot {
  const used = wakes.length;
  return {
    used,
    remaining: Math.max(0, LIMITS.wake.perHour - used),
    limit: LIMITS.wake.perHour,
    windowMs: LIMITS.wake.windowMs,
  };
}

/** Read a retained attempt decision and the shared rolling-hour usage. */
export function eventAttemptStatus(budget: EventWakeBudget, attemptId: string, now: number): EventAttemptStatus & Readonly<{ activation?: ActivationClaimV1 }> {
  const wakes = liveWakes(budget, now);
  const prior = liveAttempts(budget, now).find((row) => row.attemptId === attemptId);
  return {
    status: prior?.decision ?? "unknown",
    reservedAt: prior?.reservedAt ?? null,
    ...(prior?.activation ? { activation: prior.activation } : {}),
    budget: snapshot(wakes),
  };
}

/**
 * Reserve one shared per-agent wake slot. Successful reservations are retained for the recovery
 * horizon, so replaying a charged attempt cannot consume another slot. Over-budget refusals are not
 * reservations and are not retained.
 */
export function reserveEventAttempt(budget: EventWakeBudget, attemptId: string, now: number, activation?: ActivationClaimV1): {
  budget: EventWakeBudget;
  result: EventAttemptReservation | Readonly<{
    status: "over_budget";
    reservedAt: null;
    budget: EventAttemptBudgetSnapshot;
    idempotent: false;
  }>;
} {
  const wakes = liveWakes(budget, now);
  const attempts = liveAttempts(budget, now);
  const prior = attempts.find((row) => row.attemptId === attemptId);
  if (prior) {
    return {
      budget: { ...budget, wakes, eventAttempts: attempts },
      result: {
        status: prior.decision,
        reservedAt: prior.reservedAt,
        budget: snapshot(wakes),
        idempotent: true,
      },
    };
  }

  if (wakes.length >= LIMITS.wake.perHour) {
    // A denied call is not a reservation, so it is not retained.
    return { budget: { ...budget, wakes, eventAttempts: attempts }, result: {
      status: "over_budget", reservedAt: null, budget: snapshot(wakes), idempotent: false,
    } };
  }
  if (attempts.length >= EVENT_ATTEMPT_RECORD_LIMIT) throw new Error("event attempt reservation retention capacity exceeded");
  const reservedAt = now;
  const nextWakes = [...wakes, reservedAt];
  const nextAttempts = [...attempts, { attemptId, decision: "reserved" as const, recordedAt: now, reservedAt,
    ...(activation ? { activation } : {}) }];
  const next = { ...budget, wakes: nextWakes, eventAttempts: nextAttempts };
  return {
    budget: next,
    result: { status: "reserved", reservedAt, budget: snapshot(nextWakes), idempotent: false },
  };
}
