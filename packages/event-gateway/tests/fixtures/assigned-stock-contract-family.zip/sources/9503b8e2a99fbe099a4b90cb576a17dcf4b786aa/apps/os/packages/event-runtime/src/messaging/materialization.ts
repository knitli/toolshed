import { z } from "zod";
import {
  parseEventMessageConsumer,
  parseEventMessagePreparationResult,
  parseEventMessagePublication,
  type EventMessagePreparationResultV1,
} from "gatekeeper-messaging/src/event-authority-contract";
import { EVENT_POLICY_V1 } from "../policy";
import { MessagingEnvelopeV2Schema } from "./protocol-v2";

type Snapshot = Extract<EventMessagePreparationResultV1, { status: "eligible" }>;
type HistoricalSnapshot = Omit<Snapshot, "activation">;
export type HistoricalMessageDeliverySourceV1 = Omit<MessageDeliverySourceV1, "source"> & { source: HistoricalSnapshot };
const wire = MessagingEnvelopeV2Schema.shape;
const schema = z.strictObject({
  kind: z.literal("message_delivery_source"),
  version: z.literal(1),
  eventId: wire.eventId,
  eventReference: wire.eventReference,
  deliveryId: wire.deliveryId,
  policyRevision: z.literal(EVENT_POLICY_V1.initialPolicyRevision),
  source: z.unknown().transform((value, context): Snapshot => {
    const parsed = parseEventMessagePreparationResult(value);
    if (!parsed || parsed.status !== "eligible") {
      context.addIssue({ code: "custom", message: "invalid message source" });
      return z.NEVER;
    }
    return parsed;
  }),
  consumerCheckedAt: z.iso.datetime({ precision: 3 }),
  consumerLeaseUntil: z.iso.datetime({ precision: 3 }),
});
export type MessageDeliverySourceV1 = z.infer<typeof schema>;

/** Metadata only: callers must freshly establish authority and verify the delivery digest. */
export function parseMessageDeliverySource(value: unknown): MessageDeliverySourceV1 | null {
  return parseMessageDeliverySourceInner(value, false) as MessageDeliverySourceV1 | null;
}

/** Parses pre-activation source snapshots; callers must prove retained-attempt recovery custody. */
export function parseHistoricalMessageDeliverySource(value: unknown): HistoricalMessageDeliverySourceV1 | null {
  return parseMessageDeliverySourceInner(value, true) as HistoricalMessageDeliverySourceV1 | null;
}

function parseMessageDeliverySourceInner(value: unknown, allowHistorical: boolean): MessageDeliverySourceV1 | HistoricalMessageDeliverySourceV1 | null {
  try {
    if (new TextEncoder().encode(JSON.stringify(value)).byteLength > 8192) return null;
    if (value === null || typeof value !== "object" || Array.isArray(value)) return null;
    const raw = value as Record<string, unknown>;
    if (!Object.hasOwn(raw, "source")) return null;
    const parsedSource = parseEventMessagePreparationResult(raw.source);
    const historicalSource = !parsedSource && allowHistorical ? parseHistoricalSnapshot(raw.source) : null;
    const source = parsedSource?.status === "eligible" ? parsedSource : historicalSource;
    const { source: _source, ...outer } = raw;
    const result = schema.omit({ source: true }).safeParse(outer);
    if (!result.success || !source) return null;
    if (
      !wire.canonicalSubject.safeParse(source.canonicalSubject).success ||
      !wire.principal.safeParse(source.publication.principal).success ||
      !wire.agent.safeParse(source.publication.agent).success ||
      Date.parse(result.data.consumerLeaseUntil) <= Date.parse(result.data.consumerCheckedAt)
    )
      return null;
    return { ...result.data, source } as MessageDeliverySourceV1 | HistoricalMessageDeliverySourceV1;
  } catch {
    return null;
  }
}

function parseHistoricalSnapshot(value: unknown): HistoricalSnapshot | null {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return null;
  const raw = value as Record<string, unknown>;
  const expected = ["status", "publication", "canonicalSubject", "sourceStateVersion", "policyFingerprint", "route",
    "keyThumbprint", "keyFingerprint", "snapshotDigest", "checkedAt"];
  if (Object.keys(raw).length !== expected.length || expected.some(key => !Object.hasOwn(raw, key)) || raw.status !== "eligible") return null;
  const publication = parseEventMessagePublication(raw.publication), subject = raw.canonicalSubject as Record<string, unknown>,
    route = raw.route as Record<string, unknown>;
  if (!publication || subject === null || typeof subject !== "object" || Array.isArray(subject)
    || Object.keys(subject).length !== 4 || subject.kind !== "message" || subject.namespace !== publication.namespace
    || subject.messageId !== publication.messageId || !Number.isSafeInteger(subject.agentIncarnation) || (subject.agentIncarnation as number) < 0
    || publication.publicationId !== JSON.stringify([publication.namespace, publication.principal, publication.agent, subject.agentIncarnation, publication.messageId])
    || route === null || typeof route !== "object" || Array.isArray(route) || Object.keys(route).length !== 2
    || !Number.isSafeInteger(route.generation) || (route.generation as number) <= 0) return null;
  const consumer = parseEventMessageConsumer(route.consumer);
  const digest = (item: unknown) => typeof item === "string" && /^[0-9a-f]{64}$/.test(item);
  if (!consumer || consumer.consumerGeneration !== consumer.attachmentGeneration
    || typeof raw.sourceStateVersion !== "string" || !/^msg:[0-9a-f]{64}$/.test(raw.sourceStateVersion)
    || !digest(raw.policyFingerprint) || !digest(raw.keyFingerprint) || !digest(raw.snapshotDigest)
    || typeof raw.keyThumbprint !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(raw.keyThumbprint)
    || typeof raw.checkedAt !== "string" || !Number.isFinite(Date.parse(raw.checkedAt)) || new Date(raw.checkedAt).toISOString() !== raw.checkedAt) return null;
  return { status: "eligible", publication, canonicalSubject: { kind: "message", namespace: publication.namespace,
    messageId: publication.messageId, agentIncarnation: subject.agentIncarnation as number }, sourceStateVersion: raw.sourceStateVersion,
    policyFingerprint: raw.policyFingerprint as string, route: { generation: route.generation as number, consumer },
    keyThumbprint: raw.keyThumbprint as string, keyFingerprint: raw.keyFingerprint as string,
    snapshotDigest: raw.snapshotDigest as string, checkedAt: raw.checkedAt as string };
}

/** Preserve the existing preparation bytes; policy selection belongs to materialization. */
export function messagePreparationPayload(value: MessageDeliverySourceV1): string {
  return JSON.stringify({
    kind: "message_preparation",
    version: 1,
    eventId: value.eventId,
    eventReference: value.eventReference,
    deliveryId: value.deliveryId,
    source: value.source,
    consumerCheckedAt: value.consumerCheckedAt,
    consumerLeaseUntil: value.consumerLeaseUntil,
  });
}
