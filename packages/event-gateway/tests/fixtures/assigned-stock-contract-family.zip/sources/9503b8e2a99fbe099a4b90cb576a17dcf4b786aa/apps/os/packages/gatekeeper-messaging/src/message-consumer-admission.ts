import { principalAllowed } from "gatekeeper-memory/src/principals.ts";
import { mailboxName } from "./model.ts";
import { credentialActive } from "./registry.ts";
import { parseMessageConsumerQuery, parseMessageConsumerSnapshot, type MessageConsumerQueryV1 } from "./message-route-control-contract.ts";
import { MESSAGE_CONSUMER_DEADLINE_MS, type MessageRouteControlEnvironment } from "./message-route-control.ts";

/** Per-call commit fence: null/false is authoritative denial; unavailable preserves retry.
 * It grants no route transfer or terminal settlement. */
export function createMessageConsumerAdmission(
  storage: DurableObjectStorage, selfName: string | undefined, env: MessageRouteControlEnvironment,
): (input: MessageConsumerQueryV1) => Promise<(() => boolean | "unavailable") | null | "unavailable"> {
  return async input => {
    const query = parseMessageConsumerQuery(input);
    const service = env.EVENT_MESSAGE_CONSUMER;
    const config = { MESSAGING_NAMESPACE: env.MESSAGING_NAMESPACE, ALLOWED_PRINCIPALS: env.ALLOWED_PRINCIPALS };
    if (!query || !service || typeof service.verifyMessageConsumer !== "function") return null;
    const selected = JSON.stringify(query.consumer);
    const currentKey = (): string | null => {
      if (env.EVENT_MESSAGE_CONSUMER !== service || env.MESSAGING_NAMESPACE !== config.MESSAGING_NAMESPACE
        || env.ALLOWED_PRINCIPALS !== config.ALLOWED_PRINCIPALS || !config.MESSAGING_NAMESPACE
        || selfName !== mailboxName(config.MESSAGING_NAMESPACE, query.principal)
        || !principalAllowed(config, query.principal)
        || !credentialActive(storage.sql, query.agent, query.keyThumbprint)) return null;
      const agent = storage.sql.exec("SELECT name,kind,created_at,suspended_at FROM agents WHERE name=?", query.agent).toArray()[0];
      const key = storage.sql.exec<{ state: string }>(
        "SELECT agent,thumbprint,x,created_at,state FROM agent_keys WHERE agent=? AND thumbprint=?", query.agent, query.keyThumbprint,
      ).toArray()[0];
      return agent && key?.state === "active" ? JSON.stringify([agent, key]) : null;
    };
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      const fingerprint = currentKey();
      if (!fingerprint) return null;
      const started = Date.now();
      const response = await Promise.race([
        service.verifyMessageConsumer(structuredClone(query)),
        new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error("consumer unavailable")), MESSAGE_CONSUMER_DEADLINE_MS); }),
      ]);
      const parsed = parseMessageConsumerSnapshot(response);
      if (parsed?.status === "denied") return null;
      if (!parsed || parsed.status !== "current" || JSON.stringify(parsed.consumer) !== selected) return "unavailable";
      // Copy only validated scalars; neither the service nor another call can refresh this proof.
      const checkedAt = Date.parse(parsed.checkedAt), leaseUntil = Date.parse(parsed.leaseUntil);
      const check = (): boolean | "unavailable" => {
        try {
          const now = Date.now();
          if (JSON.stringify(query.consumer) !== selected || currentKey() !== fingerprint) return false;
          return checkedAt >= started && checkedAt <= now && now - checkedAt <= MESSAGE_CONSUMER_DEADLINE_MS
            && leaseUntil > now ? true : "unavailable";
        } catch { return "unavailable"; }
      };
      const outcome = check();
      return outcome === true ? check : outcome === "unavailable" ? outcome : null;
    } catch { return "unavailable"; }
    finally { if (timer !== undefined) clearTimeout(timer); }
  };
}
