import { z } from 'zod';

export const GITHUB_EVENT_READ_PATH = '/v1/github/event/read';
const positive = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);
export const GitHubEventReadRequestSchema = z.strictObject({ eventReference: z.string().regex(/^ref_[0-9a-f-]{36}$/) });
export const GitHubEventReadResultSchema = z.discriminatedUnion('status', [
  z.strictObject({ status: z.literal('ok'), subject: z.strictObject({ installationId: positive, repositoryId: positive, prNumber: positive }),
    sourceVersion: positive, eventKind: z.enum(['attention', 'ci', 'terminal']),
    reasonCode: z.enum(['review_requested', 'review_submitted', 'review_comment', 'check_failed', 'status_failed', 'pull_request_closed', 'pull_request_merged']),
    candidateGeneration: positive, observedAt: positive }),
  z.strictObject({ status: z.enum(['unavailable', 'conflict']) }),
]);
export type GitHubEventReadResult = z.infer<typeof GitHubEventReadResultSchema>;
