/**
 * Private Execution → Messaging contract (R4 plan 7.6): which inbox message started which run. Closed V1.
 * Every input is parsed field by field before any Mailbox is touched, and an extra key is refused, so a
 * future claim cannot quietly become an authority input. Add to a shape parser-first (FC-15): deploy the
 * receiving side's parser accepting the new key before any sender emits it. `unavailable` is a refusal.
 *
 * One message, one run (7.6.4). The protocol, which Execution follows exactly:
 *  1. verifyOrigin at propose, and again at apply, BEFORE bindOrigin and never after it. A message bound to
 *     any run, its own included, fails verifyOrigin: the plan's "not bound to a different run" cannot be told
 *     apart without the run digest, which this closed input does not carry, and refusing is the safe side.
 *  2. bindOrigin, then start the run. `bound` is the only go-ahead and is given once per message. Eligibility
 *     is checked again in that step, and a run digest that releaseOrigin has answered for (`released` or
 *     `not_bound`) is refused (`denied`): a bind that arrives late, after the release it was racing, binds
 *     nothing. `already_bound` means do not start: an earlier attempt's outcome is unknown, and a retry must
 *     not become a second run.
 *  3. releaseOrigin only when the run definitively did not start (the runtime refused it, or its start was never
 *     sent). It frees the binding for the run and workspace that made it, and not once a report shows the run
 *     past `authorized`. Its answer says what is known: `released` (it held the message, and no longer does) and
 *     `not_bound` (nothing of this run, by its digest and workspace, holds the message) both mean the message is
 *     free of this run; `denied` (the owner is refused) and `unknown` (this run holds it and it cannot be freed:
 *     it may have started) mean it may still be held, as do `unavailable` and `invalid`. A caller that needs the
 *     message free treats only the first two as free. If the start call throws, release nothing.
 *  4. reportRun any time after; it moves a run forward, never back.
 * A forward is only as good as every hop of its chain: each sender is an agent of this owner, unsuspended,
 * with its grant still covering its hop, and the root is a request (G25).
 *
 * Free of Worker types, and of imports but the pure authority package: Execution (the consumer) imports the result parser from here. The AuthorityMemory
 * contract (Memory's door to the agent registry) is in authority/src/memory-contract.ts, where Memory can import it without a package cycle; it is
 * re-exported at the end of this file so Messaging's own code and tests keep one path.
 */

import { AGENT, DIGEST, MESSAGE_ID, REFUSALS, THUMBPRINT, WORKSPACE, matches, plain, principal } from "authority/src/contract-kit.ts";

export type OriginSenderV1 = Readonly<{
  principal: string;
  agent: string;
  client: string;
  /** The thumbprint of the key the sender signed in with, on an "mcp-signed" message. */
  jkt?: string;
}>;

export type OriginV1 = Readonly<{
  /** The principal whose Mailbox answered, from the Mailbox itself and not an echo of the request. The consumer compares it with the owner it verified itself (VS-28). */
  owner: string;
  messageId: string;
  kind: "request" | "forward";
  /** Hex sha256 of the message's receipt, as `receiptDigest()` in receipts.ts. */
  receiptDigest: string;
  /** At most 200 characters, agent-written: the card escapes it. */
  subject: string;
  sender: OriginSenderV1;
  recipientAgent: string;
  /** The message's checked type: a forward's is its root's (G25). */
  taskType: string;
  messageExpiresAt: string | null;
  /** No order evidence until P5b; the consumer refuses anything but null. */
  order: null;
}>;

export type VerifyOriginResultV1 = Readonly<{ status: "ok"; origin: OriginV1 }> | Readonly<{ status: "denied" | "unavailable" | "invalid" }>;
export type BindOriginResultV1 = Readonly<{ status: "bound" | "already_bound" | "denied" | "unavailable" | "invalid" }>;
export type ReleaseOriginResultV1 = Readonly<{ status: "released" | "not_bound" | "denied" | "unknown" | "unavailable" | "invalid" }>;
export type ReportRunResultV1 = Readonly<{ status: "recorded" | "denied" | "unavailable" | "invalid" }>;

export type RunStateV1 = "requested" | "authorized" | "running" | "succeeded" | "failed" | "cancelled" | "expired" | "unknown";

export type VerifyOriginInputV1 = Readonly<{ owner: string; workspaceId: string; messageId: string; expectTaskType: string }>;
export type RunOriginInputV1 = Readonly<{ owner: string; workspaceId: string; messageId: string; runDigest: string }>;
export type ReportRunInputV1 = Readonly<{
  owner: string;
  messageId: string;
  orderActDigest: string | null;
  state: RunStateV1;
  requestDigest: string;
  receiptDigest: string | null;
}>;

/** The Execution gatekeeper's binding. `owner` and `workspaceId` are the host-attested pair it already validates. */
export interface AuthorityExecutionServiceV1 {
  verifyOrigin(input: VerifyOriginInputV1): Promise<VerifyOriginResultV1>;
  bindOrigin(input: RunOriginInputV1): Promise<BindOriginResultV1>;
  releaseOrigin(input: RunOriginInputV1): Promise<ReleaseOriginResultV1>;
  reportRun(input: ReportRunInputV1): Promise<ReportRunResultV1>;
}

/** Exported with the other grammars, so Execution reports in the same words. */
export const RUN_STATES: readonly unknown[] = ["requested", "authorized", "running", "succeeded", "failed", "cancelled", "expired", "unknown"];
const BIND_STATUSES: readonly unknown[] = ["bound", "already_bound", "denied", "unavailable", "invalid"];
const REPORT_STATUSES: readonly unknown[] = ["recorded", "denied", "unavailable", "invalid"];
const RELEASE_STATUSES: readonly unknown[] = ["released", "not_bound", "denied", "unknown", "unavailable", "invalid"];

/** Exported for Execution's run origin (gatekeeper-execution origin.ts): one grammar for the id on both sides of the contract. */
export { MESSAGE_ID };
const TASK_TYPE = /^[a-z0-9\-/]{1,64}$/;
const CLIENT = /^[a-z0-9-]{1,32}$/;
/** Execution's request digest, in the one spelling that names it: a second spelling would be a second identity (bind with one, release with the other). */
const RUN_DIGEST = /^sha256:[0-9a-f]{64}$/;
/** The other digests: Messaging's own are bare hex, Execution's `sha256:`-prefixed. */
export { DIGEST };
const SUBJECT_CODE_POINTS = 200;
const TIME_LENGTH = 40;

/**
 * The consumer's side of reportRun: exactly `{ status }`, one of the closed set, rebuilt as a new object; anything else
 * is `invalid`. Only an exact `recorded` says Messaging has the state.
 */
export function parseReportRunResult(value: unknown): ReportRunResultV1 {
  const top = plain(value, ["status"]);
  return top && REPORT_STATUSES.includes(top.status) ? { status: top.status as ReportRunResultV1["status"] } : { status: "invalid" };
}

/**
 * The consumer's side of bindOrigin: exactly `{ status }`, one of the closed set, rebuilt as a new object; anything else
 * is `invalid`, which authorizes nothing. Only an exact `bound` is a go-ahead.
 */
export function parseBindOriginResult(value: unknown): BindOriginResultV1 {
  const top = plain(value, ["status"]);
  return top && BIND_STATUSES.includes(top.status) ? { status: top.status as BindOriginResultV1["status"] } : { status: "invalid" };
}

/**
 * The consumer's side of releaseOrigin: exactly `{ status }`, one of the closed set, rebuilt as a new object (an RPC
 * result's own Symbol.dispose is left behind); anything else is `invalid`, which frees nothing.
 */
export function parseReleaseOriginResult(value: unknown): ReleaseOriginResultV1 {
  const top = plain(value, ["status"]);
  return top && RELEASE_STATUSES.includes(top.status) ? { status: top.status as ReleaseOriginResultV1["status"] } : { status: "invalid" };
}

export function parseVerifyOriginInput(value: unknown): VerifyOriginInputV1 | null {
  const input = plain(value, ["owner", "workspaceId", "messageId", "expectTaskType"]);
  if (!input) return null;
  const { owner, workspaceId, messageId, expectTaskType } = input;
  if (!principal(owner) || !matches(workspaceId, WORKSPACE) || !matches(messageId, MESSAGE_ID) || !matches(expectTaskType, TASK_TYPE)) return null;
  return { owner, workspaceId, messageId, expectTaskType };
}

/** The input of bindOrigin and releaseOrigin alike. */
export function parseRunOriginInput(value: unknown): RunOriginInputV1 | null {
  const input = plain(value, ["owner", "workspaceId", "messageId", "runDigest"]);
  if (!input) return null;
  const { owner, workspaceId, messageId, runDigest } = input;
  if (!principal(owner) || !matches(workspaceId, WORKSPACE) || !matches(messageId, MESSAGE_ID) || !matches(runDigest, RUN_DIGEST)) return null;
  return { owner, workspaceId, messageId, runDigest };
}

export function parseReportRunInput(value: unknown): ReportRunInputV1 | null {
  const input = plain(value, ["owner", "messageId", "orderActDigest", "state", "requestDigest", "receiptDigest"]);
  if (!input) return null;
  const { owner, messageId, orderActDigest, state, requestDigest, receiptDigest } = input;
  if (!principal(owner) || !matches(messageId, MESSAGE_ID) || !matches(requestDigest, RUN_DIGEST)) return null;
  if (!RUN_STATES.includes(state)) return null;
  if (orderActDigest !== null && !matches(orderActDigest, DIGEST)) return null;
  if (receiptDigest !== null && !matches(receiptDigest, DIGEST)) return null;
  return { owner, messageId, orderActDigest, state: state as RunStateV1, requestDigest, receiptDigest };
}

/**
 * The consumer's side: a result rebuilt field by field, or `invalid`. Exact keys at every level, and the
 * principals must be the one `owner` the caller verified itself: Messaging is trusted for what the signed
 * message cannot say, never to name the person (VS-28), and R4 runs are same-owner (D13, VS-07). The
 * returned object is new: an RPC result's own Symbol.dispose, or any other symbol, is left behind.
 */
export function parseVerifyOriginResult(value: unknown, owner: string): VerifyOriginResultV1 {
  const invalid = { status: "invalid" } as const;
  const top = plain(value, ["status"], ["origin"]);
  if (!top) return invalid;
  if (top.status !== "ok") return REFUSALS.includes(top.status) && !Object.hasOwn(top, "origin") ? { status: top.status as "denied" | "unavailable" | "invalid" } : invalid;
  const origin = plain(top.origin, ["owner", "messageId", "kind", "receiptDigest", "subject", "sender", "recipientAgent", "taskType", "messageExpiresAt", "order"]);
  const sender = plain(origin?.sender, ["principal", "agent", "client"], ["jkt"]);
  if (!origin || !sender) return invalid;
  if (origin.owner !== owner || sender.principal !== owner) return invalid;
  if (!matches(origin.messageId, MESSAGE_ID) || (origin.kind !== "request" && origin.kind !== "forward")) return invalid;
  if (!matches(origin.receiptDigest, DIGEST) || !matches(origin.recipientAgent, AGENT) || !matches(origin.taskType, TASK_TYPE)) return invalid;
  if (typeof origin.subject !== "string" || origin.subject.length > 4 * SUBJECT_CODE_POINTS || [...origin.subject].length > SUBJECT_CODE_POINTS) return invalid;
  if (origin.messageExpiresAt !== null && (typeof origin.messageExpiresAt !== "string" || origin.messageExpiresAt.length > TIME_LENGTH)) return invalid;
  if (origin.order !== null) return invalid;
  if (!matches(sender.agent, AGENT) || !matches(sender.client, CLIENT)) return invalid;
  if (sender.jkt !== undefined && !matches(sender.jkt, THUMBPRINT)) return invalid;
  return {
    status: "ok",
    origin: {
      owner,
      messageId: origin.messageId,
      kind: origin.kind,
      receiptDigest: origin.receiptDigest,
      subject: origin.subject,
      sender: { principal: owner, agent: sender.agent, client: sender.client, ...(sender.jkt === undefined ? {} : { jkt: sender.jkt }) },
      recipientAgent: origin.recipientAgent,
      taskType: origin.taskType,
      messageExpiresAt: origin.messageExpiresAt,
      order: null,
    },
  };
}

export * from "authority/src/memory-contract.ts";
