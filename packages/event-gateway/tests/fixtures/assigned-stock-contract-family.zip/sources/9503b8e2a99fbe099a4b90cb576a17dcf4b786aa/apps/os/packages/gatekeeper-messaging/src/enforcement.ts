// Liveness and enforcement (R4 plan 6.3, 5.11, VS-21): when a kind of act may be `enforce`d for a person, and what that means for a widening call. Plain
// synchronous functions over the Mailbox's SQLite. Nothing calls `widening` yet: the per-RPC tier checks arrive with P5c, and until then every kind is
// `observe` or `off` in the deployed configuration. This is the rule they will ask, built and tested first.
//
// The effective mode is min(requested, allowed). `enforce` needs two active credentials AND a liveness record that covers the CURRENT pin set; without either
// it degrades to `observe`, and the view says why. Two things never degrade silently:
//  - a person with no active credential under `enforce` has widening REFUSED, not downgraded (VS-21);
//  - once a kind has been `enforce` with both, it LATCHES: losing a key leaves it `enforce` (the remaining key still signs), and a pin-set change that
//    uncovers liveness refuses widening until a new record covers the new set. Only the configuration relaxes it: a latch for a kind no longer requested as
//    `enforce` is dropped, and nothing else drops one.

import { PINS_DOMAIN } from "authority/src/act.ts";
import { domainDigestHex } from "authority/src/canonical.ts";
import { pinSetOf, type PinnedPresence } from "authority/src/webauthn.ts";
import { ENFORCED_KINDS, type EnforcedKind, type Mode, type PresenceConfig } from "./presence.ts";
import { activeRows, readRows } from "./credentials.ts";
import type { EnforcementKindView, EnforcementView } from "./admin-types.ts";

/** The pins of `principal` from the deployed configuration, sorted: the set a liveness act lists. Never read from the database. */
export const pinsFor = (config: PresenceConfig, principal: string): string[] => pinSetOf(config.pinned.anchors, principal);
export const pinDigestOf = (thumbprints: readonly string[]): Promise<string> => domainDigestHex(PINS_DOMAIN, thumbprints);

/** What a pin-set change needs to know to latch what was met under the old set. */
export type Stretch = { config: PresenceConfig; principal: string; now: number };

/**
 * How many credentials were active under the pins an epoch was recorded with (a JSON list of thumbprints), not the deployment's pins now: a deploy that removes a pin
 * must not make the old rule look unmet. A NULL or unreadable list is unknown, and unknown counts as met (the covering record already proves every old pin touched): fail closed.
 */
function activeUnder(sql: SqlStorage, pins: string | null, at: Stretch): number {
  try {
    const list: unknown = pins === null ? null : JSON.parse(pins);
    if (!Array.isArray(list) || !list.every((t) => typeof t === "string")) return 2;
    return activeRows(readRows(sql), { anchors: list.map((thumbprint) => ({ principal: at.principal, thumbprint, label: "" })) } satisfies Pick<PinnedPresence, "anchors">, at.principal, at.now).length;
  } catch {
    return 2;
  }
}

/**
 * Which stretch of the deployment's life the pin set `digest` is current in, as a count: it goes up each time the Mailbox finds the deployed pin set to be a
 * different one from the last it saw. A liveness record is stamped with it, so a record covers the pin set only for the stretch it was made in: going back to
 * an old pin set (A, B, A) is a new stretch and an old record does not cover it (plan 6.3 says "current"). Limit, stated: a change is seen when the Mailbox next
 * looks (any ceremony, act, registration or view), so a pin set deployed and reverted with nothing touched in between is not seen.
 */
export function currentEpoch(sql: SqlStorage, digest: string, at: Stretch): number {
  const row = sql.exec<{ digest: string; n: number; pins: string | null }>("SELECT digest, n, pins FROM pin_epoch WHERE id = 1").toArray()[0];
  if (row?.digest === digest) return row.n;
  // The pin-set change is a write point for latches: a rule that was met under the OLD pin set (two active keys and a record covering it) and is requested as
  // `enforce` now is latched BEFORE the epoch moves, which is what uncovers liveness. Callers read the latches after livenessCovers for this reason.
  if (row && sql.exec<{ n: number }>("SELECT count(*) AS n FROM liveness_records WHERE pin_set_digest = ? AND epoch = ?", row.digest, row.n).one().n > 0 && activeUnder(sql, row.pins, at) >= 2) {
    const have = latchedKinds(sql);
    for (const kind of ENFORCED_KINDS) if (at.config.enforce[kind] === "enforce" && !have.has(kind)) sql.exec("INSERT INTO enforcement_latch (kind, latched_at) VALUES (?, ?)", kind, at.now);
  }
  const n = (row?.n ?? 0) + 1;
  sql.exec("INSERT OR REPLACE INTO pin_epoch (id, digest, n, pins) VALUES (1, ?, ?, ?)", digest, n, JSON.stringify(pinsFor(at.config, at.principal)));
  return n;
}

/** Whether a completed liveness ceremony covers the pin set `digest` names, in the stretch it is current in now. */
export const livenessCovers = (sql: SqlStorage, digest: string, at: Stretch): boolean =>
  sql.exec<{ n: number }>("SELECT count(*) AS n FROM liveness_records WHERE pin_set_digest = ? AND epoch = ?", digest, currentEpoch(sql, digest, at)).one().n > 0;

export const livenessAt = (sql: SqlStorage, digest: string, at: Stretch): number | null =>
  sql.exec<{ at: number | null }>("SELECT max(completed_at) AS at FROM liveness_records WHERE pin_set_digest = ? AND epoch = ?", digest, currentEpoch(sql, digest, at)).one().at;

export type Facts = { active: number; liveness: boolean; latched: boolean };
export type Verdict = Pick<EnforcementKindView, "effective" | "widening" | "reason">;

/** The rule, over the facts it reads (plan 6.3 "Enforcement latches", VS-21). */
export function evaluate(requested: Mode, facts: Facts): Verdict {
  if (requested !== "enforce") return { effective: requested, widening: "session", reason: null };
  if (facts.active === 0) return { effective: "enforce", widening: "refused", reason: "no_active_credential" };
  if (facts.latched) return facts.liveness ? { effective: "enforce", widening: "proof", reason: null } : { effective: "enforce", widening: "refused", reason: "liveness_missing" };
  if (facts.active < 2) return { effective: "observe", widening: "session", reason: "credentials_below_two" };
  if (!facts.liveness) return { effective: "observe", widening: "session", reason: "liveness_missing" };
  return { effective: "enforce", widening: "proof", reason: null };
}

const latchedKinds = (sql: SqlStorage): Set<string> => new Set(sql.exec<{ kind: string }>("SELECT kind FROM enforcement_latch").toArray().map((r) => r.kind));
/**
 * A latch counts only while the configuration still requests `enforce` for its kind. refreshLatches drops the rest; this keeps a stale one from being read before it does.
 * `met`: the rule is met right now, which reads as latched without writing it: a read never takes a latch, a write point does (see refreshLatches).
 */
const latched = (have: Set<string>, config: PresenceConfig, kind: EnforcedKind, met: boolean): boolean => config.enforce[kind] === "enforce" && (have.has(kind) || met);
const ruleMet = (active: number, covered: boolean): boolean => active >= 2 && covered;

/**
 * Brings the latches in line with now: a kind requested as `enforce` that meets the rule is latched, and one no longer requested as `enforce` is not. Called
 * inside the transaction of every change that can move the facts (a registration, an act, a revocation, a liveness record), so the latch is taken at the
 * moment the rule is first met and not whenever somebody next looks. A change that can only LOWER the facts (a revocation) calls it BEFORE it writes, so a rule
 * met until that moment is latched first; a read never calls it. The GET writes no latch rows, except at a pin-set change, where currentEpoch records the epoch and stores latches for a rule that was met; a
 * view and `widening` otherwise count a met rule as latched without storing it. Limits, stated: a latch is dropped for a kind no longer requested at the next write point (a stale one is hidden on read), so enforce, then observe,
 * then enforce again with no write between reuses the old latch, and asking for enforce again in the same deploy as a pin change inherits a latch from facts met while the kind was relaxed: stricter, and both fail closed.
 */
export function refreshLatches(sql: SqlStorage, config: PresenceConfig, principal: string, now: number, digest: string): void {
  const rows = readRows(sql);
  const active = activeRows(rows, config.pinned, principal, now).length;
  const covered = livenessCovers(sql, digest, { config, principal, now });
  const have = latchedKinds(sql); // after livenessCovers: a pin-set change latches inside it
  for (const kind of ENFORCED_KINDS) {
    const requested = config.enforce[kind];
    if (requested !== "enforce") {
      if (have.has(kind)) sql.exec("DELETE FROM enforcement_latch WHERE kind = ?", kind);
    } else if (!have.has(kind) && ruleMet(active, covered)) {
      sql.exec("INSERT INTO enforcement_latch (kind, latched_at) VALUES (?, ?)", kind, now);
    }
  }
}

/**
 * What widening `kind` needs of `principal` right now: `session` (the legacy path stands), `proof` (a hardware proof) or `refused`. The question P5c's per-RPC
 * checks ask; the admin view lists the answer for every kind.
 */
export function widening(sql: SqlStorage, config: PresenceConfig | null, principal: string, kind: EnforcedKind, now: number, digest: string): Verdict {
  if (config === null) return { effective: "off", widening: "session", reason: null };
  const active = activeRows(readRows(sql), config.pinned, principal, now).length;
  const covered = livenessCovers(sql, digest, { config, principal, now });
  return evaluate(config.enforce[kind], { active, liveness: covered, latched: latched(latchedKinds(sql), config, kind, ruleMet(active, covered)) });
}

export function view(sql: SqlStorage, config: PresenceConfig, principal: string, now: number, digest: string): EnforcementView {
  const pins = pinsFor(config, principal);
  const active = activeRows(readRows(sql), config.pinned, principal, now).length;
  const stretch = { config, principal, now };
  const covered = livenessCovers(sql, digest, stretch);
  const have = latchedKinds(sql); // after livenessCovers: a pin-set change latches inside it
  const at = livenessAt(sql, digest, stretch);
  const met = ruleMet(active, covered);
  return {
    enabled: true,
    activeCredentials: active,
    liveness: { covered, at: at === null ? null : new Date(at).toISOString(), pinned: pins, expected: config.livenessAnchors[principal] ?? null },
    kinds: ENFORCED_KINDS.map((kind) => ({ kind, requested: config.enforce[kind], latched: latched(have, config, kind, met), ...evaluate(config.enforce[kind], { active, liveness: covered, latched: latched(have, config, kind, met) }) })),
  };
}
