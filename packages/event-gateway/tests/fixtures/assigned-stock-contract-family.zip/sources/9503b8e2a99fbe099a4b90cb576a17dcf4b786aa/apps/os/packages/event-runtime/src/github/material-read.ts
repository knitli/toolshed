import { GITHUB_MATERIAL_RESPONSE_BYTES, GITHUB_MATERIAL_TEXT_UNITS, GitHubMaterialScreenReportSchema, encodeMaterialCursor, parseMaterialCursor, type GitHubMaterialReadRequest, type GitHubMaterialReadResult, type GitHubMaterialScreenReport } from './material-read-contract';
import { screen, SCREEN_VERSION } from 'authority/src/text.ts';

export const materialDigest = async (value: string): Promise<string> => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value)))].map(byte => byte.toString(16).padStart(2, '0')).join('');
export const GITHUB_REVIEW_STATES = ['APPROVED', 'CHANGES_REQUESTED', 'COMMENTED', 'DISMISSED', 'PENDING'] as const;
export type GitHubReviewState = typeof GITHUB_REVIEW_STATES[number];
export const GITHUB_REVIEW_FINGERPRINT_STATES: readonly GitHubReviewState[] = GITHUB_REVIEW_STATES.filter(state => state !== 'PENDING');
/** Stable with the provider's canonical JSON for the two-string [body,state] tuple. */
export const githubReviewFingerprint = async (body: string, state: GitHubReviewState): Promise<string> =>
  materialDigest(JSON.stringify([body, state]));
/** Caller must revalidate authority and retained material after this asynchronous digest. */
export async function materialPage(request: GitHubMaterialReadRequest, material: { body: string; firstVersion: number }, authorityBinding: unknown, digest?: string): Promise<GitHubMaterialReadResult> {
  if (request.representation !== 'screened-v1') {
    const bodyDigest = digest ?? await materialDigest(material.body);
    const binding = await materialDigest(JSON.stringify([authorityBinding, request.subject, request.sourceId, request.fingerprint, request.fromVersion, request.toVersion, material.firstVersion, bodyDigest]));
    return materialPageWithDigests(request, material, bodyDigest, binding);
  }
  const sourceBodyDigest = digest ?? await materialDigest(material.body);
  let screened: ReturnType<typeof screen>;
  try { screened = screen(material.body); } catch { return { status: 'unavailable' }; }
  if (screened.text.length > GITHUB_MATERIAL_TEXT_UNITS) return { status: 'unavailable' };
  const parsedReport = GitHubMaterialScreenReportSchema.safeParse(screened.report);
  if (SCREEN_VERSION !== 1 || !parsedReport.success) return { status: 'unavailable' };
  const bodyDigest = await materialDigest(screened.text);
  const report = parsedReport.data;
  const binding = await materialDigest(JSON.stringify([authorityBinding, request.subject, request.sourceId, request.fingerprint,
    request.fromVersion, request.toVersion, material.firstVersion, 'screened-v1', sourceBodyDigest, bodyDigest, report]));
  return materialPageInternal(request, { ...material, body: screened.text }, bodyDigest, binding,
    { representation: 'screened-v1', sourceBodyDigest, screening: report });
}
/** Pure sizing and slicing path, also used by initial-custody preflight with fixed-length digest placeholders. */
export function materialPageWithDigests(request: GitHubMaterialReadRequest, material: { body: string; firstVersion: number },
  bodyDigest: string, binding: string): GitHubMaterialReadResult {
  return materialPageInternal(request, material, bodyDigest, binding);
}
function materialPageInternal(request: GitHubMaterialReadRequest, material: { body: string; firstVersion: number },
  bodyDigest: string, binding: string, screened?: { representation: 'screened-v1'; sourceBodyDigest: string; screening: GitHubMaterialScreenReport }): GitHubMaterialReadResult {
  const cursor = request.cursor === undefined ? null : parseMaterialCursor(request.cursor);
  if (request.cursor !== undefined && (!cursor || cursor.binding !== binding)) return { status: 'conflict' };
  const offset = cursor?.offset ?? 0;
  if (offset > material.body.length || offset > 0 && offset === material.body.length
    || offset > 0 && /[\uD800-\uDBFF]/.test(material.body[offset - 1]!) && /[\uDC00-\uDFFF]/.test(material.body[offset]!)) return { status: 'conflict' };
  let end = Math.min(material.body.length, offset + 2048);
  for (;;) {
    if (end < material.body.length && /[\uD800-\uDBFF]/.test(material.body[end - 1]!) && /[\uDC00-\uDFFF]/.test(material.body[end]!)) end--;
    if (end === offset && material.body.length !== 0) return { status: 'unavailable' };
    const complete = end === material.body.length;
    const page = { status: 'ok' as const, subject: request.subject, sourceId: request.sourceId, fingerprint: request.fingerprint,
      requestedRange: { fromVersion: request.fromVersion, toVersion: request.toVersion }, firstVersion: material.firstVersion, bodyDigest, offset, totalLength: material.body.length, body: material.body.slice(offset, end),
      ...screened,
      nextCursor: complete ? null : encodeMaterialCursor({ binding, offset: end }), complete };
    if (new TextEncoder().encode(JSON.stringify(page)).length <= GITHUB_MATERIAL_RESPONSE_BYTES) return page;
    if (end === offset) return { status: 'unavailable' };
    end = offset + Math.floor((end - offset) / 2);
  }
}
