import { createHash } from "node:crypto";
import { canonicalJson } from "@knitli/openapi-mcp/runtime";
import type { ActivationClaimV1, ActivationSourceV1, EventSourceActivationResultV1 } from "./event-authority-contract.ts";
import { policyOf, wakeAllowed, type ActivationVerdictV1 } from "./activation.ts";
import { GITHUB_WATCH_TASK_TYPE, liveGitHubSourceOrderFor, type CredentialLive, type GitHubSourceIdentityV1 } from "./orders.ts";
import * as tasks from "./tasks.ts";

const digest = (text: string): string => createHash("sha256").update(text).digest("hex");
type Source = Exclude<ActivationSourceV1, { kind: "message" }>;
type Identity = Readonly<{ principal: string; agent: string; live: CredentialLive }>;
type Snapshot = Readonly<{ source: Source; claim: ActivationClaimV1; canonical: string }>;

function readSnapshot(sql: SqlStorage, identity: Identity, source: Source, now: number): Snapshot | null {
  const agent = sql.exec<{ kind: string; created_at: number; suspended_at: number | null }>(
    "SELECT kind,created_at,suspended_at FROM agents WHERE name=?", identity.agent,
  ).toArray()[0];
  const policy = policyOf(sql, identity.agent);
  if (!agent || agent.kind !== "external" || agent.suspended_at !== null || !policy)
    return null;

  const task = source.kind === "github" ? tasks.declaredType(sql, identity.agent, GITHUB_WATCH_TASK_TYPE) : null;
  const order = source.kind === "github"
    ? liveGitHubSourceOrderFor(sql, identity.agent, {
      installationId: source.installationId,
      repositoryId: source.repositoryId,
      prNumber: source.prNumber,
      sourceIncarnation: source.sourceIncarnation,
    } satisfies GitHubSourceIdentityV1, { owner: identity.principal, live: identity.live }, now)
    : null;
  if (source.kind === "github" && (!task || !order)) return null;

  const facts = {
    sender: `${identity.principal}/owner`, transport: "event" as const, order, ownerDirect: source.kind === "manual",
    suspended: agent.suspended_at !== null, overBudget: false,
  };
  const verdict: ActivationVerdictV1 = wakeAllowed(policy, facts);
  if (!verdict.allowed || (source.kind === "github" && verdict.reason !== "order") || (source.kind === "manual" && verdict.reason !== "owner_direct")) return null;
  const sourceId = source.kind === "github"
    ? { kind: source.kind, installationId: source.installationId, repositoryId: source.repositoryId, prNumber: source.prNumber, sourceIncarnation: source.sourceIncarnation }
    : { kind: source.kind, subjectId: source.subjectId, sourceStateVersion: source.sourceStateVersion };
  const policyFingerprint = digest(canonicalJson(["event-activation-policy-v1", policy] as never));
  const canonical = canonicalJson({ version: 1, principal: identity.principal, agent: identity.agent, source: sourceId,
    targetIncarnation: agent.created_at, policy, task,
    orderDigest: verdict.reason === "order" ? verdict.orderDigest : null, verdict } as never);
  const claim: ActivationClaimV1 = {
    version: 1, principal: identity.principal, agent: identity.agent, agentIncarnation: agent.created_at, source: sourceId as Source,
    verdict: verdict.reason === "order" ? { allowed: true, reason: "order", orderDigest: verdict.orderDigest! } : { allowed: true, reason: "owner_direct" },
    policyFingerprint, snapshotDigest: digest(canonical),
  };
  return { source: sourceId as Source, claim, canonical };
}

/** Canonical source-only activation read. The private claim digest binds durable native and stock reservations. */
export function prepareSourceActivation(
  sql: SqlStorage,
  identity: Identity,
  source: Source,
  now = Date.now(),
  expectedSnapshot?: string,
): EventSourceActivationResultV1 {
  try {
    const current = readSnapshot(sql, identity, source, now);
    if (!current) return { status: "denied" };
    if (expectedSnapshot !== undefined && expectedSnapshot !== current.claim.snapshotDigest) return { status: "changed" };
    return { status: "eligible", claim: current.claim };
  } catch {
    return { status: "unavailable" };
  }
}

/** Compares a prepared claim with a fresh canonical read inside the reservation transaction. */
export function sameActivationSnapshot(prepared: ActivationClaimV1, current: ActivationClaimV1): boolean {
  return prepared.version === current.version && prepared.principal === current.principal && prepared.agent === current.agent &&
    prepared.agentIncarnation === current.agentIncarnation &&
    prepared.policyFingerprint === current.policyFingerprint && prepared.snapshotDigest === current.snapshotDigest &&
    JSON.stringify(prepared.source) === JSON.stringify(current.source) && JSON.stringify(prepared.verdict) === JSON.stringify(current.verdict);
}

export function messageActivationClaim(input: Readonly<{
  publication: Readonly<{ namespace: string; principal: string; agent: string; messageId: string }>;
  sourceStateVersion: string;
  agentIncarnation: number;
  routeGeneration: number;
  consumer: import("./event-authority-contract.ts").EventMessageConsumerV1;
  policyFingerprint: string;
  snapshotDigest: string;
  verdict: ActivationVerdictV1;
}>): ActivationClaimV1 | null {
  if (!input.verdict.allowed || !/^msg:[0-9a-f]{64}$/.test(input.sourceStateVersion) ||
      !Number.isSafeInteger(input.agentIncarnation) || input.agentIncarnation < 1 ||
      !Number.isSafeInteger(input.routeGeneration) || input.routeGeneration < 1 ||
      !/^[0-9a-f]{64}$/.test(input.policyFingerprint) || !/^[0-9a-f]{64}$/.test(input.snapshotDigest)) return null;
  const { publication, verdict } = input;
  const common = { version: 1 as const, principal: publication.principal, agent: publication.agent,
    agentIncarnation: input.agentIncarnation, source: { kind: "message" as const, namespace: publication.namespace,
      messageId: publication.messageId, sourceStateVersion: input.sourceStateVersion, agentIncarnation: input.agentIncarnation, routeGeneration: input.routeGeneration,
      consumer: input.consumer }, policyFingerprint: input.policyFingerprint, snapshotDigest: input.snapshotDigest };
  if (verdict.reason === "order" && verdict.orderDigest && /^[0-9a-f]{64}$/.test(verdict.orderDigest))
    return { ...common, verdict: { allowed: true, reason: "order", orderDigest: verdict.orderDigest } };
  if (verdict.reason === "wake_grant" || verdict.reason === "granted") return { ...common, verdict: { allowed: true, reason: verdict.reason } };
  return null;
}
