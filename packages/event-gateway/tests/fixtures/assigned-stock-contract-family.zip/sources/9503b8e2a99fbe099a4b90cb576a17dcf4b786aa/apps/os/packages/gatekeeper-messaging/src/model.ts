// The message model: error codes, limits, input validation and the audience rule's set arithmetic
// (spec "Audience rule", "Data model"). Free of Worker types: receipts.ts imports it, and
// scripts/deploy.ts and scripts/messaging-receipts.ts import receipts.ts under Node.

import { canonicalJson } from "@knitli/openapi-mcp/runtime";
import { canonicalEmail } from "openapi-operator/src/access.ts";
import type { Message, MessageStatus } from "./types.js";
import { GRANT_MAX_MS, isoTime } from "authority/src/contract-kit.ts";
import { describeScreen, escapeHidden, hasInvisibleText, isDense, isPlainText, screen, unescapeHidden, type ScreenReport } from "authority/src/text.ts";

export const CODES = [
  "forbidden", "not_in_audience", "not_found", "expired", "too_large", "depth_exceeded", "inbox_full", "conflict", "unavailable", "invalid", "no_grant", "over_budget", "cancelled", "suspended",
  // R4 P4a: its own code for the taint rule (plan 5.13, 9.5), so it is never read as a missing grant.
  "restricted_taint",
  // R4 P5c-a: a widening call that needs a hardware proof (plan 5.11), and a key no act has listed yet (INV14). Each message ends with where to fix it.
  "proof_required", "key_provisional",
  // R4 P5b: a consequential type outside an ordered thread (plan 5.4), a hop outside its order's envelope (7.4), and an ordered thread whose order this Mailbox does not hold (VS-07).
  "order_required", "out_of_envelope", "order_unknown",
  // R4 P5b 5b-2c (Flow B): an agent asking for an order without the msg.draft right for that agent and type (plan 5.3, VS-13).
  "draft_not_allowed",
] as const;
export type Code = (typeof CODES)[number];

/**
 * Sender labels no caller may claim (VS-20). In a receipt, "os" with an endpoint means a workspace-attested sender,
 * which only the OS session sets; "order" is reserved for a human-ordered root, "platform" and "system" for the
 * platform's own mail, "me" for a person. The MCP door refuses a header naming one, and post() refuses any sender
 * that is not the session's "os", whichever door built it.
 */
export const RESERVED_CLIENTS: readonly string[] = ["os", "order", "platform", "system", "me"];

/** Agents see "<code>: <message>"; Workers RPC keeps an Error's message and drops custom fields. */
export function fail(code: Code, message: string): Error {
  return new Error(`${code}: ${message}`);
}

export function codeOf(error: unknown): Code | undefined {
  if (!(error instanceof Error)) return undefined;
  const colon = error.message.indexOf(": ");
  const code = colon > 0 ? error.message.slice(0, colon) : "";
  return (CODES as readonly string[]).includes(code) ? (code as Code) : undefined;
}

const DAY = 24 * 60 * 60 * 1000;
export const LIMITS = {
  subject: 200,
  body: 16 * 1024,
  message: 64 * 1024,
  depth: 8,
  inbox: 500,
  /** Live inbox rows one agent may hold, read replies aside, inside the Mailbox's `inbox` (R4 G27): one agent flooded with mail cannot block its person's others. */
  inboxPerAgent: 200,
  ttlMs: 30 * DAY,
  /** A request's or forward's deadline when its sender names none (#590): set by Mailbox.issue(), the signer. A reply has none. */
  defaultTtlMs: 7 * DAY,
  idempotencyMs: 7 * DAY,
  grantMs: GRANT_MAX_MS,
  /**
   * Sends refused past these (spec "Budgets"): per sending agent and per (agent, recipient) in a rolling
   * hour, and per thread in all. ponytail: constants for every agent; a per-agent override column in
   * the registry when one agent needs another limit.
   */
  budget: { agentPerHour: 60, pairPerHour: 20, thread: 50, windowMs: 60 * 60 * 1000 },
  /**
   * Wakes (spec "The wake budget"): after one, none until the agent lists its inbox or reads, or
   * pendingMs passes; and at most perHour in a rolling hour. A skipped wake loses nothing: the message
   * is delivered. ponytail: constants for every agent; a per-agent override when one needs another.
   */
  wake: { perHour: 10, pendingMs: 15 * 60 * 1000, windowMs: 3_600_000 },
  /** How long an agent that read restricted memory stays tainted, from its last such read (plan 9.5): sticky, and ended only by the time passing in this phase. */
  taintMs: DAY,
  /** How long an expired inbox row is kept (still listed as expired) before deliver() deletes it. */
  expiredRetentionMs: 7 * DAY,
  /** Task types one grant or acceptance may list (spec 2026-10-01 "Validation"). */
  taskTypesPerGrant: 16,
  // DO storage keys cap at 2 KiB, and the tracker prefixes "msg-audience:" (observers.ts).
  audienceId: 1900,
} as const;

const TASK_TYPE = /^[a-z0-9\-/]{1,64}$/;
const TASK_TYPE_RULE = 'lowercase a-z, 0-9, "-" and "/", at most 64 characters';
const IDEMPOTENCY_KEY = /^[A-Za-z0-9._-]{1,64}$/;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const STATUSES = ["unread", "read", "answered", "expired", "cancelled"] as const;

export type Kind = Message["kind"];
/** How a message was authorized, as its receipt says. "send-self" is MVP-only (v1 receipts). */
export type Applied = "send-self" | "send" | "send-granted" | "mcp-granted" | "mcp-signed" | "mcp-oauth" | "human-ordered";
/** What the broker issues to an agent's message. "human-ordered" is an order's root alone (receipts v3), which no agent sends. */
export type IssuedApplied = Exclude<Applied, "send-self" | "human-ordered">;
/** Internal proof checked again at the final operation; never exposed as a key thumbprint. */
export type AgentCredential =
  | { kind: "key"; thumbprint: string }
  | { kind: "oauth"; profile: string; generation: string; expiresAt: number };
export type OAuthBinding = { profile: string; agent: string; generation: string; leaseExpiresAt: number };
export const OAUTH_LEASE_MS = 15 * 60 * 1000;

export type Flags = { containsRestrictedData: boolean; ownerInvitesOnly: boolean; sharingProhibited: boolean };
export const NO_FLAGS: Flags = { containsRestrictedData: false, ownerInvitesOnly: false, sharingProhibited: false };
export const flagsOf = (f: Flags): Flags => ({
  containsRestrictedData: f.containsRestrictedData,
  ownerInvitesOnly: f.ownerInvitesOnly,
  sharingProhibited: f.sharingProhibited,
});
export const orFlags = (a: Flags, b: Flags): Flags => ({
  containsRestrictedData: a.containsRestrictedData || b.containsRestrictedData,
  ownerInvitesOnly: a.ownerInvitesOnly || b.ownerInvitesOnly,
  sharingProhibited: a.sharingProhibited || b.sharingProhibited,
});

/** The fork's WorkspaceAudience, structurally, after attestedOf() checked and copied it. */
export type Attested = { workspaceId: string; owner: string; collaborators: string[] } & Flags;

/**
 * A usable attestation, or null. Copied field by field and lowercased: an RPC result also carries
 * Symbol.dispose (memory workers-rpc-results-carry-symbol-dispose), and the owner's profile id is
 * compared with props.principal case-insensitively (spec "Fork hook").
 */
export function attestedOf(raw: unknown): Attested | null {
  if (!raw || typeof raw !== "object") return null;
  const a = raw as Record<string, unknown>;
  const strings = (value: unknown): value is string[] => Array.isArray(value) && value.every((s) => typeof s === "string");
  if (typeof a.workspaceId !== "string" || !a.workspaceId || typeof a.owner !== "string" || !a.owner || !strings(a.collaborators)) return null;
  if (typeof a.containsRestrictedData !== "boolean" || typeof a.ownerInvitesOnly !== "boolean" || typeof a.sharingProhibited !== "boolean")
    return null;
  // Principals are canonical emails. A malformed owner refuses; a malformed collaborator is left
  // out (fail closed: absent, so never a recipient), and no member can carry the audience id's ",".
  // canonicalEmail on the value as given, before lower-casing: a non-ASCII look-alike (the Kelvin sign lower-cases to "k") is refused.
  if (!canonicalEmail(a.owner.trim())) return null;
  const owner = a.owner.trim().toLowerCase();
  return {
    workspaceId: a.workspaceId,
    owner,
    collaborators: a.collaborators.map((c) => c.trim()).filter((c) => canonicalEmail(c)).map((c) => c.toLowerCase()),
    containsRestrictedData: a.containsRestrictedData,
    ownerInvitesOnly: a.ownerInvitesOnly,
    sharingProhibited: a.sharingProhibited,
  };
}

/** Audience(A) = {owner} ∪ collaborators, sorted and deduplicated. */
export const audienceOf = (a: Pick<Attested, "owner" | "collaborators">): string[] => [...new Set([a.owner, ...a.collaborators])].toSorted();
export const intersect = (a: readonly string[], b: readonly string[]): string[] => a.filter((p) => b.includes(p));

export function admitOwner(attested: Attested, principal: string): void {
  if (attested.owner !== principal.toLowerCase())
    throw fail("forbidden", "only the workspace owner's own connection can send messages from it");
}

export const notInAudience = (): Error =>
  fail("not_in_audience", "the recipient cannot see everything this workspace can see, so the message cannot go to them");

export const bytes = (text: string): number => new TextEncoder().encode(text).length;
export const codePoints = (text: string): number => [...text].length;
/** At most `max` code points, so a surrogate pair is never split. */
export const truncate = (text: string, max: number): string => [...text].slice(0, max).join("");

/**
 * A principal's Mailbox name. JSON, so no namespace or email (whose local part may hold "/") can
 * produce another pair's name.
 */
export const mailboxName = (namespace: string, principal: string): string => JSON.stringify([namespace, principal]);

/**
 * The observer-tracking collection for an audience (spec "Audience rule" 2). The id is the audience
 * itself, so the verifier answers without a lookup.
 * ponytail: capped below the 2 KiB storage key; past it, switch to aud:<sha256> + an AudienceSets DO.
 */
export function audienceId(audience: readonly string[]): string {
  if (audience.some((principal) => principal.includes(","))) throw fail("invalid", "an audience member is not an email address");
  const id = `aud:${audience.join(",")}`;
  if (bytes(id) > LIMITS.audienceId) throw fail("too_large", "this workspace's audience is too large to track a message for");
  return id;
}

export const parseAudienceId = (id: string): string[] | null => (id.startsWith("aud:") && id.length > 4 ? id.slice(4).split(",") : null);

/** The broker's row: the message plus what agents never see. */
export type Stored = Message & {
  audience: string[];
  flags: Flags;
  applied: Applied;
  receipt: string;
  /** The ancestors' receipts, root first; the chain is `[...chain, receipt]`. */
  chain: string[];
  requestDigest: string;
};

export function viewOf(stored: Stored): Message {
  const { audience: _a, flags: _f, applied: _p, receipt: _r, chain: _c, requestDigest: _d, ...message } = stored;
  return message;
}

// Density is recomputed on the totals, not OR-ed: a few joiners in the subject and a few in the body of a short message are a channel together.
const sum = (a: ScreenReport, b: ScreenReport): ScreenReport => ({
  version: a.version,
  removed: { ansi: a.removed.ansi + b.removed.ansi, control: a.removed.control + b.removed.control, invisible: a.removed.invisible + b.removed.invisible, surrogate: a.removed.surrogate + b.removed.surrogate },
  kept: a.kept + b.kept,
  visible: a.visible + b.visible,
  dense: isDense(a.kept + b.kept, a.visible + b.visible),
  trimmed: a.trimmed || b.trimmed,
  shortened: a.shortened || b.shortened,
  withheld: a.withheld || b.withheld,
  normalized: a.normalized || b.normalized,
  phrases: [...new Set([...a.phrases, ...b.phrases])],
  changed: a.changed || b.changed,
});

/** The report an agent is shown, with the plain line a person reads; null when screening found nothing to say. */
export type Screening = ScreenReport & { summary: string };
const reported = (report: ScreenReport): Screening | null => {
  const summary = describeScreen(report);
  return summary === null ? null : { ...report, summary };
};

/** What a body shown in place of one that decodes to hidden text: nothing of the original, and why. */
export const WITHHELD_BODY = "(withheld: this message is JSON whose strings or keys decode to hidden characters, or is JSON only once they are removed, which cannot be done without changing what it says; ask its sender to send it again)";

/** The JSON value `text` parses to, when it is an object, an array or a string: what a consumer decodes text out of. Else undefined. */
function jsonOf(text: string): { value: unknown } | undefined {
  const start = text.trimStart()[0];
  if (start !== "{" && start !== "[" && start !== '"') return undefined;
  try {
    return { value: JSON.parse(text) as unknown };
  } catch {
    return undefined;
  }
}

/**
 * Every string token of JSON source `text` (keys and values, a repeated key's hidden first value too, since a parser keeps only the last) decoded and
 * screened, with one report, and whether screening would change any of them. A JSON escape spells a hidden character the raw text does not show, and a
 * consumer parsing the text receives it. A token scan, so no nesting depth leaves a string unvisited. Only for text that parses (jsonOf).
 */
function decodedScreen(text: string): { report: ScreenReport | null; changed: boolean; escapedKept: number; tokenVisible: number } {
  let report: ScreenReport | null = null;
  let changed = false;
  // What a token holds beyond its raw text: kept characters spelled only as escapes, and the visible characters the raw token itself shows.
  let escapedKept = 0;
  let tokenVisible = 0;
  for (const [token] of text.matchAll(/"(?:[^"\\]|\\.)*"/g)) {
    let value: string;
    try {
      value = JSON.parse(token) as string;
    } catch {
      continue; // not a token of valid JSON; the text parsed, so this does not occur
    }
    const shown = screen(value);
    const raw = screen(token).report;
    report = report ? sum(report, shown.report) : shown.report;
    escapedKept += Math.max(0, shown.report.kept - raw.kept);
    tokenVisible += raw.visible;
    if (shown.text !== value) changed = true;
  }
  return { report, changed, escapedKept, tokenVisible };
}

/**
 * Whether `text`, as shown, decodes as JSON to anything screening would change: as written, or once every default-ignorable between its strings is gone
 * (outsideStrings). Null when it does not; else the decoded strings' report.
 */
function decodesHidden(text: string): ScreenReport | null {
  for (const source of [text, outsideStrings(text)]) {
    if (jsonOf(source) === undefined) continue;
    const decoded = decodedScreen(source);
    if (decoded.changed) return decoded.report;
  }
  return null;
}

/**
 * How many repeated keys screened `text` names as JSON (as written, or with every default-ignorable between its strings gone), or 0 when neither parses.
 * More than the original names means screening, or a kept joiner, made two keys one.
 */
const screenedRepeats = (text: string): number =>
  Math.max(0, ...[text, outsideStrings(text)].map((source) => (jsonOf(source) === undefined ? 0 : repeatedKeys(source, true))));

/**
 * Whether screening made `original` JSON: `shown` parses (as written, or with every default-ignorable between its strings gone) and the original does not either way. Then
 * nothing says which of its characters were string content, so a removal inside a string (a literal hidden character, a terminal sequence) cannot be told
 * from one around it, and the value shown may not be what its sender wrote.
 */
const madeJson = (original: string, shown: string): boolean =>
  shown !== original && [shown, outsideStrings(shown)].some((source) => jsonOf(source) !== undefined) && [original, outsideStrings(original)].every((source) => jsonOf(source) === undefined);

/** The repeats its sender wrote: counted only on an original that is valid JSON, since quotes inside a sequence screening removes would forge them. */
const originalRepeats = (text: string): number => (jsonOf(text) === undefined ? 0 : repeatedKeys(text));

/** How many times an object in JSON source `text` (parsed or not) names a key it already named: a parser keeps only the last, so the text says two things. */
function repeatedKeys(text: string, asRead = false): number {
  const stack: (Set<string> | null)[] = [];
  let previous = "";
  let repeats = 0;
  for (const [token] of text.matchAll(/"(?:[^"\\]|\\.)*"|[{}[\],:]/g)) {
    if (token === "{") stack.push(new Set());
    else if (token === "[") stack.push(null);
    else if (token === "}" || token === "]") stack.pop();
    else if (token[0] === '"') {
      const keys = stack.at(-1);
      if (keys && (previous === "{" || previous === ",")) {
        let key: string;
        try {
          key = JSON.parse(token) as string;
        } catch {
          key = token;
        }
        // As a reader takes it: decoded, every default-ignorable gone, so a joiner spelled as an escape makes no new key.
        if (asRead) key = key.replace(ALL_IGNORABLE, "");
        if (keys.has(key)) repeats++;
        keys.add(key);
      }
    }
    previous = token;
  }
  return repeats;
}

/** The report for a withheld body: why (removals, phrases), with kept, visible and dense measured on the text the reader is given. */
const withheld = (report: ScreenReport): ScreenReport => ({ ...report, kept: 0, visible: codePoints(WITHHELD_BODY), dense: false, withheld: true, changed: true });

/**
 * A body as read: screened (J1 4B), and never shown as JSON that decodes to hidden text. One stored before screening (or quoted from one) can spell a hidden
 * character as a JSON escape, or have distinct keys that collapse once cleaned; rewriting it would show something its sender did not sign, so it is withheld
 * whole. The check is on the screened text, which is all a reader is given. Phrases spelled with escapes are flagged as the reader decodes them.
 */
function screenedBody(body: string): { text: string; report: ScreenReport } {
  const raw = screen(body);
  // Escapes in the shown text are not in raw's counts, so they are added. The original is checked too (screening a literal hidden character out of a
  // key can make two keys one), as is the shown source for a repeated key screening made; raw already counts what those removed.
  const escaped = decodesHidden(raw.text);
  if (escaped) return { text: WITHHELD_BODY, report: withheld(sum(raw.report, escaped)) };
  // Phrases spelled with escapes are still reported: withheld() keeps only withDecoded's phrases, resetting its counts to the marker's.
  if (decodesHidden(body) || screenedRepeats(raw.text) > originalRepeats(body) || madeJson(body, raw.text)) return { text: WITHHELD_BODY, report: withheld(withDecoded(withDecoded(raw.report, raw.text), body)) };
  return { text: raw.text, report: withDecoded(raw.report, raw.text) };
}

/**
 * `report` with what `text` decodes to as JSON: its phrases, and its kept characters counted across both channels a consumer receives, those the raw
 * text shows and those spelled only as escapes, measured against the visible text outside the strings plus the decoded strings. So a dense channel split
 * between a prefix and escaped joiners is reported as one in plain text is.
 */
function withDecoded(report: ScreenReport, text: string): ScreenReport {
  const source = [text, outsideStrings(text)].find((candidate) => jsonOf(candidate) !== undefined);
  const decoded = source === undefined ? null : decodedScreen(source);
  if (!decoded?.report) return report;
  const kept = report.kept + decoded.escapedKept;
  const visible = Math.max(0, report.visible - decoded.tokenVisible) + decoded.report.visible;
  return { ...report, kept, visible, dense: isDense(kept, visible), phrases: [...new Set([...report.phrases, ...decoded.report.phrases])] };
}

/** A message as read, with its report whether or not it earns a summary: the counts an offline check recomputes from shown text. */
export function screenedParts(message: Message): { message: Message; report: ScreenReport } {
  const subject = screen(message.subject);
  const body = screenedBody(message.body);
  let report = sum(subject.report, body.report);
  let quoted = message.quoted;
  if (quoted) {
    const part = screenedParts(quoted.message);
    quoted = { ...quoted, message: part.message };
    report = sum(report, part.report);
  }
  return { message: { ...message, subject: subject.text, body: body.text, ...(quoted ? { quoted } : {}) }, report };
}

/**
 * What an agent reads of a message: subject, body and every quoted message's, screened (J1 4B), with one report for all of them or null when screening
 * found nothing to say. A view only: the stored row, its receipt and its provenance still verify the original, which is never rewritten. The original is
 * never handed to the agent in any form, encoded or not, since a model can decode what a verifier can: a changed read is checked online (provenance), and
 * offline since receipts also cover the screened text (R4 5b-2c).
 */
export function screenedView(message: Message): { message: Message; screening: Screening | null } {
  const { message: shown, report } = screenedParts(message);
  return { message: shown, screening: reported(report) };
}

/** The screening of a body alone: what a forward's retry may report, since its subject is the parent's, which the retry has not observed. */
export const bodyScreening = (body: string): Screening | null => reported(screenedBody(body).report);
/** `message` with `f` applied to its subject, body and every quoted level's. */
export function mapText(message: Message, f: (text: string) => string): Message {
  return { ...message, subject: f(message.subject), body: f(message.body), ...(message.quoted ? { quoted: { ...message.quoted, message: mapText(message.quoted.message, f) } } : {}) };
}
/** The owner's view of the original (R4 5b-2c): every hidden character a visible code point, nothing raw. unescapeMessage reads it back for the owner-side verifier. */
export const escapeMessage = (message: Message): Message => mapText(message, escapeHidden);
export const unescapeMessage = (message: Message): Message => mapText(message, unescapeHidden);

/** `result` with the screening of what the sender wrote, when there is any. */
export const withScreening = <T extends object>(result: T, screening: Screening | null): T & { screening?: Screening } => (screening ? { ...result, screening } : result);

/** An RPC result minus the Symbol.dispose workerd attaches, so it can be sent on or signed. */
export function detach<T extends object>(value: T): T {
  const copy = { ...value };
  delete (copy as { [Symbol.dispose]?: unknown })[Symbol.dispose];
  return copy;
}

export const messageBytes = (message: Message): number => bytes(canonicalJson(message as unknown as Parameters<typeof canonicalJson>[0]));


export const badExpiresAt = (): Error => fail("invalid", "expiresAt must be an ISO 8601 time in the next 30 days");

/** A raw subject's ceiling before screening: room for a 200-character subject in four-byte characters, plus a reply prefix. */
const SUBJECT_RAW_BYTES = 4 * LIMITS.subject + 64;

export type Draft = { subject: string; body: string; taskType: string | null; expiresAt: string | null; idempotencyKey: string | null };

const ALL_IGNORABLE = /\p{Default_Ignorable_Code_Point}/gu;
/**
 * `text` with every default-ignorable gone from between its string tokens (a joiner before the brace stops a parser, not a model reading it), and kept
 * inside them: removing one there would change a value without the decoded check seeing it.
 */
const outsideStrings = (text: string): string => text.replace(/("(?:[^"\\]|\\.)*")|\p{Default_Ignorable_Code_Point}/gu, (_match, token: string | undefined) => token ?? "");
/** A discriminator that reads "task" once every default-ignorable is gone, however it was written: literally or as a JSON escape. */
const isTaskKind = (kind: unknown): boolean => typeof kind === "string" && kind.replace(ALL_IGNORABLE, "") === "task";

/** A declared task's body as parsed, or null for any other text. Deliberately wider than any one recipient's declaration: a type may be undeclared, or declare no fields. */
function taskEnvelope(body: string): object | null {
  if (!body.trimStart().startsWith("{")) return null;
  try {
    const parsed = JSON.parse(body) as { kind?: unknown } | null;
    // JSON.parse keeps the last of a repeated key, so a "kind":"task" followed by another "kind" is found in the raw tokens too: it is an envelope, and
    // rawProblem() then refuses the repeat.
    return parsed !== null && typeof parsed === "object" && !Array.isArray(parsed) && (isTaskKind(parsed.kind) || rawTaskKind(body)) ? parsed : null;
  } catch {
    return null;
  }
}

/** Whether any top-level "kind" key in the raw JSON source has the string value "task" (escapes decoded, and default-ignorables gone from key and value), whatever a later repeat of it says. */
function rawTaskKind(source: string): boolean {
  let depth = 0;
  let key: string | null = null;
  let previous = "";
  for (const [token] of source.matchAll(/"(?:[^"\\]|\\.)*"|[{}[\],:]/g)) {
    if (token === "{" || token === "[") depth++;
    else if (token === "}" || token === "]") depth--;
    else if (token[0] === '"') {
      const text = JSON.parse(token) as string;
      if (depth === 1 && (previous === "{" || previous === ",")) key = text;
      else if (depth === 1 && previous === ":" && key?.replace(ALL_IGNORABLE, "") === "kind" && isTaskKind(text)) return true;
    }
    previous = token;
  }
  return false;
}

/** `text` for an error line: hidden code points written out, so the message shows what it cannot print. */
const spelled = (text: string): string => [...text].map((ch) => (isPlainText(ch) ? ch : `\\u{${ch.codePointAt(0)!.toString(16)}}`)).join("");

/**
 * Where the first string in `value` (keys included) that is not plain text (AT-11) sits, for a refusal the sender can act on, or null when all are. Too deep
 * fails closed: a body is at most 16 KB, so the walk is bounded by its size.
 */
function hiddenIn(value: unknown, path = "", depth = 0): { where: string } | { deep: string } | null {
  if (typeof value === "string") return isPlainText(value) ? null : { where: path || "the body" };
  if (value === null || typeof value !== "object") return null;
  if (depth > 32) return { deep: path };
  for (const [key, inner] of Object.entries(value)) {
    if (!isPlainText(key)) return { where: `the key "${spelled(key)}"${path ? ` under ${path}` : ""}` };
    const found = hiddenIn(inner, Array.isArray(value) ? `${path}[${key}]` : path ? `${path}.${key}` : key, depth + 1);
    if (found) return found;
  }
  return null;
}

/**
 * Why the raw source of a task envelope is refused, or null. The parsed value hides what JSON allows around and beside it: a repeated key (the parser keeps
 * the last), and a control used as whitespace (a bare CR). So the source is read as written: no repeated key in one object, every string literal plain
 * text (the first of two repeated keys included), and no control or invisible character anywhere, CRLF aside.
 */
function rawProblem(source: string): string | null {
  const stack: (Set<string> | null)[] = [];
  let previous = "";
  let index = 0;
  let hidden: string | null = null; // reported after the whole scan, so a repeated key is named first
  for (const [token] of source.matchAll(/"(?:[^"\\]|\\.)*"|[{}[\],:]/g)) {
    if (token[0] === '"') {
      index++;
      const text = JSON.parse(token) as string;
      const keys = stack.at(-1);
      if (keys && (previous === "{" || previous === ",")) {
        if (keys.has(text)) return `a task body repeats the key "${spelled(text)}"; keep one and resend`;
        keys.add(text);
      }
      if (hidden === null && !isPlainText(text)) hidden = `a task body holds a control, direction or zero-width character, or is not normalized (NFC), in string #${index} (${spelled(text.slice(0, 24))}); it is refused, not cleaned: remove it and resend`;
    } else if (token === "{") stack.push(new Set());
    else if (token === "[") stack.push(null);
    else if (token === "}" || token === "]") stack.pop();
    previous = token;
  }
  if (hidden) return hidden;
  return hasInvisibleText(source.replaceAll("\r\n", "\n")) ? "a task body holds a control or invisible character outside its strings (a bare CR or similar used as spacing); it is refused, not cleaned: remove it and resend" : null;
}

export function validateDraft(input: Parameters<typeof screenDraft>[0], now = Date.now()): Draft {
  return screenDraft(input, now).draft;
}

/**
 * The draft as it will be stored and signed, and what screening did to it (J1 4B): free text is cleaned BEFORE it is signed, so the receipt covers what the
 * recipient is shown. A task envelope is never cleaned: a hidden character anywhere in one is refused, as a declared field's is, rather than silently stripped.
 */
export function screenDraft(
  input: { subject?: unknown; body?: unknown; taskType?: unknown; expiresAt?: unknown; idempotencyKey?: unknown },
  now = Date.now(),
  /** A derived subject ("Re: " or "Fwd: " and the parent's) is cut to length after screening, so hidden characters never spend the room of visible text. */
  cutSubject = false,
): { draft: Draft; screening: Screening | null } {
  // Bounded before the work of screening it, as the body is: hidden characters screening would remove still cost a scan.
  if (typeof input.subject === "string" && bytes(input.subject) > SUBJECT_RAW_BYTES) throw fail("too_large", `subject is at most ${SUBJECT_RAW_BYTES} bytes before screening`);
  const shownSubject = typeof input.subject === "string" ? screen(input.subject) : null;
  const trimmedText = shownSubject ? shownSubject.text.trim() : "";
  const trimmed = shownSubject !== null && trimmedText !== shownSubject.text; // surrounding whitespace changes what is signed, so it is reported like any other change
  const shortened = cutSubject && codePoints(trimmedText) > LIMITS.subject;
  // The cut text is screened again: a cut inside a CRLF would otherwise sign a bare CR that screening removes from every later read.
  const cut = shortened ? screen(truncate(trimmedText, LIMITS.subject)) : null;
  const subject = cut ? cut.text : trimmedText;
  if (!subject || codePoints(subject) > LIMITS.subject) throw fail("invalid", `subject must be 1-${LIMITS.subject} characters`);
  if (typeof input.body !== "string" || input.body.length === 0) throw fail("invalid", "body must be non-empty text");
  if (bytes(input.body) > LIMITS.body) throw fail("too_large", "body is at most 16 KB"); // before the work of screening it
  const task = taskEnvelope(input.body);
  const shownBody = screen(input.body);
  // An envelope behind hidden junk (a ZWSP before the brace) does not parse as written but does once screened: it is judged as an envelope, on the original.
  // So is one whose tokens hold a character screening keeps (a ZWJ in "ta\u200dsk"): it is detected through every default-ignorable, and refused.
  const behind = task ? null : taskEnvelope(shownBody.text);
  const within = task || behind ? null : taskEnvelope(shownBody.text.replace(ALL_IGNORABLE, ""));
  const envelope = task ?? behind ?? within;
  if (envelope) {
    const found = task ? hiddenIn(task) : { where: behind ? "the body outside its JSON text" : "the body's JSON text" };
    if (found && "deep" in found) throw fail("invalid", `a task body nests deeper than 32 levels${found.deep ? ` at ${found.deep}` : ""}; flatten it and resend`);
    if (found) throw fail("invalid", `a task body holds a control, direction or zero-width character, or is not normalized (NFC), in ${found.where}; it is refused, not cleaned: remove it and resend`);
  }
  const problem = task ? rawProblem(input.body) : null;
  if (problem) throw fail("invalid", problem);
  const body = envelope ? input.body : shownBody.text;
  if (body.length === 0) throw fail("invalid", "body must be non-empty text");
  // A read withholds JSON whose strings or keys decode to hidden characters (screenedBody), so a send refuses it rather than signing what no reader is shown.
  if (!envelope && (decodesHidden(body) || decodesHidden(input.body) || screenedRepeats(body) > originalRepeats(input.body) || madeJson(input.body, body)))
    throw fail("invalid", "a JSON body holds a control, direction or zero-width character, or text not normalized (NFC), in a string or key (as a JSON escape or not), or is JSON only once one is removed; it is refused, not cleaned: remove or normalize it and resend");
  // A read shows this text in place of a withheld body, and a verifier takes it as one: no sender may write it.
  if (body === WITHHELD_BODY) throw fail("invalid", "that body is the text a withheld message is shown as, which is reserved; write it differently");
  if (bytes(body) > LIMITS.body) throw fail("too_large", "body is at most 16 KB"); // NFC can grow it
  const taskType = input.taskType ?? null;
  if (taskType !== null && (typeof taskType !== "string" || !TASK_TYPE.test(taskType)))
    throw fail("invalid", `taskType is ${TASK_TYPE_RULE}`);
  const key = input.idempotencyKey ?? null;
  if (key !== null && (typeof key !== "string" || !IDEMPOTENCY_KEY.test(key)))
    throw fail("invalid", 'idempotencyKey is A-Z, a-z, 0-9, ".", "_" or "-", at most 64 characters');
  let expiresAt: string | null = null;
  if (input.expiresAt !== undefined && input.expiresAt !== null) {
    const at = typeof input.expiresAt === "string" ? isoTime(input.expiresAt) : Number.NaN;
    // A past time passes only with a key: a retry after the first send expired may still get that
    // message back, and only that (the session looks the key up and never sends under it).
    if (!Number.isFinite(at) || (at <= now && key === null) || at - now > LIMITS.ttlMs) throw badExpiresAt();
    expiresAt = new Date(at).toISOString();
  }
  // An envelope keeps its bytes, but its tripwire phrases and density still count: they are a property of what the recipient is shown.
  // The subject counts as it is signed, trimmed: spaces around it would dilute what density is measured against.
  // A shortened subject is described as signed: its phrases and kept characters are the cut text's, and what screening removed before the cut still counts.
  // So does what the second screening of the cut text removed (a CR stranded by the cut).
  const removedBefore = shownSubject!.report.removed;
  const removedAtCut = cut?.report.removed;
  const asSigned = cut
    ? {
        ...screen(subject).report,
        removed: { ansi: removedBefore.ansi + removedAtCut!.ansi, control: removedBefore.control + removedAtCut!.control, invisible: removedBefore.invisible + removedAtCut!.invisible, surrogate: removedBefore.surrogate + removedAtCut!.surrogate },
        normalized: shownSubject!.report.normalized || cut.report.normalized,
      }
    : shownSubject!.report;
  const visible = codePoints(subject) - asSigned.kept;
  const subjectReport = { ...asSigned, visible, dense: isDense(asSigned.kept, visible) };
  // JSON's decoded strings are what its recipient reads (screenedBody): a phrase spelled with escapes is reported to the sender too, task or not.
  const report = { ...sum(subjectReport, withDecoded(shownBody.report, body)), ...(trimmed ? { trimmed: true, changed: true } : {}), ...(shortened ? { shortened: true, changed: true } : {}) };
  return { draft: { subject, body, taskType: taskType as string | null, expiresAt, idempotencyKey: key as string | null }, screening: reported(report) };
}

/**
 * The task type a grant checks `m` under (#597): a request's own; for a forward, the type at the root
 * of its signed quoted chain, since it hands that task on (a forward's own taskType is never read); a
 * reply's own, which issue() sets to its parent's checked type. Null: untyped, which a typed grant refuses.
 * Bounded: a chain is at most LIMITS.depth hops.
 */
export function checkedType(m: Message): string | null {
  let at = m;
  while (at.kind === "forward" && at.quoted) at = at.quoted.message;
  return at.kind === "forward" ? null : at.taskType;
}

/** An owner's task-type field as a grant's list: split on commas and whitespace, sorted, deduplicated; blank is null (any type). */
export function taskTypesOf(text: string): string[] | null {
  const list = [...new Set(text.split(/[\s,]+/).filter(Boolean))].toSorted();
  if (list.some((t) => !TASK_TYPE.test(t))) throw fail("invalid", `a task type is ${TASK_TYPE_RULE}`);
  if (list.length > LIMITS.taskTypesPerGrant) throw fail("invalid", `a grant lists at most ${LIMITS.taskTypesPerGrant} task types`);
  return list.length ? list : null;
}

/**
 * The sender's own grant refused the type: its owner's policy, so the type is named. `forward`: the type
 * is the forwarded request's, so an untyped one is not the sender's to fix.
 */
export function typeNotGranted(type: string | null, forward = false): Error {
  if (type !== null) return fail("no_grant", `your grant to that agent does not cover task type ${type}`);
  return fail(
    "no_grant",
    forward
      ? "your grant to that agent covers only named task types, and the request this forwards carries none"
      : "your grant to that agent covers only named task types; send with one of them",
  );
}
/** The recipient's acceptance refused the type: the other owner's private policy, so nothing about it is said. */
export const typeNotAccepted = (): Error => fail("no_grant", "that agent's owner does not accept this task type");

export function email(value: unknown, field: string): string {
  const given = typeof value === "string" ? value.trim() : "";
  // canonicalEmail on the value as given, before lower-casing: a non-ASCII look-alike (the Kelvin sign lower-cases to "k") is refused.
  if (!canonicalEmail(given)) throw fail("invalid", `${field} must be an email address`);
  return given.toLowerCase();
}

/** A mailbox: a person's default inbox (agent null), or one of their agents' (spec "Mailbox model changes"). */
export type Address = { principal: string; agent: string | null };
export const AGENT = /^[a-z0-9-]{1,32}$/;

/**
 * "principal" or "principal/agent", trimmed and lowercased, or null. The agent is what follows a "/"
 * after the "@": an email's local part may hold "/", its domain never does.
 */
export function parseAddress(value: unknown): Address | null {
  if (typeof value !== "string") return null;
  const given = value.trim();
  const at = given.lastIndexOf("@");
  const slash = at < 0 ? -1 : given.indexOf("/", at);
  // canonicalEmail on the value as given, before lower-casing: a non-ASCII look-alike (the Kelvin sign lower-cases to "k") is refused.
  if (!canonicalEmail(slash < 0 ? given : given.slice(0, slash))) return null;
  const text = given.toLowerCase();
  const principal = slash < 0 ? text : text.slice(0, slash);
  const agent = slash < 0 ? null : text.slice(slash + 1);
  if (agent !== null && !AGENT.test(agent)) return null;
  return { principal, agent };
}

export function addressOf(value: unknown, field = "to"): Address {
  const address = parseAddress(value);
  if (!address) throw fail("invalid", `${field} must be an email address, or "email/agent" for an agent`);
  return address;
}

/** A recipient that must be an agent (#561): a person's default inbox takes no new mail. */
export function agentAddressOf(value: unknown, field = "to"): Address & { agent: string } {
  const to = addressOf(value, field);
  if (to.agent === null) throw fail("invalid", 'send to an agent, as "email/agent"');
  return to as Address & { agent: string };
}
export const wireOf = (a: Address): string => (a.agent === null ? a.principal : `${a.principal}/${a.agent}`);
export const partyAddress = (p: { principal: string; agent?: string }): Address => ({ principal: p.principal, agent: p.agent ?? null });
/**
 * Whether a send from the owner's workspace is to one of the owner's own agents under a grant: the only send that may skip the
 * approval card by an owner's rule (session.ts `sendGranted`). Another person's agent and every reply ask a person.
 */
export const underOwnGrant = (granted: boolean, toOwnAgent: boolean): boolean => granted && toOwnAgent;
/** A thread is at most LIMITS.depth hops deep: issue() refuses the hop past it, and Explain asks the same question. */
export const tooDeep = (): Error => fail("depth_exceeded", `a thread is at most ${LIMITS.depth} hops deep`);
/** The MCP door does not hand out a message whose source's limits only a workspace can keep (restricted data, sharing prohibited). */
export const workspaceOnly = (): Error => fail("forbidden", "this message can be read only in a workspace, which can keep its source's limits");
export const sameAddress = (a: Address, b: Address): boolean => a.principal === b.principal && a.agent === b.agent;

export function agentName(value: unknown): string {
  if (typeof value !== "string" || !AGENT.test(value)) throw fail("invalid", 'an agent name is 1-32 of a-z, 0-9 and "-"');
  return value;
}

export const bindingChanged = (): Error =>
  fail("forbidden", "this workspace's agent changed after the message was submitted, so nothing was sent");

export const keyChanged = (): Error =>
  fail("forbidden", "this agent's credential was revoked or replaced while the request was under way, so nothing was sent or returned");

export const noGrant = (): Error => fail("no_grant", "there is no grant for this agent to send to that one; ask its owner for one");
/**
 * Why the owner may not Retry `m`, or null when it may: Mailbox.redeliverable() refuses with `refusal`,
 * and the owner page shows `hint` instead of the button, so the two cannot drift (spec "Retry").
 * - A workspace's message to another person: only that workspace can attest its audience again.
 * - Mail from before agents (#561): to a person's default inbox, which takes no new mail, or from a person.
 */
export function notRetriable(m: Message): { refusal: string; hint: string } | null {
  const to = addressOf(m.recipient, "recipient");
  if (to.agent === null) return { refusal: "a person's default inbox takes no new mail", hint: "sent to a default inbox before agents: it cannot be sent again" };
  if (m.sender.agent === undefined) return { refusal: "only an agent sends Knitli messages; a message from a person is not delivered", hint: "sent by a person before agents: it cannot be sent again" };
  if (to.principal !== m.sender.principal && m.sender.endpoint !== undefined)
    return { refusal: "a workspace's message to another person can be sent again only from that workspace", hint: "send it again from the workspace" };
  return null;
}
/** A workspace with no agent has no mailbox (#561): whoami() gives the id its owner binds. */
export const noAgent = (): Error => fail("forbidden", "this workspace has no agent; its owner binds one on the owner page, with the id whoami() gives");
/**
 * The taint rule (plan 9.5): an agent that read restricted memory sends nothing to another person until the taint ends. Said to the agent's own
 * owner, so it names the cause and where to fix it (OP-15).
 */
export const restrictedTaint = (): Error =>
  fail("restricted_taint", "this agent read restricted memory in the last 24 hours, so it cannot send to another person's agent until that time has passed; send to your own OS agents, or wait");
export const cancelled = (): Error => fail("cancelled", "the sender cancelled that message");
/** An agent its owner suspended (#596): it sends, receives and reads nothing until unsuspended. */
export const suspended = (agent: string): Error => fail("suspended", `the agent ${agent} is suspended by its owner`);

/** A grant's or an acceptance's optional expiry (spec "Grants"): epoch ms at most 90 days out, or null. */
export function grantExpiry(value: unknown, now = Date.now()): number | null {
  if (value === undefined || value === null || value === "") return null;
  const at = typeof value === "string" ? isoTime(value) : Number.NaN;
  if (!Number.isFinite(at) || at <= now || at - now > LIMITS.grantMs) throw fail("invalid", "an expiry must be an ISO 8601 time in the next 90 days");
  return at;
}

export function messageIdOf(value: unknown): string {
  if (typeof value !== "string" || !UUID.test(value)) throw fail("invalid", "messageId must be a message id");
  return value;
}

export function limitOf(value: unknown, fallback = 20, max = 100): number {
  if (value === undefined) return fallback;
  if (typeof value !== "number" || !Number.isInteger(value) || value < 1 || value > max)
    throw fail("invalid", `limit must be an integer from 1 to ${max}`);
  return value;
}

/** A listing row's place, "createdAt.rowid": list()'s `before` continues after it. */
export const CURSOR = /^(\d{1,16})\.(\d{1,16})$/;

export function beforeOf(value: unknown): string | undefined {
  if (value === undefined) return undefined;
  if (typeof value !== "string" || !CURSOR.test(value)) throw fail("invalid", "before must be a listing's cursor");
  return value;
}

export function statusFilter(value: unknown): MessageStatus | undefined {
  if (value === undefined) return undefined;
  if (!(STATUSES as readonly unknown[]).includes(value)) throw fail("invalid", `status must be one of ${STATUSES.join(", ")}`);
  return value as MessageStatus;
}

/** A stored message row's status as read at `now`. Expiry is lazy (spec "Data model"): a row past its expiry reads as expired, whatever it stored. Mailbox and the order trace share it. */
export const statusAt = (row: { expires_at: number | null; status: string }, now: number): string => (row.expires_at !== null && row.expires_at <= now ? "expired" : row.status);
