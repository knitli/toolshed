import { createPrivateKey } from 'node:crypto';
import { z } from 'zod';
import { candidateKey, GITHUB_ENDPOINTS, type GitHubFindingV1, type GitHubObservationV1, type GitHubRunV1, type GitHubSubjectV1 } from './state';
import { allowsGitHubApp, allowsGitHubUser, emptyGitHubActorExclusionCounts, filterGitHubObservation, GitHubActorPolicySchema, type GitHubActorPolicyV1 } from './actor-policy';
import { validSubject } from './ingress';
import { EventRequestDeadline } from '../request-deadline';
import { GITHUB_REVIEW_STATES, githubReviewFingerprint, type GitHubReviewState } from './material-read';
import type { GitHubAdmissionV1 } from './controller';

const id = z.number().int().positive().max(Number.MAX_SAFE_INTEGER), text = z.string().min(1), sha = z.string().regex(/^[a-f0-9]{40}$/);
const actor = z.object({ id, node_id: text.optional() });
const pullSchema = z.object({ number: id, node_id: text, head: z.object({ sha }), base: z.object({ ref: text, sha, repo: z.object({ id }) }), merge_commit_sha: sha.nullable(), state: z.enum(['open', 'closed']), merged: z.boolean(), merged_by: actor.nullable().optional() });
const reviewSchema = z.object({ id, node_id: text, user: actor.nullable(), body: z.string(), state: z.enum(GITHUB_REVIEW_STATES), commit_id: sha.nullable() });
const commentSchema = z.object({ id, node_id: text, user: actor.nullable(), body: z.string(), performed_via_github_app: z.object({ id }).nullish() });
const checkSchema = z.object({ id, name: text, head_sha: sha, app: z.object({ id }).nullable(), status: text, conclusion: text.nullable(), started_at: text.nullish(), completed_at: text.nullish() });
const statusSchema = z.object({ id, context: text, state: text, creator: actor.nullable() });
const workflowSchema = z.object({ id, workflow_id: id, run_number: id, name: z.string().nullish(), head_sha: sha, run_attempt: id.optional(), status: text.nullable(), conclusion: text.nullable(), actor: actor.optional(), triggering_actor: actor.nullable().optional() });
const pageInfo = z.object({ hasNextPage: z.boolean(), endCursor: text.nullable() });
const threadActor = z.object({ __typename: text, databaseId: id.nullish() }).nullable();
const threadComment = z.object({ id: text, body: z.string(), author: threadActor, originalCommit: z.object({ oid: sha }).nullable() });
const threadSchema = z.object({ id: text, isResolved: z.boolean(), resolvedBy: z.object({ databaseId: id.nullable() }).nullable().optional(), isOutdated: z.boolean(), comments: z.object({ nodes: z.array(threadComment), pageInfo }) });
const permissions = { contents: 'read', pull_requests: 'read', issues: 'read', checks: 'read', actions: 'read', statuses: 'read' } as const;
const admissionPermissions = { ...permissions, merge_queues: 'read' } as const;
const branchRuleSchema = z.object({ type: text, ruleset_source_type: text, ruleset_source: text, ruleset_id: id }).passthrough();
const queueProofSchema = z.object({
  data: z.object({
    repository: z.object({ id: text, mergeQueue: z.object({ id: text }).nullable() }).nullable(),
    pullRequest: z.object({ id: text, baseRefName: text, state: z.enum(['OPEN', 'CLOSED', 'MERGED']), merged: z.boolean(), mergeQueueEntry: z.object({ id: text }).nullable() }).nullable(),
  }),
  errors: z.array(z.unknown()).optional(),
});
const MAX_PAGES = 10, MAX_BYTES = 2_000_000, MAX_REQUESTS = 100, READ_MS = 30_000;
const encode = (bytes: Uint8Array): string => btoa(String.fromCharCode(...bytes)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
const canonicalize = (value: unknown): unknown => Array.isArray(value) ? value.map(canonicalize) : value && typeof value === 'object'
  ? Object.fromEntries(Object.entries(value).toSorted(([a], [b]) => a.localeCompare(b)).map(([key, child]) => [key, canonicalize(child)])) : value;
const canonicalJson = (value: unknown): string => JSON.stringify(canonicalize(value));
const digest = async (value: unknown): Promise<string> => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(canonicalJson(value))))).map(n => n.toString(16).padStart(2, '0')).join('');
export class GitHubReadError extends Error {
  constructor(message: string, readonly retryAt?: number) { super(message); }
}

/** Read-only source adapter; tokens and response bodies never enter durable state or logs. */
export class GitHubAppClient {
  private readonly fetcher: typeof fetch;
  /** privateKeyPkcs8 retains its API name but accepts unencrypted PKCS#1 or PKCS#8 RSA PEM. */
  constructor(private readonly options: { appId: string | number; privateKeyPkcs8: string; fetch?: typeof fetch }) { this.fetcher = options.fetch ?? globalThis.fetch.bind(globalThis); }
  private async jwt(): Promise<string> {
    if (!/^[A-Za-z0-9_]+$/.test(String(this.options.appId))) throw new GitHubReadError('github_app_id');
    const pem = this.options.privateKeyPkcs8;
    if (!/^-----BEGIN (RSA PRIVATE KEY|PRIVATE KEY)-----\s*[A-Za-z0-9+/=\s]+-----END \1-----\s*$/.test(pem)) throw new GitHubReadError('github_private_key'); // nosemgrep: generic.secrets.gitleaks.private-key.private-key -- PEM validation pattern, not credential material.
    let key: CryptoKey;
    try {
      const parsed = createPrivateKey(pem);
      if (parsed.asymmetricKeyType !== 'rsa') throw new GitHubReadError('github_private_key');
      const der = parsed.export({ type: 'pkcs8', format: 'der' });
      key = await crypto.subtle.importKey('pkcs8', new Uint8Array(der), { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
    } catch { throw new GitHubReadError('github_private_key'); }
    const now = Math.floor(Date.now() / 1000);
    const input = [ { alg: 'RS256', typ: 'JWT' }, { iss: String(this.options.appId), iat: now - 60, exp: now + 540 } ].map(value => encode(new TextEncoder().encode(JSON.stringify(value)))).join('.');
    return `${input}.${encode(new Uint8Array(await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, new TextEncoder().encode(input))))}`;
  }
  async observe(subject: GitHubSubjectV1, policyRevision: string, epoch: number, actorPolicy: GitHubActorPolicyV1): Promise<GitHubObservationV1> {
    if (!validSubject(subject) || !policyRevision || !Number.isSafeInteger(epoch) || epoch < 0) throw new GitHubReadError('github_subject');
    actorPolicy = GitHubActorPolicySchema.parse(actorPolicy);
    const lifetime = new EventRequestDeadline(READ_MS);
    try { return await lifetime.run(() => this.read(subject, policyRevision, epoch, actorPolicy, lifetime)); }
    finally { lifetime.dispose(); }
  }
  async admit(subject: GitHubSubjectV1, policyRevision: string, sourceRevision: string, parentDeadline?: EventRequestDeadline, readback = false): Promise<GitHubAdmissionV1 | null> {
    if (!validSubject(subject) || !policyRevision || policyRevision.length > 128 || !sourceRevision || sourceRevision.length > 1024) return null;
    const lifetime = parentDeadline ?? new EventRequestDeadline(READ_MS);
    try {
      return await lifetime.run(async () => {
        const { request, token, repo, prefix, readPull } = await this.session(subject, lifetime, admissionPermissions, readback);
        const first = await readPull();
        const readQueue = async (pull: z.infer<typeof pullSchema>): Promise<boolean> => {
          const response = queueProofSchema.safeParse((await request('/graphql', token, {
            query: 'query($repository:ID!,$pullRequest:ID!,$branch:String!){repository:node(id:$repository){... on Repository{id mergeQueue(branch:$branch){id}}} pullRequest:node(id:$pullRequest){... on PullRequest{id baseRefName state merged mergeQueueEntry{id}}}}',
            variables: { repository: repo.node_id, pullRequest: pull.node_id, branch: pull.base.ref },
          })).value);
          if (!response.success || response.data.errors?.length) {
            if (readback) throw new GitHubReadError('github_unavailable');
            return false;
          }
          const { repository, pullRequest } = response.data.data;
          const expectedState = pull.merged ? 'MERGED' : pull.state.toUpperCase();
          if (!repository || !pullRequest || repository.mergeQueue !== null || pullRequest.mergeQueueEntry !== null) return false;
          const consistent = !(pull.merged && pull.state !== 'closed') && repository.id === repo.node_id &&
            pullRequest.id === pull.node_id && pullRequest.baseRefName === pull.base.ref && pullRequest.state === expectedState && pullRequest.merged === pull.merged;
          if (!consistent && readback) throw new GitHubReadError('github_unavailable');
          return consistent;
        };
        const readBranchRules = async (baseRef: string) => {
          const rules: z.infer<typeof branchRuleSchema>[] = [], identities = new Set<string>();
          for (let page = 1; page <= MAX_PAGES; page++) {
            const response = await request(`${prefix}/rules/branches/${encodeURIComponent(baseRef)}?per_page=100&page=${page}`, token);
            const parsed = z.array(branchRuleSchema).max(100).safeParse(response.value);
            if (!parsed.success || (response.next && parsed.data.length !== 100)) {
              if (readback) throw new GitHubReadError('github_unavailable');
              return null;
            }
            for (const rule of parsed.data) {
              const identity = canonicalJson([rule.ruleset_source_type, rule.ruleset_source, rule.ruleset_id, rule.type]);
              if (identities.has(identity)) return null;
              identities.add(identity);
              rules.push(canonicalize(rule) as z.infer<typeof branchRuleSchema>);
            }
            if (!response.next) return rules.toSorted((a, b) =>
              canonicalJson([a.ruleset_source_type, a.ruleset_source, a.ruleset_id, a.type]).localeCompare(canonicalJson([b.ruleset_source_type, b.ruleset_source, b.ruleset_id, b.type])));
          }
          if (readback) throw new GitHubReadError('github_unavailable');
          return null;
        };
        if (!await readQueue(first)) return null;
        const rules = await readBranchRules(first.base.ref);
        const currentRules = await readBranchRules(first.base.ref);
        if (!rules || !currentRules || rules.some(rule => rule.type === 'merge_queue') || currentRules.some(rule => rule.type === 'merge_queue')) return null;
        if (canonicalJson(currentRules) !== canonicalJson(rules)) {
          if (readback) throw new GitHubReadError('github_unavailable');
          return null;
        }
        const current = await readPull();
        if (current.node_id !== first.node_id || current.base.ref !== first.base.ref || current.state !== first.state || current.merged !== first.merged) {
          if (readback) throw new GitHubReadError('github_unavailable');
          return null;
        }
        if (!await readQueue(current)) return null;
        return {
          revision: await digest({ subject, sourceRevision, policyRevision, repositoryId: repo.id, repositoryNodeId: repo.node_id, pullRequestNodeId: current.node_id, baseRef: current.base.ref, rules, mergeQueue: null, mergeQueueEntry: null }),
          policyRevision,
          mergeQueue: 'excluded',
        };
      });
    } catch (error) {
      if (readback) {
        if (error instanceof GitHubReadError && ['github_http_401', 'github_http_403', 'github_http_404', 'github_token_scope', 'github_repository', 'github_pull_identity'].includes(error.message)) return null;
        throw new GitHubReadError('github_unavailable');
      }
      if (error instanceof GitHubReadError && error.retryAt !== undefined) throw error;
      return null;
    } finally { if (!parentDeadline) lifetime.dispose(); }
  }
  private async session(subject: GitHubSubjectV1, lifetime: EventRequestDeadline, requestedPermissions: Readonly<Record<string, string>>, readback = false) {
    let requests = 0;
    const request = async (path: string, token: string, body?: unknown): Promise<{ value: unknown; next: boolean }> => {
      if (!path.startsWith('/') || path.startsWith('//') || ++requests > MAX_REQUESTS) throw new GitHubReadError('github_read_budget');
      const controller = new AbortController();
      let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
      try { return await lifetime.run(async () => {
        const response = await this.fetcher(`https://api.github.com${path}`, { method: body === undefined ? 'GET' : 'POST', redirect: 'manual', signal: controller.signal, headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json', 'Content-Type': 'application/json', 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'knitli-event-runtime' }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
        if (controller.signal.aborted) { void response.body?.cancel().catch(() => { /* body cancel is best-effort */ }); throw new GitHubReadError('github_read_expired'); }
        const readJson = async (limit: number) => {
          reader = response.body?.getReader();
          if (!reader) throw new GitHubReadError('github_empty');
          let bytes = 0, result = ''; const decoder = new TextDecoder();
          try {
            while (true) {
              const chunk = await reader.read(); if (chunk.done) break;
              bytes += chunk.value.byteLength;
              if (bytes > limit) throw new GitHubReadError('github_response_budget');
              result += decoder.decode(chunk.value, { stream: true });
            }
            result += decoder.decode();
          } finally { await reader.cancel(); }
          return JSON.parse(result) as unknown;
        };
        if (!response.ok) {
          // Headerless secondary limits are also 403; only a known permission message proves refusal.
          if (readback && response.status === 403 && !response.headers.has('retry-after') && response.headers.get('x-ratelimit-remaining') !== '0') {
            const error = z.object({ message: z.string() }).safeParse(await readJson(4096));
            if (error.success && ['Resource not accessible by integration', 'Resource not accessible by personal access token'].includes(error.data.message)) throw new GitHubReadError('github_http_403');
          }
          void response.body?.cancel().catch(() => { /* body cancel is best-effort */ });
          if (response.status === 429 || response.status === 403) {
            const retry = response.headers.get('retry-after'), reset = response.headers.get('x-ratelimit-reset');
            const raw = retry ? (/^\d+$/.test(retry) ? Date.now() + Number(retry) * 1000 : Date.parse(retry)) : reset ? Number(reset) * 1000 : Number.NaN;
            throw new GitHubReadError('github_rate_or_permission', Date.now() + Math.min(3600000, Math.max(5000, Number.isFinite(raw) ? raw - Date.now() : 60000)));
          }
          throw new GitHubReadError(`github_http_${response.status}`);
        }
        const value = await readJson(MAX_BYTES);
        // Never follow response-supplied URLs, including pagination links.
        const link = response.headers.get('link') ?? '';
        return { value, next: link.includes('rel="next"') };
      }, 5000); } finally {
        controller.abort();
        // Cancellation must not hold the caller past the owner deadline.
        void reader?.cancel().catch(() => { /* reader cancel is best-effort */ });
      }
    };
    const tokenResult = z.object({ token: text, expires_at: text, permissions: z.record(z.string(), z.string()), repositories: z.array(z.object({ id })) }).parse((await request(`/app/installations/${subject.installationId}/access_tokens`, await this.jwt(), { repository_ids: [subject.repositoryId], permissions: requestedPermissions })).value);
    const expiry = Date.parse(tokenResult.expires_at);
    if (!Number.isFinite(expiry) || expiry < Date.now() + READ_MS || expiry > Date.now() + 3660000 || tokenResult.repositories.length !== 1 || tokenResult.repositories[0]!.id !== subject.repositoryId || Object.entries(requestedPermissions).some(([name, value]) => tokenResult.permissions[name] !== value) || Object.entries(tokenResult.permissions).some(([name, value]) => value !== 'read' || !(name in requestedPermissions || name === 'metadata'))) throw new GitHubReadError('github_token_scope');
    const token = tokenResult.token;
    const repo = z.object({ id, node_id: text, name: z.string().regex(/^[A-Za-z0-9_.-]+$/), owner: z.object({ login: z.string().regex(/^[A-Za-z0-9-]+$/) }) }).parse((await request(`/repositories/${subject.repositoryId}`, token)).value);
    if (repo.id !== subject.repositoryId) throw new GitHubReadError('github_repository');
    const prefix = `/repos/${encodeURIComponent(repo.owner.login)}/${encodeURIComponent(repo.name)}`;
    const readPull = async () => {
      const pull = pullSchema.parse((await request(`${prefix}/pulls/${subject.prNumber}`, token)).value);
      if (pull.number !== subject.prNumber || pull.base.repo.id !== subject.repositoryId) throw new GitHubReadError('github_pull_identity');
      return pull;
    };
    return { request, token, repo, prefix, readPull };
  }
  private async read(subject: GitHubSubjectV1, policyRevision: string, epoch: number, actorPolicy: GitHubActorPolicyV1, lifetime: EventRequestDeadline): Promise<GitHubObservationV1> {
    const { request, token, prefix, readPull } = await this.session(subject, lifetime, permissions);
    const pull = await readPull();
    const candidate = (p: z.infer<typeof pullSchema>) => ({ headSha: p.head.sha, baseSha: p.base.sha, observedMergeSha: p.merge_commit_sha, policyRevision });
    const observation: GitHubObservationV1 = { schemaVersion: 1, subject, candidate: candidate(pull), observedAt: Date.now(), epoch, state: pull.merged ? 'merged' : pull.state, stateActorId: pull.merged ? String(pull.merged_by?.id ?? '') || null : null, actorExclusionCounts: emptyGitHubActorExclusionCounts(), completeness: { pull: 'complete', reviews: 'unknown', reviewRequests: 'unknown', threads: 'unknown', comments: 'unknown', checks: 'unknown', statuses: 'unknown', workflows: 'unknown' }, findings: [], findingMaterials: [], runs: [], reviewRequests: [] };
    const recordMaterial = (sourceId: string, body: string, fingerprint: string): string => {
      observation.findingMaterials!.push({ sourceId, fingerprint, body });
      return fingerprint;
    };
    const retainMaterial = async (sourceId: string, body: string, hashed: unknown = body): Promise<string> => recordMaterial(sourceId, body, await digest(hashed));
    const retainReviewMaterial = async (sourceId: string, body: string, state: GitHubReviewState): Promise<string> =>
      recordMaterial(sourceId, body, await githubReviewFingerprint(body, state));
    const attempt = async (endpoint: typeof GITHUB_ENDPOINTS[number], read: () => Promise<void>) => {
      try { await read(); observation.completeness[endpoint] = 'complete'; }
      catch (error) {
        observation.completeness[endpoint] = 'unknown';
        if (error instanceof GitHubReadError && error.retryAt !== undefined) throw error;
      }
    };
    const readReviewRequests = async (): Promise<GitHubObservationV1['reviewRequests']> => {
      const response = await request(`${prefix}/pulls/${subject.prNumber}/requested_reviewers`, token);
      // This endpoint documents a complete set, not page parameters; never infer absence from a partial response.
      if (response.next) throw new GitHubReadError('github_review_requests_partial');
      // ponytail: sets over 1000 entries stay unknown; use GraphQL cursor pagination if needed.
      const rows = z.object({ users: z.array(z.object({ id })).max(1000), teams: z.array(z.object({ id })).max(1000) }).parse(response.value);
      const unique = new Map<string, GitHubObservationV1['reviewRequests'][number]>();
      for (const [kind, values] of [['user', rows.users], ['team', rows.teams]] as const) for (const row of values) {
        const sourceId = String(row.id);
        unique.set(`${kind}:${sourceId}`, { kind, sourceId });
      }
      return [...unique.values()].toSorted((a, b) => a.kind.localeCompare(b.kind) || a.sourceId.localeCompare(b.sourceId));
    };
    await attempt('reviewRequests', async () => { observation.reviewRequests = await readReviewRequests(); });
    const list = async <T>(path: string, schema: z.ZodType<T>, field?: string): Promise<T[]> => {
      const values: T[] = []; const seen = new Set<string>(); let expected: number | undefined;
      for (let page = 1; page <= MAX_PAGES; page++) {
        const response = await request(`${prefix}${path}${path.includes('?') ? '&' : '?'}per_page=100&page=${page}`, token);
        let rows: unknown = response.value;
        if (field) {
          const result = z.object({ total_count: z.number().int().nonnegative() }).passthrough().parse(response.value);
          if (expected !== undefined && expected !== result.total_count) throw new GitHubReadError('github_pagination_race');
          expected = result.total_count; rows = result[field];
        }
        const batch = z.array(schema).max(100).parse(rows);
        for (const row of batch) {
          const identity = String(z.object({ id: z.union([id, text]) }).parse(row).id);
          if (seen.has(identity)) throw new GitHubReadError('github_duplicate_page');
          seen.add(identity);
        }
        values.push(...batch);
        if (!response.next) {
          if (expected !== undefined && values.length !== expected) throw new GitHubReadError('github_partial');
          return values;
        }
      }
      throw new GitHubReadError('github_page_budget');
    };
    await attempt('reviews', async () => {
      const reviews = await list(`/pulls/${subject.prNumber}/reviews`, reviewSchema);
      observation.findings.push(...await Promise.all(reviews.filter(r => r.state !== 'PENDING').map(async r => {
        const actorId = r.user ? String(r.user.id) : null;
        if (!allowsGitHubUser(actorPolicy, actorId)) { observation.actorExclusionCounts!.review++; return null; }
        return { sourceId: `review:${r.id}`, nodeId: r.node_id, threadId: null, actorId, appId: null, resolutionActorId: r.state === 'DISMISSED' ? null : r.state === 'APPROVED' && !r.body.trim() ? actorId : null, sourceHeadSha: r.commit_id, kind: 'review' as const, fingerprint: await retainReviewMaterial(`review:${r.id}`, r.body, r.state), disposition: r.state === 'DISMISSED' || (r.state === 'APPROVED' && !r.body.trim()) ? 'resolved' as const : 'open' as const, outdated: false };
      })).then(rows => rows.filter((row): row is NonNullable<typeof row> => row !== null)));
    });
    await attempt('comments', async () => {
      const comments = await list(`/issues/${subject.prNumber}/comments`, commentSchema);
      observation.findings.push(...await Promise.all(comments.map(async c => {
        const actorId = c.user ? String(c.user.id) : null, appId = c.performed_via_github_app ? String(c.performed_via_github_app.id) : null;
        if (!allowsGitHubUser(actorPolicy, actorId) && !allowsGitHubApp(actorPolicy, appId)) { observation.actorExclusionCounts!.comment++; return null; }
        return { sourceId: `comment:${c.id}`, nodeId: c.node_id, threadId: null, actorId, appId, sourceHeadSha: null, kind: 'comment' as const, fingerprint: await retainMaterial(`comment:${c.id}`, c.body), disposition: 'open' as const, outdated: false };
      })).then(rows => rows.filter((row): row is NonNullable<typeof row> => row !== null)));
    });
    await attempt('threads', async () => {
      const findings: GitHubFindingV1[] = []; let cursor: string | null = null;
      const seen = new Set<string>();
      for (let page = 0; page < MAX_PAGES; page++) {
        const response = z.object({ data: z.object({ node: z.object({ id: text, reviewThreads: z.object({ nodes: z.array(threadSchema).max(100), pageInfo }) }) }), errors: z.array(z.unknown()).optional() }).parse((await request('/graphql', token, {
          query: 'query($id:ID!,$cursor:String){node(id:$id){... on PullRequest{id reviewThreads(first:100,after:$cursor){nodes{id isResolved resolvedBy{databaseId} isOutdated comments(first:100){nodes{id body author{__typename ... on User{databaseId} ... on Bot{databaseId}} originalCommit{oid}} pageInfo{hasNextPage endCursor}}} pageInfo{hasNextPage endCursor}}}}}', variables: { id: pull.node_id, cursor },
        })).value);
        if (response.errors?.length || response.data.node.id !== pull.node_id) throw new GitHubReadError('github_graphql_partial');
        const connection = response.data.node.reviewThreads;
        for (const thread of connection.nodes) {
          // ponytail: threads over 100 comments stay unknown; add nested pagination when required.
          if (thread.comments.pageInfo.hasNextPage || thread.comments.nodes.length === 0 || seen.has(thread.id)) throw new GitHubReadError('github_thread_partial');
          seen.add(thread.id);
          for (const c of thread.comments.nodes) {
            const actorId = (c.author?.__typename === 'User' || c.author?.__typename === 'Bot') && c.author.databaseId != null ? String(c.author.databaseId) : null;
            if (!allowsGitHubUser(actorPolicy, actorId)) { observation.actorExclusionCounts!.thread++; continue; }
            findings.push({ sourceId: `thread-comment:${c.id}`, nodeId: c.id, threadId: thread.id, actorId, appId: null, resolutionActorId: thread.resolvedBy?.databaseId == null ? null : String(thread.resolvedBy.databaseId), sourceHeadSha: c.originalCommit?.oid ?? null, kind: 'thread', fingerprint: await retainMaterial(`thread-comment:${c.id}`, c.body), disposition: thread.isResolved ? 'resolved' : 'open', outdated: thread.isOutdated });
          }
        }
        if (!connection.pageInfo.hasNextPage) { observation.findings.push(...findings); return; }
        if (!connection.pageInfo.endCursor || connection.pageInfo.endCursor === cursor) throw new GitHubReadError('github_cursor');
        cursor = connection.pageInfo.endCursor;
      }
      throw new GitHubReadError('github_page_budget');
    });
    const shas = [...new Set([pull.head.sha, ...(pull.merge_commit_sha ? [pull.merge_commit_sha] : [])])];
    const readRuns = async (kind: 'checks' | 'statuses' | 'workflows'): Promise<GitHubRunV1[]> => {
      const runs: GitHubRunV1[] = [];
      for (const commit of shas) {
        if (kind === 'checks') {
          // GitHub only considers the latest 1000 check suites for this endpoint.
          const suites = z.object({ total_count: z.number().int().nonnegative() }).parse((await request(`${prefix}/commits/${commit}/check-suites?per_page=1`, token)).value);
          if (suites.total_count > 1000) throw new GitHubReadError('github_check_suite_limit');
          for (const r of await list(`/commits/${commit}/check-runs?filter=latest`, checkSchema, 'check_runs')) {
            if (r.head_sha !== commit) throw new GitHubReadError('github_check_sha');
            runs.push({ sourceId: `check:${r.id}`, kind: 'check', name: r.name, appId: r.app ? String(r.app.id) : null, actorId: null, headSha: commit, attempt: null, status: r.status, conclusion: r.conclusion, startedAt: r.started_at ?? null, completedAt: r.completed_at ?? null });
          }
        } else if (kind === 'statuses') {
          const contexts = new Set<string>();
          // GitHub returns newest first; old failures are not current CI.
          for (const r of await list(`/commits/${commit}/statuses`, statusSchema)) {
            const context = r.context.toLowerCase();
            if (contexts.has(context)) continue;
            contexts.add(context);
            runs.push({ sourceId: `status:${r.id}`, kind: 'status', name: r.context, appId: null, actorId: r.creator ? String(r.creator.id) : null, headSha: commit, attempt: null, status: r.state, conclusion: null });
          }
        } else {
          const latest = new Map<number, z.infer<typeof workflowSchema>>();
          for (const r of await list(`/actions/runs?head_sha=${commit}`, workflowSchema, 'workflow_runs')) {
            const previous = latest.get(r.workflow_id);
            if (previous && r.run_number === previous.run_number && (r.run_attempt === undefined || previous.run_attempt === undefined)) throw new GitHubReadError('github_workflow_attempt_unknown');
            if (!previous || r.run_number > previous.run_number || (r.run_number === previous.run_number && (r.run_attempt! > previous.run_attempt! || (r.run_attempt === previous.run_attempt && r.id > previous.id)))) latest.set(r.workflow_id, r);
          }
          for (const r of latest.values()) {
            if (r.head_sha !== commit) throw new GitHubReadError('github_workflow_sha');
            const actorForAttempt = r.run_attempt !== undefined && r.run_attempt > 1 ? r.triggering_actor ?? null : r.actor ?? r.triggering_actor ?? null;
            runs.push({ sourceId: `workflow:${r.id}:attempt:${r.run_attempt ?? 'unknown'}`, kind: 'workflow', workflowId: r.workflow_id, runNumber: r.run_number, name: r.name ?? null, appId: null, actorId: actorForAttempt ? String(actorForAttempt.id) : null, headSha: commit, attempt: r.run_attempt ?? null, status: r.status, conclusion: r.conclusion });
          }
        }
      }
      return runs.toSorted((a, b) => a.sourceId.localeCompare(b.sourceId));
    };
    const initial = new Map<string, GitHubRunV1[]>();
    for (const kind of ['checks', 'statuses', 'workflows'] as const) await attempt(kind, async () => {
      const runs = await readRuns(kind);
      initial.set(kind, runs);
      for (const run of runs) {
        // The run actor fields do not identify who cancelled the run.
        if (run.conclusion === 'cancelled') {
          observation.actorExclusionCounts![run.kind]++;
          continue;
        }
        const allowed = run.kind === 'check' ? allowsGitHubApp(actorPolicy, run.appId) : allowsGitHubUser(actorPolicy, run.actorId);
        if (allowed) observation.runs.push(run);
        else observation.actorExclusionCounts![run.kind]++;
      }
    });
    for (const kind of ['checks', 'statuses', 'workflows'] as const) if (initial.has(kind)) await attempt(kind, async () => { if (JSON.stringify(initial.get(kind)) !== JSON.stringify(await readRuns(kind))) throw new GitHubReadError('github_run_race'); });
    if (observation.completeness.reviewRequests === 'complete') await attempt('reviewRequests', async () => { if (JSON.stringify(observation.reviewRequests) !== JSON.stringify(await readReviewRequests())) throw new GitHubReadError('github_review_requests_race'); });
    await attempt('pull', async () => {
      const final = await readPull();
      if (candidateKey(candidate(final)) !== candidateKey(observation.candidate) || final.state !== pull.state || final.merged !== pull.merged || final.node_id !== pull.node_id || (final.merged_by?.id ?? null) !== (pull.merged_by?.id ?? null)) throw new GitHubReadError('github_candidate_race');
    });
    observation.observedAt = Date.now();
    return filterGitHubObservation(observation, actorPolicy);
  }
}
