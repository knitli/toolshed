import { z } from 'zod';
import {
  parseEventMessagePreparationResult,
  type EventMessageAttemptResultV1,
  type EventMessageAuthorityServiceV1,
} from 'gatekeeper-messaging/src/event-authority-contract';
import { EventApiError } from '../contracts';
import { EVENT_POLICY_V1 } from '../policy';
import { withDeadline } from '../request-deadline';
import type { HistoricalMessageDeliverySourceV1, MessageDeliverySourceV1 } from './materialization';

export type DeliverySourceFence = { refresh(): Promise<void>; check(): void };

/** Each operation owns its observation; concurrent claims cannot refresh each other's authority. */
export function createMessageDeliveryFence(
  source: MessageDeliverySourceV1 | HistoricalMessageDeliverySourceV1,
  authority: () => Partial<EventMessageAuthorityServiceV1>,
  current: () => boolean,
): DeliverySourceFence {
  const service = authority();
  const hasActivation = 'activation' in source.source;
  const expected = JSON.stringify({ ...source.source, checkedAt: '' });
  let checkedAt: number | null = null;
  const local = () => {
    if (authority() !== service || !current()) throw new Error('conflict');
  };
  return {
    async refresh() {
      checkedAt = null;
      local();
      if (!service.readMessagePreparation) throw new EventApiError('authority_unavailable', 503);
      const started = Date.now();
      const raw = await withDeadline(service.readMessagePreparation({
        publication: source.source.publication, expectedSnapshot: source.source.snapshotDigest,
      }), EVENT_POLICY_V1.nativeRpcDeadlineMs);
      local();
      const now = Date.now();
      const serialized = JSON.stringify(raw);
      if (typeof serialized !== 'string' || new TextEncoder().encode(serialized).byteLength > 8192)
        throw new EventApiError('authority_unavailable', 503);
      const result = parseEventMessagePreparationResult(raw);
      if (!result || result.status === 'unavailable') throw new EventApiError('authority_unavailable', 503);
      if (result.status !== 'eligible') throw new Error('conflict');
      const sourceObserved = hasActivation ? result : (({ activation: _activation, ...legacy }) => legacy)(result);
      if (JSON.stringify({ ...sourceObserved, checkedAt: '' }) !== expected)
        throw new Error('conflict');
      const observed = Date.parse(result.checkedAt);
      if (!Number.isSafeInteger(observed) || observed < started || observed > now
        || now - observed > EVENT_POLICY_V1.nativeRpcDeadlineMs) throw new Error('conflict');
      checkedAt = observed;
    },
    check() {
      local();
      const now = Date.now();
      if (checkedAt === null || now < checkedAt || now - checkedAt > EVENT_POLICY_V1.nativeRpcDeadlineMs)
        throw new Error('conflict');
    },
  };
}

const positive = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);
const budget = z.strictObject({
  used: z.number().int().nonnegative(), remaining: z.number().int().nonnegative(),
  limit: z.literal(10), windowMs: z.literal(3600000),
}).refine(value => value.remaining === Math.max(0, value.limit - value.used));
const resultSchema = z.union([
  z.strictObject({ status: z.literal('reserved'), attemptId: z.string(), reservedAt: positive,
    idempotent: z.boolean(), routingGeneration: positive, budget }),
  z.strictObject({ status: z.literal('over_budget'), budget: budget.refine(value => value.used >= value.limit && value.remaining === 0) }),
  z.strictObject({ status: z.enum(['unknown', 'pending', 'conflict', 'denied', 'invalid', 'unavailable']) }),
]);

/** An unbound or malformed service response cannot authorize an existing or new permit. */
export function parseMessageAttemptResult(
  value: unknown, attemptId: string, routingGeneration: number,
): EventMessageAttemptResultV1 {
  const result = resultSchema.safeParse(value);
  if (!result.success || (result.data.status === 'reserved'
    && (result.data.attemptId !== attemptId || result.data.routingGeneration !== routingGeneration
      || result.data.reservedAt > Date.now()))) throw new EventApiError('authority_unavailable', 503);
  return result.data;
}
