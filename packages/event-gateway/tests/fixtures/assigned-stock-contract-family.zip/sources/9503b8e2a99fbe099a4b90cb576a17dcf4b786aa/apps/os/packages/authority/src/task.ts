// Receiver-declared task types (plan 5.4). Types only in 3a: the tasks table, the consequence rule and the
// declaration edits that attenuate (item 5) are built on these in P4 (GM/tasks.ts).
import type { Term } from "./scope.ts";

/** A task type is a lowercase label of `a-z`, `0-9`, `-` and `/`, at most 64 characters (GM/model.ts:66). */
export const TASK_TYPE = /^[a-z0-9\-/]{1,64}$/;

// The field grammar and bounds of a declaration, shared by Messaging's parser and by the declare-task act, so the act signs exactly what Messaging would accept.
/**
 * A field name: a lowercase letter, then letters and digits, at most 32. One grammar for storing a declaration, reading it back and signing an order body, so
 * a declared field can always be filled in a signed act. `constructor` and `prototype` are ordinary names (every map of fields is read by own keys, never by
 * prototype lookup); `__proto__` starts with an underscore and was never one.
 */
export const FIELD_NAME = /^[a-z][A-Za-z0-9]{0,31}$/;
/** One value of an enum field. */
export const ENUM_VALUE = /^[a-z0-9][a-z0-9._-]{0,63}$/;
/** Fields one payload (or reply) may declare. */
export const MAX_FIELDS = 16;
/** The longest a `string` field may be, in Unicode code points, and the bound when a declaration gives none. */
export const MAX_STRING = 4096;
/** Values one enum field may list. */
export const MAX_ENUM = 16;

/** Where a declaration comes from: the owner, or a generated catalog or router entry (plan 5.4). */
export const DECLARATION_SOURCE = /^(?:owner|catalog:[a-z0-9][a-z0-9-]{0,58}|route:[a-z0-9][a-z0-9-]{0,58})$/;
/** The longest an order lives (plan 5.8): seven days. A declaration's default ttl and an order's own expiry both stop here. */
export const MAX_ORDER_LIFETIME_HOURS = 168;
/** The longest summary of a declaration, in Unicode code points. */
export const SUMMARY_MAX = 200;
/** Terms a declaration's default scope may list. */
export const MAX_DEFAULT_SCOPE_TERMS = 8;
/** The terms an order of a declared type may be drawn inside: an order's terms are msg.forward and exec.request only (plan 5.8). */
export const isOrderTerm = (term: Term): boolean => (term.svc === "msg" && term.verb === "forward") || (term.svc === "exec" && term.verb === "request");

/** `max`: a string field's length in Unicode code points (not UTF-16 units, not bytes: the body's byte limit is separate), as the summary and a subject are counted. */
export type Field = { name: string; kind: "string" | "int" | "digest" | "enum"; max?: number; enum?: string[]; required: boolean };

export type TaskDeclaration = {
  type: string; // TASK_TYPE
  class: "inform" | "consequential";
  summary: string; // at most 200 characters
  payload: { fields: Field[] }; // flat, closed; no nesting; total body stays within LIMITS.body (16 KiB)
  reply?: { fields: Field[] }; // consequential types: the result schema (default knitli.result/v1, 7.2)
  minAssurance: "hw-uv" | "hw-up"; // for an order of this type; default hw-uv
  defaults: { ttlHours: number; maxDepth: number; maxMessages: number; scope: Term[] }; // the ceiling the order form prefills; an agent-drafted order may only be at or inside it
  source: "owner" | `catalog:${string}` | `route:${string}`; // catalog entries are read-only and generated
};

/** `exec/*` is reserved (plan 5.4 item 5): an owner never declares one by hand; it is generated from the image catalog or assigned to a router by a `declare-task` act, and it is always consequential. */
export const isReserved = (type: string): boolean => type.startsWith("exec/");

/**
 * Why an order's terms contradict its type and limits, or null. An exec.request term asks for the profile its type names (`exec/<res>`), and a msg.forward
 * term is a right to hand the task on, which a thread that cannot forward (allowForward false, or no depth) could never use. A declaration's defaults are
 * judged by it too (it has no allowForward, so pass true), so the order a form prefills is one the act accepts.
 */
export function orderScopeProblem(taskType: string, scope: readonly Term[], maxDepth: number, allowForward: boolean): string | null {
  for (const term of scope) {
    if (term.svc === "exec" && term.verb === "request" && taskType !== `exec/${term.res}`) return `an exec.request term names ${term.res}, which is not this order's type`;
    if (term.svc === "msg" && term.verb === "forward" && !(allowForward && maxDepth >= 1)) return "a msg.forward term needs forwarding allowed and a depth of at least 1";
  }
  return null;
}

/**
 * Why a declaration may not be WRITTEN, or null: the rules new to a write (a stored row is read back with the older grammar, so a declaration stored before
 * a rule existed still declares its type and still has its bodies checked). An `exec/*` type is always consequential and never an owner's by hand; a
 * generated entry (`catalog:<id>` or `route:<id>`) is the declaration of `exec/<id>`; and the order terms it defaults agree with its type and depth
 * (orderScopeProblem). `defaults` is null for a route assignment, which carries none. Messaging's declare() and the declare-task act both read this one.
 */
export function declarationProblem(type: string, kind: string, source: string, defaults: { scope: readonly Term[]; maxDepth: number } | null): string | null {
  if (isReserved(type) && (kind !== "consequential" || source === "owner")) return "an exec/* type is consequential and generated or assigned, never an owner's by hand";
  const generated = /^(?:route|catalog):/.exec(source);
  if (generated && (type !== `exec/${source.slice(generated[0].length)}` || kind !== "consequential")) return "a generated declaration is the consequential declaration of exec/<id>";
  return defaults === null ? null : orderScopeProblem(type, defaults.scope, defaults.maxDepth, true);
}
