// The frozen renderer r1 (R4 plan 6.2, INV13, VS-01): the text a person reads before touching a key is a pure function of the act, so the review page, the
// ceremony page, the independent notice and the offline verifier share one implementation and a historical act stays verifiable after a copy edit (F15: a
// new wording ships as r2 and a verifier selects by act.renderer; r1's wording never changes).
//
// What the human signs is what the human saw: every leaf of the act's subject, scope and limits must be shown in a line or be a listed non-semantic id
// or digest printed in the footer. That is enforced here, not by a test alone: a line names the leaves it shows (and carries their text), the renderer
// refuses to produce text if a leaf is unshown, and the footer's "N of N fields shown" is a count, not a literal. A field added to a subject without a
// renderer line makes this throw. Pure TypeScript: no Worker types, no I/O.
import { RENDER_NONSEMANTIC, type Act } from "./act.ts";
import { isoTime } from "./contract-kit.ts";
import { printTerm, isTerm, type Term } from "./scope.ts";
import { ACTIVATION_DELAY_HOURS } from "./webauthn.ts";

export class RenderIncomplete extends Error {
  readonly missing: readonly string[];
  constructor(missing: readonly string[]) {
    super(`the renderer shows no line for: ${missing.join(", ")}`);
    this.name = "RenderIncomplete";
    this.missing = missing;
  }
}

export type Rendered = { lines: string[]; risk: "normal" | "high"; riskReasons: string[]; shown: number; total: number };

const norm = (path: string): string => path.replace(/\[\d+\]/g, "[]");
const textOf = (value: unknown): string => (value === null ? "null" : typeof value === "string" ? value : String(value));

/** Every leaf of the act's subject, scope and limits, by path (`subject.keys[0].thumbprint`), with the text a line must carry for it. A term is one leaf. */
export function leafMap(act: Act): Map<string, string> {
  const out = new Map<string, string>();
  const walk = (value: unknown, path: string): void => {
    if (Array.isArray(value)) value.forEach((entry, i) => walk(entry, `${path}[${i}]`));
    else if (value !== null && typeof value === "object") {
      if ("svc" in value && "verb" in value && "res" in value && isTerm(value)) out.set(path, printTerm(value));
      else for (const key of Object.keys(value).toSorted()) walk((value as Record<string, unknown>)[key], `${path}.${key}`); // canonical key order: one digest, one rendering
    } else out.set(path, textOf(value));
  };
  walk(act.subject, "subject");
  if (act.scope) walk(act.scope, "scope");
  if (act.limits) walk(act.limits, "limits");
  return out;
}

/**
 * `text` with one standalone occurrence of `value` blanked out, or null if there is none. Standalone: whitespace, start/end or , ; ( ) [ ] " ' around it
 * (a full stop or colon only before a space), so the 2 and the 5 of "2 hops, 5 messages" cannot be found inside "2026-10-08T15:02:00Z".
 */
export function claim(text: string, value: string): string | null {
  if (value === "") return null;
  const escaped = value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const found = new RegExp(`(?<=^|[\\s,;()\\["'])${escaped}(?=$|[\\s,;()\\]"']|[.:](?=\\s|$))`).exec(text);
  return found === null ? null : `${text.slice(0, found.index)}\u0000${text.slice(found.index + value.length)}`;
}

type Ref = string | readonly [path: string, shownAs: string];
const encoder = new TextEncoder();

/**
 * A line of free text with its tabs spelled out and its backslashes doubled, so the reading is unambiguous: a tab shows as \t and a typed backslash and t
 * as \\t. (Without the doubling, "a TAB \t b" and "a \t TAB b" would read the same and weigh the same.)
 */
export const visible = (piece: string): string => piece.replaceAll("\\", "\\\\").replaceAll("\t", "\\t");

export class Out {
  readonly lines: string[] = [];
  readonly seen = new Set<string>();
  readonly reasons: string[] = [];
  readonly leaves: ReadonlyMap<string, string>;
  readonly nonsemantic: ReadonlySet<string>;
  constructor(leaves: ReadonlyMap<string, string>, nonsemantic: ReadonlySet<string>) {
    this.leaves = leaves;
    this.nonsemantic = nonsemantic;
  }

  /** A line that shows `refs`: each leaf's text (or the stated wording) must be in it, or the renderer is wrong and refuses. */
  say(text: string, ...refs: Ref[]): void {
    let left = text; // each leaf claims its own occurrence, so two leaves cannot share one
    for (const ref of refs) {
      const [path, shownAs] = typeof ref === "string" ? [ref, this.leaves.get(ref)] : ref;
      const claimed = shownAs === undefined ? null : claim(left, shownAs);
      if (claimed === null) throw new RenderIncomplete([`${path} (not in "${text}")`]);
      left = claimed;
      this.seen.add(path);
    }
    this.lines.push(text);
  }

  /** Free text in a labelled monospace quote box: tabs spelled out, whitespace bounded by bars, the byte count and an end marker. */
  quote(path: string, label: string, value: string): void {
    const pieces = value.split("\n").map(visible);
    this.lines.push(`  ${label}, ${encoder.encode(value).length} bytes:`);
    for (const piece of pieces) this.lines.push(`  |${piece}|`);
    this.lines.push("  end of text");
    this.seen.add(path);
  }

  /**
   * One `name = value` line for each leaf whose path is in `reviewed`, the closed list of paths a person has decided to show this way. A leaf not on the
   * list gets no line, so the completeness check refuses the render: a new field is a change to this file, reviewed, and never shown by default.
   */
  listed(reviewed: readonly string[]): void {
    for (const [path, text] of this.leaves) {
      if (!this.seen.has(path) && !this.nonsemantic.has(norm(path)) && reviewed.some((entry) => (entry.endsWith(".*") ? norm(path).startsWith(entry.slice(0, -1)) : norm(path) === entry)))
        this.say(`  - ${path.slice(8)} = ${text}`, path);
    }
  }
}

/**
 * The subject paths shown as `name = value` for the kinds whose subject is a flat reviewable list (positions as `[]`). `.*` takes every key of a map whose
 * keys are validated names (limits, toolchain); nothing else is open-ended. Closed: adding a path is a review of what the person will read.
 */
const REVIEWED: Record<"declare-task" | "exec-approve", readonly string[]> = {
  "declare-task": [
    "subject.declaration.payload.fields[].name", "subject.declaration.payload.fields[].kind", "subject.declaration.payload.fields[].required", "subject.declaration.payload.fields[].max", "subject.declaration.payload.fields[].enum[]",
    "subject.declaration.reply.fields[].name", "subject.declaration.reply.fields[].kind", "subject.declaration.reply.fields[].required", "subject.declaration.reply.fields[].max", "subject.declaration.reply.fields[].enum[]",
    "subject.declaration.minAssurance", "subject.declaration.defaults.ttlHours", "subject.declaration.defaults.maxDepth", "subject.declaration.defaults.maxMessages", "subject.declaration.defaults.scope[]",
  ],
  "exec-approve": [
    "subject.candidateDigest", "subject.baseDigest", "subject.imageDigest", "subject.origin", "subject.origin.messageId", "subject.origin.receiptDigest", "subject.origin.orderActDigest",
    "subject.approvalExpiresMs",
  ],
};

const OPEN_FIELD = /^[A-Za-z0-9:._/-]{1,128}$/;
const seconds = (n: number): string => (n % 3600 === 0 ? `${n / 3600} h` : n % 60 === 0 ? `${n / 60} min` : `${n} s`);
/** A term that starts code or hands the task on: the verifier raises an order's assurance floor to hw-uv for it, and the renderer marks it high. */
export const isHighTerm = (t: Term): boolean => t.svc === "exec" || (t.svc === "msg" && t.verb === "forward");

/** One sentence per term, then the term's exact text in brackets: the sentence is for reading, the brackets are what was signed. */
function sentence(term: Term): string {
  const types = term.where?.type ? ` (task types ${term.where.type.join(", ")})` : "";
  const what =
    term.svc === "exec" ? `It may request runs of ${term.res}`
    : term.svc === "mem" ? `Memory: ${term.verb} on ${term.res}`
    : `It may ${term.verb}${term.verb === "receive" ? " from" : " to"} ${term.res}${types}`;
  return `${what} [${printTerm(term)}]`;
}

/** Who composed the content, as the signer reads it: an agent with its key, or with none when it signs in with a session (OS agents, OAuth). */
export const draftedByText = (act: Act): string => (act.draftedBy === "human" ? "you" : act.draftedBy.jkt === null ? `${act.draftedBy.agent} with no key (session)` : `${act.draftedBy.agent} (key ${act.draftedBy.jkt})`);

function grantLine(out: Out, base: string, g: { direction: string; from: string; to: string; mode: string; expiresAt: string | null; types: string[]; wake?: true; offerId?: string }): void {
  const types = g.types.length === 0 ? "any task type" : `task types ${g.types.join(", ")}`;
  const verb = g.direction === "in" ? "Accept from" : "Offer from";
  // An accepted offer keeps the earlier of its own expiry and the acceptance's (Messaging acceptOffer), so the page says the offer's may come first.
  const until = (g.expiresAt === null ? "no expiry" : `until ${g.expiresAt}`) + (g.direction === "in" ? ", or the offer's own expiry, if earlier" : "");
  out.say(
    `  - ${verb} ${g.from} to ${g.to}: ${g.mode}, ${until}, ${types}.`,
    [`${base}.direction`, verb], `${base}.from`, `${base}.to`, `${base}.mode`, [`${base}.expiresAt`, g.expiresAt ?? "no expiry"], ...g.types.map((_, i) => `${base}.types[${i}]`),
  );
  if (g.offerId) out.say(`    - Only the offer ${g.offerId}; a replacement offer is not this one.`, [`${base}.offerId`, g.offerId]);
  if (g.wake) out.say("    - Wake: a message of these types from the sender may wake the receiving agent without an order.", [`${base}.wake`, "may wake"]);
}

type ListedKey = { thumbprint: string; device: string | null; firstSeen: string; state: string };
/**
 * An agent's key list as `agent-enroll` and `bind-existing` show it: the one key the act activates (if any), then the others, unchanged. The list is shown
 * and compared; only the named key is promoted (a promotion of any other inert key is a `key-inventory` act's `include`).
 */
function keyLines(out: Out, keys: ListedKey[], activates: string | null): void {
  const line = (key: ListedKey, i: number, lead: string): void =>
    out.say(`${lead}${key.thumbprint} (${key.device ?? "added by hand"}), first seen ${key.firstSeen}, ${key.state}`, `subject.keys[${i}].thumbprint`, [`subject.keys[${i}].device`, key.device ?? "added by hand"], `subject.keys[${i}].firstSeen`, `subject.keys[${i}].state`);
  const chosen = keys.findIndex((key) => key.thumbprint === activates);
  if (chosen < 0) out.lines.push("Activates no key.");
  else {
    out.lines.push("Activates this key, inert until now:");
    line(keys[chosen]!, chosen, "  - ");
  }
  const others = keys.map((key, i) => [key, i] as const).filter(([, i]) => i !== chosen);
  out.lines.push(others.length === 0 ? "Other keys of this agent: none." : `Other keys of this agent, unchanged (${others.length}):`);
  for (const [key, i] of others) line(key, i, "  - ");
}

type WakeWas = { mode: string; senders: string[] | null; transports: string[]; suspendedAt: string | null };
/** The policy an activation act was drafted against, so the signer sees what the act replaces. */
function wasLines(out: Out, was: WakeWas): void {
  if (was.suspendedAt === null) out.say(`  - Before this: wake mode ${was.mode}, not suspended.`, "subject.was.mode", ["subject.was.suspendedAt", "not suspended"]);
  else out.say(`  - Before this: wake mode ${was.mode}, suspended since ${was.suspendedAt}.`, "subject.was.mode", "subject.was.suspendedAt");
  if (was.senders === null) {
    const any = was.mode === "granted" ? "any sender whose live grant covers the message" : "not used in this mode";
    out.say(`  - Before this, senders that may wake it without an order: ${any}.`, ["subject.was.senders", any]);
  } else if (was.senders.length === 0) out.lines.push("  - Before this, senders that may wake it without an order: none.");
  else out.say(`  - Before this, senders that may wake it without an order: ${was.senders.join(", ")}.`, ...was.senders.map((_, i) => `subject.was.senders[${i}]`));
  out.say(`  - Before this, wake transports: ${was.transports.join(", ")}.`, ...was.transports.map((_, i) => `subject.was.transports[${i}]`));
}

const KINDS: Record<Act["kind"], (act: Act, out: Out) => string> = {
  order(act, out) {
    const s = act.subject as { to: string; taskType: string; subject: string; body: { objective: string; fields: Record<string, string | number>; inputs: { kind: string; digest?: string; ref?: string }[]; deadlineSeconds: number } };
    const l = act.limits!;
    const long = isoTime(l.expiresAt) - isoTime(act.issuedAt) > 24 * 3600 * 1000;
    if (s.taskType.startsWith("exec/") || act.scope!.some((t) => t.svc === "exec")) out.reasons.push("starts code execution");
    if (l.allowForward) out.reasons.push("allows forwarding");
    if (long) out.reasons.push("lasts more than a day");
    out.say(`  - Task type ${s.taskType}, delivered to ${s.to}. Message subject: "${s.subject}".`, "subject.taskType", "subject.to", "subject.subject");
    if (act.scope!.length === 0) out.lines.push("  - Terms: none. The order carries no right to forward or to request runs.");
    act.scope!.forEach((term, i) => out.say(`  - ${sentence(term)}.`, `scope[${i}]`));
    const forwarding = l.allowForward ? "forwarding allowed" : "no forwarding";
    out.say(`  - Valid until ${l.expiresAt}, ${l.maxDepth} hops deep, ${forwarding}, at most ${l.maxMessages} messages.`,
      "limits.expiresAt", "limits.maxDepth", ["limits.allowForward", forwarding], "limits.maxMessages");
    out.lines.push("Task fields (all of them):");
    if (Object.keys(s.body.fields).length === 0) out.lines.push("  none");
    for (const name of Object.keys(s.body.fields).toSorted()) {
      const value = s.body.fields[name]!;
      if (typeof value === "number" || OPEN_FIELD.test(value)) out.say(`  ${name} = ${value}`, `subject.body.fields.${name}`);
      else out.quote(`subject.body.fields.${name}`, name, value);
    }
    out.quote("subject.body.objective", `objective, drafted by ${draftedByText(act)}`, s.body.objective);
    if (s.body.inputs.length === 0) out.lines.push("Inputs: none.");
    else {
      out.lines.push("Inputs:");
      s.body.inputs.forEach((input, i) => {
        const at = `subject.body.inputs[${i}]`;
        out.say(`  ${input.kind} ${input.digest ?? input.ref}`, `${at}.kind`, `${at}.${input.digest === undefined ? "ref" : "digest"}`);
      });
    }
    out.say(`Deliver within: ${s.body.deadlineSeconds} s (${seconds(s.body.deadlineSeconds)}).`, "subject.body.deadlineSeconds");
    return `Order ${s.to} to run task type ${s.taskType}`;
  },

  "agent-scope"(act, out) {
    const s = act.subject as { agent: string; add: Term[]; remove: Term[]; preset?: { id: string; n: number } | null };
    if (s.add.some(isHighTerm)) out.reasons.push("widens an agent toward execution or forwarding");
    out.say(`  - Agent: ${s.agent}.`, "subject.agent");
    if (s.preset) out.say(`  - Applying preset ${s.preset.id} version ${s.preset.n}.`, "subject.preset.id", "subject.preset.n");
    else if (s.preset === null) out.say("  - Applied without a preset.", ["subject.preset", "preset"]);
    if (s.add.length === 0) out.lines.push("  - Add: nothing.");
    s.add.forEach((term, i) => out.say(`  - Add: ${sentence(term)}.`, `subject.add[${i}]`));
    if (s.remove.length === 0) out.lines.push("  - Remove: nothing.");
    s.remove.forEach((term, i) => out.say(`  - Remove: ${sentence(term)}.`, `subject.remove[${i}]`));
    return `Change what ${s.agent} may do`;
  },

  grant(act, out) {
    const s = act.subject as Parameters<typeof grantLine>[2];
    grantLine(out, "subject", s);
    return `${s.direction === "in" ? "Accept a grant from" : "Offer a grant to"} ${s.direction === "in" ? s.from : s.to}`;
  },

  "agent-enroll"(act, out) {
    const s = act.subject as { agent: string; agentKeyThumbprint: string; deviceName: string; presetId: string; presetVersion: number; terms: Term[]; grants: Parameters<typeof grantLine>[2][]; keys: { thumbprint: string; device: string | null; firstSeen: string; state: string }[] };
    out.reasons.push("gives an agent standing permissions");
    out.say(`  - Agent ${s.agent} on ${s.deviceName}; its key ${s.agentKeyThumbprint} is promoted.`, "subject.agent", "subject.deviceName", "subject.agentKeyThumbprint");
    out.say(`  - Starting permissions: preset ${s.presetId} version ${s.presetVersion}.`, "subject.presetId", "subject.presetVersion");
    if (s.terms.length === 0) out.lines.push("  - Scope: none. The agent starts with no scope rows.");
    s.terms.forEach((term, i) => out.say(`  - Scope: ${sentence(term)}.`, `subject.terms[${i}]`));
    if (s.grants.length === 0) out.lines.push("  - Starting permissions to send: none.");
    s.grants.forEach((grant, i) => grantLine(out, `subject.grants[${i}]`, grant));
    keyLines(out, s.keys, s.agentKeyThumbprint);
    return `Enroll agent ${s.agent} on ${s.deviceName}`;
  },

  "bind-existing"(act, out) {
    const s = act.subject as { agent: string; what: string; ref: string; replaces: string | null; keys: { thumbprint: string; device: string | null; firstSeen: string; state: string }[] };
    out.reasons.push("binds an existing agent to a new credential");
    out.say(`  - Bind ${s.what} ${s.ref} to agent ${s.agent}.`, "subject.what", "subject.ref", "subject.agent");
    if (s.replaces === null) out.say("  - It replaces no earlier binding.", ["subject.replaces", "no"]);
    else out.say(`  - This moves it from ${s.replaces}.`, "subject.replaces");
    keyLines(out, s.keys, s.what === "key" ? s.ref : null);
    return `Bind ${s.what} ${s.ref} to ${s.agent}`;
  },

  "key-inventory"(act, out) {
    type K = { thumbprint: string; device: string | null; firstSeen: string; state: string };
    type Entry = { agent: string; keys: K[] };
    const s = act.subject as { agents: Entry[]; inert: Entry[] };
    // Every key the touch changes is named: those it activates (inert now), those it keeps active, and those it makes inert. A key in none of the three is not touched.
    const rows = (entries: Entry[], base: string, keep: (key: K) => boolean): { n: number; lines: [string, ...Ref[]][] } => {
      const lines: [string, ...Ref[]][] = [];
      entries.forEach((a, i) => a.keys.forEach((key, j) => {
        if (keep(key)) lines.push([`  - ${a.agent}: ${key.thumbprint} (${key.device ?? "added by hand"}), first seen ${key.firstSeen}, ${key.state}`, `${base}[${i}].agent`, `${base}[${i}].keys[${j}].thumbprint`, [`${base}[${i}].keys[${j}].device`, key.device ?? "added by hand"], `${base}[${i}].keys[${j}].firstSeen`, `${base}[${i}].keys[${j}].state`]);
      }));
      return { n: lines.length, lines };
    };
    const activates = rows(s.agents, "subject.agents", (key) => key.state === "provisional");
    const keeps = rows(s.agents, "subject.agents", (key) => key.state !== "provisional");
    const inert = rows(s.inert, "subject.inert", () => true);
    const section = (title: string, r: ReturnType<typeof rows>): void => {
      out.lines.push(r.n === 0 ? `${title.replace(/ \{n\}.*$/, "")}: none.` : title.replace("{n}", String(r.n)));
      for (const [text, ...refs] of r.lines) out.say(text, ...refs);
    };
    out.reasons.push("decides which computers can act as agents");
    section("Activates {n} keys that are inert now:", activates);
    section("Keeps {n} keys active:", keeps);
    section("Makes {n} keys inert, so they authenticate nothing:", inert);
    // Every entry of either list has at least one key (the parser), so every agent name and key was shown in a line above.
    return `Activate ${activates.n} and make ${inert.n} keys inert`;
  },

  activation(act, out) {
    const u = act.subject as { agent: string; op: string; was: WakeWas };
    if (u.op === "unsuspend") {
      out.reasons.push("restores a suspended agent's authority");
      out.say(`  - Operation unsuspend: restores the suspended agent ${u.agent}. Its keys, bindings, grants and wake authority come back.`, "subject.op", "subject.agent");
      wasLines(out, u.was);
      return `Restore the suspended agent ${u.agent}`;
    }
    const s = act.subject as { agent: string; mode: string; senders: string[] | null; transports: string[]; was: WakeWas };
    out.say(`  - Operation set-policy: wake mode ${s.mode} for agent ${s.agent}.`, "subject.op", "subject.mode", "subject.agent");
    if (s.senders === null) {
      const any = s.mode === "granted" ? "any sender whose live grant covers the message" : "not used in this mode";
      out.say(`  - Senders that may wake it without an order: ${any}.`, ["subject.senders", any]);
    } else if (s.senders.length === 0) out.lines.push("  - Senders that may wake it without an order: none.");
    else out.say(`  - Senders that may wake it without an order: ${s.senders.join(", ")}.`, ...s.senders.map((_, i) => `subject.senders[${i}]`));
    if (s.transports.length === 0) out.lines.push("  - Wake transports: none.");
    else out.say(`  - Wake transports: ${s.transports.join(", ")}.`, ...s.transports.map((_, i) => `subject.transports[${i}]`));
    wasLines(out, s.was);
    return `Change how ${s.agent} is woken`;
  },

  "declare-task"(act, out) {
    const gone = act.subject as { agent: string; op: string; type: string };
    if (gone.op === "delete") {
      out.reasons.push("removes a task declaration");
      out.say(`  - Operation delete: deletes the declaration of ${gone.type} for ${gone.agent}; its consequential tombstone is removed, and the type is free text again.`, "subject.op", "subject.type", "subject.agent");
      return `Delete the declaration of task type ${gone.type} for ${gone.agent}`;
    }
    const s = act.subject as { agent: string; type: string; class: string; source: string; declaration: unknown; replaces: { class?: string; summary?: string; unreadable?: true } | null };
    if (s.class === "consequential") out.reasons.push("declares a task that has consequences");
    out.say(`  - Operation declare: agent ${s.agent} takes task type ${s.type}: class ${s.class}, from ${s.source}.`, "subject.op", "subject.agent", "subject.type", "subject.class", "subject.source");
    if (s.replaces === null) out.say("  - It replaces no earlier declaration: this is a new type for this agent.", ["subject.replaces", "no"]);
    else if (s.replaces.unreadable) out.say("  - It replaces a declaration now stored that no longer parses, so it cannot be shown here.", ["subject.replaces.unreadable", "no longer parses"]);
    else {
      out.say(`  - It replaces the declaration now stored: class ${s.replaces.class}.`, "subject.replaces.class");
      out.quote("subject.replaces.summary", "summary now stored", s.replaces.summary!);
    }
    if (s.declaration === null) out.say("  - This is a route assignment: no declaration of its own.", ["subject.declaration", "no declaration"]);
    else {
      // The summary is free text a person reads before touching the key: boxed, never merged into a sentence.
      out.quote("subject.declaration.summary", "summary", (s.declaration as { summary: string }).summary);
      out.listed(REVIEWED["declare-task"]);
      // An empty list has no leaf to list, so each says what its emptiness means: otherwise a schema that accepts anything reads the same as one that was left out.
      const d = s.declaration as { payload: { fields: unknown[] }; reply?: { fields: unknown[] }; defaults: { scope: unknown[] } };
      if (d.payload.fields.length === 0) out.lines.push("  - No declared payload fields: any free-text body is accepted.");
      if (d.reply === undefined) out.lines.push("  - No reply schema: an answer is the standard result.");
      else if (d.reply.fields.length === 0) out.lines.push("  - Reply declares no fields: any free-text answer is accepted.");
      if (d.defaults.scope.length === 0) out.lines.push("  - Default order terms: none. An order of this type carries no right to forward or to request runs.");
    }
    return `Declare task type ${s.type} for ${s.agent}`;
  },

  "enroll-credential"(act, out) {
    const s = act.subject as { credentialThumbprint: string; label: string; parentThumbprint: string; aaguidClaimed: string | null };
    out.reasons.push("adds a key that can sign");
    out.say(`  - Key ${s.credentialThumbprint} is added as a signer, enrolled by key ${s.parentThumbprint}. It becomes active after ${ACTIVATION_DELAY_HOURS} hours.`, "subject.credentialThumbprint", "subject.parentThumbprint");
    out.say(`  - Model claimed by the key, not verified: ${s.aaguidClaimed ?? "none"}.`, ["subject.aaguidClaimed", s.aaguidClaimed ?? "none"]);
    out.say(`  - Label: ${s.label}.`, "subject.label");
    out.lines.push("Both keys must be present: the new key touches too.");
    return `Enroll the security key "${s.label}"`;
  },


  "revoke-credential"(act, out) {
    const s = act.subject as { credentialThumbprint: string; label: string };
    out.say(`  - Key ${s.credentialThumbprint} stops being a signer, and every live order it signed is revoked.`, "subject.credentialThumbprint");
    out.say(`  - Label: ${s.label}.`, "subject.label");
    out.lines.push("Signed by a different key than the one revoked.");
    return `Revoke the security key "${s.label}"`;
  },

  "anchor-liveness"(act, out) {
    const s = act.subject as { principal: string; thumbprints: string[] };
    out.say(`  - Pinned keys for ${s.principal}: touch each of them. This proves you hold every key the deployment pins.`, "subject.principal");
    s.thumbprints.forEach((thumbprint, i) => out.say(`  - ${thumbprint}`, `subject.thumbprints[${i}]`));
    return `Prove you hold all ${s.thumbprints.length} pinned keys`;
  },


  "exec-approve"(act, out) {
    const s = act.subject as { profileId: string; runId: string | null };
    out.reasons.push("approves one run");
    const run = s.runId === null ? "no run id yet" : `run ${s.runId}`;
    out.say(`  - Profile ${s.profileId}, ${run}. Compare the candidate digest with the card.`, "subject.profileId", ["subject.runId", s.runId === null ? run : s.runId]);
    out.listed(REVIEWED["exec-approve"]);
    return `Approve one run of ${s.profileId}`;
  },
};

/**
 * The text of `act` under r1. Throws RenderIncomplete if any leaf of the act has no line; the caller shows nothing then, so there is no partial page to sign.
 * `act` must already have passed parseAct: this reads its shape, it does not check it.
 */
export function renderR1(act: Act): Rendered {
  const leaves = leafMap(act);
  const nonsemantic = new Set(RENDER_NONSEMANTIC[act.kind]);
  const out = new Out(leaves, nonsemantic);
  const headline = KINDS[act.kind](act, out);
  const high = out.reasons.length > 0;
  const body = out.lines;
  const ids: string[] = [];
  for (const [path, text] of leaves) {
    if (!nonsemantic.has(norm(path))) continue;
    ids.push(`${norm(path).split(".").at(-1)} ${text}`);
    out.seen.add(path);
  }
  const missing = [...leaves.keys()].filter((path) => !out.seen.has(path));
  if (missing.length > 0) throw new RenderIncomplete(missing);
  const total = leaves.size;
  const shown = [...leaves.keys()].filter((path) => out.seen.has(path)).length;
  const assurance = act.assurance === "hw-uv" ? "PIN and touch" : "touch only";
  const lines = [
    "Sign with your security key",
    `${headline}${high ? `  [High: ${out.reasons.join("; ")}]` : ""}`,
    `  - Signing as ${act.principal} for ${act.aud} at ${act.rpId}, with ${assurance}. Drafted by ${draftedByText(act)}. Valid until ${act.windowExpiresAt}.`,
    ...body,
    `This act: ${act.kind} . ${shown} of ${total} fields shown . renderer ${act.renderer}${ids.length > 0 ? ` . ${ids.join(" . ")}` : ""}`,
    "Touch only if every line is what you intend.",
  ];
  return { lines, risk: high ? "high" : "normal", riskReasons: out.reasons, shown, total };
}

/** Renderers by version. A verifier selects by `act.renderer`; an unknown version is refused by parseAct before this is reached. */
export const RENDERERS = { r1: renderR1 } as const;
