// The five acts that widen an agent's authority (R4 plan 6.2, 5.11, P5c-a 5c-1): `agent-enroll`, `bind-existing`, `activation`, `declare-task` and the flip-time
// `key-inventory`. acts.ts hosts the ceremony (draft, open, one completion); this file is what is particular to them: the subject each is drafted into FROM
// STORED STATE (the browser and the caller supply references, never act bytes, INV4), and the effect each applies in the consuming transaction, which first
// compares what was signed with what is stored now (the compare-and-set) and refuses with `keys_changed` if anything it lists has moved.
//
// The effects reuse the registry, enrollment, activation, task and key modules the session path uses, so a signed act and a session call leave the same rows.
// Synchronous, because the consuming step is.

import { createHash } from "node:crypto";
import { KEYS_DOMAIN, MAX_INVENTORY_AGENTS } from "authority/src/act.ts";
import { MAX_AGENT_KEYS } from "authority/src/contract-kit.ts";
import { canonicalJson, domainDigestHex } from "authority/src/canonical.ts";
import { OAUTH_PROFILE, WORKSPACE, matches } from "authority/src/contract-kit.ts";
import type { Act } from "authority/src/act.ts";
import { isReserved } from "authority/src/task.ts";
import { parseActivation, policyOf, setPolicy, type ActivationPolicy } from "./activation.ts";
import { Refuse } from "./credentials.ts";
import * as enrollment from "./enrollment-store.ts";
import type { StartingGrant } from "./enrollment-store.ts";
import * as keys from "./keys.ts";
import { agentName, codeOf, fail, wireOf } from "./model.ts";
import * as registry from "./registry.ts";
import { isPlainText } from "authority/src/text.ts";
import { declare, declaredType, parseDeclaration, refuseManaged } from "./tasks.ts";
import type { TaskDeclaration } from "authority/src/task.ts";

/** What a draft of each core kind is made from: references and the owner's own words, never the bytes of an act. */
export type CoreDraft =
  | { kind: "agent-enroll"; enrollment: string; code: string }
  | { kind: "bind-existing"; agent: string; what: "workspace" | "oauth" | "key"; ref: string }
  | { kind: "activation"; agent: string; op: "unsuspend" }
  | { kind: "activation"; agent: string; op: "set-policy"; policy: unknown }
  | { kind: "declare-task"; agent: string; declaration: unknown }
  | { kind: "key-inventory"; include: string[]; leave: string[] };
export const CORE_KINDS = ["agent-enroll", "bind-existing", "activation", "declare-task", "key-inventory"] as const;
export const isCoreDraft = (input: { kind: string }): input is CoreDraft => (CORE_KINDS as readonly string[]).includes(input.kind);

type Subject = Record<string, unknown>;
const keysDigest = (list: readonly keys.KeyRecord[]): Promise<string> => domainDigestHex(KEYS_DOMAIN, list);
const isoOf = (ms: number): string => new Date(ms).toISOString();
const agentRow = (sql: SqlStorage, name: string): { kind: string; workspace_id: string | null } => {
  const row = sql.exec<{ kind: string; workspace_id: string | null }>("SELECT kind, workspace_id FROM agents WHERE name = ?", name).toArray()[0];
  if (!row) throw fail("not_found", `no agent named ${name}`);
  return row;
};

/** A starting permission as the act lists it (authority's grantOf): an outgoing one from the new agent to one of its owner's, no type list meaning any type. */
const grantsOf = (principal: string, agent: string, grants: readonly StartingGrant[]): Subject[] =>
  grants.map((g) => ({
    direction: "out", from: wireOf({ principal, agent }), to: g.to, mode: g.mode, expiresAt: g.expiresAt === null ? null : isoOf(g.expiresAt), types: [...(g.taskTypes ?? [])].toSorted(),
  }));
/**
 * The agent's whole key list as an `agent-enroll` act lists it (spec 6.2): its keys now and the one being added, sorted. A key's `state` is what it is BEFORE the
 * touch, which the act changes: the new key is listed inert, with the time its computer redeemed the code, which is what is stored as its first-seen time.
 */
const keysWithEnrolled = (sql: SqlStorage, f: enrollment.EnrollmentFacts): keys.KeyRecord[] =>
  [...keys.recordsOf(sql, f.agent), { thumbprint: f.thumbprint, device: f.device, firstSeen: isoOf(f.redeemedAt), state: "provisional" as const }].toSorted((a, b) => (a.thumbprint < b.thumbprint ? -1 : 1));

/** The stored body of a `declare-task` act: everything of the declaration but the type, class and source, which the subject carries beside it. */
const declarationBody = (d: TaskDeclaration): Subject => {
  const { type: _type, class: _class, source: _source, ...rest } = d;
  return rest as unknown as Subject;
};

/**
 * The declaration an act replaces, as it lists it: class and summary, and a digest of the stored ROW (class, source, text), which the effect compares. A row that
 * no longer parses is still a row: it is listed as unreadable and compared by the same digest, so it is never presented as a new type.
 */
function replacedBy(sql: SqlStorage, agent: string, type: string): { class: string; summary: string; digest: string } | { unreadable: true; digest: string } | null {
  const row = sql.exec<{ class: string; source: string; declaration: string }>("SELECT class, source, declaration FROM tasks WHERE agent = ? AND type = ?", agent, type).toArray()[0];
  if (!row) return null;
  const digest = createHash("sha256").update(`knitli-decl/v1\0${row.class}\0${row.source}\0${row.declaration}`).digest("hex");
  const was = declaredType(sql, agent, type);
  return was !== null && isPlainText(was.summary) ? { class: was.class, summary: was.summary, digest } : { unreadable: true, digest };
}
/** The wake policy and when the agent was suspended (null: not) an activation act is drafted against, spelled as the act spells them (sorted transports). */
function wakeWas(sql: SqlStorage, agent: string): Subject {
  const policy = policyOf(sql, agent);
  if (!policy) throw fail("not_found", `no agent named ${agent}`);
  const at = sql.exec<{ suspended_at: number | null }>("SELECT suspended_at FROM agents WHERE name = ?", agent).one().suspended_at;
  return { mode: policy.mode, senders: policy.senders, transports: [...policy.transports].toSorted(), suspendedAt: at === null ? null : isoOf(at) };
}

// --- drafting: the subject, from stored state -------------------------------------------------------------------

/** The closed subject of a core act, composed from what the Mailbox stores now. Throws coded errors (the admin API's refusals). */
export async function subjectOf(sql: SqlStorage, input: CoreDraft, principal: string, now: number): Promise<Subject> {
  switch (input.kind) {
    case "agent-enroll": {
      const f = enrollment.factsForAct(sql, input.enrollment, input.code, now);
      const list = keysWithEnrolled(sql, f);
      return {
        agent: f.agent, agentKeyThumbprint: f.thumbprint, deviceName: f.device, enrollId: input.enrollment, presetId: "none", presetVersion: 0, terms: [],
        grants: grantsOf(principal, f.agent, f.grants), keys: list, keysDigest: await keysDigest(list),
      };
    }
    case "bind-existing": {
      const agent = agentName(input.agent);
      const row = agentRow(sql, agent);
      if (input.what === "workspace") {
        if (row.kind !== "os") throw fail("invalid", "only an os agent binds to a workspace");
        if (!matches(input.ref, WORKSPACE)) throw fail("invalid", "that is not a workspace id");
        const holder = registry.agentForWorkspace(sql, input.ref);
        if (holder !== null && holder !== agent) throw fail("conflict", `that workspace is already bound to ${holder}`);
        return { agent, what: "workspace", ref: input.ref, replaces: row.workspace_id, keys: [], keysDigest: await keysDigest([]) };
      }
      // Both of the others list the agent's whole key list, so the signer sees every key of the agent and what the touch does to each (spec 6.2).
      const all = keys.recordsOf(sql, agent);
      if (input.what === "oauth") {
        if (row.kind !== "external") throw fail("invalid", "only an external agent binds to an OAuth profile");
        if (!matches(input.ref, OAUTH_PROFILE)) throw fail("invalid", "that is not an OAuth profile");
        return { agent, what: "oauth", ref: input.ref, replaces: registry.oauthBinding(sql, input.ref)?.agent ?? null, keys: all, keysDigest: await keysDigest(all) };
      }
      // A key: one the Mailbox already holds inert. Listing it is what makes it a key that can act.
      const record = all.find((k) => k.thumbprint === input.ref);
      if (!record) throw fail("not_found", `${agent} has no such key`);
      if (record.state !== "provisional") throw fail("conflict", "that key is already active");
      return { agent, what: "key", ref: record.thumbprint, replaces: null, keys: all, keysDigest: await keysDigest(all) };
    }
    case "activation": {
      const agent = agentName(input.agent);
      const was = wakeWas(sql, agent);
      if (input.op === "unsuspend") {
        if (was.suspendedAt === null) throw fail("conflict", `${agent} is not suspended`);
        return { agent, op: "unsuspend", was };
      }
      const next = parseActivation(input.policy);
      return { agent, op: "set-policy", mode: next.mode, senders: next.senders, transports: next.transports, was };
    }
    case "declare-task": {
      const agent = agentName(input.agent);
      agentRow(sql, agent);
      const declaration = parseDeclaration(input.declaration, "owner");
      if (isReserved(declaration.type)) throw fail("forbidden", "task types starting with exec/ come from the image catalog; a router is assigned one with a route: declaration, which needs the catalog (not built yet)");
      refuseManaged(sql, agent, declaration);
      return { agent, op: "declare", type: declaration.type, class: declaration.class, source: declaration.source, declaration: declarationBody(declaration), replaces: replacedBy(sql, agent, declaration.type) };
    }
    case "key-inventory": {
      // Active keys are listed and stay active; an inert key is activated only if it is named in `include`; an active key named in `leave` is made inert, and listed
      // in `inert` so the signer sees it. A key in none of these is not touched, and not in the act.
      const all = keys.allRecords(sql);
      const known = new Map(all.flatMap(({ agent, keys: list }) => list.map((k) => [k.thumbprint, { agent, k }] as const)));
      for (const t of input.include) if (known.get(t)?.k.state !== "provisional") throw fail("not_found", "include names a key that is not inert");
      for (const t of input.leave) if (known.get(t)?.k.state !== "active") throw fail("not_found", "leave names a key that is not active");
      if (input.include.some((t) => input.leave.includes(t))) throw fail("invalid", "a key is activated or made inert, not both");
      const part = (keep: (k: keys.KeyRecord) => boolean) => all.map(({ agent, keys: list }) => ({ agent, keys: list.filter(keep) })).filter(({ keys: kept }) => kept.length > 0);
      const listed = part((k) => (k.state === "active" ? !input.leave.includes(k.thumbprint) : input.include.includes(k.thumbprint)));
      const gone = part((k) => input.leave.includes(k.thumbprint));
      if (listed.length === 0) throw fail("invalid", "no agent has a key to list");
      if (listed.length > MAX_INVENTORY_AGENTS || gone.length > MAX_INVENTORY_AGENTS) throw fail("invalid", `one inventory lists at most ${MAX_INVENTORY_AGENTS} agents with keys: remove the ones that are not used`);
      const total = [...listed, ...gone].reduce((n, { keys: list }) => n + list.length, 0);
      if (total > MAX_INVENTORY_AGENTS * MAX_AGENT_KEYS) throw fail("invalid", `one inventory names at most ${MAX_INVENTORY_AGENTS * MAX_AGENT_KEYS} keys in all: make fewer inert, or remove the agents that are not used`);
      const withDigest = (entries: typeof listed) => Promise.all(entries.map(async (entry) => ({ ...entry, keysDigest: await keysDigest(entry.keys) })));
      const agents = await withDigest(listed);
      const inert = await withDigest(gone);
      return { agents, inert, inventoryDigest: await domainDigestHex(KEYS_DOMAIN, { agents, inert }) };
    }
  }
}

// --- the effects, in the consuming transaction ------------------------------------------------------------------

/** What an effect is given: the Mailbox's SQLite and clock, the act as signed (and its digest), and the one thing that lives outside SQL. */
export type CoreHost = { sql: SqlStorage; now: number; act: Act; digest: string; forgetWake?: (agent: string) => void; enrollAllowed?: (principal: string) => boolean };

/**
 * Runs an effect's store calls so that a refusal of theirs rolls the consumption back (the touch is not spent) and keeps its own meaning: a missing agent is
 * `not_found`, and any other coded refusal (conflict, invalid, suspended, over a limit, ...) is `denied`, the host's closest reason (the reasons are a closed list).
 * Only a compare-and-set mismatch is `keys_changed`, and each effect throws that itself. A fault that is not a coded refusal is rethrown as it is.
 */
export function moved<T>(work: () => T): T {
  try {
    return work();
  } catch (error) {
    if (error instanceof Refuse || codeOf(error) === undefined) throw error;
    throw new Refuse(codeOf(error) === "not_found" ? "not_found" : "denied");
  }
}
/** The same for a store call that is itself a read of whether the thing the act was drafted against is still there: any coded refusal means it moved, so `keys_changed`. */
function stale<T>(work: () => T): T {
  try {
    return work();
  } catch (error) {
    if (error instanceof Refuse || codeOf(error) === undefined) throw error;
    throw new Refuse("keys_changed");
  }
}
const same = (stored: unknown, signed: unknown): boolean => canonicalJson(stored as never) === canonicalJson(signed as never);

function enrollEffect(h: CoreHost): void {
  const s = h.act.subject as { agent: string; agentKeyThumbprint: string; deviceName: string; enrollId: string; grants: unknown; keys: { thumbprint: string }[] };
  // A computer is a key: the list that decides who may add one can narrow between the draft and the touch, so it is asked again here. No answer is a no.
  if (!h.enrollAllowed) throw new Refuse("unavailable");
  if (!h.enrollAllowed(h.act.principal)) throw new Refuse("denied");
  stale(() => {
    enrollment.confirmByAct(h.sql, s.enrollId, h.now, { thumbprint: s.agentKeyThumbprint, device: s.deviceName }, h.digest, (facts) => {
      // What was signed is what is stored: the agent's whole key list with the new key, and the permissions it starts with (compare-and-set, before any write).
      if (facts.agent !== s.agent || !keys.sameKeys(keysWithEnrolled(h.sql, facts), s.keys) || !same(grantsOf(h.act.principal, facts.agent, facts.grants), s.grants)) throw new Refuse("keys_changed");
    });
    // Only the new key is activated (confirmByAct). The rest of the list is shown and compared; promoting another inert key is a key-inventory `include`.
  });
}

function bindEffect(h: CoreHost): void {
  const s = h.act.subject as { agent: string; what: "workspace" | "oauth" | "key"; ref: string; replaces: string | null; keys: { thumbprint: string }[] };
  moved(() => {
    const row = agentRow(h.sql, s.agent);
    if (s.what === "workspace") {
      if (row.workspace_id !== s.replaces) throw new Refuse("keys_changed");
      registry.bindWorkspace(h.sql, s.agent, s.ref);
      // The race rule (mailbox.bindWorkspace): a wake follows its workspace, never the agent to a new one.
      if (row.workspace_id !== s.ref) (h.forgetWake ?? unavailable)(s.agent);
    } else if (s.what === "oauth") {
      if ((registry.oauthBinding(h.sql, s.ref)?.agent ?? null) !== s.replaces) throw new Refuse("keys_changed");
      if (!keys.sameKeys(keys.recordsOf(h.sql, s.agent), s.keys)) throw new Refuse("keys_changed");
      registry.bindOAuth(h.sql, s.ref, s.agent); // activates no key: the list is shown and compared
    } else {
      if (!keys.sameKeys(keys.recordsOf(h.sql, s.agent), s.keys)) throw new Refuse("keys_changed");
      keys.activate(h.sql, s.agent, [s.ref], h.digest); // only the key the act is about
    }
  });
}

const unavailable = (): never => {
  throw new Refuse("unavailable");
};

function activationEffect(h: CoreHost): void {
  const s = h.act.subject as { agent: string; op: "unsuspend" | "set-policy"; mode?: ActivationPolicy["mode"]; senders?: string[] | null; transports?: ActivationPolicy["transports"]; was: unknown };
  moved(() => {
    // The policy and suspension it was drafted against must still be the stored ones, or an old draft signed later would undo a newer narrowing.
    if (!same(wakeWas(h.sql, s.agent), s.was)) throw new Refuse("keys_changed");
    if (s.op === "unsuspend") registry.setSuspended(h.sql, s.agent, null);
    else setPolicy(h.sql, s.agent, { mode: s.mode!, senders: s.senders!, transports: s.transports! });
  });
}

function declareEffect(h: CoreHost): void {
  const s = h.act.subject as { agent: string; op: "declare" | "delete"; type: string; class: TaskDeclaration["class"]; source: TaskDeclaration["source"]; declaration: Subject | null; replaces: unknown };
  // A deletion has no path to apply it yet (no delete exists to gate), and a route assignment needs the catalog: neither is drafted, and a signed one is refused here.
  if (s.op !== "declare" || s.declaration === null) throw new Refuse("act_malformed");
  moved(() => {
    // The declaration it replaces must still be the stored one (or none, for a new type), or an old draft signed later would undo a newer narrowing.
    if (!same(replacedBy(h.sql, s.agent, s.type), s.replaces)) throw new Refuse("keys_changed");
    declare(h.sql, s.agent, parseDeclaration({ type: s.type, class: s.class, ...s.declaration }, s.source), h.now);
    h.sql.exec("UPDATE tasks SET act_digest = ? WHERE agent = ? AND type = ?", h.digest, s.agent, s.type);
  });
}

function inventoryEffect(h: CoreHost): void {
  type Entry = { agent: string; keys: { thumbprint: string }[] };
  const s = h.act.subject as { agents: Entry[]; inert: Entry[] };
  moved(() => {
    // Every key the act names, to keep, activate or make inert, is what is stored (device, first seen and state), or the list is stale and nothing is applied.
    for (const entry of [...s.agents, ...s.inert]) {
      const now = keys.recordsFor(h.sql, entry.agent, entry.keys.map((k) => k.thumbprint));
      if (now === null || !keys.sameKeys(now, entry.keys)) throw new Refuse("keys_changed");
    }
    for (const entry of s.agents) keys.activate(h.sql, entry.agent, entry.keys.map((k) => k.thumbprint), h.digest);
    // Exactly the keys the act lists as inert, and no others: a key it does not name is not touched (INV14 and the signer's own list).
    for (const entry of s.inert) keys.demote(h.sql, entry.agent, entry.keys.map((k) => k.thumbprint));
  });
}

/** Applies a core act, or throws. Exhaustive over the core kinds; a kind that is not one is the caller's to refuse. */
export function applyCore(h: CoreHost): void {
  switch (h.act.kind) {
    case "agent-enroll":
      return enrollEffect(h);
    case "bind-existing":
      return bindEffect(h);
    case "activation":
      return activationEffect(h);
    case "declare-task":
      return declareEffect(h);
    case "key-inventory":
      return inventoryEffect(h);
    default:
      throw new Refuse("act_malformed");
  }
}
