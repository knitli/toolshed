// Canonical source metadata and a retry outbox. Private publication is separately gated;
// accepting a reference never grants a consumer or native turn.
import { addressOf, checkedType, codeOf, fail, partyAddress, wireOf, type Stored } from "./model.ts";
import { THUMBPRINT } from "./agent-token.ts";
import { policyOf, wakeAllowed, type ActivationVerdictV1 } from "./activation.ts";
import { accepts, coversReplay, isSuspended, wakeGrantCovers } from "./registry.ts";
import { liveOrderFor, type CredentialLive } from "./orders.ts";
import * as tasks from "./tasks.ts";

import { parseEventMessageConsumer, type EventMessagePublicationV1, type EventMessageConsumerV1, type EventMessageRouteV1 } from "./event-authority-contract.ts";

export const BRIDGE_CAPACITY = 1000;
/** No unknown attempt is pruned to make room. Trusted settlement/retention must qualify first. */
export const MESSAGE_ATTEMPT_CAPACITY = 1000;
export const MESSAGE_ROUTE_OPERATION_CAPACITY = 1000;
export const MESSAGE_ROUTE_OPERATION_BYTE_CAPACITY = 1_048_576;
export const BRIDGE_SCHEMA = `
CREATE TABLE IF NOT EXISTS message_event_outbox (
  message_id TEXT PRIMARY KEY,
  agent TEXT NOT NULL,
  agent_created_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  next_at INTEGER NOT NULL,
  published_at INTEGER
);
CREATE TABLE IF NOT EXISTS message_event_sources (
  message_id TEXT PRIMARY KEY,
  agent TEXT NOT NULL,
  agent_created_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  published_at INTEGER
);
CREATE TRIGGER IF NOT EXISTS message_event_source_cleanup AFTER DELETE ON messages
WHEN OLD.box = 'in' BEGIN
  DELETE FROM message_event_sources WHERE message_id = OLD.id;
END;
CREATE TRIGGER IF NOT EXISTS message_event_source_ack AFTER UPDATE OF published_at ON message_event_outbox
WHEN NEW.published_at IS NOT NULL BEGIN
  UPDATE message_event_sources SET published_at = NEW.published_at
  WHERE message_id = NEW.message_id AND agent = NEW.agent
    AND agent_created_at = NEW.agent_created_at AND created_at = NEW.created_at
    AND published_at IS NULL;
END;
CREATE INDEX IF NOT EXISTS message_event_outbox_due ON message_event_outbox (published_at, next_at);
CREATE TRIGGER IF NOT EXISTS message_event_outbox_cleanup AFTER DELETE ON messages
WHEN OLD.box = 'in' BEGIN
  DELETE FROM message_event_outbox WHERE message_id = OLD.id;
END;
CREATE TABLE IF NOT EXISTS message_wake_routes (
  agent TEXT PRIMARY KEY, owner TEXT NOT NULL CHECK(owner IN ('os','event')),
  generation INTEGER NOT NULL, consumer TEXT
);
CREATE TABLE IF NOT EXISTS message_route_operations (
  operation_id TEXT PRIMARY KEY, agent TEXT NOT NULL, agent_created_at INTEGER NOT NULL,
  request_json TEXT NOT NULL, result_json TEXT NOT NULL, committed_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS message_wake_attempts (
  attempt_id TEXT PRIMARY KEY, agent TEXT NOT NULL, identity TEXT NOT NULL, reserved_at INTEGER NOT NULL,
  activation_json TEXT
);
CREATE INDEX IF NOT EXISTS message_wake_attempts_retention ON message_wake_attempts(reserved_at);
CREATE TABLE IF NOT EXISTS message_attempt_settlements (
  attempt_id TEXT PRIMARY KEY, receipt_id TEXT NOT NULL UNIQUE,
  fact_json TEXT NOT NULL, settled_at INTEGER NOT NULL
);`;

type Source = { message_id: string; agent: string; agent_created_at: number; created_at: number; published_at: number | null };
type Pending = Omit<Source, "published_at"> & { attempts: number };

/** Preserve the original staged incarnation; never synthesize historical source authority from today's agent. */
export function migrateMessageSources(sql: SqlStorage): void {
  if (!sql.exec<{ name: string }>("PRAGMA table_info(message_wake_attempts)").toArray().some(column => column.name === "activation_json"))
    sql.exec("ALTER TABLE message_wake_attempts ADD COLUMN activation_json TEXT");
  sql.exec(`INSERT OR IGNORE INTO message_event_sources(message_id,agent,agent_created_at,created_at,published_at)
    SELECT e.message_id,e.agent,e.agent_created_at,e.created_at,e.published_at
    FROM message_event_outbox e JOIN messages m ON m.box='in' AND m.id=e.message_id
    WHERE m.agent=e.agent AND m.created_at=e.created_at`);
}
/** Internal source reference, deliberately not an Event native-protocol envelope. */
export type MessagePublication = EventMessagePublicationV1;
export type BridgeOwner = { namespace: string; principal: string; admitted: (principal: string) => boolean; /** Omission denies ordered messages while leaving legacy unordered routes available. */ live?: CredentialLive };

/** Called inside the inbox transaction, and on duplicate delivery using the stored row. */
export function stageMessageEvent(sql: SqlStorage, message: Stored, now: number, publisherEnabled = true): void {
  const recipient = addressOf(message.recipient, "recipient");
  if (recipient.agent === null || message.flags.containsRestrictedData || message.flags.sharingProhibited) return;
  const policy = policyOf(sql, recipient.agent);
  if (!policy?.transports.includes("event")) return;
  const source = sql.exec<Source>("SELECT * FROM message_event_sources WHERE message_id=?", message.id).toArray()[0];
  if (source && (source.agent !== recipient.agent || source.published_at !== null)) return;
  if (sql.exec("SELECT message_id FROM message_event_outbox WHERE message_id=?", message.id).toArray().length) return;
  sql.exec(`INSERT OR IGNORE INTO message_event_sources(message_id,agent,agent_created_at,created_at,published_at)
    SELECT m.id,m.agent,a.created_at,m.created_at,NULL FROM messages m JOIN agents a ON a.name=m.agent
    WHERE m.box='in' AND m.id=? AND m.agent=? AND a.created_at<=m.created_at
      AND m.status!='cancelled' AND (m.expires_at IS NULL OR m.expires_at>?)`,
  message.id, recipient.agent, now);
  // The source row is the durable publication obligation. Keep it even when the
  // bounded retry outbox is full; the publisher materializes it when space opens.
  if (!publisherEnabled || sql.exec<{ n: number }>("SELECT count(*) AS n FROM message_event_outbox").one().n >= BRIDGE_CAPACITY) return;
  sql.exec(`INSERT INTO message_event_outbox (message_id,agent,agent_created_at,created_at,next_at)
    SELECT s.message_id,s.agent,s.agent_created_at,s.created_at,? FROM message_event_sources s
    JOIN messages m ON m.box='in' AND m.id=s.message_id JOIN agents a ON a.name=s.agent
    WHERE s.message_id=? AND s.agent=? AND s.published_at IS NULL
      AND m.agent=s.agent AND m.created_at=s.created_at AND a.created_at=s.agent_created_at
      AND m.status!='cancelled' AND (m.expires_at IS NULL OR m.expires_at>?)`,
  now, message.id, recipient.agent, now);
}

/** Fill a bounded number of retry rows from delivery-time source obligations. */
export function materializeMessagePublications(sql: SqlStorage, now = Date.now()): number {
  const current = sql.exec<{ n: number }>("SELECT count(*) AS n FROM message_event_outbox").one().n;
  const capacity = Math.min(50, Math.max(0, BRIDGE_CAPACITY - current));
  if (capacity === 0) return 0;
  sql.exec(`INSERT OR IGNORE INTO message_event_outbox(message_id,agent,agent_created_at,created_at,next_at)
    SELECT s.message_id,s.agent,s.agent_created_at,s.created_at,? FROM message_event_sources s
    JOIN messages m ON m.box='in' AND m.id=s.message_id JOIN agents a ON a.name=s.agent
    WHERE s.published_at IS NULL AND m.agent=s.agent AND m.created_at=s.created_at
      AND a.created_at=s.agent_created_at AND m.status!='cancelled'
      AND (m.expires_at IS NULL OR m.expires_at>?)
      AND NOT EXISTS (SELECT 1 FROM message_event_outbox e WHERE e.message_id=s.message_id)
    ORDER BY s.created_at,s.message_id LIMIT ?`, now, now, capacity);
  const after = sql.exec<{ n: number }>("SELECT count(*) AS n FROM message_event_outbox").one().n;
  return Math.max(0, after - current);
}

function eligible(sql: SqlStorage, owner: BridgeOwner, pending: Pick<Source, "message_id" | "agent" | "agent_created_at" | "created_at">, now: number): ActivationVerdictV1 | null {
  if (!owner.admitted(owner.principal)) return null;
  const row = sql.exec<{ row: string; status: string; expires_at: number | null; agent: string; agent_created_at: number; created_at: number }>(
    `SELECT m.row,m.status,m.expires_at,m.agent,m.created_at,a.created_at AS agent_created_at
     FROM messages m JOIN agents a ON a.name=m.agent WHERE m.box='in' AND m.id=?`, pending.message_id,
  ).toArray()[0];
  if (!row || row.agent !== pending.agent || row.agent_created_at !== pending.agent_created_at || row.created_at !== pending.created_at || row.status === "cancelled" ||
    (row.expires_at !== null && row.expires_at <= now)) return null;
  const message = JSON.parse(row.row) as Stored;
  if (message.recipient !== `${owner.principal}/${pending.agent}` || message.flags.containsRestrictedData || message.flags.sharingProhibited ||
    (message.expiresAt !== null && Date.parse(message.expiresAt) <= now)) return null;
  const sender = partyAddress(message.sender);
  let order = null;
  try {
    order = liveOrderFor(sql, message, pending.agent, { owner: owner.principal, live: owner.live ?? (() => false) }, now);
  } catch (error) {
    const code = codeOf(error);
    // A carried but stale/invalid claim denies activation outright; it may not
    // be reinterpreted as an ordinary message and fall through to sender grants.
    if (code === "order_unknown" || code === "out_of_envelope") return null;
    throw error;
  }
  const humanRoot = sender.agent === null && sender.principal === owner.principal && message.kind === "request" &&
    message.sender.client === "order" && message.applied === "human-ordered" && order?.root === true;
  if ((sender.agent === null && !humanRoot) || !owner.admitted(sender.principal)) return null;
  if (sender.agent !== null && sender.principal === owner.principal && isSuspended(sql, sender.agent)) return null;
  if (message.kind !== "reply" && !humanRoot) {
    const type = checkedType(message);
    if (sender.principal === owner.principal
      ? !coversReplay(sql, sender.agent!, addressOf(message.recipient, "recipient"), message.id, now, type)
      : !accepts(sql, pending.agent, sender, now, type)) return null;
  }
  const policy = policyOf(sql, pending.agent);
  if (policy === null) return null;
  const type = checkedType(message), recipient = addressOf(message.recipient, "recipient");
  const wakeGrant = sender.principal === owner.principal && sender.agent !== null && type !== null &&
    tasks.declaredType(sql, pending.agent, type)?.class === "inform" &&
    wakeGrantCovers(sql, sender.agent, recipient, message.id, now, type);
  const verdict = wakeAllowed(policy, {
    sender: wireOf(partyAddress(message.sender)), transport: "event", order, wakeGrant,
    suspended: isSuspended(sql, pending.agent), overBudget: false,
  });
  return verdict.allowed ? verdict : null;
}

/**
 * Bounded at-least-once source publication. A publisher must dedupe publicationId
 * and acknowledge that exact durable record; throws/ambiguous acks retain it.
 * The default-disabled private publisher supplies the RPC. Sink dispatch independently rechecks source
 * eligibility and reserve the shared budget under the exclusive consumer fence.
 */
export async function publishMessageEvents(
  sql: SqlStorage, owner: BridgeOwner,
  publish: (event: MessagePublication) => Promise<{ publicationId: string }>,
  now: () => number = Date.now,
): Promise<void> {
  materializeMessagePublications(sql, now());
  const pending = sql.exec<Pending>(`SELECT message_id,agent,agent_created_at,created_at,attempts
    FROM message_event_outbox e WHERE published_at IS NULL AND next_at<=?
    AND EXISTS (SELECT 1 FROM message_event_sources s WHERE s.message_id=e.message_id AND s.agent=e.agent
      AND s.agent_created_at=e.agent_created_at AND s.created_at=e.created_at AND s.published_at IS NULL)
    ORDER BY next_at,message_id LIMIT 50`, now()).toArray();
  for (const row of pending) {
    let attemptNumber = row.attempts;
    try {
      if (!eligible(sql, owner, row, now())?.allowed) {
        // Keep temporarily disabled work without starving later eligible rows.
        sql.exec("UPDATE message_event_outbox SET next_at=? WHERE message_id=? AND published_at IS NULL", now() + 60_000, row.message_id);
        continue;
      }
      const publicationId = JSON.stringify([owner.namespace, owner.principal, row.agent, row.agent_created_at, row.message_id]);
      // Persist retry timing before I/O, including a crash or an unacknowledged acceptance.
      const attempt = sql.exec<{ attempts: number }>(`UPDATE message_event_outbox SET attempts=attempts+1,next_at=?
        WHERE message_id=? AND published_at IS NULL RETURNING attempts`,
        now() + Math.min(60_000 * 2 ** Math.min(row.attempts, 6), 3_600_000), row.message_id).toArray()[0];
      if (!attempt) continue;
      attemptNumber = attempt.attempts;
      const ack = await publish({ publicationId, topic: "knitli.message.created", namespace: owner.namespace,
        principal: owner.principal, agent: row.agent, messageId: row.message_id, storedAt: new Date(row.created_at).toISOString() });
      // Revocation/cancellation during publication never settles or erases source work.
      if (ack.publicationId === publicationId && eligible(sql, owner, row, now())?.allowed)
        sql.exec(`UPDATE message_event_outbox SET published_at=? WHERE message_id=? AND agent=? AND agent_created_at=? AND created_at=? AND attempts=? AND published_at IS NULL`,
          now(), row.message_id, row.agent, row.agent_created_at, row.created_at, attempt.attempts);
    } catch {
      // A throwing source must not hot-loop or strand later rows. Preserve any newer attempt's
      // retry time, and never let a late failed/unknown result rewrite its admission state.
      sql.exec(`UPDATE message_event_outbox SET next_at=max(next_at,?) WHERE message_id=? AND agent=?
        AND agent_created_at=? AND created_at=? AND attempts=? AND published_at IS NULL`,
      now() + 60_000, row.message_id, row.agent, row.agent_created_at, row.created_at, attemptNumber);
    }
  }
}

/** Internal route-transfer seam and explicit test injection; Mailbox admission defaults to its consumer service. */
export type MessageRoutingAuthority = {
  authorizeTransfer(input: Readonly<{ namespace: string; principal: string; agent: string; operationId: string; agentCreatedAt: number; keyThumbprint: string | null; replay: boolean; previous: EventMessageRouteV1; next: EventMessageRouteV1 }>): Promise<boolean>;
  currentConsumer(input: Readonly<{ principal: string; agent: string; keyThumbprint: string; consumer: EventMessageConsumerV1 }>): Promise<boolean>;
};

export function messageRoute(sql: SqlStorage, agent: string): EventMessageRouteV1 {
  const row = sql.exec<{ owner: "os" | "event"; generation: number; consumer: string | null }>(
    "SELECT owner,generation,consumer FROM message_wake_routes WHERE agent=?", agent,
  ).toArray()[0];
  return row ? { owner: row.owner, generation: row.generation, consumer: row.consumer === null ? null : JSON.parse(row.consumer) } : { owner: "os", generation: 0, consumer: null };
}

export type MessageRouteTransfer = Readonly<{
  operationId: string; agentCreatedAt: number; expectedGeneration: number; keyThumbprint: string | null;
  owner: "os" | "event"; consumer: EventMessageConsumerV1 | null;
}>;
/** Historical completion only: route is the committed result, never current consumer authority. */
export type MessageRouteReceipt = Readonly<{
  operationId: string; agentCreatedAt: number; route: EventMessageRouteV1; replayed: boolean;
}>;
type RouteOperation = { request_json: string; result_json: string };

/** Module-only seam. The trusted host verifies fresh owner consent, including on historical replay. */
export async function transferMessageRoute(
  storage: DurableObjectStorage, owner: BridgeOwner, agent: string,
  input: MessageRouteTransfer, authority?: MessageRoutingAuthority,
  finalGuard?: (phase: "historical" | "commit") => void,
): Promise<MessageRouteReceipt> {
  // Capture every selector before the first await; caller mutation cannot change the committed action.
  const { operationId, agentCreatedAt, expectedGeneration, keyThumbprint, owner: target } = input;
  const namespace = owner.namespace, principal = owner.principal, admitted = owner.admitted;
  if (typeof operationId !== "string" || !/^[A-Za-z0-9_-]{1,128}$/.test(operationId) ||
    !Number.isSafeInteger(agentCreatedAt) || agentCreatedAt < 0 ||
    !Number.isSafeInteger(expectedGeneration) || expectedGeneration < 0 || expectedGeneration >= Number.MAX_SAFE_INTEGER ||
    !["os", "event"].includes(target)) throw fail("invalid", "invalid message routing transfer");
  const consumer = target === "event" ? parseEventMessageConsumer(input.consumer) : null;
  if (target === "event" ? consumer === null : input.consumer !== null) throw fail("invalid", "invalid message routing consumer");
  // This is an exact selector, not proof that the key is currently registered or active.
  if (target === "event" ? typeof keyThumbprint !== "string" || !THUMBPRINT.test(keyThumbprint) : keyThumbprint !== null)
    throw fail("invalid", "invalid message routing key selector");
  const request = JSON.stringify({ operationId, namespace, principal, agent, agentCreatedAt, expectedGeneration, owner: target, consumer, keyThumbprint });
  if (new TextEncoder().encode(request).byteLength > 4096) throw fail("invalid", "message routing request is too large");
  const liveIncarnation = () => storage.sql.exec<{ created_at: number }>("SELECT created_at FROM agents WHERE name=?", agent).toArray()[0]?.created_at;
  const receipt = (): { previous: EventMessageRouteV1; route: EventMessageRouteV1 } | null => {
    const row = storage.sql.exec<RouteOperation>("SELECT request_json,result_json FROM message_route_operations WHERE operation_id=?", operationId).toArray()[0];
    if (!row) return null;
    if (row.request_json !== request) throw fail("conflict", "message routing operation changed");
    return JSON.parse(row.result_json);
  };
  if (!authority || !admitted(principal)) throw fail("forbidden", "qualified message routing authority is unavailable");
  if (liveIncarnation() !== agentCreatedAt) throw fail("conflict", "message routing agent incarnation changed");
  const recorded = receipt();
  const previous = recorded?.previous ?? messageRoute(storage.sql, agent);
  if (!recorded && previous.generation !== expectedGeneration) throw fail("conflict", "message routing changed");
  const next: EventMessageRouteV1 = recorded?.route ?? { owner: target, generation: previous.generation + 1, consumer };
  if (!await authority.authorizeTransfer({ namespace, principal, agent, operationId, agentCreatedAt, keyThumbprint,
    replay: recorded !== null, previous: structuredClone(previous), next: structuredClone(next) }))
    throw fail("forbidden", "qualified message routing authority is unavailable");
  return storage.transactionSync(() => {
    if (!admitted(principal)) throw fail("forbidden", "message routing owner is no longer admitted");
    if (liveIncarnation() !== agentCreatedAt) throw fail("conflict", "message routing agent incarnation changed");
    // Another identical call may have committed while this call awaited authority.
    const completed = receipt();
    if (completed) {
      finalGuard?.("historical");
      return { operationId, agentCreatedAt, route: completed.route, replayed: true };
    }
    if (recorded) throw fail("conflict", "message routing operation is unavailable");
    finalGuard?.("commit");
    if (!policyOf(storage.sql, agent) || (next.owner === "event" && isSuspended(storage.sql, agent)))
      throw fail("forbidden", "message routing owner is no longer admitted");
    if (JSON.stringify(messageRoute(storage.sql, agent)) !== JSON.stringify(previous)) throw fail("conflict", "message routing changed");
    if (next.owner === "event" && !policyOf(storage.sql, agent)?.transports.includes("event"))
      throw fail("forbidden", "event transport is not owner-enabled");
    const result = JSON.stringify({ previous, route: next });
    const usage = storage.sql.exec<{ n: number; bytes: number }>(`SELECT count(*) AS n,
      coalesce(sum(length(CAST(operation_id AS BLOB))+length(CAST(agent AS BLOB))+16+
        length(CAST(request_json AS BLOB))+length(CAST(result_json AS BLOB))),0) AS bytes FROM message_route_operations`).one();
    const bytes = new TextEncoder().encode(operationId + agent + request + result).byteLength + 16;
    if (usage.n >= MESSAGE_ROUTE_OPERATION_CAPACITY || usage.bytes + bytes > MESSAGE_ROUTE_OPERATION_BYTE_CAPACITY)
      throw fail("over_budget", "message routing operation ledger is full");
    storage.sql.exec(`INSERT INTO message_wake_routes(agent,owner,generation,consumer) VALUES (?,?,?,?)
      ON CONFLICT(agent) DO UPDATE SET owner=excluded.owner,generation=excluded.generation,consumer=excluded.consumer`,
    agent, next.owner, next.generation, consumer === null ? null : JSON.stringify(consumer));
    storage.sql.exec(`INSERT INTO message_route_operations(operation_id,agent,agent_created_at,request_json,result_json,committed_at)
      VALUES (?,?,?,?,?,?)`, operationId, agent, agentCreatedAt, request, result, Date.now());
    return { operationId, agentCreatedAt, route: next, replayed: false };
  });
}

/** Resolve the canonical source row again at reservation and use boundaries. */
export function eligibleMessagePublication(sql: SqlStorage, owner: BridgeOwner, agent: string, messageId: string, now: number): string | null {
  return canonicalMessagePublication(sql, owner, agent, messageId, now)?.publicationId ?? null;
}

/** Reads canonical message activation facts and publication metadata from the authoritative mailbox. */
export function canonicalMessageActivation(sql: SqlStorage, owner: BridgeOwner, agent: string, messageId: string, now: number): { publication: MessagePublication; verdict: ActivationVerdictV1 } | null {
  const pending = sql.exec<Source>("SELECT * FROM message_event_sources WHERE message_id=? AND agent=?", messageId, agent).toArray()[0];
  if (!pending) return null;
  const verdict = eligible(sql, owner, pending, now);
  if (verdict === null) return null;
  const publication: MessagePublication = { publicationId: JSON.stringify([owner.namespace, owner.principal, pending.agent, pending.agent_created_at, pending.message_id]),
    topic: "knitli.message.created", namespace: owner.namespace, principal: owner.principal,
    agent: pending.agent, messageId: pending.message_id, storedAt: new Date(pending.created_at).toISOString() };
  return { publication, verdict };
}

/** Reads only an eligible canonical publication from the authoritative mailbox's source rows. */
export function canonicalMessagePublication(sql: SqlStorage, owner: BridgeOwner, agent: string, messageId: string, now: number): MessagePublication | null {
  return canonicalMessageActivation(sql, owner, agent, messageId, now)?.publication ?? null;
}
