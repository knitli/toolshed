// The credential chain (R4 plan 6.3, 6.7 step 6): a credential signs only if it chains, through human-signed `enroll-credential` acts, to a pin in the
// verifier's own configuration. The receipt key never certifies a human and the database is never a root (INV5); an anchor is a thumbprint a deploy named.
// Pure TypeScript: no Worker types, no I/O.
import { actChallenge, parseAct, subjectDigestsHold, type Act } from "./act.ts";
import { isoTime } from "./contract-kit.ts";
import { snapshot } from "./snapshot.ts";
import { renderR1 } from "./render.ts";
import { checkAssertion, readPinned, floorFor, stricter, thumbprintOf, type CredentialKey, type Evidence, type PinnedPresence } from "./webauthn.ts";

export const MAX_CHAIN_LINKS = 4;

/**
 * Whether a credential may be enrolled at all: it is registered and inert, nobody has enrolled it, and it was not registered through a window. A window key is a root
 * to be pinned by a deploy; giving it a parent would take it out of the keys a pin may name. Read by the host (draft and completion) and by the Keys page.
 */
export const canBeEnrolled = (c: { status: string; via?: string | null; parent: string | null }): boolean => c.status === "registered" && c.via !== "window" && c.parent === null;

/** One credential as the depth rule sees it: whether a deploy pins it, and the key that enrolled it. */
export type ChainNode = { pinned: boolean; parent: string | null };

/**
 * How many enrollment links lie between a credential and a pin: 0 for a pin, 1 for a key a pin enrolled, and so on. Null when it never reaches a pin (or loops).
 * The one place the rule is written, read by the host (draft and completion) and by the admin page's list of parents.
 */
export function enrollmentDepth(thumbprint: string, lookup: (thumbprint: string) => ChainNode | undefined): number | null {
  const seen = new Set<string>();
  let at: string | null = thumbprint;
  for (let depth = 0; at !== null && depth <= MAX_CHAIN_LINKS; depth++) {
    const node = lookup(at);
    if (!node || seen.has(at)) return null;
    if (node.pinned) return depth;
    seen.add(at);
    at = node.parent;
  }
  return null;
}

/** Whether a key can be the one that enrolls another: the new key would sit one link deeper, and a chain holds at most MAX_CHAIN_LINKS links (chainFor cannot build a longer one). */
export function canEnrollUnder(thumbprint: string, lookup: (thumbprint: string) => ChainNode | undefined): boolean {
  const depth = enrollmentDepth(thumbprint, lookup);
  return depth !== null && depth < MAX_CHAIN_LINKS;
}

/**
 * The chain a bundle carries for one signature, signing credential first. Every entry but the last holds the `enroll-credential` act that enrolled its
 * credential, signed by the next entry's credential; the last entry's credential is an anchor and carries no act. A direct anchor signature is one entry.
 * `enrollEvidence` holds two assertions over the one act: the signer's and the new credential's own (VS-09), so a key that was never touched cannot be enrolled.
 */
export type ChainLink = { credential: CredentialKey; enrollAct?: unknown; enrollEvidence?: { signer: Evidence; newCredential: Evidence } };

export type ShapeReason = "act_malformed" | "aud_mismatch" | "rp_mismatch";
export type ChainReason = "chain_broken" | "unanchored" | "credential_revoked" | "assurance_below_floor";

/** Step 1: `value` as an act that is closed, complete under its renderer, and addressed to this deployment (the verifier's own aud and rpId). */
export async function readAct(value: unknown, pinned: Pick<PinnedPresence, "aud" | "rpId">): Promise<{ ok: true; act: Act } | { ok: false; reason: ShapeReason }> {
  const act = parseAct(value);
  if (!act || !(await subjectDigestsHold(act))) return { ok: false, reason: "act_malformed" };
  if (act.aud !== pinned.aud) return { ok: false, reason: "aud_mismatch" };
  if (act.rpId !== pinned.rpId) return { ok: false, reason: "rp_mismatch" };
  try {
    renderR1(act); // an act no person could have been shown in full is not one that was signed
  } catch {
    return { ok: false, reason: "act_malformed" };
  }
  return { ok: true, act };
}

const HOUR = 3600 * 1000;

/**
 * Whether `key` is the key the enrollment act names in `role` (the new credential, or the parent that enrolls it) and touched this exact act with the
 * assertion `evidence`. The chain walk asks it of both keys of a link, and verifyEnrollmentAssertion of the new one, so a touch means one thing.
 */
type TouchArgs = { act: Act; role: "credential" | "parent"; key: CredentialKey; evidence: Evidence; challenge: Uint8Array; pinned: Pick<PinnedPresence, "rpId" | "origin">; requireUv: boolean };
/** The touch, with the authenticator's signature counter when it holds (the Mailbox judges and keeps it, as for any other assertion), else null. */
export async function enrollmentAssertion(args: TouchArgs): Promise<{ counter: number } | null> {
  const subject = args.act.subject as { credentialThumbprint: string; parentThumbprint: string };
  const print = await thumbprintOf(args.key);
  if (print === null || print !== (args.role === "credential" ? subject.credentialThumbprint : subject.parentThumbprint)) return null;
  const checked = await checkAssertion({ challenge: args.challenge, evidence: args.evidence, key: args.key, pinned: args.pinned, requireUv: args.requireUv });
  return checked.ok ? { counter: checked.counter } : null;
}
export async function enrollmentTouch(args: TouchArgs): Promise<boolean> {
  return (await enrollmentAssertion(args)) !== null;
}

/**
 * The new credential's own touch over an enrollment act (VS-09), for the Mailbox to check when the second assertion arrives: the credential is the one the act
 * names, and it touched with the PIN over exactly this act. The parent's touch and the chain are verifyHumanProof's.
 */
export async function verifyEnrollmentAssertion(input: { act: unknown; newCredential: { credential: CredentialKey; evidence: Evidence }; pinned: unknown }): Promise<{ ok: true; credential: string; counter: number } | { ok: false; reason: ShapeReason | "chain_broken" }> {
  const { act: given, newCredential, pinned: givenPinned } = input;
  const pinned = readPinned(givenPinned, "full");
  const read = snapshot({ act: given, newCredential });
  if (!pinned || !read) return broken;
  const { act: actValue, newCredential: touch } = read.value as { act: unknown; newCredential: { credential: CredentialKey; evidence: Evidence } | null };
  const parsed = await readAct(actValue, pinned);
  if (!parsed.ok) return { ok: false, reason: parsed.reason };
  if (parsed.act.kind !== "enroll-credential" || touch === null || typeof touch !== "object") return broken;
  const challenge = await actChallenge(parsed.act);
  const asserted = await enrollmentAssertion({ act: parsed.act, role: "credential", key: touch.credential, evidence: touch.evidence, challenge, pinned, requireUv: true });
  if (asserted === null) return broken;
  return { ok: true, credential: (parsed.act.subject as { credentialThumbprint: string }).credentialThumbprint, counter: asserted.counter };
}
const broken = { ok: false, reason: "chain_broken" } as const;

/**
 * Step 6 for the credential that signed an act issued at `at` (epoch ms): walks `chain` to a pinned anchor for `principal`. Every link is itself checked
 * by steps 1 to 5 (the act is an `enroll-credential` for this principal, both keys touched it with user verification), and the signer of each link must
 * have been active when it signed: an anchor always, a chained credential once the activation delay after its own enrollment had passed.
 * `revoked` is the live revocation list online; offline there is none to give, and the README says so.
 */
export async function verifyCredentialChain(args: {
  principal: string;
  chain: readonly ChainLink[];
  at: number;
  pinned: PinnedPresence;
  revoked: readonly string[] | null; // null: offline, where there is no list to give
}): Promise<{ ok: true; signer: string; links: number } | { ok: false; reason: ChainReason }> {
  // Every input is read once, as plain data, and only that copy is used below: a getter that answers differently the second time (a credential that is the
  // attacker's for the thumbprint and an anchor's for the signature) has nowhere to hide.
  const { principal, at } = args;
  const rest = snapshot({ chain: args.chain, revoked: args.revoked });
  const pinned = readPinned(args.pinned, "full");
  if (!rest || !pinned || typeof principal !== "string" || typeof at !== "number" || !Number.isFinite(at)) return broken;
  const { chain, revoked } = rest.value as { chain: readonly ChainLink[]; revoked: readonly string[] | null };
  if (!Array.isArray(chain) || chain.length === 0 || chain.length > MAX_CHAIN_LINKS + 1 || chain.some((link) => link === null || typeof link !== "object")) return broken;
  if (revoked !== null && !(Array.isArray(revoked) && revoked.every((t) => typeof t === "string"))) return broken;
  const prints: string[] = [];
  for (const link of chain) {
    const print = await thumbprintOf(link.credential);
    if (print === null || prints.includes(print)) return broken; // a repeated key would be a loop
    prints.push(print);
  }
  if (prints.some((print) => revoked !== null && revoked.includes(print))) return { ok: false, reason: "credential_revoked" };

  const delay = pinned.activationDelayHours * HOUR;
  const anchored = (print: string): boolean => pinned.anchors.some((anchor) => anchor.principal === principal && anchor.thumbprint === print);
  let signedAt = at; // when the credential at k signed
  for (let k = 0; k < chain.length; k++) {
    const link = chain[k]!;
    if (anchored(prints[k]!)) return k === chain.length - 1 ? { ok: true, signer: prints[0]!, links: k } : broken; // nothing may follow an anchor
    const signerLink = chain[k + 1];
    if (!signerLink) return { ok: false, reason: "unanchored" };
    const enrolled = link.enrollEvidence;
    if (link.enrollAct === undefined || enrolled === null || typeof enrolled !== "object") return broken;

    const read = await readAct(link.enrollAct, pinned);
    if (!read.ok || read.act.kind !== "enroll-credential" || read.act.principal !== principal) return broken;
    const issuedAt = isoTime(read.act.issuedAt);
    // This credential must have been active, after its enrollment's delay, when it signed; the next iteration asks the same of its signer at this act's time.
    if (issuedAt + delay > signedAt) return broken;
    // The enroll act is held to the pinned floor as the outer act is: one claiming less is refused before any of its assertions is read.
    const floor = floorFor(pinned.floors, "enroll-credential");
    if (floor === "hw-uv" && read.act.assurance !== "hw-uv") return { ok: false, reason: "assurance_below_floor" };
    const requireUv = stricter(floor, read.act.assurance) === "hw-uv";
    const challenge = await actChallenge(read.act);
    for (const [role, key, evidence] of [["parent", signerLink.credential, enrolled.signer], ["credential", link.credential, enrolled.newCredential]] as const) {
      if (!(await enrollmentTouch({ act: read.act, role, key, evidence, challenge, pinned, requireUv }))) return broken;
    }
    signedAt = issuedAt;
  }
  return { ok: false, reason: "unanchored" };
}
