import {
  messagePreparationPayload,
  parseMessageDeliverySource,
  type MessageDeliverySourceV1,
} from "./materialization";
import {
  parseEventMessagePreparationResult,
  type EventMessagePreparationResultV1,
} from "gatekeeper-messaging/src/event-authority-contract";
import { principalAllowed } from "gatekeeper-memory/src/principals";
import { requireNativeAdmissionCanary } from "../native-admission-gate";
import type { NativeRuntimeStore } from "../native-runtime-store";
import { EVENT_POLICY_V1 } from "../policy";
import { withDeadline } from "../request-deadline";
import { verifyMessageConsumerSnapshot, type MessageConsumerRegistry } from "./consumer-authority";
import { deriveMessagingDeliveryIdV2, MessagingEnvelopeV2Schema } from "./protocol-v2";
import { publicationJson, type MessagePublicationAuthority } from "./publication";
import type { MessagePreparationJob, MessagePublicationStore } from "./store";

type Snapshot = Extract<EventMessagePreparationResultV1, { status: "eligible" }>;
type Environment = Parameters<typeof requireNativeAdmissionCanary>[0] & {
  EVENT_MESSAGING_ACCEPT_ENABLED?: string;
  EVENT_MESSAGING_DELIVERY_ENABLED?: string;
  MESSAGE_NAMESPACE?: string;
  ALLOWED_PRINCIPALS?: string;
  MESSAGE_AUTHORITY: Partial<MessagePublicationAuthority>;
};
type Identity = { principal: string; agent: string };

export function messagePreparationEnabled(environment: Environment, identity: Identity): boolean {
  return (
    environment.EVENT_MESSAGING_ACCEPT_ENABLED === "true" &&
    !!environment.MESSAGE_NAMESPACE &&
    principalAllowed(
      { ALLOWED_PRINCIPALS: environment.ALLOWED_PRINCIPALS ?? "" },
      identity.principal,
    )
  );
}

/** Fresh preparation may feed the gated materializer; eventual admission must reacquire authority. */
export async function prepareMessagePublication(
  store: MessagePublicationStore,
  native: NativeRuntimeStore,
  identity: Identity,
  environment: Environment,
  registry: () => MessageConsumerRegistry,
  job: MessagePreparationJob,
  materialize?: (
    job: MessagePreparationJob,
    source: MessageDeliverySourceV1,
    current: () => boolean,
  ) => Promise<void>,
): Promise<void> {
  const authority = environment.MESSAGE_AUTHORITY;
  const allowed = () =>
    authority === environment.MESSAGE_AUTHORITY &&
    messagePreparationEnabled(environment, identity) &&
    job.publication.namespace === environment.MESSAGE_NAMESPACE &&
    job.publication.principal === identity.principal &&
    job.publication.agent === identity.agent;
  const query = async (expectedSnapshot?: string): Promise<Snapshot | null> => {
    if (!allowed() || !authority.readMessagePreparation) return null;
    const started = Date.now();
    const result = parseEventMessagePreparationResult(
      await withDeadline(
        authority.readMessagePreparation({
          publication: job.publication,
          ...(expectedSnapshot === undefined ? {} : { expectedSnapshot }),
        }),
        EVENT_POLICY_V1.nativeRpcDeadlineMs,
      ),
    );
    const now = Date.now();
    if (
      !allowed() ||
      !result ||
      result.status !== "eligible" ||
      publicationJson(result.publication) !== publicationJson(job.publication) ||
      Date.parse(result.checkedAt) < started ||
      Date.parse(result.checkedAt) > now ||
      now - Date.parse(result.checkedAt) > EVENT_POLICY_V1.nativeRpcDeadlineMs ||
      (expectedSnapshot !== undefined && result.snapshotDigest !== expectedSnapshot)
    )
      return null;
    return result;
  };
  try {
    const source = await query();
    if (
      !source ||
      !MessagingEnvelopeV2Schema.shape.canonicalSubject.safeParse(source.canonicalSubject)
        .success ||
      !MessagingEnvelopeV2Schema.shape.principal.safeParse(source.publication.principal).success ||
      !MessagingEnvelopeV2Schema.shape.agent.safeParse(source.publication.agent).success
    )
      return;
    const consumer = source.route.consumer;
    const fingerprint = () =>
      JSON.stringify([native.runtime(consumer.runtimeId), native.binding(consumer.runtimeId)]);
    const before = fingerprint();
    const verified = await verifyMessageConsumerSnapshot(
      native,
      identity,
      {
        ...identity,
        keyThumbprint: source.keyThumbprint,
        consumer,
      },
      environment,
      registry,
    );
    if (verified.status !== "current" || fingerprint() !== before) return;
    const deliveryId = await deriveMessagingDeliveryIdV2({
      eventId: job.eventId,
      ...consumer,
      routingGeneration: source.route.generation,
    });
    const final = await query(source.snapshotDigest);
    if (
      !final ||
      JSON.stringify({ ...final, checkedAt: "" }) !== JSON.stringify({ ...source, checkedAt: "" })
    )
      return;
    const current = (): boolean => {
      if (!allowed() || fingerprint() !== before) return false;
      try {
        requireNativeAdmissionCanary(environment, identity);
      } catch {
        return false;
      }
      const now = Date.now();
      return (
        Number.isSafeInteger(now) &&
        now >= Date.parse(verified.checkedAt) &&
        now - Date.parse(verified.checkedAt) <= EVENT_POLICY_V1.nativeRpcDeadlineMs &&
        now >= Date.parse(final.checkedAt) &&
        now - Date.parse(final.checkedAt) <= EVENT_POLICY_V1.nativeRpcDeadlineMs &&
        Date.parse(verified.leaseUntil) > now
      );
    };
    const deliverySource = parseMessageDeliverySource({
      kind: "message_delivery_source",
      version: 1,
      eventId: job.eventId,
      eventReference: job.eventReference,
      deliveryId,
      policyRevision: EVENT_POLICY_V1.initialPolicyRevision,
      source: final,
      consumerCheckedAt: verified.checkedAt,
      consumerLeaseUntil: verified.leaseUntil,
    });
    if (!deliverySource) return;
    const completed = await store.completePreparation(
      job,
      messagePreparationPayload(deliverySource),
      current,
    );
    const deliveryCurrent = () =>
      environment.EVENT_MESSAGING_DELIVERY_ENABLED === "true" && current();
    if (completed && materialize && deliveryCurrent())
      await materialize(job, deliverySource, deliveryCurrent);
  } catch {
    // The batch transaction already invalidated the old payload and rearmed the held obligation.
    // Ambiguous source/registry/storage outcomes do not erase identity or imply delivery.
  }
}
