// Broker receipts (spec "Data model"): JWS compact serialization (RFC 7515) with alg "Ed25519"
// (RFC 9864) over canonical JSON (@knitli/openapi-mcp, RFC 8785-equivalent), each linked to its
// parent by the sha256 of the parent's compact JWS. Digests use @knitli/openapi-mcp's
// domain-separated sha256(domain, value) = sha256(`${domain}\0${canonicalJson(value)}`), hex.
// Free of Worker types: scripts/messaging-receipts.ts verifies bundles with this under Node.

import { canonicalJson, sha256 } from "@knitli/openapi-mcp/runtime";
import { isAgentAddress } from "authority/src/act.ts";
import { snapshot } from "authority/src/snapshot.ts";
import { HEX64, isThumbprint, isoTime, plain, principal as isPrincipal } from "authority/src/contract-kit.ts";
import { TASK_TYPE } from "authority/src/task.ts";
import { SCREEN_VERSION } from "authority/src/text.ts";
import { THUMBPRINT, b64u, unb64u } from "./agent-token.ts";
import { AGENT, codeOf, fail, parseAddress, partyAddress, sameAddress, screenedView, wireOf, type Address, type Applied, type IssuedApplied, type Kind } from "./model.ts";
import type { Message, MessageParty, ReadMessage, Verification } from "./types.js";

export type Jwk = { kty: "OKP"; crv: "Ed25519"; x: string; kid: string };
type SignedAddress = { principal: string; agent?: string };
type SignedParty = SignedAddress & { client: string; endpoint?: string; jkt?: string };
/** Present on a receipt whose message screening changes (R4 5b-2c): the digest of the screened view under SCREEN_VERSION, so the text an agent was shown verifies without the original. Additive on every version. */
export type ScreenedClaim = { version: number; digest: string };
type Common = {
  id: string;
  threadId: string;
  kind: Kind;
  parents: { id: string; receiptDigest: string }[];
  sender: SignedParty;
  payloadDigest: string;
  issuedAt: string;
  expiresAt: string | null;
  depth: number;
  screened?: ScreenedClaim;
};
/** MVP receipts: a person-addressed recipient and no agents. Still signed when neither end is an agent. */
export type ReceiptPayloadV1 = Common & { v: 1; recipient: string; applied: "send-self" | "send" };
/**
 * The broker checked that the sender was this agent, bound as stated: workspace-attested ("send",
 * "send-granted", client "os" with an endpoint), key-held ("mcp-granted": a bearer key), or signed in
 * with a registered key ("mcp-signed": a token that key signed, whose thumbprint is sender.jkt). A
 * request or forward to an agent also passed a grant check; a reply needs none, so its receipt claims
 * no grant. "mcp-oauth" attests an owner-bound OAuth profile, never a key-held agent.
 * It never names the grant: grants are private policy. "mcp-signed" attests the broker's check
 * of the agent's session token, not an agent signature over this message.
 */
export type ReceiptPayloadV2 = Common & { v: 2; recipient: SignedAddress; applied: IssuedApplied };
/**
 * The root of an order: the person's own hardware-signed order, not an agent's message (plan 6.8). `order` rides on every hop of an
 * ordered thread, identical to the root's but for `root`; the order's id is its `actDigest`, and the root receipt's `id` is the act's
 * `subject.rootMessageId`. `taskType` is signed here so a verifier needs no message to know a hop's type: a request and a reply sign
 * theirs, a forward signs null and takes its root's (checkedType, G25). Banners claim human authorship for the root only (AT-04).
 * Nothing issues v3 yet (R4 5b-1 teaches the verifiers; emission is 5b-2, behind a flag), and `order` is required here though the plan's
 * sketch marks it optional: v3 exists only for ordered threads, so a v3 receipt without one is not one a verifier should read.
 */
export type OrderClaim = {
  actDigest: string; tier: "anchored"; cred: string;
  /** "human", or "agent:<address>" for an order an agent composed and a person signed. */
  draftedBy: string;
  expiresAt: string; scopeDigest: string; root: boolean;
};
/** An order's root sender: the person, by the credential that signed. No agent, endpoint or key thumbprint: those read as undefined, as on any sender. */
export type OrderSender = { principal: string; client: "order"; cred: string; agent?: undefined; endpoint?: undefined; jkt?: undefined };
export type ReceiptPayloadV3 = Omit<ReceiptPayloadV2, "v" | "applied" | "sender"> & {
  v: 3;
  taskType: string | null;
  applied: IssuedApplied | "human-ordered";
  sender: SignedParty | OrderSender;
  order: OrderClaim;
};
export type ReceiptPayload = ReceiptPayloadV1 | ReceiptPayloadV2 | ReceiptPayloadV3;
export type KeyRing = { kid: string; signer: CryptoKey; publicKeys: ReadonlyMap<string, Jwk> };
export type Verdict = Verification;

export const RECEIPT_TYP = "knitli-msg-receipt+jws";
const KID = /^[A-Za-z0-9._-]{1,64}$/;
const X = /^[A-Za-z0-9_-]{43}$/; // a 32-byte Ed25519 public key, base64url

type Json = Parameters<typeof canonicalJson>[0];
const canon = (value: unknown): string => canonicalJson(value as Json);
const digest = (domain: string, value: unknown): Promise<string> => sha256(domain, value as Json);
const encoder = new TextEncoder();
const decoder = new TextDecoder();

// Present fields are kept whatever their value: an added `agent: ""` or `endpoint: ""` must not compare
// equal to a receipt that signed none.
const partyOf = (p: MessageParty): SignedParty & { cred?: string } => ({
  principal: p.principal,
  ...(p.agent !== undefined ? { agent: p.agent } : {}),
  client: p.client,
  ...(p.endpoint !== undefined ? { endpoint: p.endpoint } : {}),
  ...(p.jkt !== undefined ? { jkt: p.jkt } : {}),
  // Only an order's root sender has one (v3): a message that shows one a receipt did not sign is a mismatch, as for jkt.
  ...((p as { cred?: string }).cred !== undefined ? { cred: (p as { cred?: string }).cred } : {}),
});
const signedAddress = (a: Address): SignedAddress => ({ principal: a.principal, ...(a.agent === null ? {} : { agent: a.agent }) });
/** The recipient a receipt names, from either version. */
const recipientOf = (p: ReceiptPayload): Address => (p.v === 1 ? { principal: p.recipient, agent: null } : partyAddress(p.recipient));
const content = (m: Message) => ({ subject: m.subject, body: m.body, taskType: m.taskType, ...(m.quoted ? { quoted: m.quoted } : {}) });

/** The digest a receipt's payloadDigest holds, of what a message says: an order's root is checked against the signed act's text with this (messaging-receipts.ts). */
export const contentDigest = (c: ReturnType<typeof content>): Promise<string> => digest("knitli-msg-payload/v1", c);
/**
 * The digest of what an agent is shown: the screened view's content (subject, body, task type, every quoted level) and its screening report, under SCREEN_VERSION.
 * Computed from the view alone, so the issuer and a verifier holding only the shown read get the same value and neither needs the original.
 */
export const screenedDigest = (view: ReturnType<typeof screenedView>): Promise<string> =>
  digest("knitli-msg-screened/v1", { version: SCREEN_VERSION, content: content(view.message), screening: view.screening });
export const payloadDigest = (message: Message): Promise<string> => contentDigest(content(message));
export const receiptDigest = (jws: string): Promise<string> => digest("knitli-msg-receipt/v1", jws);
/**
 * What read() returns under `provenance`, built here so the MCP tool, the workspace session and the offline verifier's
 * fixtures cannot disagree on its shape: the chain, whether it verifies, and the digest of the message's own (last) receipt.
 */
export async function readProvenance(chain: string[], verified: Verification): Promise<ReadMessage["provenance"]> {
  return { chain, verified, receiptDigest: await receiptDigest(chain[chain.length - 1]!) };
}
export const requestDigest = (r: {
  kind: Kind; parentId: string | null; to: string; subject: string; body: string; taskType: string | null; expiresAt: string | null;
}): Promise<string> =>
  digest("knitli-msg-request/v1", { kind: r.kind, parentId: r.parentId, to: r.to, subject: r.subject, body: r.body, taskType: r.taskType, expiresAt: r.expiresAt });

function jwkOf(value: unknown): Jwk {
  const v = value as Partial<Jwk> | null;
  if (!v || v.kty !== "OKP" || v.crv !== "Ed25519" || typeof v.x !== "string" || !X.test(v.x) || typeof v.kid !== "string" || !KID.test(v.kid))
    throw fail("unavailable", "a receipt key is not an Ed25519 public JWK with a kid");
  return { kty: "OKP", crv: "Ed25519", x: v.x, kid: v.kid };
}

const importPublic = (jwk: Jwk): Promise<CryptoKey> =>
  crypto.subtle.importKey("jwk", { kty: jwk.kty, crv: jwk.crv, x: jwk.x }, "Ed25519", false, ["verify"]);

/** RECEIPT_PUBLIC_KEYS: a JWKS of retired keys, or "" for none. */
export function parsePublicKeys(raw: string): Map<string, Jwk> {
  const keys = new Map<string, Jwk>();
  if (!raw.trim()) return keys;
  try {
    const list = (JSON.parse(raw) as { keys?: unknown } | null)?.keys;
    if (!Array.isArray(list)) throw fail("unavailable", "RECEIPT_PUBLIC_KEYS must be a JWKS");
    for (const entry of list) {
      const jwk = jwkOf(entry);
      if (keys.has(jwk.kid)) throw fail("unavailable", `receipt key id ${jwk.kid} appears twice`);
      keys.set(jwk.kid, jwk);
    }
  } catch (error) {
    throw codeOf(error) ? error : fail("unavailable", "RECEIPT_PUBLIC_KEYS must be a JWKS");
  }
  return keys;
}

/**
 * RECEIPT_KEYS is {current: kid, keys: {kid: {pkcs8: base64, publicJwk}}}. The private key is
 * imported non-extractable; the public JWK stored beside it is what verifiers use, so the pair is
 * checked here and a mismatch fails closed rather than signing receipts nothing can verify.
 */
export async function loadKeyRing(receiptKeys: string, retiredKeys: string): Promise<KeyRing> {
  let kid: string;
  let pkcs8: string;
  let publicJwk: Jwk;
  let publicKeys: Map<string, Jwk>;
  try {
    const parsed = JSON.parse(receiptKeys) as { current?: unknown; keys?: Record<string, { pkcs8?: unknown; publicJwk?: unknown }> };
    if (typeof parsed?.current !== "string" || !KID.test(parsed.current)) throw new Error("current");
    const entry = parsed.keys?.[parsed.current];
    if (!entry || typeof entry.pkcs8 !== "string") throw new Error("entry");
    kid = parsed.current;
    pkcs8 = entry.pkcs8;
    publicJwk = jwkOf({ ...(entry.publicJwk as object), kid });
    publicKeys = parsePublicKeys(retiredKeys);
  } catch (error) {
    throw codeOf(error) ? error : fail("unavailable", "RECEIPT_KEYS is not a receipt key set");
  }
  // Listing the current key as retired before rotating to a new one is the documented rotation
  // step (README "Receipt keys"), so the same key is accepted; the same kid for another key is not.
  const listed = publicKeys.get(kid);
  if (listed && listed.x !== publicJwk.x) throw fail("unavailable", `the current receipt key ${kid} is also listed as retired, with another key`);
  const signer = await crypto.subtle
    .importKey("pkcs8", Uint8Array.from(atob(pkcs8), (c) => c.charCodeAt(0)), "Ed25519", false, ["sign"])
    .catch(() => {
      throw fail("unavailable", "the current RECEIPT_KEYS key is not an Ed25519 PKCS#8 key");
    });
  const probe = encoder.encode("knitli-msg-receipt key check");
  const verifier = await importPublic(publicJwk);
  if (!(await crypto.subtle.verify("Ed25519", verifier, await crypto.subtle.sign("Ed25519", signer, probe), probe)))
    throw fail("unavailable", "the current RECEIPT_KEYS key does not match its publicJwk");
  publicKeys.set(kid, publicJwk);
  return { kid, signer, publicKeys };
}

let cached: { raw: string; ring: Promise<KeyRing> } | undefined;

/** The key ring for this isolate, rebuilt only when the configuration changes. */
export function keyRing(env: { RECEIPT_KEYS: string; RECEIPT_PUBLIC_KEYS: string }): Promise<KeyRing> {
  const raw = `${env.RECEIPT_KEYS}\n${env.RECEIPT_PUBLIC_KEYS}`;
  if (cached?.raw !== raw) {
    const ring = loadKeyRing(env.RECEIPT_KEYS, env.RECEIPT_PUBLIC_KEYS);
    cached = { raw, ring };
    ring.catch(() => {
      if (cached?.ring === ring) cached = undefined; // retry a bad config on the next call
    });
  }
  return cached.ring;
}

/** v1 when neither end is an agent (the MVP's shape, unchanged); v2 whenever one is; v3 for every hop of an order's thread, which carries `order` (plan 6.8). */
export async function receiptPayload(message: Message, parentReceipt: string | null, applied: Applied, order: OrderClaim | null = null): Promise<ReceiptPayload> {
  const recipient = parseAddress(message.recipient);
  if (!recipient) throw fail("invalid", "a message's recipient must be an address");
  const view = screenedView(message);
  const common = {
    id: message.id,
    threadId: message.threadId,
    kind: message.kind,
    parents: parentReceipt ? [{ id: message.parents[0]!, receiptDigest: await receiptDigest(parentReceipt) }] : [],
    sender: partyOf(message.sender),
    payloadDigest: await payloadDigest(message),
    issuedAt: message.issuedAt,
    expiresAt: message.expiresAt,
    depth: message.depth,
    // Only a message whose screened read differs from the stored text needs it; an older receipt has none and its changed reads stay unverifiable offline.
    ...(view.screening?.changed ? { screened: { version: SCREEN_VERSION, digest: await screenedDigest(view) } } : {}),
  };
  if (order !== null) return { v: 3, ...common, recipient: signedAddress(recipient), applied, taskType: message.taskType, order } as ReceiptPayloadV3;
  if (applied === "human-ordered") throw fail("invalid", "human-ordered is an order's root, which carries its order");
  if (message.sender.agent === undefined && recipient.agent === null && (applied === "send-self" || applied === "send"))
    return { v: 1, ...common, recipient: message.recipient, applied };
  if (applied === "send-self") throw fail("invalid", "send-self is an MVP receipt, which names no agent");
  return { v: 2, ...common, recipient: signedAddress(recipient), applied };
}

export async function signReceipt(ring: Pick<KeyRing, "kid" | "signer">, payload: ReceiptPayload): Promise<string> {
  const input = `${b64u(encoder.encode(canon({ alg: "Ed25519", kid: ring.kid, typ: RECEIPT_TYP })))}.${b64u(encoder.encode(canon(payload)))}`;
  const signature = new Uint8Array(await crypto.subtle.sign("Ed25519", ring.signer, encoder.encode(input)));
  return `${input}.${b64u(signature)}`;
}

const str = (value: unknown): value is string => typeof value === "string";
const KINDS: readonly unknown[] = ["request", "reply", "forward"];
const V1_APPLIED: readonly unknown[] = ["send-self", "send"];
const V2_APPLIED: readonly unknown[] = ["send", "send-granted", "mcp-granted", "mcp-signed", "mcp-oauth"];
const agentOk = (value: unknown): boolean => value === undefined || (str(value) && AGENT.test(value));
const record = (value: unknown): value is Record<string, unknown> => !!value && typeof value === "object" && !Array.isArray(value);

/** An order's drafter as it is signed: "human", or "agent:" and an agent address in the one grammar acts use. */
const draftedByOk = (value: unknown): boolean => value === "human" || (typeof value === "string" && value.startsWith("agent:") && isAgentAddress(value.slice(6)));
const V3_KEYS = ["id", "threadId", "kind", "parents", "sender", "recipient", "payloadDigest", "issuedAt", "expiresAt", "depth", "v", "applied", "taskType", "order"];

/** A receipt's screened claim: closed, a version and a digest. Whether it matches a shown read is the verifier's (scripts/messaging-receipts.ts). */
const screenedOk = (value: unknown): boolean =>
  value === undefined || (record(value) && plain(value, ["version", "digest"]) !== null && Number.isSafeInteger(value.version) && str(value.digest) && HEX64.test(value.digest));

function isOrderClaim(value: unknown): value is OrderClaim {
  return (
    record(value) && plain(value, ["actDigest", "tier", "cred", "draftedBy", "expiresAt", "scopeDigest", "root"]) !== null &&
    typeof value.actDigest === "string" && HEX64.test(value.actDigest) && value.tier === "anchored" && isThumbprint(value.cred) &&
    draftedByOk(value.draftedBy) && str(value.expiresAt) && !Number.isNaN(isoTime(value.expiresAt)) &&
    typeof value.scopeDigest === "string" && HEX64.test(value.scopeDigest) && typeof value.root === "boolean"
  );
}

/**
 * v3 (plan 6.8), a closed shape. Per receipt, with h for applied == "human-ordered": h <=> sender.client == "order" <=> depth == 0 <=> order.root (so the
 * root has no parent and every later hop exactly one). The root is a request that names an agent, a task type and the same credential in sender.cred and
 * order.cred; a forward signs a null type; no other hop may say "order" for a client (reserved, VS-20). Chain-wide rules (one `order` on every hop but for
 * `root`, no mixing of versions) are verifyChain's, since they are about more than one receipt.
 */
function isPayloadV3(p: Record<string, unknown>): boolean {
  if (plain(p, V3_KEYS, ["screened"]) === null || !screenedOk(p.screened)) return false;
  const { sender, recipient, parents, order, applied, kind, depth } = p as { sender: unknown; recipient: unknown; parents: unknown[]; order: unknown; applied: unknown; kind: unknown; depth: number };
  if (!isOrderClaim(order) || !KINDS.includes(kind) || !(str(p.id) && p.id !== "" && str(p.threadId) && p.threadId !== "")) return false;
  // Times are read by the attenuation check, so each is a time and not any string.
  if (!(str(p.issuedAt) && !Number.isNaN(isoTime(p.issuedAt))) || !(p.expiresAt === null || (str(p.expiresAt) && !Number.isNaN(isoTime(p.expiresAt))))) return false;
  if (!parents.every((link) => record(link) && plain(link, ["id", "receiptDigest"]) !== null && str(link.id) && link.id !== "" && str(link.receiptDigest) && HEX64.test(link.receiptDigest))) return false;
  if (!(str(p.payloadDigest) && HEX64.test(p.payloadDigest)) || !(Number.isSafeInteger(depth) && parents.length === (depth === 0 ? 0 : 1))) return false;
  // Only a forward signs null (its type is its root's, G25); a request and a reply each sign a task type in the grammar, so a hop cannot leave its type unsaid.
  if (kind === "forward" ? p.taskType !== null : !(str(p.taskType) && TASK_TYPE.test(p.taskType))) return false;
  if (!record(recipient) || plain(recipient, ["principal"], ["agent"]) === null || !isPrincipal(recipient.principal) || !agentOk(recipient.agent)) return false;
  if (!record(sender) || !isPrincipal(sender.principal)) return false;
  const human = applied === "human-ordered";
  if (human !== (sender.client === "order") || human !== (depth === 0) || human !== order.root) return false;
  if (human)
    return plain(sender, ["principal", "client", "cred"]) !== null && sender.cred === order.cred && kind === "request" && str(p.taskType) && str(recipient.agent);
  // Every hop after the root is an agent's message in the order (the root is the only human hop), so its sender names the agent: authoredBy depends on it.
  // A v3 hop's key thumbprint is in its one canonical spelling (isThumbprint): the loose 43-character form v2 accepts has aliases that name no key. v2 stays as it was.
  return plain(sender, ["principal", "client"], ["agent", "endpoint", "jkt"]) !== null && str(sender.agent) && (sender.jkt === undefined || isThumbprint(sender.jkt)) && str(sender.client) && sender.client !== "" && (sender.endpoint === undefined || str(sender.endpoint)) && v2Tail(applied, sender);
}

/** What v2 and a v3 hop other than the root share: the sender's agent and thumbprint, and an applied value the broker issues to an agent. */
function v2Tail(applied: unknown, sender: Record<string, unknown>): boolean {
  // sender.jkt is present exactly on an "mcp-signed" receipt, and is a thumbprint.
  const jktOk = (applied === "mcp-signed") === (sender.jkt !== undefined) && (sender.jkt === undefined || (str(sender.jkt) && THUMBPRINT.test(sender.jkt)));
  if (applied === "mcp-oauth" && (!str(sender.agent) || !AGENT.test(sender.agent) || sender.endpoint !== undefined)) return false;
  return agentOk(sender.agent) && jktOk && V2_APPLIED.includes(applied);
}

/** The whole signed shape, so nothing downstream reads a field of the wrong type from untrusted input. */
function isPayload(value: unknown): value is ReceiptPayload {
  if (!record(value)) return false;
  const p = value;
  const sender = p.sender;
  // v3 is closed and checks its own common fields; an old-style check here would be looser than isPayloadV3 on a v3 receipt.
  if (p.v === 3) return Array.isArray(p.parents) && isPayloadV3(p);
  const common =
    str(p.id) && str(p.threadId) && KINDS.includes(p.kind) &&
    Array.isArray(p.parents) &&
    p.parents.every((link) => record(link) && str(link.id) && str(link.receiptDigest)) &&
    record(sender) && str(sender.principal) && str(sender.client) && (sender.endpoint === undefined || str(sender.endpoint)) &&
    str(p.payloadDigest) && str(p.issuedAt) && (p.expiresAt === null || str(p.expiresAt)) &&
    Number.isInteger(p.depth) && (p.depth as number) >= 0;
  if (!common || !screenedOk(p.screened)) return false;
  if (p.v === 1) return sender.agent === undefined && sender.jkt === undefined && str(p.recipient) && V1_APPLIED.includes(p.applied);
  return p.v === 2 && v2Tail(p.applied, sender) && record(p.recipient) && str(p.recipient.principal) && agentOk(p.recipient.agent);
}

export function decodeReceipt(jws: string): { kid: string; payload: ReceiptPayload; input: string; signature: Uint8Array<ArrayBuffer> } | null {
  const parts = jws.split(".");
  if (parts.length !== 3) return null;
  const [head, body, signature] = parts.map(unb64u);
  if (!head || !body || !signature) return null;
  try {
    const header = JSON.parse(decoder.decode(head)) as Record<string, unknown>;
    if (header.alg !== "Ed25519" || header.typ !== RECEIPT_TYP || typeof header.kid !== "string") return null;
    const payload: unknown = JSON.parse(decoder.decode(body));
    if (!isPayload(payload)) return null;
    return { kid: header.kid, payload, input: `${parts[0]}.${parts[1]}`, signature };
  } catch {
    return null;
  }
}

/**
 * Checks a chain, root first: every signature (by kid, retired keys included), every parent link
 * and derivation, and, given the message, that it is the one the last receipt names. Authenticity
 * only: it never says the sender was authorized (spec "Three separate concerns").
 *
 * A chain whose root is v3 (a person's signed order) is never authentic here: `order_unverified`. The claim in
 * it is the whole point of v3, and this function cannot judge a human proof (that needs the verifier's own pins),
 * so every caller that is not the order-verifying path fails closed, online Workers included, until 5b-2 wires
 * order status in. The order-verifying path calls verifyChainStructure, which is not re-exported anywhere.
 */
export async function verifyChain(receipts: readonly string[], keys: ReadonlyMap<string, Jwk>, message?: Message): Promise<Verdict> {
  const { verdict, v3 } = await checkChain(receipts, keys, message);
  return v3 ? { authentic: false, reasons: [...verdict.reasons, "order_unverified"] } : verdict;
}

/**
 * verifyChain without the v3 refusal: signatures, links, derivations and the v3 chain rules, and nothing about the human order. For
 * the order-verifying path (scripts/messaging-receipts.ts verifyOrdered) only: a caller that reads `authentic` from this and stops has
 * trusted a person's order on the broker's word. A test pins that no other module imports it.
 */
export async function verifyChainStructure(receipts: readonly string[], keys: ReadonlyMap<string, Jwk>, message?: Message): Promise<Verdict> {
  return (await checkChain(receipts, keys, message)).verdict;
}

/** The closed verdict for an input that is not what a verifier takes: the same word the offline verifier uses for a file that is not a bundle. */
const closed = (): Verdict => ({ authentic: false, reasons: ["malformed_bundle"] }); // a fresh object each time: a caller that edits its verdict edits nothing shared

/**
 * Every caller-supplied input, read once and copied as plain data before the first await (authority's snapshot rule): the keys and the message first, since
 * they are the verifier's own, then the receipts. A getter, a proxy or a later mutation cannot show the signature check one input and a later decision another;
 * a trap that throws, an accessor or a non-string receipt is an input that is not one (null).
 */
function chainInputs(receipts: unknown, keys: unknown, message: unknown): { receipts: string[]; keys: Map<string, Jwk>; message: Message | undefined } | null {
  try {
    // The first operation on each caller input is one structuredClone: getters run once, in order, each value serialized before the next runs; a Proxy, a function
    // or a symbol is not cloneable and throws (the closed verdict). Every check below is on a clone, never on the caller's object. (Keys are a Map of plain JWKs, which clones.)
    const keysCopy = structuredClone(keys) as ReadonlyMap<string, Jwk>;
    const messageCopy = message === undefined ? undefined : (structuredClone(message) as Message);
    const receiptsCopy = structuredClone(receipts);
    const copied = new Map<string, Jwk>();
    for (const [kid, jwk] of keysCopy) {
      const read = snapshot(jwk);
      if (typeof kid !== "string" || read === null) return null;
      copied.set(kid, read.value as Jwk);
    }
    const list = snapshot(receiptsCopy);
    if (list === null || !Array.isArray(list.value) || !list.value.every((r) => typeof r === "string")) return null;
    return { receipts: list.value as string[], keys: copied, message: messageCopy };
  } catch {
    return null;
  }
}

/** The structure check on the copies, and whether the root it authenticated is v3: decided from the decoded receipts that were checked, not from the caller's list again. Never rejects. */
async function checkChain(receiptsGiven: unknown, keysGiven: unknown, messageGiven: unknown): Promise<{ verdict: Verdict; v3: boolean }> {
  const given = chainInputs(receiptsGiven, keysGiven, messageGiven);
  if (!given) return { verdict: closed(), v3: false };
  try {
    const { verdict, hops } = await chainStructure(given.receipts, given.keys, given.message);
    return { verdict, v3: hops?.[0]?.payload.v === 3 };
  } catch {
    return { verdict: closed(), v3: false };
  }
}

async function chainStructure(receipts: readonly string[], keys: ReadonlyMap<string, Jwk>, message?: Message): Promise<{ verdict: Verdict; hops: NonNullable<ReturnType<typeof decodeReceipt>>[] | null }> {
  if (receipts.length === 0) return { verdict: { authentic: false, reasons: ["empty"] }, hops: null };
  const decoded = receipts.map(decodeReceipt);
  const bad = decoded.findIndex((hop) => hop === null);
  if (bad >= 0) return { verdict: { authentic: false, reasons: [`malformed:${bad}`] }, hops: null };
  const hops = decoded as NonNullable<(typeof decoded)[number]>[];
  const reasons: string[] = [];
  const imported = new Map<string, CryptoKey>();
  for (const [index, hop] of hops.entries()) {
    const jwk = keys.get(hop.kid);
    if (!jwk) {
      reasons.push(`unknown_kid:${hop.kid}`);
      continue;
    }
    // A key or signature WebCrypto refuses to use is as bad as one that does not verify.
    const valid = await (async () => {
      const key = imported.get(hop.kid) ?? (await importPublic(jwk));
      imported.set(hop.kid, key);
      return crypto.subtle.verify("Ed25519", key, hop.signature, encoder.encode(hop.input));
    })().catch(() => false);
    if (!valid) reasons.push(`bad_signature:${index}`);
  }
  const root = hops[0]!.payload;
  if (root.kind !== "request" || root.parents.length !== 0 || root.depth !== 0 || root.threadId !== root.id) reasons.push("not_a_root");
  for (let i = 1; i < hops.length; i++) {
    const hop = hops[i]!.payload;
    const prev = hops[i - 1]!.payload;
    const link = hop.parents.length === 1 ? hop.parents[0]! : null;
    if (!link || link.id !== prev.id || link.receiptDigest !== (await receiptDigest(receipts[i - 1]!))) reasons.push(`parent_mismatch:${i}`);
    if (hop.kind === "request") reasons.push(`kind_mismatch:${i}`);
    if (hop.threadId !== root.id) reasons.push(`thread_mismatch:${i}`);
    if (hop.depth !== i) reasons.push(`depth_mismatch:${i}`);
    if (!sameAddress(partyAddress(hop.sender), recipientOf(prev))) reasons.push(`sender_not_parent_recipient:${i}`);
    if (hop.kind === "reply" && !sameAddress(recipientOf(hop), partyAddress(prev.sender))) reasons.push(`reply_recipient_mismatch:${i}`);
  }
  // v3 (plan 6.8): a thread rooted at an order is v3 throughout and every other thread is not, and the order claim is the root's on every hop (but for `root`).
  const ordered = root.v === 3;
  for (let i = 0; i < hops.length; i++) {
    const hop = hops[i]!.payload;
    if (i > 0 && (hop.v === 3) !== ordered) reasons.push(`version_mismatch:${i}`);
    else if (ordered && hop.v === 3 && i > 0 && canon({ ...hop.order, root: false }) !== canon({ ...(root as ReceiptPayloadV3).order, root: false })) reasons.push(`order_mismatch:${i}`);
  }
  if (message) reasons.push(...(await mismatches(message, hops.length - 1, receipts, hops.map((hop) => hop.payload))));
  return { verdict: { authentic: reasons.length === 0, reasons }, hops };
}

/**
 * Every signed field of `message` against the receipt at `index`, and, on a forward, its quoted
 * message against the receipt before it (recursively, since that may be a forward too).
 */
async function mismatches(message: Message, index: number, receipts: readonly string[], payloads: readonly ReceiptPayload[]): Promise<string[]> {
  const p = payloads[index]!;
  const reasons: string[] = [];
  if (message.id !== p.id || message.kind !== p.kind) reasons.push("id_mismatch");
  if (message.threadId !== p.threadId) reasons.push("thread_mismatch");
  if (canon(message.parents) !== canon(p.parents.map((link) => link.id))) reasons.push("parents_mismatch");
  if (message.depth !== p.depth) reasons.push("depth_mismatch");
  if (message.issuedAt !== p.issuedAt || message.expiresAt !== p.expiresAt) reasons.push("time_mismatch");
  if (canon(partyOf(message.sender)) !== canon(p.sender)) reasons.push("sender_mismatch");
  // Exactly the signed form, as v1 does: a recipient shown in another case or with spaces is not the one signed.
  if (message.recipient !== (p.v === 1 ? p.recipient : wireOf(recipientOf(p)))) reasons.push("recipient_mismatch");
  if (p.v === 3 && message.taskType !== p.taskType) reasons.push("task_type_mismatch");
  if ((await payloadDigest(message)) !== p.payloadDigest) reasons.push("payload_mismatch");
  if (message.kind === "forward" || message.quoted) {
    const quoted = message.quoted;
    if (message.kind !== "forward" || !quoted || index === 0 || quoted.receipt !== receipts[index - 1]) reasons.push("quoted_mismatch");
    else {
      const inner = await mismatches(quoted.message, index - 1, receipts, payloads);
      if (inner.length) reasons.push("quoted_mismatch", ...inner.map((reason) => `quoted:${reason}`));
    }
  }
  return reasons;
}

/** The public keys a bundle needs: those of the kids its receipts name. */
export function bundleKeys(ring: KeyRing, receipts: readonly string[]): Jwk[] {
  const kids = new Set(receipts.map((jws) => decodeReceipt(jws)?.kid).filter((kid): kid is string => kid !== undefined));
  return [...kids].flatMap((kid) => {
    const jwk = ring.publicKeys.get(kid);
    return jwk ? [jwk] : [];
  });
}
