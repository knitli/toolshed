import { INVENTORY_LIMITS as limits, type InventoryRequest, type InventoryPage, type InventoryRow, type InventoryScope, type InventoryScalar } from './quarantine-inventory-contract.ts';

export type Field = { kind: 'text' | 'integer'; nullable?: boolean; min?: number; states?: readonly InventoryScalar[] };
export type Collection = { scope: InventoryScope; keys: readonly string[]; fields: Record<string, Field> };
const text: Field = { kind: 'text' };
const optionalText: Field = { kind: 'text', nullable: true };
const integer: Field = { kind: 'integer', min: 0 };
const generation: Field = { kind: 'integer', min: 1 };
const optionalInteger: Field = { ...integer, nullable: true };
const boolean: Field = { ...integer, states: [0, 1] };
const state = (...states: string[]): Field => ({ kind: 'text', states });
const attemptState = state('created', 'reserving', 'unknown', 'budget_refused', 'refused', 'admitted', 'submitted', 'observed', 'command_accepted', 'ambiguous', 'not_started');
const claimState = state('reserving', 'unknown', 'budget_refused', 'refused', 'admitted', 'submitted', 'observed', 'command_accepted', 'ambiguous', 'not_started');
export const collections: Record<string, Collection> = {
  admitted_coordinators: { scope: 'registry', keys: ['agent'], fields: { agent: text } },
  nodes: { scope: 'registry', keys: ['node_id'], fields: { node_id: text, generation, revoked: boolean } },
  native_capacity_quarantine: { scope: 'registry', keys: ['node_id'], fields: { node_id: text, quarantined_at: integer } },
  slots: { scope: 'registry', keys: ['node_id', 'delivery_id'], fields: { node_id: text, agent: text, delivery_id: text, generation } },
  revocation_outbox: { scope: 'registry', keys: ['node_id', 'agent'], fields: {
    node_id: text, agent: text, revoked_generation: { ...integer, min: 2 }, next_at: integer, attempts: integer,
  } },
  runtimes: { scope: 'coordinator', keys: ['runtime_id'], fields: {
    runtime_id: text, runtime_generation: generation, node_id: text, node_generation: generation,
    attachment_generation: generation, lease_until: integer, qualified: boolean,
  } },
  native_runtime_bindings: { scope: 'coordinator', keys: ['runtime_id'], fields: {
    runtime_id: text, client_id: text, nonce: integer, sequence: generation,
  } },
  assigned_stock_runtime_bindings: { scope: 'coordinator', keys: ['runtime_id'], fields: {
    runtime_id: text,
  } },
  deliveries: { scope: 'coordinator', keys: ['delivery_id'], fields: {
    delivery_id: text, event_id: text, subject_id: text, source_state_version: text, runtime_id: text,
    runtime_generation: generation, attachment_generation: generation, node_id: text, node_generation: generation,
    state: state('pending', 'submitted', 'ambiguous', 'expired', 'observed', 'command_accepted', 'failed'),
    created_at: integer, retry_until: integer, terminal_at: optionalInteger,
    transport_state: state('queued', 'sending', 'accepted', 'admitted'), transport_failures: integer,
  } },
  attempts: { scope: 'coordinator', keys: ['attempt_id'], fields: {
    attempt_id: text, delivery_id: text, state: attemptState, transport_until: integer,
    permit_id: optionalText, permit_until: optionalInteger,
    reservation_state: state('none', 'pending', 'unknown', 'reserved', 'budget_refused', 'refused'),
    stock_wake_reserved_at: { ...generation, nullable: true },
    stock_wake_settlement_pending: boolean,
    submission_id: optionalText, turn_id: optionalText,
    transport_status: state('pending', 'sending', 'accepted', 'failed', 'not_started'),
  } },
  native_claims: { scope: 'coordinator', keys: ['delivery_id'], fields: {
    delivery_id: text, attempt_id: text, state: claimState, permit_id: optionalText,
    permit_issued_at: optionalInteger, permit_until: optionalInteger, updated_at: integer,
  } },
  no_start_settlements: { scope: 'coordinator', keys: ['attempt_id'], fields: { attempt_id: text, delivery_id: text } },
  native_correlations: { scope: 'coordinator', keys: ['correlation_id'], fields: {
    correlation_id: text, delivery_id: text, attempt_id: text, kind: state('submission', 'turn', 'input_item'),
  } },
  slot_intents: { scope: 'coordinator', keys: ['delivery_id'], fields: {
    delivery_id: text, node_id: text, node_generation: generation,
    state: state('reserve_pending', 'reserved', 'release_pending', 'quarantined'),
    updated_at: integer, attempts: integer, next_at: integer,
  } },
  queue_outbox: { scope: 'coordinator', keys: ['delivery_id'], fields: {
    delivery_id: text, due_at: integer, attempts: integer, state: state('queued', 'claimed', 'sent'),
  } },
};

const encoder = new TextEncoder();
function boundedText(value: unknown, maxBytes: number): value is string {
  return typeof value === 'string' && value.length > 0 && value.length <= maxBytes
    && encoder.encode(value).byteLength <= maxBytes;
}
// Read data descriptors only: an untrusted RPC result must never execute getters or toJSON.
function record(input: unknown, allowed: readonly string[], required = allowed, allowRpcDisposal = false): Record<string, unknown> | null {
  if (!input || typeof input !== 'object' || Array.isArray(input) || Object.getPrototypeOf(input) !== Object.prototype) return null;
  let keys = Reflect.ownKeys(input);
  if (allowRpcDisposal && keys.includes(Symbol.dispose)) {
    const disposal = Object.getOwnPropertyDescriptor(input, Symbol.dispose);
    if (!disposal || disposal.enumerable || !('value' in disposal) || typeof disposal.value !== 'function') return null;
    // workerd attaches disposal metadata to RPC values; copy only the projected data.
    keys = keys.filter(key => key !== Symbol.dispose);
  }
  if (keys.length > allowed.length || keys.some(key => typeof key !== 'string' || !allowed.includes(key))) return null;
  const result: Record<string, unknown> = {};
  for (const key of keys as string[]) {
    const descriptor = Object.getOwnPropertyDescriptor(input, key);
    if (!descriptor || !('value' in descriptor) || !descriptor.enumerable) return null;
    result[key] = descriptor.value;
  }
  return required.every(key => Object.hasOwn(result, key)) ? result : null;
}
function array(input: unknown, max: number): unknown[] | null {
  if (!Array.isArray(input) || Object.getPrototypeOf(input) !== Array.prototype) return null;
  const length = Object.getOwnPropertyDescriptor(input, 'length')?.value;
  if (!Number.isSafeInteger(length) || length < 0 || length > max) return null;
  const keys = Reflect.ownKeys(input);
  if (keys.length !== length + 1) return null;
  const result: unknown[] = [];
  for (let index = 0; index < length; index++) {
    const descriptor = Object.getOwnPropertyDescriptor(input, String(index));
    if (!descriptor || !('value' in descriptor) || !descriptor.enumerable) return null;
    result.push(descriptor.value);
  }
  return result;
}
function parseKey(input: unknown, arity: number): string[] | null {
  const items = array(input, arity);
  return items?.length === arity && items.every(item => boundedText(item, limits.keyBytes)) ? items as string[] : null;
}

export function parseInventoryRequest(input: unknown): InventoryRequest | null {
  try {
    const value = record(input, ['scopeKind', 'collection', 'limit', 'maxBytes', 'after'], ['scopeKind', 'collection']);
    if (!value || typeof value.collection !== 'string' || !Object.hasOwn(collections, value.collection)) return null;
    const collection = collections[value.collection]!;
    if (value.scopeKind !== collection.scope) return null;
    const limit = value.limit === undefined ? limits.defaultRows : value.limit;
    const maxBytes = value.maxBytes === undefined ? limits.defaultBytes : value.maxBytes;
    if (typeof limit !== 'number' || !Number.isInteger(limit) || limit < 1 || limit > limits.rows
      || typeof maxBytes !== 'number' || !Number.isInteger(maxBytes) || maxBytes < limits.minBytes || maxBytes > limits.bytes) return null;
    const after = value.after === undefined ? undefined : parseKey(value.after, collection.keys.length);
    if (after === null) return null;
    return Object.freeze({ scopeKind: collection.scope, collection: value.collection, limit, maxBytes,
      ...(after ? { after: Object.freeze(after) } : {}) });
  } catch { return null; }
}

function projectedValues(values: Record<string, unknown>, fields: Record<string, Field>, issues: unknown[]): {
  values: Record<string, InventoryScalar>; issues: string[];
} | null {
  const copied: Record<string, InventoryScalar> = {}, expectedIssues: string[] = [];
  for (const [name, field] of Object.entries(fields)) {
    const value = values[name], issue = `${name}:uninterpretable`;
    if (value === null) {
      if (issues.includes(issue)) expectedIssues.push(issue);
      else if (!field.nullable) return null;
    } else {
      if (field.kind === 'text' ? !boundedText(value, limits.textBytes)
        : typeof value !== 'number' || !Number.isSafeInteger(value) || value < (field.min ?? 0)) return null;
      if (field.states && !field.states.includes(value as InventoryScalar)) return null;
    }
    copied[name] = value as InventoryScalar;
  }
  return { values: copied, issues: expectedIssues };
}
function projectedRow(input: unknown, collection: Collection): InventoryRow | null {
  const row = record(input, ['key', 'interpretation', 'values', 'issues']);
  if (!row || !['raw', 'uninterpretable'].includes(row.interpretation as string)) return null;
  const names = Object.keys(collection.fields), values = record(row.values, names), issues = array(row.issues, names.length + 1);
  if (!values || !issues || issues.some(issue => typeof issue !== 'string')) return null;
  const copied = projectedValues(values, collection.fields, issues);
  if (!copied) return null;
  const projectedKey = collection.keys.map(name => copied.values[name]);
  const hasKey = projectedKey.every(value => boundedText(value, limits.keyBytes));
  const parsedKey = row.key === null ? null : parseKey(row.key, collection.keys.length);
  if (hasKey ? !parsedKey || parsedKey.some((value, index) => value !== projectedKey[index]) : row.key !== null) return null;
  if (!hasKey) copied.issues.push('key:uninterpretable');
  if (issues.length !== copied.issues.length || issues.some((value, index) => value !== copied.issues[index])
    || row.interpretation !== (issues.length ? 'uninterpretable' : 'raw')) return null;
  return { key: parsedKey, interpretation: row.interpretation as InventoryRow['interpretation'], ...copied };
}
function sameKey(left: readonly string[], right: readonly string[]): boolean {
  return left.length === right.length && left.every((value, index) => value === right[index]);
}
// SQLite's BINARY ordering compares UTF-8 bytes, not JavaScript UTF-16 code units.
function laterKey(left: readonly string[], right: readonly string[]): boolean {
  for (let index = 0; index < left.length; index++) {
    const a = encoder.encode(left[index]), b = encoder.encode(right[index]);
    for (let offset = 0; offset < Math.min(a.length, b.length); offset++) {
      if (a[offset] !== b[offset]) return a[offset]! > b[offset]!;
    }
    if (a.length !== b.length) return a.length > b.length;
  }
  return false;
}

function pageHeader(input: unknown, request: InventoryRequest): Record<string, unknown> | null {
  const common = ['status', 'scopeKind', 'collection', 'rows', 'nextKey', 'pageComplete', 'historicalCoverage', 'clearanceAssessment', 'consistency'];
  const page = record(input, [...common, 'reason'], common, true);
  if (!page || page.scopeKind !== request.scopeKind || page.collection !== request.collection
    || page.historicalCoverage !== 'unknown' || page.clearanceAssessment !== 'not_performed' || page.consistency !== 'single_page_only'
    || typeof page.pageComplete !== 'boolean' || !['page', 'unavailable'].includes(page.status as string)) return null;
  if (page.status === 'page' ? Object.hasOwn(page, 'reason')
    : !['schema_unknown', 'query_failed', 'uninterpretable_key', 'page_budget'].includes(page.reason as string)) return null;
  return page;
}
function pageRows(input: unknown, request: InventoryRequest, collection: Collection): InventoryRow[] | null {
  const rawRows = array(input, request.limit);
  if (!rawRows) return null;
  const rows: InventoryRow[] = [];
  let previous = request.after;
  for (const raw of rawRows) {
    const row = projectedRow(raw, collection);
    if (!row || (row.key && previous && !laterKey(row.key, previous))) return null;
    if (row.key) previous = row.key;
    rows.push(row);
  }
  return rows;
}
function validContinuation(page: Record<string, unknown>, rows: InventoryRow[], nextKey: string[] | null): boolean {
  if (page.status === 'unavailable') {
    if (page.pageComplete || nextKey) return false;
    return page.reason === 'uninterpretable_key'
      ? rows.length > 0 && rows.at(-1)!.key === null && rows.slice(0, -1).every(row => row.key !== null)
      : rows.length === 0;
  }
  if (rows.some(row => !row.key)) return false;
  return page.pageComplete ? nextKey === null
    : rows.length > 0 && nextKey !== null && sameKey(nextKey, rows.at(-1)!.key!);
}

export function parseInventoryPage(input: unknown, request: InventoryRequest): InventoryPage | null {
  try {
    const canonical = parseInventoryRequest(request);
    if (!canonical) return null;
    const page = pageHeader(input, canonical);
    if (!page) return null;
    const collection = collections[canonical.collection]!, rows = pageRows(page.rows, canonical, collection);
    if (!rows) return null;
    const nextKey = page.nextKey === null ? null : parseKey(page.nextKey, collection.keys.length);
    if ((page.nextKey !== null && !nextKey) || !validContinuation(page, rows, nextKey)) return null;
    const copied: InventoryPage = {
      status: 'page', scopeKind: canonical.scopeKind, collection: canonical.collection, rows, nextKey,
      pageComplete: page.pageComplete === true, historicalCoverage: 'unknown', clearanceAssessment: 'not_performed', consistency: 'single_page_only',
    };
    const result: InventoryPage = page.status === 'unavailable'
      ? { ...copied, status: 'unavailable', reason: page.reason as Extract<InventoryPage, { status: 'unavailable' }>['reason'] } : copied;
    return encoder.encode(JSON.stringify(result)).byteLength <= canonical.maxBytes ? result : null;
  } catch { return null; }
}
