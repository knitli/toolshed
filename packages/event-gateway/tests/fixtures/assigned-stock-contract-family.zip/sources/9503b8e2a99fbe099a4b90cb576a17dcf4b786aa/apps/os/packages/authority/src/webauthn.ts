// The WebAuthn assertion checks of the verification algorithm (R4 plan 6.7 steps 3 to 5), the pinned configuration every verifier reads instead of the act or
// the bundle (AT-22), and the assurance floors (VS-12). WebCrypto only: ES256 (with DER to raw r||s) and EdDSA, no CBOR, because a credential is stored as a
// JWK (6.3). Pure TypeScript: no Worker types, no I/O.
//
// rpId, origin and aud come from the verifier's own configuration; nothing here reads them from the evidence or the act except to compare.
import { ACT_KINDS, type ActKind, type Assurance } from "./act.ts";
import { b64u, sha256, unb64u } from "./canonical.ts";
import { AUD, HOST, LABEL, MAX_ANCHORS_PER_PRINCIPAL, ORIGIN, isThumbprint, matches, plain } from "./contract-kit.ts";
import { snapshot } from "./snapshot.ts";
import { isCanonicalPrincipal } from "./scope.ts";
import { TASK_TYPE } from "./task.ts";

export type Evidence = { authenticatorData: string; clientDataJSON: string; signature: string; credentialId: string }; // base64url; clientDataJSON as the raw bytes
/**
 * The most base64url characters each part of an assertion may have, checked before anything is decoded (the parts are a bundle's or a browser's, so their
 * size is not ours to trust): an assertion's authData is 37 bytes, an ES256 signature at most 72, an EdDSA one 64, the client data a short JSON object, and
 * a credential id at most 1023 bytes. contracts.ts bounds the parsed JSON by the same numbers.
 */
export const MAX_EVIDENCE_CHARS = { authenticatorData: 64, clientDataJSON: 2048, signature: 100, credentialId: 1366 } as const;

export type CredentialKey = { jwk: Readonly<Record<string, unknown>>; alg: -7 | -8 }; // COSE: -7 ES256, -8 EdDSA

export type Anchor = Readonly<{ principal: string; thumbprint: string; label: string }>;
/** `default`, `<kind>`, `<kind>:<task type>` or `<kind>:<prefix>/*` -> the least assurance an act of that kind and type may claim. */
export type Floors = Readonly<Record<string, Assurance>>;
/** How long a newly enrolled credential waits before it can sign (plan D3). The renderer says this number to the person signing, so a pinned file may not say another. */
export const ACTIVATION_DELAY_HOURS = 24;
export type PinnedPresence = {
  rpId: string;
  origin: string;
  aud: string;
  anchors: readonly Anchor[];
  floors: Floors;
  activationDelayHours: number;
};

// Built from TASK_TYPE, so every task type that can be declared can have a floor (`kind:type`, or `kind:prefix/*`).
const FLOOR_KEY = new RegExp(`^(?:default|(?:${ACT_KINDS.join("|")})(?::${TASK_TYPE.source.slice(1, -1)}(?:/\\*)?)?)$`);

/** The thumbprints a deployment pins for `principal`, sorted: the set a liveness act lists and a liveness proof must be made inside. Both the presence Worker's review and the verifier read this one. */
export const pinSetOf = (anchors: readonly Anchor[], principal: string): string[] => anchors.filter((a) => a.principal === principal).map((a) => a.thumbprint).toSorted();
/** Whether two sorted lists of thumbprints are one list. */
export const samePinSet = (x: readonly string[], y: readonly string[]): boolean => x.length === y.length && x.every((t, i) => t === y[i]);

/** The anchors of a pinned file or a verifier's configuration, checked and frozen, or null. An anchor names a principal and a thumbprint; a principal has at most MAX_ANCHORS_PER_PRINCIPAL. */
function anchorsOf(list: unknown): Anchor[] | null {
  if (!Array.isArray(list) || list.length > 16) return null;
  const anchors: Anchor[] = [];
  for (const entry of list) {
    const a = plain(entry, ["principal", "thumbprint", "label"]);
    if (!a || !isCanonicalPrincipal(a.principal) || !coordinate(a.thumbprint) || typeof a.label !== "string" || !LABEL.test(a.label)) return null;
    if (anchors.some((b) => b.thumbprint === a.thumbprint)) return null; // one key anchors one person: shared across two principals, it would be either one's
    if (anchors.filter((b) => b.principal === a.principal).length >= MAX_ANCHORS_PER_PRINCIPAL) return null; // the liveness act lists them all
    anchors.push(Object.freeze({ principal: a.principal, thumbprint: a.thumbprint, label: a.label }));
  }
  return anchors;
}

/** The floors of a pinned file or a verifier's configuration, a frozen copy, or null: a default, only known keys, hw-uv or hw-up, and touch-only for orders alone. */
function floorsOf(value: unknown): Floors | null {
  const floors = value !== null && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : null;
  if (!floors || !Object.hasOwn(floors, "default")) return null; // no default floor means no floor: refuse rather than guess
  // Touch-only is for orders of a declared low-risk type alone (D2, 6.3): no other kind may be pinned below hw-uv.
  for (const [key, level] of Object.entries(floors)) {
    if (!FLOOR_KEY.test(key) || (level !== "hw-uv" && level !== "hw-up") || (level === "hw-up" && key !== "order" && !key.startsWith("order:"))) return null;
  }
  return Object.freeze({ ...floors }) as Floors;
}

/** The pins a verifier trusts, from the file `presence-anchors.ts` exports (anchors, floors, delay), or null. Closed; an anchor names a principal and a thumbprint. */
export function parsePinnedFile(value: unknown): Readonly<Pick<PinnedPresence, "anchors" | "floors" | "activationDelayHours">> | null {
  const read = snapshot(value);
  const f = read && plain(read.value, ["v", "anchors", "floors", "activationDelayHours"]);
  if (!f || f.v !== 1 || f.activationDelayHours !== ACTIVATION_DELAY_HOURS) return null;
  const anchors = anchorsOf(f.anchors);
  const floors = floorsOf(f.floors);
  // A copy, frozen: the caller's object is not the verifier's config, and nothing may edit the floors after they were checked.
  return anchors && floors ? Object.freeze({ anchors: Object.freeze(anchors), floors, activationDelayHours: ACTIVATION_DELAY_HOURS }) : null;
}

/**
 * A verifier's configuration, read once and checked by the predicates the pinned file is (so a Worker that builds one by hand cannot hold what the file could
 * not): the part each caller needs, and nothing else is returned. `assertion`: rpId and origin. `review`: aud, rpId and floors. `full`: all of it, with the
 * fixed activation delay. Extra members are ignored, since callers hold a `Pick`. Null when anything it needs is missing or malformed.
 */
export function readPinned(value: unknown, parts: "assertion"): Pick<PinnedPresence, "rpId" | "origin"> | null;
export function readPinned(value: unknown, parts: "review"): Pick<PinnedPresence, "aud" | "rpId" | "floors"> | null;
export function readPinned(value: unknown, parts: "full"): PinnedPresence | null;
export function readPinned(value: unknown, parts: "assertion" | "review" | "full"): Partial<PinnedPresence> | null {
  const read = snapshot(value);
  const p = read && read.value !== null && typeof read.value === "object" && !Array.isArray(read.value) ? (read.value as Record<string, unknown>) : null;
  if (!p || !matches(p.rpId, HOST)) return null;
  if (parts === "assertion") return matches(p.origin, ORIGIN) ? { rpId: p.rpId, origin: p.origin } : null;
  const floors = floorsOf(p.floors);
  if (!floors || !matches(p.aud, AUD)) return null;
  if (parts === "review") return { aud: p.aud, rpId: p.rpId, floors };
  const anchors = anchorsOf(p.anchors);
  if (!anchors || !matches(p.origin, ORIGIN) || p.activationDelayHours !== ACTIVATION_DELAY_HOURS) return null;
  return { rpId: p.rpId, origin: p.origin, aud: p.aud, anchors, floors, activationDelayHours: ACTIVATION_DELAY_HOURS };
}

const rank = (level: Assurance): number => (level === "hw-uv" ? 1 : 0);
export const stricter = (a: Assurance, b: Assurance): Assurance => (rank(a) >= rank(b) ? a : b);

/** The pinned floor for an act: the most specific entry (`kind:type`, then the longest `kind:prefix/*`, then `kind`, then `default`). A declaration may raise it, never lower it. */
export function floorFor(floors: Floors, kind: ActKind, type?: string, declared?: Assurance): Assurance {
  const prefixes = type === undefined ? [] : Object.keys(floors).filter((key) => key.startsWith(`${kind}:`) && key.endsWith("/*") && type.startsWith(key.slice(kind.length + 1, -1))).toSorted((a, b) => b.length - a.length);
  const key = [type === undefined ? undefined : `${kind}:${type}`, ...prefixes, kind, "default"].find((candidate) => candidate !== undefined && Object.hasOwn(floors, candidate));
  const pinned = (key === undefined ? "hw-uv" : floors[key]!) as Assurance; // fail closed if no default was given
  return declared === undefined ? pinned : stricter(pinned, declared);
}

// --- keys ----------------------------------------------------------------------------------------------------

/** A 32-byte coordinate in its one canonical base64url spelling: 43 characters whose last one carries no stray bits. WebCrypto decodes the loose spellings to the same point, and a thumbprint hashes the text, so one key would otherwise pass for several. */
const coordinate = isThumbprint;
const encoder = new TextEncoder();

/**
 * The eight small-order Ed25519 points (libsodium's blocklist, canonical encodings). Verification under such a key succeeds for signatures its holder never
 * made, and BoringSSL (workerd) accepts the identity key's all-zero-ish signature for any message where Node refuses it, so a key like this is refused at
 * the door. Registration (COSE to JWK, 5a-2) calls isAcceptableEd25519Key too.
 */
const SMALL_ORDER = new Set([
  "0100000000000000000000000000000000000000000000000000000000000000", "ecffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff7f",
  "0000000000000000000000000000000000000000000000000000000000000000", "0000000000000000000000000000000000000000000000000000000000000080",
  "26e8958fc2b227b045c3f489f2ef98f0d5dfac05d3c63339b13802886d53fc05", "26e8958fc2b227b045c3f489f2ef98f0d5dfac05d3c63339b13802886d53fc85",
  "c7176a703d4dd84fba3c0b760d10670f2a2053fa2c39ccc64ec7fd7792ac037a", "c7176a703d4dd84fba3c0b760d10670f2a2053fa2c39ccc64ec7fd7792ac03fa",
]);
const P25519 = 2n ** 255n - 19n;

/** Whether the 32 bytes (or base64url text) of an Ed25519 public key are acceptable: 32 bytes, not small-order, and y canonical (below 2^255 - 19). */
export function isAcceptableEd25519Key(key: Uint8Array | string): boolean {
  const bytes = typeof key === "string" ? unb64u(key) : key;
  if (!bytes || bytes.length !== 32) return false;
  // Compared with the sign bit (bit 7 of byte 31) cleared, as libsodium does: the sign bit picks between x and -x, and both are small-order for these y.
  const masked = Uint8Array.from(bytes);
  masked[31] = masked[31]! & 0x7f;
  if (SMALL_ORDER.has(Array.from(masked, (b) => b.toString(16).padStart(2, "0")).join(""))) return false;
  let y = 0n;
  for (let i = 31; i >= 0; i--) y = (y << 8n) | BigInt(i === 31 ? bytes[i]! & 0x7f : bytes[i]!);
  return y < P25519;
}

/** The public JWK as WebCrypto imports it, or null: P-256 for ES256, Ed25519 for EdDSA, nothing else and no private member. */
type PublicJwk = { kty: "EC"; crv: "P-256"; x: string; y: string } | { kty: "OKP"; crv: "Ed25519"; x: string; y?: undefined };
function publicJwk(given: CredentialKey): PublicJwk | null {
  const read = snapshot(given); // read once: a getter must not show one key to the check and another to the import
  const key = read?.value as CredentialKey | null | undefined;
  if (key === null || key === undefined || typeof key !== "object" || key.jwk === null || typeof key.jwk !== "object") return null;
  const j = key.jwk as { kty?: unknown; crv?: unknown; x?: unknown; y?: unknown; d?: unknown };
  if (j.d !== undefined) return null;
  if (key.alg === -7) return j.kty === "EC" && j.crv === "P-256" && coordinate(j.x) && coordinate(j.y) ? { kty: "EC", crv: "P-256", x: j.x, y: j.y } : null;
  if (key.alg === -8) return j.kty === "OKP" && j.crv === "Ed25519" && coordinate(j.x) && isAcceptableEd25519Key(j.x) ? { kty: "OKP", crv: "Ed25519", x: j.x } : null;
  return null;
}

/** RFC 7638 thumbprint of a credential's public JWK, or null if it is not an acceptable key. */
export async function thumbprintOf(key: CredentialKey): Promise<string | null> {
  const j = publicJwk(key);
  if (!j) return null;
  const members = j.kty === "EC" ? { crv: j.crv, kty: j.kty, x: j.x, y: j.y } : { crv: j.crv, kty: j.kty, x: j.x };
  return b64u(await sha256(encoder.encode(JSON.stringify(members))));
}

/** An ASN.1 DER ECDSA signature as the raw r||s (64 bytes) WebCrypto verifies, or null. Strict: minimal lengths and integers, positive, nothing trailing. */
export function derToRaw(der: Uint8Array): Uint8Array<ArrayBuffer> | null {
  if (der.length < 8 || der.length > 72 || der[0] !== 0x30 || der[1] !== der.length - 2) return null;
  const raw = new Uint8Array(64);
  let at = 2;
  for (let half = 0; half < 2; half++) {
    if (der[at] !== 0x02) return null;
    const length = der[at + 1];
    if (length === undefined || length < 1 || length > 33 || at + 2 + length > der.length) return null;
    let int = der.subarray(at + 2, at + 2 + length);
    if ((int[0]! & 0x80) !== 0) return null; // negative
    if (int[0] === 0 && int.length > 1) {
      if ((int[1]! & 0x80) === 0) return null; // a needless leading zero
      int = int.subarray(1);
    }
    if (int.length > 32) return null;
    raw.set(int, half * 32 + (32 - int.length));
    at += 2 + length;
  }
  return at === der.length ? raw : null;
}

// --- one assertion -------------------------------------------------------------------------------------------

export type AssertionReason =
  | "evidence_malformed" | "bad_type" | "challenge_mismatch" | "origin_mismatch" | "cross_origin"
  | "rp_hash_mismatch" | "up_missing" | "uv_missing" | "be_set" | "flags" | "bad_signature";
export type AssertionResult = { ok: true; uv: boolean; counter: number } | { ok: false; reason: AssertionReason };

const FLAG = { up: 0x01, uv: 0x04, be: 0x08, bs: 0x10, reserved: 0x22, at: 0x40, ed: 0x80 };
const refuse = (reason: AssertionReason): AssertionResult => ({ ok: false, reason });

/**
 * Steps 3 to 5 for one assertion by `key` over `challenge`: the client data (type, challenge, pinned origin, no cross-origin), the authenticator data (pinned
 * rpIdHash, UP, UV when `requireUv`, no BE, no extensions), and the signature over authData || sha256(clientDataJSON) with the raw clientDataJSON bytes,
 * never a re-serialization. `requireUv` is the caller's decision from the pinned floor; this never relaxes it.
 */
export async function checkAssertion(args: { challenge: Uint8Array; evidence: Evidence; key: CredentialKey; pinned: Pick<PinnedPresence, "rpId" | "origin">; requireUv: boolean }): Promise<AssertionResult> {
  const { challenge, requireUv } = args;
  const keyRead = snapshot(args.key);
  const pinned = readPinned(args.pinned, "assertion");
  const evidenceRead = snapshot(args.evidence);
  const evidence = evidenceRead?.value as Partial<Evidence> | null | undefined; // a bundle's: any shape, read once
  if (!keyRead || !pinned || evidence === null || evidence === undefined || typeof evidence !== "object") return refuse("evidence_malformed");
  const key = keyRead.value as CredentialKey;
  for (const part of ["authenticatorData", "clientDataJSON", "signature", "credentialId"] as const) {
    const text = evidence[part];
    if (typeof text !== "string" || text.length > MAX_EVIDENCE_CHARS[part]) return refuse("evidence_malformed");
  }
  if (!evidence.credentialId || unb64u(evidence.credentialId) === null) return refuse("evidence_malformed"); // only a hint, but a bundle's bytes are bounded and well formed like the rest
  const clientBytes = unb64u(evidence.clientDataJSON);
  const authData = unb64u(evidence.authenticatorData);
  const signature = unb64u(evidence.signature);
  const jwk = publicJwk(key);
  if (!clientBytes || !authData || !signature || !jwk) return refuse("evidence_malformed");

  let client: { type?: unknown; challenge?: unknown; origin?: unknown; crossOrigin?: unknown; topOrigin?: unknown };
  try {
    client = JSON.parse(new TextDecoder("utf-8", { fatal: true, ignoreBOM: false }).decode(clientBytes));
    if (client === null || typeof client !== "object" || Array.isArray(client)) return refuse("bad_type");
  } catch {
    return refuse("bad_type");
  }
  if (client.type !== "webauthn.get") return refuse("bad_type");
  if (client.challenge !== b64u(challenge)) return refuse("challenge_mismatch");
  if (client.origin !== pinned.origin) return refuse("origin_mismatch");
  if (client.crossOrigin !== undefined && client.crossOrigin !== false) return refuse("cross_origin");
  if (client.topOrigin !== undefined) return refuse("cross_origin");

  if (authData.length < 37) return refuse("flags");
  const rpIdHash = await sha256(encoder.encode(pinned.rpId));
  if (!rpIdHash.every((byte, i) => byte === authData[i])) return refuse("rp_hash_mismatch");
  const flags = authData[32]!;
  if ((flags & FLAG.up) === 0) return refuse("up_missing");
  if (requireUv && (flags & FLAG.uv) === 0) return refuse("uv_missing");
  if ((flags & FLAG.be) !== 0) return refuse("be_set");
  // Backup state without eligibility, the reserved bits, attested data and extensions have no place in an assertion, which is exactly 37 bytes.
  if ((flags & (FLAG.bs | FLAG.reserved | FLAG.at | FLAG.ed)) !== 0 || authData.length !== 37) return refuse("flags");

  const signed = new Uint8Array(authData.length + 32);
  signed.set(authData);
  signed.set(await sha256(clientBytes), authData.length);
  let valid = false;
  try {
    if (key.alg === -7) {
      const raw = derToRaw(signature);
      valid = raw !== null && (await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, await crypto.subtle.importKey("jwk", jwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]), raw, signed));
    } else {
      valid = signature.length === 64 && (await crypto.subtle.verify("Ed25519", await crypto.subtle.importKey("jwk", jwk, "Ed25519", false, ["verify"]), signature, signed));
    }
  } catch {
    valid = false;
  }
  if (!valid) return refuse("bad_signature");
  return { ok: true, uv: (flags & FLAG.uv) !== 0, counter: new DataView(authData.buffer, authData.byteOffset + 33, 4).getUint32(0) };
}
