import type { GitHubAttentionController } from './controller';
import { materialDigest } from './material-read';

export const MATERIAL_CACHE_LIMITS = Object.freeze({ entries: 8, utf16Bytes: 4 * 1024 * 1024 });
type Stamp = ReturnType<GitHubAttentionController['findingMaterialStamp']>;
type Material = Readonly<{ body: string; firstVersion: number; digest: string }>;
/** Ephemeral content only. Every use still requires fresh authority, membership and metadata fences. */
export class GitHubMaterialCache {
  private readonly entries = new Map<string, { material: Material; bytes: number; locator: string }>();
  private generation: string | undefined;
  private bytes = 0;
  private pending: { stamp: string; promise: Promise<Material | null> } | undefined;
  private reset(generation: string): void {
    if (generation === this.generation) return;
    this.entries.clear(); this.bytes = 0; this.generation = generation;
  }
  private dropLocator(locator: string): void {
    // At most eight entries. No second index or unbounded negative cache.
    for (const [stamp, entry] of this.entries) if (entry.locator === locator) {
      this.bytes -= entry.bytes; this.entries.delete(stamp);
    }
  }
  private reserve(bytes: number): void {
    while (this.entries.size >= MATERIAL_CACHE_LIMITS.entries || this.bytes + bytes > MATERIAL_CACHE_LIMITS.utf16Bytes) {
      const oldest = this.entries.keys().next().value!;
      this.bytes -= this.entries.get(oldest)!.bytes; this.entries.delete(oldest);
    }
  }
  async read(controller: GitHubAttentionController, sourceId: string, fingerprint: string, before: Stamp): Promise<Material | null> {
    this.reset(before.generation);
    const locator = JSON.stringify([sourceId, fingerprint]);
    if (before.status !== 'available') {
      // Time-only expiry can invalidate this locator without a storage mutation.
      // Missing/deleted lookups must not evict unrelated available content.
      this.dropLocator(locator); return null;
    }
    const cached = this.entries.get(before.stamp);
    if (cached) {
      this.entries.delete(before.stamp); this.entries.set(before.stamp, cached);
      return cached.material;
    }
    // One in-flight body maximum; duplicate callers share its work. Other misses
    // retry through the caller's conflict response, without loading another body.
    if (this.pending) return this.pending.stamp === before.stamp ? this.pending.promise : null;
    const reservation = 3 * 1024 * 1024 + (before.stamp.length + locator.length) * 2 + 256;
    if (reservation > MATERIAL_CACHE_LIMITS.utf16Bytes) return null;
    // Reserve worst-case UTF-16 body plus the UTF-8 digest input before loading.
    this.reserve(reservation);
    const promise = Promise.resolve().then(() => this.load(controller, sourceId, fingerprint, before, locator));
    this.pending = { stamp: before.stamp, promise };
    try { return await promise; }
    finally { this.pending = undefined; }
  }
  private async load(controller: GitHubAttentionController, sourceId: string, fingerprint: string, before: Stamp, locator: string): Promise<Material | null> {
    if (controller.findingMaterialStamp(sourceId, fingerprint).stamp !== before.stamp) return null;
    const retained = controller.readFindingMaterial(sourceId, fingerprint);
    if (retained.status !== 'available' || retained.firstVersion !== before.firstVersion) return null;
    const bytes = retained.body.length * 2 + (before.stamp.length + locator.length) * 2 + 256;
    const digest = await materialDigest(retained.body);
    const after = controller.findingMaterialStamp(sourceId, fingerprint);
    if (after.stamp !== before.stamp) { this.reset(after.generation); return null; }
    this.reset(after.generation);
    const material = Object.freeze({ body: retained.body, firstVersion: retained.firstVersion, digest });
    this.reserve(bytes);
    this.entries.set(before.stamp, { material, bytes, locator }); this.bytes += bytes;
    return material;
  }
}
