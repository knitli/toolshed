/** Guarded rollback floors must be deployed before opting into a newer storage version. */
export const GITHUB_HOST_STORAGE_VERSION = 2;
export function assertGitHubHostStorageVersion(sql: SqlStorage, supported = GITHUB_HOST_STORAGE_VERSION): void {
  const objects = sql.exec<{ type: string }>("SELECT type FROM sqlite_master WHERE name='github_host_storage_version' COLLATE NOCASE LIMIT 2").toArray();
  if (!objects.length) return;
  if (objects.length !== 1 || objects[0]?.type !== 'table') throw new Error('unsupported github host storage');
  const rows = sql.exec<{ id: number; version: number }>('SELECT id,version FROM github_host_storage_version LIMIT 2').toArray();
  if (rows.length !== 1 || rows[0]?.id !== 1 || !Number.isSafeInteger(rows[0].version)
    || rows[0].version < 1 || rows[0].version > supported) throw new Error('unsupported github host storage');
}
/** Caller includes this effect in the same transaction as the initial retention pin. */
export function markGitHubInitialCustody(sql: SqlStorage): void {
  assertGitHubHostStorageVersion(sql);
  sql.exec('CREATE TABLE IF NOT EXISTS github_host_storage_version(id INTEGER PRIMARY KEY CHECK(id=1),version INTEGER NOT NULL)');
  sql.exec('INSERT INTO github_host_storage_version(id,version) VALUES(1,2) ON CONFLICT(id) DO UPDATE SET version=2');
}
