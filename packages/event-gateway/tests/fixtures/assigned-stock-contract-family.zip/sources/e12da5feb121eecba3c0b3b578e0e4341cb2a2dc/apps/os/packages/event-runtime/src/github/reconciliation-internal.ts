import { z } from 'zod';
import { WatchActivateTokenSchema } from './watch-control-internal';
import type { GitHubSourceReadItem } from './readback-contract';

const positive = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);
const cursor = z.strictObject({ rangeDigest: z.string().regex(/^[a-f0-9]{64}$/), offset: positive.max(16_384) });
/** Internal retention identity, never source-read authority or a public reference. */
export const InitialReconciliationObligationSchema = z.strictObject({
  token: WatchActivateTokenSchema, cause: z.literal('initial'), operationId: z.string().uuid(),
  fromVersion: z.literal(1), toVersion: positive, observationEpoch: positive, hostEpoch: positive,
}).refine(value => value.operationId === value.token.operationId && value.hostEpoch > value.observationEpoch);
export type InitialReconciliationObligation = z.infer<typeof InitialReconciliationObligationSchema>;
export const InitialPinnedMetadataReadSchema = z.strictObject({ obligation: InitialReconciliationObligationSchema, cursor: cursor.optional() });
export type InitialPinnedMetadataReadResult = { status: 'unavailable' | 'coverage_unavailable' | 'conflict' } | {
  status: 'ok'; operationId: string; fromVersion: number; toVersion: number; rangeDigest: string;
  items: GitHubSourceReadItem[]; nextCursor: z.infer<typeof cursor> | null; complete: boolean;
};
