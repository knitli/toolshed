import { ConversionMaterialReadBudget, ConversionManifestPagePlanner, initialConversionShape } from './conversion-planning';
import type { EventRequestDeadline } from '../request-deadline';
import { CONVERSION_MANIFEST_LIMITS as L, type ConversionManifestInput } from './conversion-manifest-store';
import { materialDigest } from './material-read';
import { GitHubMaterialReadResultSchema, materialPageMatches } from './material-read-contract';
import { projectGitHubSourceRecord } from './readback-contract';
import type { InitialReconciliationJob } from './reconciliation-store';
import type { GitHubAttentionHost } from './host';

/** Complete bounded initial union. No reservation, delivery, observation, or release effects. */
export async function prepareInitialConversion(job: InitialReconciliationJob,
  host: Pick<GitHubAttentionHost, 'readInitialReconciliationMetadata' | 'readInitialReconciliationMaterial'>,
  check: () => void, deadline: EventRequestDeadline): Promise<ConversionManifestInput> {
  const o = job.obligation, entries: ConversionManifestInput['pages'][number]['entries'] = [];
  const materials = new Map<string, { sourceId: string; fingerprint: string }>(), versions = new Map<number, number>();
  const identities = new Set<string>();
  let cursor: { rangeDigest: string; offset: number } | undefined, rangeDigest: string | undefined;
  let bytes = 0, pagesRead = 0, count = 0;
  do {
    deadline.assertCurrent(); check();
    const page = await deadline.run(() => host.readInitialReconciliationMetadata({ obligation: o, ...(cursor ? { cursor } : {}) }), 20_000); check();
    if (page.status !== 'ok' || page.operationId !== o.operationId || page.fromVersion !== o.fromVersion || page.toVersion !== o.toVersion
      || page.complete !== (page.nextCursor === null) || !/^[a-f0-9]{64}$/.test(page.rangeDigest)
      || rangeDigest !== undefined && rangeDigest !== page.rangeDigest || !Array.isArray(page.items) || page.items.length === 0)
      throw new Error('github_source_conflict');
    rangeDigest = page.rangeDigest;
    bytes += new TextEncoder().encode(JSON.stringify(page)).length;
    if (++pagesRead > L.pages || bytes > L.bytes) throw new Error('capacity');
    for (const item of page.items) {
      if (++count > L.entries || item.phase !== 'transition' || !Number.isSafeInteger(item.sourceVersion)
        || item.sourceVersion < 1 || item.sourceVersion > o.toVersion || !Number.isSafeInteger(item.epoch)
        || item.epoch < 1 || item.epoch > o.observationEpoch) throw new Error('github_source_conflict');
      const key = JSON.stringify([item.sourceVersion, item.recordType, item.recordKey]);
      if (identities.has(key)) throw new Error('github_source_conflict'); identities.add(key);
      const value = projectGitHubSourceRecord(item.recordType, item.value);
      if (item.recordType === 'version') {
        if (item.recordKey !== '' || versions.has(item.sourceVersion)) throw new Error('github_source_conflict');
        versions.set(item.sourceVersion, item.epoch);
      }
      const valueDigest = await deadline.run(() => materialDigest(JSON.stringify(value))); check();
      entries.push({ kind: 'transition', sourceVersion: item.sourceVersion, epoch: item.epoch,
        recordType: item.recordType, recordKey: item.recordKey, valueDigest });
      if (item.recordType === 'finding') {
        for (const state of [value.from, value.to]) {
          if (state && typeof state === 'object' && 'presence' in state && state.presence === 'present'
            && 'fingerprint' in state && typeof state.fingerprint === 'string' && typeof value.sourceId === 'string') {
            materials.set(JSON.stringify([value.sourceId, state.fingerprint]), { sourceId: value.sourceId, fingerprint: state.fingerprint });
          }
        }
      }
    }
    if (page.nextCursor && (page.nextCursor.rangeDigest !== rangeDigest || page.nextCursor.offset !== count
      || page.nextCursor.offset <= (cursor?.offset ?? 0))) throw new Error('github_source_conflict');
    cursor = page.nextCursor ?? undefined;
  } while (cursor);
  if (versions.size !== o.toVersion || versions.get(o.toVersion) !== o.observationEpoch) throw new Error('github_source_conflict');
  for (const entry of entries) if (entry.kind === 'transition' && versions.get(entry.sourceVersion) !== entry.epoch) throw new Error('github_source_conflict');
  let materialBytes = 0;
  const reads = new ConversionMaterialReadBudget();
  for (const material of materials.values()) {
    let body = '', next: string | undefined, digest: string | undefined, firstVersion = 0, totalLength = -1;
    do {
      const request = { subject: { installationId: o.token.installationId, ...o.token.subject }, ...material,
        fromVersion: o.fromVersion, toVersion: o.toVersion, ...(next ? { cursor: next } : {}) };
      check(); reads.consume();
      const page = GitHubMaterialReadResultSchema.parse(await deadline.run(() => host.readInitialReconciliationMaterial({ obligation: o, material: request }), 20_000)); check();
      if (page.status !== 'ok' || !materialPageMatches(request, page) || page.offset !== body.length
        || digest !== undefined && (digest !== page.bodyDigest || firstVersion !== page.firstVersion || totalLength !== page.totalLength)) throw new Error('github_source_conflict');
      digest = page.bodyDigest; firstVersion = page.firstVersion; totalLength = page.totalLength;
      materialBytes += new TextEncoder().encode(page.body).length;
      if (materialBytes > L.bytes || page.body.length === 0 && !page.complete) throw new Error('capacity');
      body += page.body; next = page.nextCursor ?? undefined;
    } while (next);
    if (body.length !== totalLength || await deadline.run(() => materialDigest(body)) !== digest) throw new Error('github_source_conflict'); check();
    entries.push({ kind: 'material', ...material, firstVersion, bodyDigest: digest!, availability: 'available' });
    if (entries.length > L.entries) throw new Error('capacity');
  }
  const pages: ConversionManifestInput['pages'] = [], planner = new ConversionManifestPagePlanner();
  for (const entry of entries) {
    const index = planner.append(entry);
    const page = pages[index] ?? (pages[index] = { index, entries: [] });
    page.entries.push(entry);
  }
  return { ...initialConversionShape(o, job.fence, pages.length, entries.length), pages };
}
