import { GITHUB_MATERIAL_RESPONSE_BYTES, encodeMaterialCursor, parseMaterialCursor, type GitHubMaterialReadRequest, type GitHubMaterialReadResult } from './material-read-contract';

export const materialDigest = async (value: string): Promise<string> => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value)))].map(byte => byte.toString(16).padStart(2, '0')).join('');
/** Caller must revalidate authority and retained material after this asynchronous digest. */
export async function materialPage(request: GitHubMaterialReadRequest, material: { body: string; firstVersion: number }, authorityBinding: unknown, digest?: string): Promise<GitHubMaterialReadResult> {
  const bodyDigest = digest ?? await materialDigest(material.body);
  const binding = await materialDigest(JSON.stringify([authorityBinding, request.subject, request.sourceId, request.fingerprint, request.fromVersion, request.toVersion, material.firstVersion, bodyDigest]));
  return materialPageWithDigests(request, material, bodyDigest, binding);
}
/** Pure sizing and slicing path, also used by initial-custody preflight with fixed-length digest placeholders. */
export function materialPageWithDigests(request: GitHubMaterialReadRequest, material: { body: string; firstVersion: number },
  bodyDigest: string, binding: string): GitHubMaterialReadResult {
  const cursor = request.cursor === undefined ? null : parseMaterialCursor(request.cursor);
  if (request.cursor !== undefined && (!cursor || cursor.binding !== binding)) return { status: 'conflict' };
  const offset = cursor?.offset ?? 0;
  if (offset > material.body.length || offset > 0 && offset === material.body.length
    || offset > 0 && /[\uD800-\uDBFF]/.test(material.body[offset - 1]!) && /[\uDC00-\uDFFF]/.test(material.body[offset]!)) return { status: 'conflict' };
  let end = Math.min(material.body.length, offset + 2048);
  for (;;) {
    if (end < material.body.length && /[\uD800-\uDBFF]/.test(material.body[end - 1]!) && /[\uDC00-\uDFFF]/.test(material.body[end]!)) end--;
    if (end === offset && material.body.length !== 0) return { status: 'unavailable' };
    const complete = end === material.body.length;
    const page = { status: 'ok' as const, subject: request.subject, sourceId: request.sourceId, fingerprint: request.fingerprint,
      requestedRange: { fromVersion: request.fromVersion, toVersion: request.toVersion }, firstVersion: material.firstVersion, bodyDigest, offset, totalLength: material.body.length, body: material.body.slice(offset, end),
      nextCursor: complete ? null : encodeMaterialCursor({ binding, offset: end }), complete };
    if (new TextEncoder().encode(JSON.stringify(page)).length <= GITHUB_MATERIAL_RESPONSE_BYTES) return page;
    if (end === offset) return { status: 'unavailable' };
    end = offset + Math.floor((end - offset) / 2);
  }
}
