/** Stage-2 attention observation, not full stage-3 reviewer/completion evidence.
 * Runs preserve provider metadata, including unknown attempts/status; this is not the transport protocol. */
export interface GitHubSubjectV1 {
  installationId: number;
  repositoryId: number;
  prNumber: number;
}
export interface GitHubCandidateV1 {
  headSha: string;
  baseSha: string;
  /** Raw GitHub merge_commit_sha observation; never proof of test-merge applicability or parents. */
  observedMergeSha: string | null;
  policyRevision: string;
}
export interface GitHubFindingV1 {
  sourceId: string;
  nodeId: string;
  threadId: string | null;
  actorId: string | null;
  appId: string | null;
  sourceHeadSha: string | null;
  kind: 'review' | 'thread' | 'comment';
  fingerprint: string;
  disposition: 'open' | 'resolved';
  outdated: boolean;
}
export interface GitHubRunV1 {
  workflowId?: number;
  runNumber?: number;
  sourceId: string;
  kind: 'check' | 'status' | 'workflow';
  name: string | null;
  appId: string | null;
  actorId: string | null;
  headSha: string;
  attempt: number | null;
  status: string | null;
  conclusion: string | null;
  /** Check lifecycle metadata distinguishes same-ID reruns when supplied by the provider. */
  startedAt?: string | null;
  completedAt?: string | null;
}
export const GITHUB_ENDPOINTS = ['pull', 'reviews', 'threads', 'comments', 'checks', 'statuses', 'workflows', 'reviewRequests'] as const;
export type GitHubCompletenessV1 = Record<typeof GITHUB_ENDPOINTS[number], 'complete' | 'unknown'>;
export interface GitHubObservationV1 {
  schemaVersion: 1;
  retryAt?: number;
  subject: GitHubSubjectV1;
  candidate: GitHubCandidateV1;
  observedAt: number;
  epoch: number;
  state: 'open' | 'closed' | 'merged';
  completeness: GitHubCompletenessV1;
  reviewRequests: { kind: 'user' | 'team'; sourceId: string }[];
  /** Source-private text; removed before metadata snapshots and publication. */
  findingMaterials?: { sourceId: string; fingerprint: string; body: string }[];
  findings: GitHubFindingV1[];
  runs: GitHubRunV1[];
}
export interface RetainedFindingV1 extends GitHubFindingV1 { discoveryGeneration: number }
export interface GitHubAttentionV1 {
  publicationId: string;
  subject: GitHubSubjectV1;
  sourceVersion: number;
  candidateGeneration: number;
  observedAt: number;
  eventKind: 'attention' | 'ci' | 'terminal';
  reasonCode: 'review_requested' | 'review_submitted' | 'review_comment' | 'check_failed' | 'status_failed' | 'pull_request_closed' | 'pull_request_merged';
}
export const subjectKey = (subject: GitHubSubjectV1): string => JSON.stringify([subject.installationId, subject.repositoryId, subject.prNumber]);
export const candidateKey = (candidate: GitHubCandidateV1): string => JSON.stringify([candidate.headSha, candidate.baseSha, candidate.observedMergeSha, candidate.policyRevision]);
