import { EventApiError, parseApiJson } from "./contracts.ts";
import { requireAssignedStockProfile, requireNativeAdmissionCanary } from "./native-admission-gate.ts";
import { ManualCanarySchema } from "./manual-canary-scope.ts";

export function requireManualCanary(env: {
  EVENT_ENABLED?: string; EVENT_MANUAL_ENABLED?: string; EVENT_MANUAL_CANARY?: string;
  EVENT_NATIVE_BINDING_ENABLED?: string; EVENT_NATIVE_BINDING_CANARY?: string;
  EVENT_ASSIGNED_STOCK_ENABLED?: string; EVENT_ASSIGNED_STOCK_CANARY?: string;
}, identity: { principal: string; agent: string }, subjectId: string, profile?: "assigned_stock_client"): void {
  if (env.EVENT_ENABLED !== "true" || env.EVENT_MANUAL_ENABLED !== "true")
    throw new EventApiError("manual_disabled", 409);
  if (profile === "assigned_stock_client") requireAssignedStockProfile(env, identity);
  else requireNativeAdmissionCanary(env, identity);
  try {
    const scope = ManualCanarySchema.parse(parseApiJson(env.EVENT_MANUAL_CANARY ?? ""));
    const admitted = "subjectId" in scope ? scope.subjectId === subjectId : scope.subjectIds.includes(subjectId);
    if (admitted && Date.now() < Date.parse(scope.expiresAt)) return;
  } catch { /* Invalid or expired scope never grants manual publication. */ }
  throw new EventApiError("manual_disabled", 409);
}

export function manualPublicationResult(delivery: { state: string; reason: string | null } | null, deliveryId: string): { deliveryId: string } {
  if (!delivery) throw new EventApiError("unavailable", 503);
  if (delivery.state === "failed" || delivery.state === "expired") {
    if (delivery.reason === "capacity" || delivery.reason === "denied") throw new Error(delivery.reason);
    if (delivery.reason === "destination_expired" || delivery.reason === "transport_retry_horizon_elapsed" || !delivery.reason)
      throw new Error("expired");
    throw new EventApiError(delivery.reason, 409);
  }
  return { deliveryId };
}
