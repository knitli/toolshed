import { InitialReconciliationObligationSchema, type InitialReconciliationObligation } from './reconciliation-internal';
import { GitHubConversionManifestStore, ConversionManifestFenceSchema, type ConversionManifestFence, type HeldConversionManifest } from './conversion-manifest-store';
import { EVENT_POLICY_V1 } from '../policy';
import { WatchPromotionRequestSchema, type WatchPromotionRequest } from './watch-control-internal';
import { INITIAL_RECONCILIATION_PLAN_LIMITS as PLAN_LIMITS, InitialReconciliationPlanRecordSchema,
  planInitialReconciliation, type InitialReconciliationPlan, type InitialReconciliationPlanRecord } from './reconciliation-planner';

/** Valid plans remain charged by their original job. Unexpected orphan rows add a
 * conservative charge; SQL errors propagate rather than turning custody into capacity.
 */
export function initialReconciliationPlanOrphanCharge(sql: SqlStorage): number {
  if (!sql.exec("SELECT 1 FROM sqlite_master WHERE name='github_initial_reconciliation_plans'").toArray().length) return 0;
  if (!sql.exec("SELECT 1 FROM sqlite_master WHERE name='github_initial_reconciliations'").toArray().length)
    return sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_initial_reconciliation_plans').one().n;
  return sql.exec<{ n: number }>(`SELECT count(*) AS n FROM github_initial_reconciliation_plans p
    LEFT JOIN github_initial_reconciliations j ON j.operation_id=p.operation_id WHERE j.operation_id IS NULL`).one().n;
}

type CustodyRow = { obligation: string; fence: string; state: string; digest: string | null };
const equal = (left: unknown, right: unknown) => JSON.stringify(left) === JSON.stringify(right);

export interface InitialReconciliationJob { operationId: string; obligation: InitialReconciliationObligation;
  fence: ConversionManifestFence; claim: string; attempts: number }
/** Shares coordinator pending capacity; held/quarantined custody remains charged until future explicit disposition. */
export class InitialReconciliationStore {
  constructor(private readonly storage: DurableObjectStorage) {
    storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_initial_reconciliations(operation_id TEXT PRIMARY KEY,
      obligation TEXT NOT NULL,fence TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ('pending','held','quarantined')),
      due_at INTEGER NOT NULL,claim TEXT,attempts INTEGER NOT NULL,digest TEXT)`);
    storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_initial_activation_intents(operation_id TEXT PRIMARY KEY,
      promotion TEXT NOT NULL,fence TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ('reserved','quarantined')))`);
    storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_initial_reconciliation_plans(operation_id TEXT PRIMARY KEY,value TEXT NOT NULL)`);
  }
  charged(): number {
    const preparations = this.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE name='github_initial_watch_preparations'").toArray().length
      ? this.storage.sql.exec<{ n: number }>("SELECT count(*) AS n FROM github_initial_watch_preparations WHERE phase!='refused'").one().n : 0;
    return preparations + initialReconciliationPlanOrphanCharge(this.storage.sql) + this.storage.sql.exec<{ n: number }>(`SELECT
    (SELECT count(*) FROM github_initial_reconciliations)+(SELECT count(*) FROM github_initial_activation_intents) AS n`).one().n; }
  private requireCapacity(replacingIntent = false): void {
    const deliveries = this.storage.sql.exec<{ n: number }>("SELECT count(*) AS n FROM deliveries WHERE state IN ('pending','submitted','ambiguous')").one().n;
    if (this.charged() + deliveries - Number(replacingIntent) >= EVENT_POLICY_V1.maxPendingDeliveriesPerAgent) throw new Error('capacity');
  }
  reserveActivation(input: WatchPromotionRequest, fence: ConversionManifestFence, now: number): void {
    const promotion = WatchPromotionRequestSchema.parse(input), parsed = ConversionManifestFenceSchema.parse(fence);
    const request = JSON.stringify(promotion), bound = JSON.stringify(parsed), id = promotion.token.operationId;
    if (promotion.initialReconciliation !== true || JSON.stringify(promotion.token) !== JSON.stringify(parsed.token)
      || new TextEncoder().encode(request + bound).length > 8192) throw new Error('github_source_conflict');
    this.storage.transactionSync(() => {
      if (!new GitHubConversionManifestStore(this.storage).reservation(id, parsed)) throw new Error('github_source_conflict');
      const existing = this.storage.sql.exec<{ promotion: string; fence: string; state: string }>(
        'SELECT promotion,fence,state FROM github_initial_activation_intents WHERE operation_id=?', id).toArray()[0];
      if (existing) {
        if (existing.promotion !== request || existing.fence !== bound || existing.state !== 'reserved') throw new Error('github_source_conflict');
        return;
      }
      const known = this.storage.sql.exec<{ fence: string; state: string }>('SELECT fence,state FROM github_initial_reconciliations WHERE operation_id=?', id).toArray()[0];
      if (known) { if (known.fence !== bound || known.state !== 'pending') throw new Error('github_source_conflict'); return; }
      this.requireCapacity();
      this.storage.sql.exec('INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(11,?)', now);
      this.storage.sql.exec("INSERT INTO github_initial_activation_intents VALUES(?,?,?,'reserved')", id, request, bound);
    });
  }
  pendingActivations(): { operationId: string; fence: ConversionManifestFence }[] {
    const result: { operationId: string; fence: ConversionManifestFence }[] = [];
    for (const row of this.storage.sql.exec<{ operation_id: string; promotion: string; fence: string }>(
      "SELECT operation_id,promotion,fence FROM github_initial_activation_intents WHERE state='reserved'").toArray()) {
      try {
        if (row.promotion.length + row.fence.length > 8192 || new TextEncoder().encode(row.promotion + row.fence).length > 8192) throw new Error('invalid');
        const input = WatchPromotionRequestSchema.parse(JSON.parse(row.promotion)), fence = ConversionManifestFenceSchema.parse(JSON.parse(row.fence));
        if (input.initialReconciliation !== true || input.token.operationId !== row.operation_id
          || JSON.stringify(input.token) !== JSON.stringify(fence.token)) throw new Error('invalid');
        if (!new GitHubConversionManifestStore(this.storage).reservation(row.operation_id, fence)) throw new Error('invalid');
        result.push({ operationId: row.operation_id, fence });
      } catch { this.quarantineActivation(row.operation_id); }
    }
    return result;
  }
  quarantineActivation(operationId: string): void {
    this.storage.sql.exec("UPDATE github_initial_activation_intents SET state='quarantined' WHERE operation_id=?", operationId);
    this.storage.sql.exec("UPDATE github_initial_reconciliations SET state='quarantined',claim=NULL WHERE operation_id=? AND state='pending'", operationId);
  }
  enqueue(obligation: InitialReconciliationObligation, fence: ConversionManifestFence, now: number, quarantined = false): void {
    const parsed = InitialReconciliationObligationSchema.parse(obligation), id = parsed.operationId;
    const parsedFence = ConversionManifestFenceSchema.parse(fence);
    const serialized = JSON.stringify(parsed), bound = JSON.stringify(parsedFence);
    if (JSON.stringify(parsed.token) !== JSON.stringify(parsedFence.token) || new TextEncoder().encode(serialized + bound).length > 8192) throw new Error('github_source_conflict');
    this.storage.transactionSync(() => {
      const existing = this.storage.sql.exec<{ obligation: string; fence: string }>('SELECT obligation,fence FROM github_initial_reconciliations WHERE operation_id=?', id).toArray()[0];
      if (existing) {
        if (existing.obligation !== serialized || existing.fence !== bound) throw new Error('github_source_conflict');
        if (quarantined) this.quarantineActivation(id);
        return;
      }
      if (!new GitHubConversionManifestStore(this.storage).reservation(id, parsedFence)) throw new Error('github_source_conflict');
      const intent = this.storage.sql.exec<{ fence: string; state: string }>('SELECT fence,state FROM github_initial_activation_intents WHERE operation_id=?', id).toArray()[0];
      if (intent && intent.fence !== bound) throw new Error('github_source_conflict');
      this.requireCapacity(!!intent);
      this.storage.sql.exec('INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(11,?)', now);
      this.storage.sql.exec('INSERT INTO github_initial_reconciliations VALUES(?,?,?,?,?,NULL,0,NULL)',
        id, serialized, bound, quarantined || intent?.state === 'quarantined' ? 'quarantined' : 'pending', now);
      this.storage.sql.exec('DELETE FROM github_initial_activation_intents WHERE operation_id=?', id);
    });
  }
  claim(now: number): InitialReconciliationJob | null {
    return this.storage.transactionSync(() => {
      const row = this.storage.sql.exec<{ operation_id: string; obligation: string; fence: string; attempts: number }>(
        "SELECT operation_id,obligation,fence,attempts FROM github_initial_reconciliations WHERE state='pending' AND due_at<=? ORDER BY due_at,operation_id LIMIT 1", now).toArray()[0];
      if (!row) return null;
      let obligation: InitialReconciliationObligation, fence: ConversionManifestFence;
      try {
        if (typeof row.obligation !== 'string' || typeof row.fence !== 'string'
          || row.obligation.length + row.fence.length > 8192
          || new TextEncoder().encode(row.obligation + row.fence).length > 8192) throw new Error('invalid');
        obligation = InitialReconciliationObligationSchema.parse(JSON.parse(row.obligation));
        fence = ConversionManifestFenceSchema.parse(JSON.parse(row.fence));
        if (!new GitHubConversionManifestStore(this.storage).reservation(row.operation_id, fence)) throw new Error('invalid');
        if (obligation.operationId !== row.operation_id || JSON.stringify(obligation.token) !== JSON.stringify(fence.token)
          || !Number.isSafeInteger(row.attempts) || row.attempts < 0 || row.attempts >= Number.MAX_SAFE_INTEGER) throw new Error('invalid');
      } catch {
        this.storage.sql.exec("UPDATE github_initial_reconciliations SET state='quarantined',claim=NULL WHERE operation_id=?", row.operation_id);
        return null;
      }
      const claim = crypto.randomUUID();
      this.storage.sql.exec('UPDATE github_initial_reconciliations SET claim=?,due_at=?,attempts=attempts+1 WHERE operation_id=?', claim, now + 30_000, row.operation_id);
      return { operationId: row.operation_id, obligation, fence, claim, attempts: row.attempts + 1 };
    });
  }
  current(job: InitialReconciliationJob): boolean {
    return !!this.storage.sql.exec("SELECT 1 FROM github_initial_reconciliations WHERE operation_id=? AND claim=? AND state='pending' AND due_at>? AND obligation=? AND fence=?", job.operationId, job.claim, Date.now(), JSON.stringify(job.obligation), JSON.stringify(job.fence)).toArray()[0];
  }
  hold(job: InitialReconciliationJob, manifest: HeldConversionManifest): void {
    if (!this.current(job) || manifest.operationId !== job.operationId) throw new Error('github_source_conflict');
    this.storage.sql.exec("UPDATE github_initial_reconciliations SET state='held',digest=?,claim=NULL WHERE operation_id=?", manifest.digest, job.operationId);
  }
  /** Called synchronously inside retain()'s already hashed manifest transaction.
   * Persist only a bounded child; the original job and all source custody stay charged.
   */
  holdAndPlan(job: InitialReconciliationJob, manifest: HeldConversionManifest): InitialReconciliationPlanRecord {
    const plan = planInitialReconciliation(job.obligation, manifest), value = JSON.stringify(plan.record);
    if (job.operationId !== manifest.operationId || !equal(job.fence, manifest.fence)
      || new TextEncoder().encode(job.operationId + value).length > PLAN_LIMITS.rowBytes) throw new Error('github_source_conflict');
    return this.storage.transactionSync(() => {
      if (!this.persistedManifestMatches(manifest)) throw new Error('github_source_conflict');
      const custody = this.custody(job.operationId);
      if (!custody || custody.obligation !== JSON.stringify(job.obligation) || custody.fence !== JSON.stringify(job.fence))
        throw new Error('github_source_conflict');
      const prior = this.planValue(job.operationId);
      if (prior !== null) {
        if (prior !== value || custody.state !== 'held' || custody.digest !== manifest.digest) throw new Error('github_source_conflict');
        return plan.record;
      }
      if (!this.current(job)) throw new Error('github_source_conflict');
      const used = this.storage.sql.exec<{ n: number; bytes: number }>(`SELECT count(*) AS n,
        coalesce(sum(length(CAST(operation_id AS BLOB))+length(CAST(value AS BLOB))),0) AS bytes
        FROM github_initial_reconciliation_plans`).one();
      if (used.n >= PLAN_LIMITS.rows || used.bytes + new TextEncoder().encode(job.operationId + value).length > PLAN_LIMITS.bytes)
        throw new Error('capacity');
      this.storage.sql.exec('INSERT INTO github_initial_reconciliation_plans VALUES(?,?)', job.operationId, value);
      this.hold(job, manifest);
      return plan.record;
    });
  }
  /** Descriptive read only. Rehash the immutable manifest, then recheck the exact
   * plan/custody snapshot after that await; this never establishes current authority.
   */
  async readPlan(operationId: string, fence: ConversionManifestFence, onValidated?: (isCurrent: () => boolean) => void): Promise<InitialReconciliationPlan | { status: 'unavailable' }> {
    const parsedFence = ConversionManifestFenceSchema.safeParse(fence);
    if (!parsedFence.success) return { status: 'unavailable' };
    const value = this.planValue(operationId), custody = this.custody(operationId);
    const custodyBytes = JSON.stringify(this.storage.sql.exec('SELECT * FROM github_initial_reconciliations WHERE operation_id=?', operationId).toArray());
    if (value === null || !custody || custody.state !== 'held' || custody.fence !== JSON.stringify(parsedFence.data)
      || new TextEncoder().encode(operationId + value).length > PLAN_LIMITS.rowBytes) return { status: 'unavailable' };
    try {
      const record = InitialReconciliationPlanRecordSchema.parse(JSON.parse(value));
      if (record.operationId !== operationId || record.manifestDigest !== custody.digest) return { status: 'unavailable' };
      const manifest = await new GitHubConversionManifestStore(this.storage).read(operationId, fence);
      if (manifest.status !== 'held') return { status: 'unavailable' };
      const plan = planInitialReconciliation(InitialReconciliationObligationSchema.parse(JSON.parse(custody.obligation)), manifest);
      if (!equal(plan.record, record) || this.planValue(operationId) !== value || !equal(this.custody(operationId), custody)
        || !this.persistedManifestMatches(manifest)) return { status: 'unavailable' };
      // Preserve the exact verified bytes across later RPC/authentication awaits.
      const current = () => this.planValue(operationId) === value
        && JSON.stringify(this.storage.sql.exec('SELECT * FROM github_initial_reconciliations WHERE operation_id=?', operationId).toArray()) === custodyBytes
        && this.persistedManifestMatches(manifest);
      if (!current()) return { status: 'unavailable' };
      onValidated?.(current);
      return plan;
    } catch { return { status: 'unavailable' }; }
  }
  private planValue(operationId: string): string | null {
    return this.storage.sql.exec<{ value: string }>('SELECT value FROM github_initial_reconciliation_plans WHERE operation_id=?', operationId).toArray()[0]?.value ?? null;
  }
  private custody(operationId: string): CustodyRow | null {
    return this.storage.sql.exec<CustodyRow>('SELECT obligation,fence,state,digest FROM github_initial_reconciliations WHERE operation_id=?', operationId).toArray()[0] ?? null;
  }
  private persistedManifestMatches(manifest: HeldConversionManifest): boolean {
    const { pages, digest, ...header } = manifest;
    const row = this.storage.sql.exec<{ header: string; digest: string }>(
      'SELECT header,digest FROM github_conversion_manifests WHERE operation_id=?', manifest.operationId).toArray()[0];
    if (!row || row.header !== JSON.stringify(header) || row.digest !== digest) return false;
    const stored = this.storage.sql.exec<{ page_index: number; value: string }>(
      'SELECT page_index,value FROM github_conversion_manifest_pages WHERE operation_id=? ORDER BY page_index', manifest.operationId).toArray();
    return stored.length === pages.length && stored.every((entry, index) => entry.page_index === index && entry.value === JSON.stringify(pages[index]));
  }
  quarantine(job: InitialReconciliationJob): void {
    this.storage.sql.exec("UPDATE github_initial_reconciliations SET state='quarantined',claim=NULL WHERE operation_id=? AND claim=? AND state='pending'", job.operationId, job.claim);
  }
  retry(job: InitialReconciliationJob, dueAt: number): void {
    this.storage.sql.exec("UPDATE github_initial_reconciliations SET due_at=?,claim=NULL WHERE operation_id=? AND claim=? AND state='pending'", dueAt, job.operationId, job.claim);
  }
  defer(at: number): void { this.storage.sql.exec("UPDATE github_initial_reconciliations SET due_at=? WHERE state='pending' AND due_at<?", at, at); }
  nextAt(): number | null { return this.storage.sql.exec<{ at: number | null }>("SELECT min(due_at) AS at FROM github_initial_reconciliations WHERE state='pending'").one().at; }
}
