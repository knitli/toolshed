import { GitHubConversionManifestStore } from './conversion-manifest-store';
import { InitialWatchPreparationStore, InitialWatchPreparationSchema, InitialWatchPreparationReceiptSchema, type InitialWatchPreparation, type InitialWatchPreparationRow } from './initial-watch-preparation';
import { InitialReconciliationStore } from './reconciliation-store';
import { z } from 'zod';
import type { AccessPorts } from 'openapi-operator/src/access.ts';
import { AccessDenied, AccessUnavailable } from 'openapi-operator/src/access.ts';
import type { EventAdminCall } from '../admin-types';
import { EventApiError, type EventApiEnvironment } from '../contracts';
import { EventRequestDeadline } from '../request-deadline';
import { requireNativeAdmissionCanary } from '../native-admission-gate';
import { NativeRuntimeStore } from '../native-runtime-store';
import { NativeRuntimeBindingSchema } from '../native-admission-contract';
import { ownerRegistryName, type NodeAuthorization } from '../registry';
import { GitHubGrantStore } from './grants';
import { GitHubSourceControlStore, sourceTokenEquals } from './source-control';
import { GitHubWatchPromotionCheckpointSchema, githubHostName, type GitHubAttentionHost } from './host';
import { WatchOwnerProofVerifier, type WatchOwnerEnvironment } from './watch-owner-proof';
import { GitHubWatchControlStore } from './watch-store';
import { WatchRequestSchema, WatchActivateTokenSchema, WatchStopTokenSchema, WatchOutcomeSchema,
  WATCH_CONTROL_LIMITS, watchJson, type WatchOutcome, type CreateWatchRequest, type WatchHolder,
  type WatchRequest, type WatchControlToken } from './watch-control-internal';

export function watchCoordinatorIdentity(state: DurableObjectState): { principal: string; agent: string } {
  let raw: unknown;
  try { raw = JSON.parse(state.id.name ?? 'null'); } catch { throw new Error('github_denied'); }
  const parsed = z.tuple([z.literal('event-agent-v1'), z.string().email().max(254).refine(value => value === value.toLowerCase()),
    z.string().regex(/^[a-z0-9-]{1,32}$/)]).safeParse(raw);
  if (!parsed.success || JSON.stringify(parsed.data) !== state.id.name) throw new Error('github_denied');
  return { principal: parsed.data[1], agent: parsed.data[2] };
}
function sourceEpoch(raw: string | undefined): number | null {
  if (!raw || !/^[1-9][0-9]*$/.test(raw)) return null;
  const value = Number(raw); return Number.isSafeInteger(value) ? value : null;
}
function next(value: number): number {
  if (!Number.isSafeInteger(value) || value < 1 || value >= Number.MAX_SAFE_INTEGER) throw new Error('github_watch_conflict');
  return value + 1;
}
function errorOutcome(error: unknown): WatchOutcome {
  if (error instanceof z.ZodError || error instanceof SyntaxError) return { status: 'error', code: 'invalid' };
  if (error instanceof AccessDenied) return { status: 'error', code: 'denied' };
  if (error instanceof AccessUnavailable) return { status: 'error', code: 'unavailable' };
  if (error instanceof EventApiError && error.code === 'unsupported') return { status: 'error', code: 'unsupported' };
  if (error instanceof EventApiError) return { status: 'error', code: error.status === 403 ? 'denied' : error.status === 503 ? 'unavailable' : error.status === 400 ? 'invalid' : 'conflict' };
  const reason = error instanceof Error ? error.message : '';
  if (/capacity/.test(reason)) return { status: 'error', code: 'capacity' };
  if (/denied/.test(reason)) return { status: 'error', code: 'denied' };
  if (/conflict|fenced/.test(reason)) return { status: 'error', code: 'conflict' };
  if (['unsupported', 'unsupported coordinator schema', 'github_watch_unsupported'].includes(reason))
    return { status: 'error', code: 'unsupported' };
  return { status: 'error', code: 'unavailable' };
}

export type WatchKernelEnvironment = WatchOwnerEnvironment & Pick<EventApiEnvironment,
  'OWNER_REGISTRY' | 'EVENT_NATIVE_BINDING_ENABLED' | 'EVENT_NATIVE_BINDING_CANARY' | 'GITHUB_SOURCE_MAP' | 'EVENT_GITHUB_WATCH_CONTROL_ENABLED'> & {
  EVENT_GITHUB_INITIAL_RECONCILIATION_ENABLED?: string;
  EVENT_ENABLED?: string; EVENT_GITHUB_ENABLED?: string; EVENT_GITHUB_SOURCE_CONTROL_ENABLED?: string;
  EVENT_GITHUB_SOURCE_GATE_EPOCH?: string; GITHUB_ATTENTION_HOST?: DurableObjectNamespace<GitHubAttentionHost>;
};

/** Internal owner RPC kernel; no public HTTP route or delivery admission. */
export class WatchControlKernel {
  readonly #identity: { principal: string; agent: string };
  readonly #store: GitHubWatchControlStore;
  readonly #owner: WatchOwnerProofVerifier;
  readonly #preparations: InitialWatchPreparationStore;
  constructor(private readonly state: DurableObjectState, private readonly env: WatchKernelEnvironment, ports?: AccessPorts) {
    this.#identity = watchCoordinatorIdentity(state);
    this.#store = new GitHubWatchControlStore(state.storage.sql, this.#identity.principal, this.#identity.agent);
    this.#owner = new WatchOwnerProofVerifier(env, ports);
    this.#preparations = new InitialWatchPreparationStore(state.storage);
  }
  async execute(call: EventAdminCall, rawRequest: string): Promise<WatchOutcome> {
    const deadline = new EventRequestDeadline();
    try {
      if (typeof rawRequest !== 'string' || rawRequest.length > WATCH_CONTROL_LIMITS.messageBytes || new TextEncoder().encode(rawRequest).byteLength > WATCH_CONTROL_LIMITS.messageBytes)
        return { status: 'error', code: 'invalid' };
      const raw: unknown = JSON.parse(rawRequest);
      if (raw && typeof raw === 'object' && 'kind' in raw && typeof raw.kind === 'string'
        && !['create', 'read', 'operation_readback', 'detach', 'unsubscribe'].includes(raw.kind)) return { status: 'error', code: 'unsupported' };
      const request = WatchRequestSchema.parse(raw);
      watchJson(request);
      const originalCall = Object.freeze({ ...call });
      const proof = await this.#owner.requireOwner(originalCall, this.#identity, request.kind, deadline);
      this.#owner.assertCurrent(proof);
      if (request.kind === 'read') {
        const watch = this.#store.read(request.input.subject);
        return this.#checked(watch ? { status: 'present', watch, attachmentStatus: watch.attachment === null ? 'none'
          : watch.attachment.leaseUntil > Date.now() ? 'live' : 'expired' } : { status: 'absent' });
      }
      if (request.kind === 'operation_readback' || request.kind === 'create') {
        const prepared = this.#preparations.get(request.input.operationId);
        if (prepared) {
          if (JSON.stringify(prepared.input.request.subject) !== JSON.stringify(request.input.subject)
            || request.kind === 'create' && JSON.stringify(prepared.input.request) !== JSON.stringify(request.input)) throw new Error('github_operation_conflict');
          if (request.kind === 'create') await this.#resumePreparation(prepared);
          const completed = this.#store.exactOperation(request.input.operationId, { kind: 'create', input: prepared.input.request }, Date.now());
          return this.#checked(completed ?? { status: 'unresolved', operationId: request.input.operationId });
        }
      }
      if (request.kind === 'operation_readback') return this.#checked(this.#store.operation(request.input.subject, request.input.operationId, Date.now()));
      const replay = this.#store.exactOperation(request.input.operationId, request, Date.now());
      if (replay) return this.#checked(replay);
      if (request.kind === 'create') return await this.#create(originalCall, request, deadline);
      // Cleanup is owner/CAS authorized even when the node, runtime, grant or admission gate is dead.
      const view = await this.state.storage.transaction(async () => {
        const alarm = await this.state.storage.getAlarm();
        this.#owner.assertCurrent(proof);
        const again = this.#store.exactOperation(request.input.operationId, request, Date.now());
        if (again) return again;
        const current = this.#store.authority(request.input.subject);
        if (current.status !== 'watch') throw new Error('github_watch_conflict');
        const now = Date.now();
        const result = request.kind === 'detach' ? this.#store.detach(request.input, now)
          : this.#store.retireOrJoinStop(request.input, current.token.mode === 'stopped' ? current.token : this.#stopToken(current.token, request.input.operationId), now);
        const nextAt = this.#store.nextAt(now);
        if (nextAt !== null && (alarm === null || alarm > nextAt)) await this.state.storage.setAlarm(Math.max(now + 1, nextAt));
        this.#owner.assertCurrent(proof);
        return { status: 'committed' as const, operationId: request.input.operationId, result };
      });
      return this.#checked(view);
    } catch (error) { return errorOutcome(error); }
    finally { deadline.dispose(); }
  }
  #requireCreateEnabled(): void {
    if (this.env.EVENT_GITHUB_WATCH_CONTROL_ENABLED !== 'true') throw new Error('github_denied');
  }
  #checked(outcome: WatchOutcome): WatchOutcome { const parsed = WatchOutcomeSchema.parse(outcome); watchJson(parsed); return parsed; }
  #stopToken(token: WatchControlToken, operationId: string) {
    const view = this.#store.read(token.subject);
    if (!view) throw new Error('github_watch_conflict');
    return WatchStopTokenSchema.parse({ ...token, operationId, obligationId: crypto.randomUUID(), action: 'stop', mode: 'stopped',
      routingRevision: next(view.routingRevision), lifecycleEpoch: next(token.lifecycleEpoch) });
  }
  #holderSnapshot(holder: WatchHolder) {
    const store = new NativeRuntimeStore(this.state.storage.sql), runtime = store.runtime(holder.runtimeId), binding = store.binding(holder.runtimeId);
    if (!runtime || runtime.qualified !== 1 || runtime.runtime_generation !== holder.runtimeGeneration
      || runtime.attachment_generation !== holder.attachmentGeneration || runtime.node_id !== holder.nodeId
      || runtime.node_generation !== holder.nodeGeneration || runtime.lease_until <= Date.now() || !binding
      || !binding.key_thumbprint || !/^[A-Za-z0-9_-]{43}$/.test(binding.key_thumbprint)
      || !Number.isSafeInteger(binding.nonce) || binding.nonce < 0 || !Number.isSafeInteger(binding.sequence) || binding.sequence < 1)
      throw new Error('github_denied');
    const native = NativeRuntimeBindingSchema.parse(JSON.parse(binding.binding_json));
    if (native.clientId !== binding.client_id) throw new Error('github_denied');
    return { runtime, binding };
  }
  async #create(call: Readonly<EventAdminCall>, request: Extract<WatchRequest, { kind: 'create' }>, deadline: EventRequestDeadline): Promise<WatchOutcome> {
    const input: CreateWatchRequest = request.input;
    const initialReconciliation = this.env.EVENT_GITHUB_INITIAL_RECONCILIATION_ENABLED === 'true';
    this.#requireCreateEnabled();
    requireNativeAdmissionCanary(this.env, this.#identity);
    if (this.env.EVENT_ENABLED !== 'true' || this.env.EVENT_GITHUB_ENABLED !== 'true'
      || this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED !== 'true' || !this.env.GITHUB_ATTENTION_HOST) throw new Error('github_denied');
    const sourceStore = new GitHubSourceControlStore(this.state.storage.sql, this.#identity.principal, this.#identity.agent);
    sourceStore.requireSourceOnlyOwnership(input.subject);
    const prior = sourceStore.control(input.subject);
    if (!prior || prior.state !== 'active' || sourceStore.pendingFor(input.subject)
      || prior.token.lifecycleEpoch > Number.MAX_SAFE_INTEGER - 2
      || prior.token.sourceIncarnation !== input.expectedSourceIncarnation || prior.token.lifecycleEpoch !== input.expectedLifecycleEpoch
      || prior.token.installationId !== input.source.installationId || this.#store.read(input.subject)) throw new Error('github_watch_conflict');
    const subject = { installationId: input.source.installationId, ...input.subject };
    const grants = new GitHubGrantStore(this.state.storage, this.#identity.principal, this.#identity.agent,
      () => this.env.GITHUB_SOURCE_MAP ?? '[]', () => this.env.EVENT_GITHUB_ENABLED === 'true' && this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED === 'true',
      () => sourceEpoch(this.env.EVENT_GITHUB_SOURCE_GATE_EPOCH));
    const sourceSnapshot = (inTransaction = false) => {
      const grant = grants.grant(subject), gate = inTransaction ? grants.sourceGateInTransaction(subject) : grants.sourceGate(subject);
      if (!grant || !gate.enabled || gate.deploymentEpoch === null || grant.revision !== input.source.grantRevision
        || grant.mappingRevision !== input.source.mappingRevision || grant.policyRevision !== input.source.policyRevision
        || gate.generation !== prior.token.sourceEnableGeneration || grant.revision !== prior.token.grantRevision
        || grant.mappingRevision !== prior.token.mappingRevision || grant.policyRevision !== prior.token.policyRevision)
        throw new Error('github_watch_conflict');
      return { grant, gate };
    };
    const source = sourceSnapshot(), sourceJson = JSON.stringify(source), holder = this.#holderSnapshot(input.holder), holderJson = JSON.stringify(holder);
    const identity = { ...this.#identity, subject };
    const checkpoint = GitHubWatchPromotionCheckpointSchema.parse(await deadline.run(() =>
      this.env.GITHUB_ATTENTION_HOST!.getByName(githubHostName(identity)).watchPromotionCheckpoint(identity), 20_000));
    // Initial custody requires a complete first observation before coordinator ownership changes.
    // Leave source-only polling and the caller's operation ID available for exact retry.
    if (initialReconciliation
      && checkpoint.sourceStatus.status !== 'absent' && checkpoint.sourceStatus.sourceVersion === 0)
      throw new Error('github_source_unavailable');
    if (checkpoint.sourceStatus.status === 'absent' || checkpoint.sourceStatus.hostControl !== 'active'
      || Math.max(checkpoint.snapshotEpoch, checkpoint.sourceStatus.hostEpoch, checkpoint.sourceRpcGeneration) > Number.MAX_SAFE_INTEGER - 2)
      throw new Error('github_watch_conflict');
    const node = await deadline.run<NodeAuthorization>(() => Promise.resolve(this.env.OWNER_REGISTRY.getByName(ownerRegistryName(this.#identity.principal))
      .currentNode({ nodeId: input.holder.nodeId, agent: this.#identity.agent, generation: input.holder.nodeGeneration })), 5000);
    if (node.status !== 'authorized' || node.node.nodeId !== input.holder.nodeId || node.node.generation !== input.holder.nodeGeneration
      || !node.node.agents.includes(this.#identity.agent)) throw new Error('github_denied');
    const proof = await this.#owner.requireOwner(call, this.#identity, 'create', deadline);
    const finalNode = await deadline.run<NodeAuthorization>(() => Promise.resolve(this.env.OWNER_REGISTRY.getByName(ownerRegistryName(this.#identity.principal))
      .currentNode({ nodeId: input.holder.nodeId, agent: this.#identity.agent, generation: input.holder.nodeGeneration })), 5000);
    if (finalNode.status !== 'authorized' || JSON.stringify(finalNode.node) !== JSON.stringify(node.node)) throw new Error('github_denied');
    this.#owner.assertCurrent(proof);
    const token = WatchActivateTokenSchema.parse({ ...prior.token, operationId: input.operationId, obligationId: crypto.randomUUID(),
      watchIncarnation: 1, routingRevision: 1, lifecycleEpoch: next(prior.token.lifecycleEpoch), action: 'activate', mode: 'watch' });
    const promotion = { predecessor: { operationId: prior.token.operationId, obligationId: prior.token.obligationId, lifecycleEpoch: prior.token.lifecycleEpoch },
      token, expectedSourceVersion: checkpoint.sourceStatus.sourceVersion, expectedHostEpoch: checkpoint.sourceStatus.hostEpoch };
    watchJson(promotion);
    if (initialReconciliation) {
      const preparation = { request: input, predecessor: prior.token,
        promotion: { ...promotion, initialReconciliation: true }, fence: { token, holder: input.holder, leaseRevision: 1 },
        leaseUntil: Math.min(Date.now() + input.leaseMs, holder.runtime.lease_until), preparationGeneration: checkpoint.preparationGeneration };
      await this.state.storage.transaction(async () => {
        const alarm = await this.state.storage.getAlarm();
        this.#owner.assertCurrent(proof);
        if (JSON.stringify(sourceSnapshot(true)) !== sourceJson || JSON.stringify(this.#holderSnapshot(input.holder)) !== holderJson)
          throw new Error('github_watch_conflict');
        this.#store.assertOperationUnused(input.operationId);
        const reservation = new GitHubConversionManifestStore(this.state.storage).reserve(input.operationId, preparation.fence, preparation.preparationGeneration);
        const prepared = InitialWatchPreparationSchema.parse({ ...preparation, manifestBytes: reservation.manifestBytes });
        this.#assertPreparationCurrent(prepared);
        this.#preparations.reserve(prepared, Date.now());
        if (alarm === null || alarm > Date.now() + 1) await this.state.storage.setAlarm(Date.now() + 1);
        this.#owner.assertCurrent(proof);
      });
      await this.#resumePreparation(this.#preparations.get(input.operationId)!);
      return this.#checked(this.#store.exactOperation(input.operationId, request, Date.now())
        ?? { status: 'unresolved', operationId: input.operationId });
    }
    const result = await this.state.storage.transaction(async () => {
      const alarm = await this.state.storage.getAlarm();
      this.#owner.assertCurrent(proof);
      const again = this.#store.exactOperation(input.operationId, request, Date.now());
      if (again) return again;
      this.#requireCreateEnabled();
      requireNativeAdmissionCanary(this.env, this.#identity);
      sourceStore.requireSourceOnlyOwnership(input.subject);
      const current = sourceStore.control(input.subject);
      if (!current || current.state !== 'active' || !sourceTokenEquals(current.token, prior.token) || sourceStore.pendingFor(input.subject)
        || JSON.stringify(sourceSnapshot(true)) !== sourceJson || JSON.stringify(this.#holderSnapshot(input.holder)) !== holderJson)
        throw new Error('github_watch_conflict');
      if ((this.env.EVENT_GITHUB_INITIAL_RECONCILIATION_ENABLED === 'true') !== initialReconciliation) throw new Error('github_source_conflict');
      const now = Date.now(), leaseUntil = Math.min(now + input.leaseMs, holder.runtime.lease_until);
      const view = this.#store.promote({ request: input, predecessor: prior.token, token, leaseUntil,
        expectedSourceVersion: checkpoint.sourceStatus.sourceVersion, expectedHostEpoch: checkpoint.sourceStatus.hostEpoch, now,
        ...(initialReconciliation ? { initialReconciliation: true as const } : {}) });
      const nextAt = this.#store.nextAt(now);
      if (nextAt !== null && (alarm === null || alarm > nextAt)) await this.state.storage.setAlarm(Math.max(now + 1, nextAt));
      this.#requireCreateEnabled();
      this.#owner.assertCurrent(proof);
      requireNativeAdmissionCanary(this.env, this.#identity);
      if (JSON.stringify(sourceSnapshot(true)) !== sourceJson || JSON.stringify(this.#holderSnapshot(input.holder)) !== holderJson)
        throw new Error('github_watch_conflict');
      return { status: 'committed' as const, operationId: input.operationId, result: view };
    });
    return this.#checked(result);
  }
  #assertPreparationCurrent(input: InitialWatchPreparation): void {
    this.#requireCreateEnabled(); requireNativeAdmissionCanary(this.env, this.#identity);
    if (input.promotion.token.principal !== this.#identity.principal || input.promotion.token.agent !== this.#identity.agent
      || this.env.EVENT_GITHUB_INITIAL_RECONCILIATION_ENABLED !== 'true' || this.env.EVENT_ENABLED !== 'true'
      || this.env.EVENT_GITHUB_ENABLED !== 'true' || this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED !== 'true'
      || input.leaseUntil <= Date.now()) throw new Error('github_source_conflict');
    const sources = new GitHubSourceControlStore(this.state.storage.sql, this.#identity.principal, this.#identity.agent);
    sources.requireSourceOnlyOwnership(input.request.subject);
    const control = sources.control(input.request.subject);
    if (!control || control.state !== 'active' || !sourceTokenEquals(control.token, input.predecessor)
      || sources.pendingFor(input.request.subject) || this.#store.read(input.request.subject)) throw new Error('github_source_conflict');
    const grants = new GitHubGrantStore(this.state.storage, this.#identity.principal, this.#identity.agent,
      () => this.env.GITHUB_SOURCE_MAP ?? '[]', () => this.env.EVENT_GITHUB_ENABLED === 'true' && this.env.EVENT_GITHUB_SOURCE_CONTROL_ENABLED === 'true',
      () => sourceEpoch(this.env.EVENT_GITHUB_SOURCE_GATE_EPOCH));
    const subject = { installationId: input.predecessor.installationId, ...input.request.subject };
    const grant = grants.grant(subject), gate = grants.sourceGateInTransaction(subject), token = input.predecessor;
    if (!grant || !gate.enabled || gate.deploymentEpoch === null || gate.generation !== token.sourceEnableGeneration
      || grant.revision !== token.grantRevision || grant.mappingRevision !== token.mappingRevision
      || grant.policyRevision !== token.policyRevision) throw new Error('github_source_conflict');
    this.#holderSnapshot(input.request.holder);
  }
  canonicalPreparation(raw: InitialWatchPreparation): InitialWatchPreparationRow | null {
    const input = InitialWatchPreparationSchema.parse(raw), row = this.#preparations.get(input.request.operationId);
    if (input.promotion.token.principal !== this.#identity.principal || input.promotion.token.agent !== this.#identity.agent
      || !row || JSON.stringify(row.input) !== JSON.stringify(input)) return null;
    const reservation = new GitHubConversionManifestStore(this.state.storage).reservation(input.request.operationId, input.fence);
    if (row.phase !== 'refused' && (!reservation || reservation.manifestBytes !== input.manifestBytes
      || reservation.preparationGeneration !== input.preparationGeneration)) return null;
    if (row.phase === 'preparing') {
      try { this.#assertPreparationCurrent(input); } catch { return null; }
    }
    return row;
  }
  async drainPreparations(): Promise<void> {
    for (const row of this.#preparations.pending(Date.now()).slice(0, 10)) await this.#resumePreparation(row);
  }
  async #resumePreparation(old: InitialWatchPreparationRow): Promise<void> {
    const input = old.input, id = input.request.operationId;
    const namespace = this.env.GITHUB_ATTENTION_HOST;
    const deadline = new EventRequestDeadline();
    try {
      if (!namespace) throw new Error('github_source_unavailable');
      const host = namespace.getByName(githubHostName({ ...this.#identity,
        subject: { installationId: input.predecessor.installationId, ...input.request.subject } }));
      let row = this.#preparations.get(id);
      if (!row || row.phase === 'refused' || row.phase === 'quarantined' && row.acknowledgedAt !== null) return;
      const reservation = new GitHubConversionManifestStore(this.state.storage).reservation(id, input.fence);
      if (!reservation || reservation.manifestBytes !== input.manifestBytes || reservation.preparationGeneration !== input.preparationGeneration) {
        this.#preparations.quarantine(id, Date.now()); return;
      }
      if (row.phase === 'preparing') {
        try { this.#assertPreparationCurrent(input); }
        catch { this.#preparations.beginAbort(id, Date.now()); }
        row = this.#preparations.get(id)!;
      }
      if (row.phase === 'preparing') {
        const receipt = InitialWatchPreparationReceiptSchema.parse(await deadline.run<unknown>(() => Promise.resolve(host.prepareInitialWatch(input)), 20_000));
        this.state.storage.transactionSync(() => {
          const current = this.#preparations.get(id);
          if (!current || current.phase !== 'preparing') throw new Error('github_source_conflict');
          if (receipt.status === 'prepared') this.#preparations.recordPrepared(id, receipt, Date.now());
          else if (receipt.effect === 'none') this.#preparations.recordRefused(id, receipt, Date.now());
          else throw new Error('github_source_conflict');
        });
        if (receipt.status === 'prepared') {
          const holder = input.request.holder;
          const node = await deadline.run<NodeAuthorization>(() => Promise.resolve(this.env.OWNER_REGISTRY.getByName(ownerRegistryName(this.#identity.principal))
            .currentNode({ nodeId: holder.nodeId, agent: this.#identity.agent, generation: holder.nodeGeneration })), 5000);
          if (node.status !== 'authorized' || node.node.nodeId !== holder.nodeId || node.node.generation !== holder.nodeGeneration
            || !node.node.agents.includes(this.#identity.agent)) {
            this.#preparations.beginAbort(id, Date.now());
          } else {
            this.state.storage.transactionSync(() => {
              this.#assertPreparationCurrent(input);
              this.#preparations.transfer(id, () => {
              const initial = new InitialReconciliationStore(this.state.storage);
              this.#store.promote({ request: input.request, predecessor: input.predecessor, token: input.promotion.token,
                expectedSourceVersion: input.promotion.expectedSourceVersion, expectedHostEpoch: input.promotion.expectedHostEpoch,
                leaseUntil: input.leaseUntil, now: Date.now(), initialReconciliation: true });
              initial.reserveActivation(input.promotion, input.fence, Date.now());
              });
            });
            return;
          }
        }
        row = this.#preparations.get(id)!;
      }
      if (row.phase === 'aborting' || row.phase === 'quarantined') {
        const receipt = InitialWatchPreparationReceiptSchema.parse(await deadline.run<unknown>(() => Promise.resolve(host.abortInitialWatch(input)), 20_000));
        this.state.storage.transactionSync(() => {
          if (receipt.status === 'refused') this.#preparations.recordRefused(id, receipt, Date.now());
          else this.#preparations.recordAborted(id, receipt, Date.now());
        });
        row = this.#preparations.get(id)!;
      }
      if (row.phase === 'refused_ack' && row.receipt) {
        await deadline.run(() => host.acknowledgeInitialWatchRefusal(input), 20_000);
        this.state.storage.transactionSync(() => this.#preparations.acknowledgeRefusal(id, row!.receipt!, Date.now()));
      }
    } catch {
      this.#preparations.retry(id, Date.now() + 20_000);
    } finally {
      deadline.dispose();
      const nextAt = this.#preparations.nextAt(), watchAt = this.#store.nextAt(Date.now());
      const due = [nextAt, watchAt].filter((v): v is number => v !== null);
      if (due.length) {
        const target = Math.max(Date.now() + 1, Math.min(...due)), alarm = await this.state.storage.getAlarm();
        if (alarm === null || alarm > target) await this.state.storage.setAlarm(target);
      }
    }
  }

}
