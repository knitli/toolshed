import { z } from 'zod';
import { GitHubSourceControlTokenSchema, type GitHubSourceControlToken } from './source-control';
import { GITHUB_SOURCE_REFERENCE_LIMITS as L, SourceReferenceActorSchema, SourceReferenceIssueRequestSchema, SourceReferenceIssuedSchema,
  type SourceReferenceActor, type SourceReferenceIssueRequest, type SourceReferenceIssueResult, type SourceReferenceIssued } from './source-reference-contract';
import type { GitHubMaterialReadResult } from './material-read-contract';

const recordSchema = z.strictObject({ request: SourceReferenceIssueRequestSchema, actor: SourceReferenceActorSchema,
  token: GitHubSourceControlTokenSchema, receipt: SourceReferenceIssuedSchema });
type Record = z.infer<typeof recordSchema>;
const equal = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);

/** Permanent bounded dedupe ledger, including expired rows. Expiry never renews an operation. */
export class GitHubSourceReferenceStore {
  // eslint-disable-next-line no-unused-vars -- The parameter property retains the Durable Object storage.
  constructor(private readonly storage: DurableObjectStorage) {
    storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_source_references(operation_id TEXT PRIMARY KEY,
      reference TEXT NOT NULL UNIQUE, value TEXT NOT NULL, bytes INTEGER NOT NULL)`);
  }
  private read(column: 'operation_id' | 'reference', value: string): Record | null {
    const row = this.storage.sql.exec<{ value: string }>(`SELECT value FROM github_source_references WHERE ${column}=?`, value).toArray()[0];
    if (!row) return null;
    const record = recordSchema.parse(JSON.parse(row.value));
    if (record.receipt.operationId !== record.request.operationId || !equal(record.receipt.material, record.request.material)) throw new Error('unavailable');
    return record;
  }
  prior(request: SourceReferenceIssueRequest, actor: SourceReferenceActor, token: GitHubSourceControlToken, now: number): SourceReferenceIssueResult | null {
    const prior = this.read('operation_id', request.operationId);
    if (!prior) return null;
    if (!equal(prior.actor, actor)) throw new Error('denied');
    if (!equal(prior.request, request) || !equal(prior.token, token)) return { status: 'conflict' };
    return prior.receipt.expiresAt <= now ? { status: 'unavailable' } : prior.receipt;
  }
  resolve(reference: string, actor: SourceReferenceActor, token: GitHubSourceControlToken, now: number): Record | { status: 'unavailable' | 'conflict' } {
    const record = this.read('reference', reference);
    if (!record) return { status: 'unavailable' };
    if (!equal(record.actor, actor)) throw new Error('denied');
    if (!equal(record.token, token)) return { status: 'conflict' };
    return record.receipt.expiresAt <= now ? { status: 'unavailable' } : record;
  }
  issue(request: SourceReferenceIssueRequest, actor: SourceReferenceActor, token: GitHubSourceControlToken,
    page: Extract<GitHubMaterialReadResult, { status: 'ok' }>, now: number): SourceReferenceIssueResult {
    return this.storage.transactionSync(() => {
      const prior = this.prior(request, actor, token, now);
      if (prior) {
        if (prior.status === 'issued' && (prior.bodyDigest !== page.bodyDigest || prior.firstVersion !== page.firstVersion || prior.totalLength !== page.totalLength)) return { status: 'conflict' };
        return prior;
      }
      const receipt: SourceReferenceIssued = { status: 'issued', operationId: request.operationId, reference: `gref_${crypto.randomUUID()}`,
        material: request.material, bodyDigest: page.bodyDigest, totalLength: page.totalLength, firstVersion: page.firstVersion, expiresAt: now + L.ttlMs };
      const value = JSON.stringify(recordSchema.parse({ request, actor, token, receipt })), bytes = new TextEncoder().encode(value).length;
      const used = this.storage.sql.exec<{ rows: number; bytes: number }>('SELECT count(*) AS rows,COALESCE(sum(bytes),0) AS bytes FROM github_source_references').one();
      if (bytes > L.rowBytes || used.rows >= L.rows || used.bytes + bytes > L.bytes) return { status: 'capacity' };
      this.storage.sql.exec('INSERT INTO github_source_references(operation_id,reference,value,bytes) VALUES(?,?,?,?)', request.operationId, receipt.reference, value, bytes);
      return receipt;
    });
  }
}
