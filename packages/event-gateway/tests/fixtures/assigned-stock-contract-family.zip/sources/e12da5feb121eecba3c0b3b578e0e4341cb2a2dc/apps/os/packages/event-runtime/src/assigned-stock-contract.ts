import { z } from "zod";

const uuid = z.uuid().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[47][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
const generation = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);
const timestamp = z.iso.datetime({ precision: 3 });

export const AssignedStockRuntimeBindingSchema = z.strictObject({
  profile: z.literal("assigned_stock_client"),
  client: z.literal("codex"),
  conversationId: uuid,
});
export type AssignedStockRuntimeBinding = z.infer<typeof AssignedStockRuntimeBindingSchema>;

export const AssignedStockRuntimeRequestSchema = z.discriminatedUnion("operation", [
  z.strictObject({ operation: z.literal("attach"), runtimeId: uuid, conversationId: uuid,
    expectedRuntimeGeneration: generation.nullable(), expectedAttachmentGeneration: generation.nullable() })
    .refine(value => (value.expectedRuntimeGeneration === null) === (value.expectedAttachmentGeneration === null)),
  z.strictObject({ operation: z.literal("renew"), runtimeId: uuid, conversationId: uuid,
    expectedRuntimeGeneration: generation, expectedAttachmentGeneration: generation }),
]);
export type AssignedStockRuntimeRequest = z.infer<typeof AssignedStockRuntimeRequestSchema>;

export const AssignedStockRuntimeResponseSchema = z.strictObject({
  status: z.enum(["attached", "renewed"]),
  runtimeProfile: AssignedStockRuntimeBindingSchema,
  runtimeId: uuid,
  runtimeGeneration: generation,
  nodeId: uuid,
  nodeGeneration: generation,
  attachmentGeneration: generation,
  leaseUntil: timestamp,
});
export type AssignedStockRuntimeResponse = z.infer<typeof AssignedStockRuntimeResponseSchema>;
