import { z } from 'zod';

export const GITHUB_MATERIAL_READ_PATH = '/v1/github/source/material';
export const GITHUB_MATERIAL_REQUEST_BYTES = 4096;
export const GITHUB_MATERIAL_RESPONSE_BYTES = 8192;
const positive = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);
const offset = z.number().int().nonnegative().max(1024 * 1024);
const digest = z.string().regex(/^[a-f0-9]{64}$/);
const subject = z.strictObject({ installationId: positive, repositoryId: positive, prNumber: positive });
const sourceId = z.string().min(1).max(4096).regex(/^(?:review:[1-9][0-9]*|comment:[1-9][0-9]*|thread-comment:.+)$/s);
const cursor = z.string().min(1).max(256).regex(/^[A-Za-z0-9_-]+$/);
const identity = { subject, sourceId, fingerprint: digest };
export const GitHubMaterialReadRequestSchema = z.strictObject({ ...identity, fromVersion: positive, toVersion: positive, cursor: cursor.optional() })
  .refine(value => value.fromVersion <= value.toVersion)
  .refine(value => new TextEncoder().encode(JSON.stringify(value)).length <= GITHUB_MATERIAL_REQUEST_BYTES);
export type GitHubMaterialReadRequest = z.infer<typeof GitHubMaterialReadRequestSchema>;
export const GitHubMaterialReadResultSchema = z.union([
  z.strictObject({ status: z.enum(['unavailable', 'deleted', 'conflict']) }),
  z.strictObject({ status: z.literal('ok'), ...identity, requestedRange: z.strictObject({ fromVersion: positive, toVersion: positive }), firstVersion: positive, bodyDigest: digest,
    offset, totalLength: offset, body: z.string().max(2048), nextCursor: cursor.nullable(), complete: z.boolean(),
  }).refine(value => value.requestedRange.fromVersion <= value.firstVersion && value.firstVersion <= value.requestedRange.toVersion
    && value.offset + value.body.length <= value.totalLength
    && value.complete === (value.nextCursor === null)
    && value.complete === (value.offset + value.body.length === value.totalLength)
    && (value.body.length > 0 || value.totalLength === 0)),
]).refine(value => new TextEncoder().encode(JSON.stringify(value)).length <= GITHUB_MATERIAL_RESPONSE_BYTES);
export type GitHubMaterialReadResult = z.infer<typeof GitHubMaterialReadResultSchema>;

/** The request identity and start offset must match even for a validly shaped downstream page. */
export function materialPageMatches(request: GitHubMaterialReadRequest, result: GitHubMaterialReadResult): boolean {
  if (result.status !== 'ok') return true;
  const previous = request.cursor === undefined ? null : parseMaterialCursor(request.cursor);
  const start = request.cursor === undefined ? 0 : previous?.offset;
  const next = result.nextCursor === null ? null : parseMaterialCursor(result.nextCursor);
  return JSON.stringify(result.subject) === JSON.stringify(request.subject) && result.sourceId === request.sourceId
    && result.fingerprint === request.fingerprint && result.requestedRange.fromVersion === request.fromVersion
    && result.requestedRange.toVersion === request.toVersion && result.offset === start
    && (result.nextCursor === null || next?.offset === result.offset + result.body.length
      && (request.cursor === undefined || next.binding === previous?.binding));
}
const cursorValue = z.strictObject({ binding: digest, offset });
export function parseMaterialCursor(value: string): z.infer<typeof cursorValue> | null {
  try {
    if (!cursor.safeParse(value).success) return null;
    const parsed = cursorValue.safeParse(JSON.parse(atob(value.replaceAll('-', '+').replaceAll('_', '/'))));
    return parsed.success ? parsed.data : null;
  } catch { return null; }
}
export const encodeMaterialCursor = (value: z.infer<typeof cursorValue>): string =>
  btoa(JSON.stringify(value)).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');
