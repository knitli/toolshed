import { z } from 'zod';
import { generation, uuid } from '../contracts';
import { GitHubMaterialReadRequestSchema, GitHubMaterialReadResultSchema, materialPageMatches } from './material-read-contract';

export const GITHUB_SOURCE_REFERENCE_ISSUE_PATH = '/v1/github/source/reference/issue';
export const GITHUB_SOURCE_REFERENCE_RESOLVE_PATH = '/v1/github/source/reference/resolve';
export const GITHUB_SOURCE_REFERENCE_LIMITS = Object.freeze({ ttlMs: 15 * 60_000, rows: 256, bytes: 1024 * 1024, rowBytes: 8192 });
// Preserve the existing 8 KiB material page, plus bounded reference/expiry metadata.
export const GITHUB_SOURCE_REFERENCE_RESPONSE_BYTES = 9 * 1024;
const reference = z.string().regex(/^gref_[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
const material = GitHubMaterialReadRequestSchema.refine(value => value.cursor === undefined);
const subject = z.strictObject({ installationId: generation, repositoryId: generation, prNumber: generation });
const bounded = (value: unknown) => new TextEncoder().encode(JSON.stringify(value)).length <= 4096;
export const SourceReferenceIssueRequestSchema = z.strictObject({ operationId: uuid, material }).refine(bounded);
export const SourceReferenceResolveRequestSchema = z.strictObject({ subject, reference, cursor: z.string().min(1).max(256).regex(/^[A-Za-z0-9_-]+$/).optional() }).refine(bounded);
export type SourceReferenceIssueRequest = z.infer<typeof SourceReferenceIssueRequestSchema>;
export type SourceReferenceResolveRequest = z.infer<typeof SourceReferenceResolveRequestSchema>;

/** Set by the authenticated coordinator; never accepted from the public request body. */
export const SourceReferenceActorSchema = z.strictObject({ principal: z.email().max(254).refine(value => value === value.toLowerCase()),
  agent: z.string().regex(/^[a-z0-9-]{1,32}$/), keyThumbprint: z.string().regex(/^[A-Za-z0-9_-]{43}$/), nodeId: uuid, nodeGeneration: generation });
export type SourceReferenceActor = z.infer<typeof SourceReferenceActorSchema>;
const refusal = z.strictObject({ status: z.enum(['unavailable', 'deleted', 'conflict', 'capacity']) });
export const SourceReferenceIssuedSchema = z.strictObject({ status: z.literal('issued'), operationId: uuid, reference, material,
  bodyDigest: z.string().regex(/^[a-f0-9]{64}$/), totalLength: z.number().int().min(0).max(1024 * 1024), firstVersion: generation, expiresAt: generation,
}).refine(value => value.material.fromVersion <= value.firstVersion && value.firstVersion <= value.material.toVersion);
export const SourceReferenceIssueResultSchema = z.union([SourceReferenceIssuedSchema, refusal]);
export const SourceReferenceResolveResultSchema = z.union([
  z.strictObject({ status: z.literal('ok'), reference, expiresAt: generation,
    page: GitHubMaterialReadResultSchema.refine(value => value.status === 'ok'),
  }), refusal,
]).refine(value => new TextEncoder().encode(JSON.stringify(value)).length <= GITHUB_SOURCE_REFERENCE_RESPONSE_BYTES);
export type SourceReferenceIssueResult = z.infer<typeof SourceReferenceIssueResultSchema>;
export type SourceReferenceResolveResult = z.infer<typeof SourceReferenceResolveResultSchema>;
export type SourceReferenceIssued = z.infer<typeof SourceReferenceIssuedSchema>;

export function sourceReferenceIssueMatches(request: SourceReferenceIssueRequest, result: SourceReferenceIssueResult): boolean {
  return result.status !== 'issued' || result.operationId === request.operationId && JSON.stringify(result.material) === JSON.stringify(request.material);
}
export function sourceReferenceResolveMatches(request: SourceReferenceResolveRequest, result: SourceReferenceResolveResult): boolean {
  if (result.status !== 'ok' || result.page.status !== 'ok') return result.status !== 'ok';
  return result.reference === request.reference && JSON.stringify(result.page.subject) === JSON.stringify(request.subject)
    && materialPageMatches({ subject: request.subject, sourceId: result.page.sourceId, fingerprint: result.page.fingerprint,
      ...result.page.requestedRange, ...(request.cursor === undefined ? {} : { cursor: request.cursor }) }, result.page);
}
