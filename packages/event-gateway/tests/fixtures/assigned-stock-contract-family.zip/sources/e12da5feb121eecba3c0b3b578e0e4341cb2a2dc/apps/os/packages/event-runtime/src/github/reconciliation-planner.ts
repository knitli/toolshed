import { z } from 'zod';
import { uuid } from '../contracts';
import { CONVERSION_MANIFEST_LIMITS, ConversionManifestFenceSchema, type HeldConversionManifest } from './conversion-manifest-store';
import { InitialReconciliationObligationSchema, type InitialReconciliationObligation } from './reconciliation-internal';

/** A bounded descriptive child of existing custody, never a second pending charge. */
export const INITIAL_RECONCILIATION_PLAN_LIMITS = Object.freeze({ rows: 1000, rowBytes: 512, bytes: 512_000 });
const count = z.number().int().nonnegative().max(CONVERSION_MANIFEST_LIMITS.entries);
export const InitialReconciliationPlanRecordSchema = z.strictObject({
  operationId: uuid, revision: z.literal(1), manifestDigest: z.string().regex(/^[a-f0-9]{64}$/),
  inputRecorded: z.literal(false), materialRead: z.literal(false), terminalDisposition: z.literal('pending'),
  materialCount: count, terminalCount: count,
});
export type InitialReconciliationPlanRecord = z.infer<typeof InitialReconciliationPlanRecordSchema>;
type Evidence = HeldConversionManifest['pages'][number]['entries'][number];
type Material = Extract<Evidence, { kind: 'material' }>;
type Transition = Extract<Evidence, { kind: 'transition' }>;
type PendingReference<T> = { pageIndex: number; entryIndex: number; state: 'pending'; evidence: T };
export interface InitialReconciliationPlan {
  record: InitialReconciliationPlanRecord;
  member: { operationId: string; manifestDigest: string; obligation: InitialReconciliationObligation;
    fence: HeldConversionManifest['fence']; reconciliation: HeldConversionManifest['reconciliation'] };
  obligations: { input: { state: 'pending' }; materials: PendingReference<Material>[]; terminals: PendingReference<Transition>[] };
}

/** Derive every outstanding reference from one immutable, already verified manifest.
 * This is descriptive retention data, not current read, observation, or release authority.
 */
export function planInitialReconciliation(input: InitialReconciliationObligation, manifest: HeldConversionManifest): InitialReconciliationPlan {
  const obligation = InitialReconciliationObligationSchema.parse(input), fence = ConversionManifestFenceSchema.parse(manifest.fence), r = manifest.reconciliation;
  if (manifest.status !== 'held' || manifest.operationId !== obligation.operationId
    || JSON.stringify(fence.token) !== JSON.stringify(obligation.token)
    || r.cause !== 'initial' || r.fromVersion !== obligation.fromVersion || r.toVersion !== obligation.toVersion
    || r.anchorVersion !== obligation.toVersion || r.hostEpoch !== obligation.hostEpoch
    || r.observationEpoch !== obligation.observationEpoch || r.coverageStartVersion !== 1 || r.complete !== true
    || manifest.observation.inputRecorded !== false || manifest.observation.materialRead !== false
    || manifest.observation.disposition !== 'pending') throw new Error('github_source_conflict');
  const materials: PendingReference<Material>[] = [], terminals: PendingReference<Transition>[] = [];
  for (const [pageIndex, page] of manifest.pages.entries()) {
    if (page.index !== pageIndex) throw new Error('github_source_conflict');
    for (const [entryIndex, evidence] of page.entries.entries()) {
      if (evidence.kind === 'material') {
        if (evidence.firstVersion < obligation.fromVersion || evidence.firstVersion > obligation.toVersion
          || evidence.availability !== 'available') throw new Error('github_source_conflict');
        materials.push({ pageIndex, entryIndex, state: 'pending', evidence: { ...evidence } });
      } else if (evidence.recordType === 'terminal') {
        terminals.push({ pageIndex, entryIndex, state: 'pending', evidence: { ...evidence } });
      }
    }
  }
  const record = InitialReconciliationPlanRecordSchema.parse({ operationId: obligation.operationId, revision: 1,
    manifestDigest: manifest.digest, inputRecorded: false, materialRead: false, terminalDisposition: 'pending',
    materialCount: materials.length, terminalCount: terminals.length });
  return { record, member: { operationId: record.operationId, manifestDigest: record.manifestDigest, obligation,
    fence, reconciliation: { ...r } },
  obligations: { input: { state: 'pending' }, materials, terminals } };
}
