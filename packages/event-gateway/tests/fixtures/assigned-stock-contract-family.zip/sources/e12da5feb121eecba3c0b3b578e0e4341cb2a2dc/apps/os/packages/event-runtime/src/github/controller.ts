import { ConversionMaterialReadBudget, ConversionManifestPagePlanner, initialConversionShape, RetainedMetadataPagePlanner, serializedBytes } from './conversion-planning';
import { CONVERSION_MANIFEST_LIMITS, conversionManifestByteUsage, type ConversionManifestFence } from './conversion-manifest-store';
import { GitHubMaterialReadRequestSchema, GitHubMaterialReadResultSchema } from './material-read-contract';
import { materialPageWithDigests } from './material-read';
import { assertGitHubHostStorageVersion, markGitHubInitialCustody } from './host-storage-version';
import { InitialReconciliationObligationSchema, InitialPinnedMetadataReadSchema, type InitialReconciliationObligation, type InitialPinnedMetadataReadResult } from './reconciliation-internal';
import { WatchActivateTokenSchema, type WatchActivateToken } from './watch-control-internal';
import { ensureMaterialDeletionStore, materialLifetime } from './material-delete';
import { PinnedMetadataReadSchema, type PinnedMetadataReadResult } from './pinned-read-contract';
import { GITHUB_SOURCE_READ_REQUEST_BYTES, GITHUB_SOURCE_READ_RESPONSE_BYTES, parseGitHubSourceReadRequest, projectGitHubSourceRecord, type GitHubSourceReadRequest, type GitHubSourceReadResult, type GitHubSourceReadItem, type GitHubSourceReadCursor, type GitHubSourceRecordType } from './readback-contract';
import { candidateKey, GITHUB_ENDPOINTS, subjectKey, type GitHubAttentionV1, type GitHubObservationV1, type GitHubSubjectV1, type GitHubCompletenessV1, type RetainedFindingV1 } from './state';
import { EventRequestDeadline } from '../request-deadline';
import { validSubject, type GitHubTriggerV1 } from './ingress';
import { EVENT_POLICY_V1 } from '../policy';

export interface GitHubAdmissionV1 { revision: string; policyRevision: string; mergeQueue: 'excluded' }
export interface GitHubSource {
  // eslint-disable-next-line no-unused-vars -- TypeScript declaration parameter names are labels, not runtime variables.
  authorize(subject: GitHubSubjectV1, deadline?: EventRequestDeadline): Promise<GitHubAdmissionV1 | null>;
  observe(subject: GitHubSubjectV1, policyRevision: string, epoch: number): Promise<GitHubObservationV1>;
}
interface Snapshot { subject: GitHubSubjectV1; epoch: number; version: number; generation: number; dueAt: number; firstAttachedAt: number; lastSuccess: number | null; failures: number; health: 'unknown' | 'fresh' | 'stale' | 'denied'; lastAttemptCompleteness: GitHubCompletenessV1 | null; failureReason: 'denied' | 'incomplete' | 'capacity' | 'unavailable' | null; observation: GitHubObservationV1 | null }
/** Build the empty retained checkpoint used before the first provider observation. */
export function createInitialGitHubSnapshot(subject: GitHubSubjectV1, now: number, epoch = 1): Snapshot {
  return { subject, epoch, version: 0, generation: 0, dueAt: now, firstAttachedAt: now, lastSuccess: null,
    failures: 0, health: 'unknown', lastAttemptCompleteness: null, failureReason: null, observation: null };
}
const POLL_MS = 300_000;
export const GITHUB_SOURCE_STALE_MS = 600_000;
export const GITHUB_SOURCE_LIMITS = { receipts: 8192, findings: 4096, outbox: 1000, observationBytes: 1024 * 1024, journalRows: 16_384, journalBytes: 4 * 1024 * 1024, journalEntryBytes: 4096 } as const;
const failed = (run: GitHubObservationV1['runs'][number]) => run.status !== null && (run.kind !== 'workflow' || run.attempt !== null) && ['failure', 'error', 'timed_out', 'cancelled', 'action_required', 'startup_failure', 'stale'].includes(run.conclusion ?? run.status);

type JournalFinding = { presence: 'present'; kind: 'review' | 'thread' | 'comment'; sourceHeadSha: string | null; fingerprint: string; disposition: 'open' | 'resolved'; outdated: boolean } | { presence: 'absent' };
type JournalRun = { presence: 'present'; kind: 'check' | 'status' | 'workflow'; sourceId: string; headSha: string; attempt: number | null; status: string | null; conclusion: string | null; startedAt: number | null; completedAt: number | null; workflowId?: number; runNumber?: number } | { presence: 'absent' };
interface JournalEntry { type: 'version' | 'finding' | 'terminal' | 'request' | 'run'; key: string; value: Record<string, unknown> }
const SHA1 = /^[a-f0-9]{40}$/, SHA256 = /^[a-f0-9]{64}$/, NUMERIC_ID = /^[1-9]\d{0,15}$/;
const REVIEW_PREFIX = 'review:', COMMENT_PREFIX = 'comment:', THREAD_COMMENT_PREFIX = 'thread-comment:';
const CHECK_PREFIX = 'check:', STATUS_PREFIX = 'status:';
const RUN_STATUSES = new Set(['queued', 'in_progress', 'completed', 'requested', 'waiting', 'pending', 'success', 'failure', 'error', 'action_required', 'cancelled', 'timed_out', 'startup_failure', 'stale', 'neutral', 'skipped']);
const RUN_CONCLUSIONS = new Set(['success', 'failure', 'error', 'action_required', 'cancelled', 'timed_out', 'startup_failure', 'stale', 'neutral', 'skipped']);
const capacity = (): never => { throw new Error('github_capacity'); };
const incomplete = (): never => { throw new Error('github_incomplete'); };
function assertJournal(condition: unknown): asserts condition { if (!condition) incomplete(); }
function assertJournalCapacity(condition: unknown): asserts condition { if (!condition) capacity(); }
type StoredJournalRow = { source_version: number; reconciliation_epoch: number; record_type: string; record_key: string; value: string };
function retainedTransitionItem(row: StoredJournalRow): GitHubSourceReadItem {
  assertJournal(positiveInteger(row.source_version) && positiveInteger(row.reconciliation_epoch)
    && ['version', 'finding', 'terminal', 'request', 'run'].includes(row.record_type));
  const recordType = row.record_type as GitHubSourceRecordType, value = projectGitHubSourceRecord(recordType, JSON.parse(row.value));
  if (recordType === 'version') assertJournal(row.record_key === '');
  if (recordType === 'terminal') assertJournal(row.record_key === 'pull-request');
  if (recordType === 'finding') assertJournal(row.record_key === JSON.stringify(value.sourceId));
  if (recordType === 'request') assertJournal(row.record_key === value.identity);
  if (recordType === 'run') {
    const present = [value.from, value.to].filter(entry => (entry as { presence?: string } | null)?.presence === 'present') as Record<string, unknown>[];
    assertJournal(present.length > 0 && present.every(entry => row.record_key === JSON.stringify([entry.kind, entry.sourceId, entry.headSha])));
  }
  return { phase: 'transition', sourceVersion: row.source_version, epoch: row.reconciliation_epoch, recordType, recordKey: row.record_key, value };
}

const safeInteger = (value: unknown): value is number => Number.isSafeInteger(value) && Number(value) >= 0;
const positiveInteger = (value: unknown): value is number => Number.isSafeInteger(value) && Number(value) > 0;
const safeNumericId = (value: unknown): value is string => typeof value === 'string' && NUMERIC_ID.test(value) && Number.isSafeInteger(Number(value));
const validSha = (value: unknown): value is string => typeof value === 'string' && SHA1.test(value);
const runState = (value: string | null, allowed: Set<string>): string | null => {
  assertJournal(value === null || typeof value === 'string' && value.length <= 128);
  if (value === null) return null;
  const normalized = value.toLowerCase();
  return allowed.has(normalized) ? normalized : 'unknown';
};
const runTimestamp = (value: string | null | undefined): number | null => {
  if (value === undefined || value === null) return null;
  assertJournal(typeof value === 'string' && value.length <= 32 && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?Z$/.test(value));
  const timestamp = Date.parse(value);
  assertJournal(safeInteger(timestamp));
  return timestamp;
};

function findingValue(finding: GitHubObservationV1['findings'][number]): JournalFinding {
  assertJournal(finding && typeof finding === 'object' && typeof finding.sourceId === 'string');
  const sourceIdValid = finding.kind === 'review' ? finding.sourceId.startsWith(REVIEW_PREFIX) && safeNumericId(finding.sourceId.slice(REVIEW_PREFIX.length))
    : finding.kind === 'comment' ? finding.sourceId.startsWith(COMMENT_PREFIX) && safeNumericId(finding.sourceId.slice(COMMENT_PREFIX.length))
      : finding.kind === 'thread' ? finding.sourceId.startsWith(THREAD_COMMENT_PREFIX) && finding.sourceId.length > THREAD_COMMENT_PREFIX.length : false;
  assertJournal(sourceIdValid && typeof finding.fingerprint === 'string' && SHA256.test(finding.fingerprint) &&
    (finding.sourceHeadSha === null || validSha(finding.sourceHeadSha)) &&
    (finding.disposition === 'open' || finding.disposition === 'resolved') && typeof finding.outdated === 'boolean');
  return { presence: 'present', kind: finding.kind, sourceHeadSha: finding.sourceHeadSha, fingerprint: finding.fingerprint, disposition: finding.disposition, outdated: finding.outdated };
}

function requestValues(requests: GitHubObservationV1['reviewRequests']): Map<string, { kind: 'user' | 'team'; sourceId: string }> {
  const values = new Map<string, { kind: 'user' | 'team'; sourceId: string }>();
  for (const request of requests) {
    assertJournal(request && typeof request === 'object' && (request.kind === 'user' || request.kind === 'team') && safeNumericId(request.sourceId));
    const key = `${request.kind}:${request.sourceId}`;
    assertJournal(!values.has(key));
    values.set(key, { kind: request.kind, sourceId: request.sourceId });
  }
  return values;
}

function runValues(runs: GitHubObservationV1['runs']): Map<string, JournalRun> {
  const values = new Map<string, JournalRun>();
  for (const run of runs) {
    assertJournal(run && typeof run === 'object' && typeof run.sourceId === 'string');
    assertJournal(validSha(run.headSha));
    const workflow = run.kind === 'workflow' ? /^workflow:([1-9]\d{0,15}):attempt:(unknown|[1-9]\d{0,15})$/.exec(run.sourceId) : null;
    const sourceIdValid = run.kind === 'check' ? run.sourceId.startsWith(CHECK_PREFIX) && safeNumericId(run.sourceId.slice(CHECK_PREFIX.length))
      : run.kind === 'status' ? run.sourceId.startsWith(STATUS_PREFIX) && safeNumericId(run.sourceId.slice(STATUS_PREFIX.length))
        : run.kind === 'workflow' && workflow !== null && safeNumericId(workflow[1]!);
    assertJournal(sourceIdValid && run.sourceId.length <= 64);
    assertJournal(run.attempt === null || positiveInteger(run.attempt));
    const projected: JournalRun = {
      presence: 'present', kind: run.kind, sourceId: run.sourceId, headSha: run.headSha, attempt: run.attempt,
      status: runState(run.status, RUN_STATUSES), conclusion: runState(run.conclusion, RUN_CONCLUSIONS),
      startedAt: runTimestamp(run.startedAt), completedAt: runTimestamp(run.completedAt),
    };
    if (run.kind === 'workflow') assertJournal(workflow![2] === 'unknown' ? run.attempt === null : Number(workflow![2]) === run.attempt);
    if (run.workflowId !== undefined) { assertJournal(positiveInteger(run.workflowId)); projected.workflowId = run.workflowId; }
    if (run.runNumber !== undefined) { assertJournal(positiveInteger(run.runNumber)); projected.runNumber = run.runNumber; }
    const key = JSON.stringify([run.kind, run.sourceId, run.headSha]);
    assertJournal(!values.has(key));
    values.set(key, projected);
  }
  return values;
}

function journalEntries(previous: GitHubObservationV1 | null, observation: GitHubObservationV1, generation: number, coverageStartVersion: number): JournalEntry[] {
  assertJournal(observation && typeof observation === 'object' && observation.subject && typeof observation.subject === 'object' &&
    observation.candidate && typeof observation.candidate === 'object' && Array.isArray(observation.findings) &&
    Array.isArray(observation.reviewRequests) && Array.isArray(observation.runs));
  assertJournal(validSubject(observation.subject) && safeInteger(observation.epoch) && observation.epoch > 0 && safeInteger(observation.observedAt) &&
    (observation.state === 'open' || observation.state === 'closed' || observation.state === 'merged') &&
    validSha(observation.candidate.headSha) && validSha(observation.candidate.baseSha) &&
    (observation.candidate.observedMergeSha === null || validSha(observation.candidate.observedMergeSha)) &&
    safeInteger(generation));
  const entries: JournalEntry[] = [{ type: 'version', key: '', value: {
    complete: true, observedAt: observation.observedAt, candidateGeneration: generation, coverageStartVersion, candidate: {
      headSha: observation.candidate.headSha, baseSha: observation.candidate.baseSha,
      observedMergeSha: observation.candidate.observedMergeSha,
    }, state: observation.state,
  } }];
  if (previous?.state !== observation.state) entries.push({ type: 'terminal', key: 'pull-request', value: { from: previous?.state ?? null, to: observation.state } });

  const uniqueFindings = (findings: GitHubObservationV1['findings']) => {
    const values = new Map<string, JournalFinding>();
    for (const finding of findings) {
      const value = findingValue(finding);
      assertJournal(!values.has(finding.sourceId));
      values.set(finding.sourceId, value);
    }
    return values;
  };
  const beforeFindings = uniqueFindings(previous?.findings ?? []);
  const afterFindings = uniqueFindings(observation.findings);
  const findingSources = new Set([...beforeFindings.keys(), ...afterFindings.keys()]);
  for (const sourceId of [...findingSources].toSorted()) {
    const from = beforeFindings.get(sourceId) ?? (previous ? { presence: 'absent' as const } : null);
    const to = afterFindings.get(sourceId) ?? { presence: 'absent' as const };
    if (JSON.stringify(from) !== JSON.stringify(to)) entries.push({ type: 'finding', key: JSON.stringify(sourceId), value: { sourceId, from, to } });
  }

  const beforeRequests = requestValues(previous?.reviewRequests ?? []), afterRequests = requestValues(observation.reviewRequests);
  const requestIds = new Set([...beforeRequests.keys(), ...afterRequests.keys()]);
  for (const key of [...requestIds].toSorted()) {
    const from = beforeRequests.has(key) ? 'present' : previous ? 'absent' : null;
    const to = afterRequests.has(key) ? 'present' : 'absent';
    if (from !== to) entries.push({ type: 'request', key, value: { kind: 'review_request', identity: key, from, to } });
  }

  const beforeRuns = runValues(previous?.runs ?? []), afterRuns = runValues(observation.runs);
  const runIds = new Set([...beforeRuns.keys(), ...afterRuns.keys()]);
  for (const key of [...runIds].toSorted()) {
    const from = beforeRuns.get(key) ?? (previous ? { presence: 'absent' as const } : null);
    const to = afterRuns.get(key) ?? { presence: 'absent' as const };
    if (JSON.stringify(from) !== JSON.stringify(to)) entries.push({ type: 'run', key, value: { from, to } });
  }
  return entries;
}

/** One canonical PR per storage instance. No transport, reviewer invocation, or completion authority. */
interface ReadManifest { key: string; anchors: GitHubSourceReadItem[]; rowIds: number[]; pages: Map<number, number> }
interface RetainedReadPlan { key: string; nonce: string; digest: string; rowIds: number[]; pages: Map<number, number> }
// One plan per storage: at most journalRows numeric IDs and page pairs; no payloads or logical keys.
const retainedReadPlans = new WeakMap<DurableObjectStorage, RetainedReadPlan>();
const readManifests = new WeakMap<DurableObjectStorage, ReadManifest>();
export class GitHubAttentionController {
  private readonly sourceClaimGuard?: () => boolean;
  constructor(private readonly storage: DurableObjectStorage, private readonly source: GitHubSource, private readonly random = () => crypto.getRandomValues(new Uint32Array(1))[0]! / 0x1_0000_0000, private readonly publicationsEnabled = false,
    private readonly sourceGuard?: () => Promise<boolean>, private readonly sourceGuardLocal?: () => boolean, private readonly createPublications = true,
    sourceClaimGuard?: () => boolean) {
    this.sourceClaimGuard = sourceClaimGuard;
    assertGitHubHostStorageVersion(storage.sql);
    storage.transactionSync(() => {
      const readTables = ['github_source_journal', 'github_handoffs', 'github_initial_reconciliation_pins'];
      const readSchema = [...readTables, 'github_retained_read_nonce', ...readTables.flatMap(table =>
        ['insert', 'update', 'delete'].map(action => `${table}_read_nonce_${action}`))];
      const ready = storage.sql.exec<{ n: number }>(`SELECT count(*) AS n FROM sqlite_master WHERE name IN (${readSchema.map(() => '?').join(',')})`, ...readSchema).one().n === readSchema.length;
      ensureMaterialDeletionStore(storage);
      storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_initial_reconciliation_pins (
        operation_id TEXT PRIMARY KEY, obligation TEXT NOT NULL
      )`);
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_state (id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL)');
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_receipts (id TEXT PRIMARY KEY, received_at INTEGER NOT NULL)');
      storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_finding_material (
        source_id TEXT NOT NULL, fingerprint TEXT NOT NULL, body TEXT, first_version INTEGER NOT NULL,
        resolved_at INTEGER, deleted_at INTEGER, PRIMARY KEY(source_id,fingerprint)
      )`);
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_findings (id TEXT PRIMARY KEY, value TEXT NOT NULL)');
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_outbox (id TEXT PRIMARY KEY, value TEXT NOT NULL)');
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_publication_created (id TEXT PRIMARY KEY, created_at INTEGER NOT NULL)');
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_publication_authority (id TEXT PRIMARY KEY, revision TEXT NOT NULL, policy_revision TEXT NOT NULL)');
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_publication_retry (id INTEGER PRIMARY KEY CHECK(id=1), due_at INTEGER NOT NULL)');
      storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_handoffs (
        id TEXT PRIMARY KEY, request TEXT, reason TEXT NOT NULL, checked_at INTEGER NOT NULL,
        state TEXT NOT NULL DEFAULT 'pending'
      )`);
      if (!storage.sql.exec<{ name: string }>('PRAGMA table_info(github_handoffs)').toArray().some(column => column.name === 'state')) {
        storage.sql.exec("ALTER TABLE github_handoffs ADD COLUMN state TEXT NOT NULL DEFAULT 'pending'");
      }
      storage.sql.exec("CREATE INDEX IF NOT EXISTS github_handoffs_state ON github_handoffs(state,checked_at)");
      storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_source_journal (
        subject_key TEXT NOT NULL, source_version INTEGER NOT NULL, reconciliation_epoch INTEGER NOT NULL,
        committed_at INTEGER NOT NULL, record_type TEXT NOT NULL, record_key TEXT NOT NULL, value TEXT NOT NULL,
        PRIMARY KEY(subject_key,source_version,record_type,record_key)
      )`);
      storage.sql.exec('CREATE INDEX IF NOT EXISTS github_source_journal_committed_at ON github_source_journal(subject_key,committed_at,source_version)');
      // Structural repair rotates identity; an ordinary reopen preserves reusable plans.
      storage.sql.exec('CREATE TABLE IF NOT EXISTS github_retained_read_nonce (id INTEGER PRIMARY KEY CHECK(id=1), nonce TEXT NOT NULL)');
      const nonce = storage.sql.exec<{ nonce: string }>('SELECT nonce FROM github_retained_read_nonce WHERE id=1').toArray()[0]?.nonce;
      if (!ready || !nonce || !/^[A-F0-9]{32}$/.test(nonce)) {
        retainedReadPlans.delete(storage);
        storage.sql.exec('INSERT OR REPLACE INTO github_retained_read_nonce(id,nonce) VALUES (1,hex(randomblob(16)))');
      }
      for (const table of ['github_source_journal', 'github_handoffs', 'github_initial_reconciliation_pins']) {
        for (const action of ['INSERT', 'UPDATE', 'DELETE']) {
          storage.sql.exec(`CREATE TRIGGER IF NOT EXISTS ${table}_read_nonce_${action.toLowerCase()} AFTER ${action} ON ${table}
            BEGIN UPDATE github_retained_read_nonce SET nonce=hex(randomblob(16)) WHERE id=1; END`);
        }
      }
    });
  }
  snapshot(now = Date.now()): Snapshot | null {
    const row = this.storage.sql.exec<{ value: string }>('SELECT value FROM github_state WHERE id=1').toArray()[0];
    if (!row) return null;
    const snapshot = JSON.parse(row.value) as Snapshot;
    if (now - (snapshot.lastSuccess ?? snapshot.firstAttachedAt) >= GITHUB_SOURCE_STALE_MS && snapshot.health !== 'denied') snapshot.health = 'stale';
    return snapshot;
  }
  /** Pure current-incarnation read: never repairs retention or changes source lifecycle. */
  readSource(input: GitHubSourceReadRequest, authority: { revision: string; policyRevision: string }): GitHubSourceReadResult {
    const request = parseGitHubSourceReadRequest(input);
    if (!request) return { status: 'conflict' };
    const current = this.snapshot();
    if (!current?.observation || subjectKey(current.subject) !== subjectKey(request.subject)) return { status: 'coverage_unavailable' };
    const observation = current.observation;
    const key = subjectKey(request.subject);
    const physical = this.storage.sql.exec<{ count: number; last: number; changes: number }>('SELECT count(*) AS count,COALESCE(MAX(rowid),0) AS last,total_changes() AS changes FROM github_source_journal WHERE subject_key=?', key).one();
    const suffix = this.storage.sql.exec<{ first: number | null; gap: number | null }>(`SELECT MIN(source_version) AS first,
      MIN(CASE WHEN source_version != ? - position + 1 OR complete IS NOT 'true' THEN position END) AS gap FROM (
        SELECT source_version,json_type(value,'$.complete') AS complete,ROW_NUMBER() OVER (ORDER BY source_version DESC) AS position
        FROM github_source_journal WHERE subject_key=? AND record_type='version' AND source_version<=?
      )`, current.version, key, current.version).one();
    const coverage = suffix.gap === null ? suffix.first ?? current.version + 1 : current.version - suffix.gap + 2;
    if (request.fromVersion < coverage || request.toVersion > current.version) return { status: 'coverage_unavailable' };
    const binding = { subjectKey: subjectKey(request.subject), fromVersion: request.fromVersion, toVersion: request.toVersion, anchorVersion: current.version, anchorEpoch: current.epoch, observationEpoch: observation.epoch, revision: authority.revision, policyRevision: authority.policyRevision };
    if (request.cursor && Object.entries(binding).some(([field, value]) => request.cursor![field as keyof GitHubSourceReadCursor] !== value)) return { status: 'conflict' };
    const envelope = { status: 'ok' as const, subject: request.subject, requestedRange: { fromVersion: request.fromVersion, toVersion: request.toVersion }, coverageStartVersion: coverage, anchor: { sourceVersion: current.version, epoch: current.epoch, observationEpoch: observation.epoch, observedAt: observation.observedAt } };
    const manifestKey = JSON.stringify([binding, coverage, physical]);
    let manifest = readManifests.get(this.storage);
    if (manifest?.key !== manifestKey) {
      const anchors: GitHubSourceReadItem[] = journalEntries(null, observation, current.generation, coverage).map(entry => ({ phase: 'anchor', sourceVersion: current.version, epoch: observation.epoch, recordType: entry.type, recordKey: entry.key, value: projectGitHubSourceRecord(entry.type, entry.value) }));
      // Transfer only compact locators and sizes, never retained journal payloads, when building boundaries.
      const records = this.storage.sql.exec<{ id: number; bytes: number }>(`SELECT rowid AS id,length(CAST(json_object(
        'phase','transition','sourceVersion',source_version,'epoch',reconciliation_epoch,
        'recordType',record_type,'recordKey',record_key,'value',json(value)) AS BLOB)) AS bytes
        FROM github_source_journal WHERE subject_key=? AND source_version>=? AND source_version<=?
        ORDER BY source_version DESC,record_type,record_key`, key, request.fromVersion, current.version).toArray();
      const sizes = [...anchors.map(item => new TextEncoder().encode(JSON.stringify(item)).length), ...records.map(row => row.bytes)];
      const pages = new Map<number, number>();
      let start = 0, bytes = 0;
      for (let offset = 0; offset < sizes.length; offset++) {
        const next = offset + 1;
        const overhead = new TextEncoder().encode(JSON.stringify({ ...envelope, rangeDigest: '0'.repeat(64), items: [], nextCursor: next === sizes.length ? null : { ...binding, offset: next }, complete: next === sizes.length })).length;
        if (overhead + bytes + sizes[offset]! + Number(offset > start) > GITHUB_SOURCE_READ_RESPONSE_BYTES) {
          if (offset === start) return { status: 'coverage_unavailable' };
          pages.set(start, offset);
          start = offset;
          bytes = 0;
          if (overhead + sizes[offset]! > GITHUB_SOURCE_READ_RESPONSE_BYTES) return { status: 'coverage_unavailable' };
        }
        bytes += sizes[offset]! + Number(offset > start);
      }
      pages.set(start, sizes.length);
      manifest = { key: manifestKey, anchors, rowIds: records.map(row => row.id), pages };
      readManifests.set(this.storage, manifest);
    }
    const start = request.cursor?.offset ?? 0, end = manifest.pages.get(start);
    if (end === undefined || end === start) return { status: 'conflict' };
    const items = manifest.anchors.slice(start, end);
    const rowIds = manifest.rowIds.slice(Math.max(0, start - manifest.anchors.length), Math.max(0, end - manifest.anchors.length));
    if (rowIds.length) {
      const rows = this.storage.sql.exec<{ source_version: number; reconciliation_epoch: number; record_type: string; record_key: string; value: string }>(
        `SELECT source_version,reconciliation_epoch,record_type,record_key,value FROM github_source_journal WHERE rowid IN (${rowIds.map(() => '?').join(',')}) ORDER BY source_version DESC,record_type,record_key`, ...rowIds,
      ).toArray();
      if (rows.length !== rowIds.length) return { status: 'coverage_unavailable' };
      for (const row of rows) {
        if (!['version', 'finding', 'terminal', 'request', 'run'].includes(row.record_type)) return { status: 'coverage_unavailable' };
        const recordType = row.record_type as GitHubSourceRecordType;
        items.push({ phase: 'transition', sourceVersion: row.source_version, epoch: row.reconciliation_epoch, recordType, recordKey: row.record_key, value: projectGitHubSourceRecord(recordType, JSON.parse(row.value)) });
      }
    }
    const complete = end === manifest.anchors.length + manifest.rowIds.length;
    const result = { ...envelope, items, nextCursor: complete ? null : { ...binding, offset: end }, complete };
    return new TextEncoder().encode(JSON.stringify(result)).length <= GITHUB_SOURCE_READ_RESPONSE_BYTES ? result : { status: 'coverage_unavailable' };

  }
  /** Pure internal pinned-range read; callers must establish historical read authority separately. */
  async readPinnedMetadata(input: unknown): Promise<PinnedMetadataReadResult> {
    const encoder = new TextEncoder();
    let request;
    try {
      if (encoder.encode(JSON.stringify(input)).length > 4096) return { status: 'conflict' };
      request = PinnedMetadataReadSchema.parse(input);
    } catch { return { status: 'conflict' }; }
    const { publication, toVersion, cursor } = request;
    const { publicationId, subject, sourceVersion: fromVersion } = publication.event;
    const exactRequest = JSON.stringify(publication), key = subjectKey(subject);
    const pin = () => this.storage.sql.exec<{ request: string | null; state: string }>(
      'SELECT request,state FROM github_handoffs WHERE id=?', publicationId).toArray()[0];
    const result = await this.readRetainedMetadata(publication, { status: 'ok' as const, publicationId, fromVersion, toVersion }, key, exactRequest, pin, cursor);
    if (result.status !== 'ok') return result;
    return { status: 'ok', publicationId, fromVersion, toVersion, items: result.items, nextCursor: result.nextCursor, complete: result.complete };
  }
  /** Must run inside the host promotion transaction; no network I/O or inferred coverage. */
  acquireInitialReconciliationPin(input: unknown, fence?: ConversionManifestFence, reservedManifestBytes = 0): InitialReconciliationObligation {
    const obligation = InitialReconciliationObligationSchema.parse(input);
    const exact = JSON.stringify(obligation), { token, toVersion, observationEpoch } = obligation;
    this.storage.transactionSync(() => {
      const prior = this.storage.sql.exec<{ obligation: string }>(
        'SELECT obligation FROM github_initial_reconciliation_pins WHERE operation_id=?', obligation.operationId).toArray()[0];
      if (prior) {
        if (prior.obligation !== exact) throw new Error('github_initial_pin_conflict');
        return;
      }
      const current = this.snapshot();
      const key = subjectKey({ installationId: token.installationId, ...token.subject });
      assertJournal(current?.observation && subjectKey(current.subject) === key && current.version === toVersion
        && current.observation.epoch === observationEpoch);
      const cutoff = Date.now() - EVENT_POLICY_V1.terminalDeduplicationRetentionMs;
      const expiredJournal = this.storage.sql.exec(`SELECT 1 FROM github_source_journal AS j
        WHERE j.subject_key=? AND j.record_type='version' AND j.source_version BETWEEN 1 AND ? AND j.committed_at<=?
          AND NOT EXISTS (SELECT 1 FROM github_initial_reconciliation_pins AS p WHERE j.source_version<=json_extract(p.obligation,'$.toVersion'))
          AND NOT EXISTS (SELECT 1 FROM github_outbox AS o WHERE json_extract(o.value,'$.sourceVersion')<=j.source_version)
          AND NOT EXISTS (SELECT 1 FROM github_handoffs AS h WHERE h.request IS NOT NULL AND json_extract(h.request,'$.event.sourceVersion')<=j.source_version)
        LIMIT 1`, key, toVersion, cutoff).toArray().length;
      assertJournal(!expiredJournal);
      assertJournalCapacity(toVersion <= GITHUB_SOURCE_LIMITS.journalRows);
      const bounds = this.storage.sql.exec<{ n: number; bytes: number; invalid: number }>(`SELECT count(*) AS n,
        COALESCE(sum(length(CAST(j.value AS BLOB))),0) AS bytes,
        COALESCE(sum(CASE WHEN h.source_version IS NULL OR j.reconciliation_epoch!=h.reconciliation_epoch
          OR length(CAST(j.value AS BLOB))>? OR length(CAST(j.record_key AS BLOB))>? THEN 1 ELSE 0 END),0) AS invalid
        FROM github_source_journal AS j LEFT JOIN github_source_journal AS h
          ON h.subject_key=j.subject_key AND h.source_version=j.source_version AND h.record_type='version' AND h.record_key=''
        WHERE j.subject_key=? AND j.source_version BETWEEN 1 AND ?`,
      GITHUB_SOURCE_LIMITS.journalEntryBytes, GITHUB_SOURCE_LIMITS.journalEntryBytes, key, toVersion).one();
      assertJournal(!bounds.invalid);
      assertJournalCapacity(bounds.n <= GITHUB_SOURCE_LIMITS.journalRows && bounds.bytes <= GITHUB_SOURCE_LIMITS.journalBytes);
      const headers = this.storage.sql.exec<{ source_version: number; reconciliation_epoch: number; value: string }>(
        "SELECT source_version,reconciliation_epoch,value FROM github_source_journal WHERE subject_key=? AND record_type='version' AND source_version<=? ORDER BY source_version", key, toVersion).toArray();
      assertJournal(headers.length === toVersion);
      for (const [index, header] of headers.entries()) {
        const value = projectGitHubSourceRecord('version', JSON.parse(header.value));
        assertJournal(header.source_version === index + 1 && value.coverageStartVersion === 1
          && positiveInteger(header.reconciliation_epoch) && header.reconciliation_epoch <= observationEpoch);
      }
      assertJournal(headers.at(-1)?.reconciliation_epoch === observationEpoch);
      // Historical from/to states require bodies even when the finding disappeared before the anchor.
      const materials = new Set<string>();
      const findings = this.storage.sql.exec<{ value: string }>(
        "SELECT value FROM github_source_journal WHERE subject_key=? AND record_type='finding' AND source_version BETWEEN 1 AND ?", key, toVersion).toArray();
      for (const row of findings) {
        const finding = projectGitHubSourceRecord('finding', JSON.parse(row.value));
        for (const state of [finding.from, finding.to]) {
          if (!state || typeof state !== 'object' || !('presence' in state) || state.presence !== 'present') continue;
          assertJournal(typeof finding.sourceId === 'string' && 'fingerprint' in state && typeof state.fingerprint === 'string');
          const identity = JSON.stringify([finding.sourceId, state.fingerprint]);
          if (materials.has(identity)) continue;
          const stamp = this.findingMaterialStamp(finding.sourceId, state.fingerprint);
          assertJournal(stamp.status === 'available' && stamp.firstVersion <= toVersion);
          materials.add(identity);
        }
      }
      this.assertInitialConversionFits(obligation, bounds.n, fence, reservedManifestBytes);
      const count = this.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_initial_reconciliation_pins').one().n;
      assertJournalCapacity(count < GITHUB_SOURCE_LIMITS.outbox);
      markGitHubInitialCustody(this.storage.sql);
      this.storage.sql.exec('INSERT INTO github_initial_reconciliation_pins(operation_id,obligation) VALUES (?,?)', obligation.operationId, exact);
    });
    return obligation;
  }
  private assertInitialConversionFits(obligation: InitialReconciliationObligation, count: number, fence: ConversionManifestFence | undefined, reservedManifestBytes: number): void {
    const L = CONVERSION_MANIFEST_LIMITS, zeroDigest = '0'.repeat(64);
    assertJournalCapacity(Number.isSafeInteger(reservedManifestBytes) && reservedManifestBytes > 0 && reservedManifestBytes <= L.bytes);
    const subject = { installationId: obligation.token.installationId, ...obligation.token.subject };
    const envelope = { status: 'ok', operationId: obligation.operationId, fromVersion: 1, toVersion: obligation.toVersion };
    assertJournalCapacity(serializedBytes({ obligation, cursor: { rangeDigest: zeroDigest, offset: count } }) <= GITHUB_SOURCE_READ_REQUEST_BYTES);
    const metadata = new RetainedMetadataPagePlanner(envelope, count, GITHUB_SOURCE_LIMITS.journalEntryBytes);
    const manifest = new ConversionManifestPagePlanner(), materials = new Map<string, { sourceId: string; fingerprint: string }>();
    for (const row of this.storage.sql.exec<StoredJournalRow>(
      'SELECT source_version,reconciliation_epoch,record_type,record_key,value FROM github_source_journal WHERE subject_key=? AND source_version BETWEEN 1 AND ? ORDER BY source_version,record_type,record_key',
      subjectKey(subject), obligation.toVersion)) {
      const item = retainedTransitionItem(row);
      metadata.append(serializedBytes(item));
      assertJournalCapacity(metadata.bytes <= L.bytes && metadata.pageCount <= L.pages);
      manifest.append({ kind: 'transition', sourceVersion: item.sourceVersion, epoch: item.epoch,
        recordType: item.recordType, recordKey: item.recordKey, valueDigest: zeroDigest });
      if (item.recordType === 'finding') for (const state of [item.value.from, item.value.to]) {
        if (state && typeof state === 'object' && 'presence' in state && state.presence === 'present'
          && 'fingerprint' in state && typeof state.fingerprint === 'string' && typeof item.value.sourceId === 'string')
          materials.set(JSON.stringify([item.value.sourceId, state.fingerprint]), { sourceId: item.value.sourceId, fingerprint: state.fingerprint });
      }
      assertJournalCapacity(count + materials.size <= L.entries);
    }
    const planned = metadata.finish();
    assertJournalCapacity(planned.bytes <= L.bytes && planned.pageCount <= L.pages);
    let bodyBytes = 0;
    const reads = new ConversionMaterialReadBudget();
    for (const material of materials.values()) {
      const retained = this.readFindingMaterial(material.sourceId, material.fingerprint);
      assertJournal(retained.status === 'available');
      assertJournal(this.initialMaterialWitness(obligation, material.sourceId, material.fingerprint, retained.firstVersion) !== null);
      bodyBytes += new TextEncoder().encode(retained.body).length;
      assertJournalCapacity(bodyBytes <= L.bytes);
      let cursor: string | undefined;
      do {
        reads.consume();
        const request = GitHubMaterialReadRequestSchema.safeParse({ subject, ...material,
          fromVersion: 1, toVersion: obligation.toVersion, ...(cursor ? { cursor } : {}) });
        assertJournalCapacity(request.success);
        const result = GitHubMaterialReadResultSchema.safeParse(materialPageWithDigests(request.data, retained, zeroDigest, zeroDigest));
        assertJournalCapacity(result.success && result.data.status === 'ok');
        cursor = result.data.nextCursor ?? undefined;
      } while (cursor);
      manifest.append({ kind: 'material', ...material, firstVersion: retained.firstVersion, bodyDigest: zeroDigest, availability: 'available' });
    }
    const headerBytes = fence ? serializedBytes({ ...initialConversionShape(obligation, fence, manifest.pageBytes.length, manifest.entries),
      status: 'held', observation: { inputRecorded: false, materialRead: false, disposition: 'pending' } }) : L.controlBytes;
    assertJournalCapacity(headerBytes <= L.controlBytes && conversionManifestByteUsage(headerBytes, manifest.pageBytes) <= reservedManifestBytes);
  }
  initialReconciliationPin(input: WatchActivateToken): InitialReconciliationObligation | null {
    const token = WatchActivateTokenSchema.parse(input);
    const row = this.storage.sql.exec<{ obligation: string }>(
      'SELECT obligation FROM github_initial_reconciliation_pins WHERE operation_id=?', token.operationId).toArray()[0];
    if (!row) return null;
    const obligation = InitialReconciliationObligationSchema.parse(JSON.parse(row.obligation));
    return JSON.stringify(obligation.token) === JSON.stringify(token) ? obligation : null;
  }
  initialReconciliationMaterialWitness(input: InitialReconciliationObligation, sourceId: string, fingerprint: string, firstVersion: number): string | null {
    try {
      const obligation = InitialReconciliationObligationSchema.parse(input);
      const held = this.initialReconciliationPin(obligation.token);
      if (!held || JSON.stringify(held) !== JSON.stringify(obligation)) return null;
      return this.initialMaterialWitness(obligation, sourceId, fingerprint, firstVersion);
    } catch { return null; }
  }
  private initialMaterialWitness(obligation: InitialReconciliationObligation, sourceId: string, fingerprint: string, firstVersion: number): string | null {
    try {
      if (!positiveInteger(firstVersion) || firstVersion > obligation.toVersion) return null;
      const key = subjectKey({ installationId: obligation.token.installationId, ...obligation.token.subject });
      const row = this.storage.sql.exec<{ value: string; reconciliation_epoch: number; header: string }>(
        `SELECT j.value,j.reconciliation_epoch,h.value AS header FROM github_source_journal AS j
          JOIN github_source_journal AS h ON h.subject_key=j.subject_key AND h.source_version=j.source_version
            AND h.record_type='version' AND h.record_key='' AND h.reconciliation_epoch=j.reconciliation_epoch
          WHERE j.subject_key=? AND j.source_version=? AND j.record_type='finding' AND j.record_key=?
            AND length(CAST(j.value AS BLOB))<=? AND length(CAST(h.value AS BLOB))<=?`,
        key, firstVersion, JSON.stringify(sourceId), GITHUB_SOURCE_LIMITS.journalEntryBytes, GITHUB_SOURCE_LIMITS.journalEntryBytes).toArray()[0];
      if (!row || !positiveInteger(row.reconciliation_epoch) || row.reconciliation_epoch > obligation.observationEpoch) return null;
      const header = projectGitHubSourceRecord('version', JSON.parse(row.header));
      if (header.coverageStartVersion !== 1) return null;
      const finding = projectGitHubSourceRecord('finding', JSON.parse(row.value));
      const to = finding.to as { presence: string; fingerprint?: string };
      if (finding.sourceId !== sourceId || to.presence !== 'present' || to.fingerprint !== fingerprint) return null;
      return JSON.stringify([obligation, firstVersion, row]);
    } catch { return null; }
  }
  async readInitialPinnedMetadata(input: unknown): Promise<InitialPinnedMetadataReadResult> {
    let request;
    try {
      if (new TextEncoder().encode(JSON.stringify(input)).length > GITHUB_SOURCE_READ_REQUEST_BYTES) return { status: 'conflict' };
      request = InitialPinnedMetadataReadSchema.parse(input);
    } catch { return { status: 'conflict' }; }
    const { obligation, cursor } = request;
    const { operationId, fromVersion, toVersion, token, observationEpoch } = obligation;
    const pin = () => {
      const row = this.storage.sql.exec<{ obligation: string }>(
        'SELECT obligation FROM github_initial_reconciliation_pins WHERE operation_id=?', operationId).toArray()[0];
      return row ? { request: row.obligation, state: 'pending' } : undefined;
    };
    return this.readRetainedMetadata(obligation, { status: 'ok' as const, operationId, fromVersion, toVersion },
      subjectKey({ installationId: token.installationId, ...token.subject }), JSON.stringify(obligation), pin, cursor, observationEpoch);
  }
  private async readRetainedMetadata<T extends { status: 'ok'; fromVersion: number; toVersion: number }>(
    binding: unknown, envelope: T, key: string, exactRequest: string,
    pin: () => { request: string | null; state: string } | undefined,
    cursor?: { rangeDigest: string; offset: number }, anchorEpoch?: number,
  ): Promise<{ status: 'unavailable' | 'coverage_unavailable' | 'conflict' } | T & {
    items: GitHubSourceReadItem[]; rangeDigest: string; nextCursor: { rangeDigest: string; offset: number } | null; complete: boolean;
  }> {
    const encoder = new TextEncoder(), { fromVersion, toVersion } = envelope;
    const retained = pin();
    if (!retained || !['pending', 'accepted'].includes(retained.state)) return { status: 'unavailable' };
    if (retained.request !== exactRequest) return { status: 'conflict' };
    const changes = () => this.storage.sql.exec<{ nonce: string }>('SELECT nonce FROM github_retained_read_nonce WHERE id=1').toArray()[0]?.nonce;
    const planKey = JSON.stringify([binding, envelope, key, exactRequest, anchorEpoch]);
    const before = changes();
    if (!before || !/^[A-F0-9]{32}$/.test(before)) { retainedReadPlans.delete(this.storage); return { status: 'conflict' }; }
    const cached = retainedReadPlans.get(this.storage);
    if (cached?.key === planKey && cached.nonce === before) {
      if (cursor && cursor.rangeDigest !== cached.digest) return { status: 'conflict' };
      const start = cursor?.offset ?? 0, end = cached.pages.get(start);
      if (end === undefined || end <= start) return { status: 'conflict' };
      const items: GitHubSourceReadItem[] = [];
      try {
        // Bound query parameters independently of the response page size.
        for (let offset = start; offset < end; offset += 64) {
          const ids = cached.rowIds.slice(offset, Math.min(end, offset + 64));
          const rows = this.storage.sql.exec<{ source_version: number; reconciliation_epoch: number; record_type: string; record_key: string; value: string }>(
            `SELECT source_version,reconciliation_epoch,record_type,record_key,value FROM github_source_journal WHERE rowid IN (${ids.map(() => '?').join(',')}) ORDER BY source_version,record_type,record_key`, ...ids).toArray();
          assertJournal(rows.length === ids.length);
          for (const row of rows) {
            const recordType = row.record_type as GitHubSourceRecordType;
            items.push({ phase: 'transition', sourceVersion: row.source_version, epoch: row.reconciliation_epoch, recordType, recordKey: row.record_key, value: projectGitHubSourceRecord(recordType, JSON.parse(row.value)) });
          }
        }
      } catch { retainedReadPlans.delete(this.storage); return { status: 'coverage_unavailable' }; }
      const fresh = pin();
      if (!fresh || !['pending', 'accepted'].includes(fresh.state)) return { status: 'unavailable' };
      if (fresh.request !== exactRequest || changes() !== before) return { status: 'conflict' };
      const complete = end === cached.rowIds.length, rangeDigest = cached.digest;
      const result = { ...envelope, rangeDigest, items, nextCursor: complete ? null : { rangeDigest, offset: end }, complete };
      return encoder.encode(JSON.stringify(result)).length <= GITHUB_SOURCE_READ_RESPONSE_BYTES ? result : { status: 'coverage_unavailable' };
    }
    retainedReadPlans.delete(this.storage);
    const rowIds: number[] = [];
    let pages = new Map<number, number>();
    const bounds = this.storage.sql.exec<{ count: number; bytes: number; largest: number; keyBytes: number }>(`SELECT count(*) AS count,
      COALESCE(sum(length(CAST(value AS BLOB))),0) AS bytes,COALESCE(max(length(CAST(value AS BLOB))),0) AS largest,
      COALESCE(max(length(CAST(record_key AS BLOB))),0) AS keyBytes FROM github_source_journal
      WHERE subject_key=? AND source_version BETWEEN ? AND ?`, key, fromVersion, toVersion).one();
    if (!bounds.count || bounds.count > GITHUB_SOURCE_LIMITS.journalRows || bounds.bytes > GITHUB_SOURCE_LIMITS.journalBytes
      || bounds.largest > GITHUB_SOURCE_LIMITS.journalEntryBytes || bounds.keyBytes > GITHUB_SOURCE_LIMITS.journalEntryBytes)
      return { status: 'coverage_unavailable' };
    const stream = new crypto.DigestStream('SHA-256');
    const writer = stream.getWriter();
    const digestResult = stream.digest.catch(() => null);
    let digest: ArrayBuffer | null = null;
    const items: GitHubSourceReadItem[] = [];
    const requestedOffset = cursor?.offset ?? 0;
    let offset = 0, pageEnd = 0, foundPage = false;
    const pagePlan = new RetainedMetadataPagePlanner(envelope, bounds.count, GITHUB_SOURCE_LIMITS.journalEntryBytes);
    let version = fromVersion, epoch: number | null = null, completeVersion = false;
    let after: [number, string, string] = [fromVersion - 1, '', ''];
    try {
      await writer.write(encoder.encode(JSON.stringify([binding, fromVersion, toVersion]) + '\n'));
      for (let batchStart = 0; batchStart < bounds.count; batchStart += 16) {
        if (changes() !== before) throw new Error('github_source_changed');
        // Consume each bounded SQL cursor before yielding to the digest stream.
        const batch = this.storage.sql.exec<{ row_id: number; source_version: number; reconciliation_epoch: number; record_type: string; record_key: string; value: string }>(
          `SELECT rowid AS row_id,source_version,reconciliation_epoch,record_type,record_key,value FROM github_source_journal
          WHERE subject_key=? AND source_version BETWEEN ? AND ? AND (source_version,record_type,record_key) > (?,?,?)
          ORDER BY source_version,record_type,record_key LIMIT 16`, key, fromVersion, toVersion, ...after).toArray();
        let chunk = '';
        for (const row of batch) {
          assertJournal(positiveInteger(row.source_version) && positiveInteger(row.reconciliation_epoch)
            && (anchorEpoch === undefined || row.reconciliation_epoch <= anchorEpoch));
          if (row.source_version !== version) {
            assertJournal(completeVersion && row.source_version === version + 1);
            version = row.source_version; epoch = null; completeVersion = false;
          }
          assertJournal(epoch === null || epoch === row.reconciliation_epoch);
          epoch = row.reconciliation_epoch;
          assertJournal(['version', 'finding', 'terminal', 'request', 'run'].includes(row.record_type));
          const item = retainedTransitionItem(row), value = item.value;
          if (item.recordType === 'version') {
            assertJournal(!completeVersion && Number(value.coverageStartVersion) <= version
              && (anchorEpoch === undefined || value.coverageStartVersion === 1));
            completeVersion = true;
          }
          const serialized = JSON.stringify(item), bytes = encoder.encode(serialized).length;
          const pageStart = pagePlan.append(bytes);
          chunk += serialized + '\n';
          if (pageStart === requestedOffset) items.push(item);
          assertJournal(Number.isSafeInteger(row.row_id) && row.row_id > 0);
          rowIds.push(row.row_id);
          offset++;
          after = [row.source_version, row.record_type, row.record_key];
        }
        await writer.write(encoder.encode(chunk));
        if (changes() !== before) throw new Error('github_source_changed');
      }
      assertJournal(completeVersion && version === toVersion && offset === bounds.count && (anchorEpoch === undefined || epoch === anchorEpoch));
      pages = pagePlan.finish().pages;
      const requestedEnd = pages.get(requestedOffset);
      if (requestedEnd !== undefined) { foundPage = true; pageEnd = requestedEnd; }
      await writer.close();
      digest = await digestResult;
    } catch {
      await writer.abort().catch(() => undefined);
      await digestResult;
      const fresh = pin();
      if (!fresh || !['pending', 'accepted'].includes(fresh.state)) return { status: 'unavailable' };
      return { status: changes() !== before || fresh.request !== exactRequest ? 'conflict' : 'coverage_unavailable' };
    }
    if (!digest || !foundPage) return { status: 'conflict' };
    const currentPin = pin();
    if (!currentPin || !['pending', 'accepted'].includes(currentPin.state)) return { status: 'unavailable' };
    if (currentPin.request !== exactRequest || changes() !== before) return { status: 'conflict' };
    const rangeDigest = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
    if (cursor && cursor.rangeDigest !== rangeDigest) return { status: 'conflict' };
    retainedReadPlans.set(this.storage, { key: planKey, nonce: before, digest: rangeDigest, rowIds, pages });
    const complete = pageEnd === bounds.count;
    return { ...envelope, rangeDigest, items, nextCursor: complete ? null : { rangeDigest, offset: pageEnd }, complete };
  }
  /** Locator membership is readable only within the same current coverage as source metadata. */
  materialReadWitness(request: Omit<GitHubSourceReadRequest, 'cursor'> & { sourceId: string; fingerprint: string }, firstVersion: number,
    authority: { revision: string; policyRevision: string }): string | null {
    if (firstVersion < request.fromVersion || firstVersion > request.toVersion) return null;
    const page = this.readSource({ subject: request.subject, fromVersion: request.fromVersion, toVersion: request.toVersion }, authority);
    if (page.status !== 'ok') return null;
    const row = this.storage.sql.exec<{ value: string; reconciliation_epoch: number }>(
      "SELECT value,reconciliation_epoch FROM github_source_journal WHERE subject_key=? AND source_version=? AND record_type='finding' AND record_key=?",
      subjectKey(request.subject), firstVersion, JSON.stringify(request.sourceId),
    ).toArray()[0];
    if (!row) return null;
    try {
      const finding = projectGitHubSourceRecord('finding', JSON.parse(row.value)) as { sourceId: string; to: JournalFinding };
      if (finding.sourceId !== request.sourceId || finding.to.presence !== 'present' || finding.to.fingerprint !== request.fingerprint) return null;
      return JSON.stringify([page.requestedRange, page.coverageStartVersion, page.anchor, row]);
    } catch { return null; }
  }
  /** Bounded metadata only. octet_length reads SQLite record size without scanning/loading the text. */
  findingMaterialStamp(sourceId: string, fingerprint: string): { status: 'available' | 'deleted' | 'unavailable'; firstVersion: number; generation: string; stamp: string } {
    const changes = this.storage.sql.exec<{ n: number }>('SELECT total_changes() AS n').one().n;
    const lifetime = materialLifetime(this.storage);
    const row = this.storage.sql.exec<{ bytes: number | null; body_type: string; first_version: number; deleted_at: number | null; expired: number }>(
      `SELECT octet_length(body) AS bytes,typeof(body) AS body_type,first_version,deleted_at,
        CASE WHEN resolved_at<=? AND NOT EXISTS (SELECT 1 FROM github_outbox)
        AND NOT EXISTS (SELECT 1 FROM github_initial_reconciliation_pins)
      AND NOT EXISTS (SELECT 1 FROM github_handoffs WHERE request IS NOT NULL) THEN 1 ELSE 0 END AS expired
        FROM github_finding_material WHERE source_id=? AND fingerprint=?`,
      Date.now() - EVENT_POLICY_V1.terminalDeduplicationRetentionMs, sourceId, fingerprint,
    ).toArray()[0];
    const valid = Number.isSafeInteger(changes) && changes >= 0 && !!lifetime && !!row && positiveInteger(row.first_version);
    const status = !valid ? 'unavailable' : row.deleted_at !== null ? 'deleted'
      : row.expired || row.body_type !== 'text' || !Number.isSafeInteger(row.bytes) || row.bytes! < 0 || row.bytes! > GITHUB_SOURCE_LIMITS.observationBytes ? 'unavailable' : 'available';
    return Object.freeze({ status, firstVersion: valid ? row.first_version : 0, generation: JSON.stringify([changes, lifetime]),
      stamp: JSON.stringify([changes, lifetime, sourceId, fingerprint, row ?? null, status]) });
  }
  /** Internal only: the caller must enforce current owner/agent/source read authority. */
  readFindingMaterial(sourceId: string, fingerprint: string): { status: 'available'; body: string; firstVersion: number } | { status: 'deleted'; firstVersion: number } | { status: 'unavailable' } {
    const row = this.storage.sql.exec<{ body: string | null; first_version: number; deleted_at: number | null }>(
      `SELECT CASE WHEN resolved_at<=? AND NOT EXISTS (SELECT 1 FROM github_outbox)
        AND NOT EXISTS (SELECT 1 FROM github_initial_reconciliation_pins)
      AND NOT EXISTS (SELECT 1 FROM github_handoffs WHERE request IS NOT NULL) THEN NULL ELSE body END AS body,
        first_version,deleted_at FROM github_finding_material WHERE source_id=? AND fingerprint=?`,
      Date.now() - EVENT_POLICY_V1.terminalDeduplicationRetentionMs, sourceId, fingerprint,
    ).toArray()[0];
    if (!row || !positiveInteger(row.first_version)) return { status: 'unavailable' };
    if (row.deleted_at !== null) return { status: 'deleted', firstVersion: row.first_version };
    return row.body === null ? { status: 'unavailable' } : { status: 'available', body: row.body, firstVersion: row.first_version };
  }
  private retainFindingMaterials(materials: NonNullable<GitHubObservationV1['findingMaterials']>, observation: GitHubObservationV1, version: number, now: number): void {
    const findings = new Map(observation.findings.map(finding => [finding.sourceId, finding]));
    const seen = new Set<string>();
    for (const material of materials) {
      const finding = findings.get(material?.sourceId);
      if (!material || Object.keys(material).toSorted().join(',') !== 'body,fingerprint,sourceId' || !finding || finding.fingerprint !== material.fingerprint || typeof material.body !== 'string' || seen.has(material.sourceId)) throw new Error('github_invalid_material');
      if (new TextEncoder().encode(material.body).length > GITHUB_SOURCE_LIMITS.observationBytes) throw new Error('github_capacity');
      seen.add(material.sourceId);
      const prior = this.storage.sql.exec<{ body: string | null; deleted_at: number | null }>('SELECT body,deleted_at FROM github_finding_material WHERE source_id=? AND fingerprint=?', material.sourceId, material.fingerprint).toArray()[0];
      if (prior && prior.deleted_at === null && prior.body !== null && prior.body !== material.body) throw new Error('github_invalid_material');
      this.storage.sql.exec('INSERT OR IGNORE INTO github_finding_material(source_id,fingerprint,body,first_version,resolved_at,deleted_at) VALUES(?,?,?,?,NULL,NULL)', material.sourceId, material.fingerprint, material.body, version);
    }
    // A source edit/deletion cannot settle the original finding; only explicit resolved evidence can.
    for (const finding of observation.findings) {
      this.storage.sql.exec(`UPDATE github_finding_material SET resolved_at=${finding.disposition === 'resolved' ? 'COALESCE(resolved_at,?)' : '?'} WHERE source_id=?`, finding.disposition === 'resolved' ? now : null, finding.sourceId);
    }
    const size = this.storage.sql.exec<{ rows: number; bytes: number }>('SELECT count(*) AS rows,COALESCE(sum(length(CAST(body AS BLOB))),0) AS bytes FROM github_finding_material').one();
    if (size.rows > GITHUB_SOURCE_LIMITS.findings || size.bytes > GITHUB_SOURCE_LIMITS.journalBytes) throw new Error('github_capacity');
  }
  findings(): RetainedFindingV1[] { return this.storage.sql.exec<{ value: string }>('SELECT value FROM github_findings ORDER BY id').toArray().map(row => JSON.parse(row.value) as RetainedFindingV1); }
  pending(): GitHubAttentionV1[] { return this.storage.sql.exec<{ value: string }>('SELECT value FROM github_outbox ORDER BY id').toArray().map(row => JSON.parse(row.value) as GitHubAttentionV1); }
  publicationAuthority(id: string): { revision: string; policy_revision: string } | null {
    return this.storage.sql.exec<{ revision: string; policy_revision: string }>('SELECT revision,policy_revision FROM github_publication_authority WHERE id=?', id).toArray()[0] ?? null;
  }
  private pruneJournalVersions(key: string, committedAt: number): void {
    const cutoff = committedAt - EVENT_POLICY_V1.terminalDeduplicationRetentionMs;
    this.storage.sql.exec(`UPDATE github_finding_material SET body=NULL WHERE deleted_at IS NULL AND body IS NOT NULL AND resolved_at<=?
      AND NOT EXISTS (SELECT 1 FROM github_outbox)
      AND NOT EXISTS (SELECT 1 FROM github_initial_reconciliation_pins)
      AND NOT EXISTS (SELECT 1 FROM github_handoffs WHERE request IS NOT NULL)`, cutoff);
    this.storage.sql.exec(`DELETE FROM github_source_journal
      WHERE subject_key=? AND source_version IN (
        SELECT j.source_version FROM github_source_journal AS j
        WHERE j.subject_key=? AND j.record_type='version' AND j.committed_at<=?
          AND NOT EXISTS (SELECT 1 FROM github_initial_reconciliation_pins AS p WHERE j.source_version BETWEEN 1 AND json_extract(p.obligation,'$.toVersion'))
          AND NOT EXISTS (
            SELECT 1 FROM github_outbox AS o
            WHERE json_extract(o.value,'$.sourceVersion')<=j.source_version
          )
          AND NOT EXISTS (
            SELECT 1 FROM github_handoffs AS h
            WHERE h.request IS NOT NULL AND json_extract(h.request,'$.event.sourceVersion')<=j.source_version
          )
      )`, key, key, cutoff);
  }
  private nextJournalCleanupAtFor(key: string): number | null {
    const oldest = this.storage.sql.exec<{ oldest: number | null }>(`SELECT MIN(j.committed_at) AS oldest FROM github_source_journal AS j
      WHERE j.subject_key=? AND j.record_type='version'
      AND NOT EXISTS (SELECT 1 FROM github_initial_reconciliation_pins AS p WHERE j.source_version BETWEEN 1 AND json_extract(p.obligation,'$.toVersion'))
      AND NOT EXISTS (
        SELECT 1 FROM github_outbox AS o WHERE json_extract(o.value,'$.sourceVersion')<=j.source_version
      ) AND NOT EXISTS (
        SELECT 1 FROM github_handoffs AS h
        WHERE h.request IS NOT NULL AND json_extract(h.request,'$.event.sourceVersion')<=j.source_version
      )`, key).one().oldest;
    const materialOldest = this.storage.sql.exec<{ oldest: number | null }>(`SELECT MIN(resolved_at) AS oldest FROM github_finding_material
      WHERE body IS NOT NULL AND deleted_at IS NULL AND NOT EXISTS (SELECT 1 FROM github_outbox)
      AND NOT EXISTS (SELECT 1 FROM github_initial_reconciliation_pins)
      AND NOT EXISTS (SELECT 1 FROM github_handoffs WHERE request IS NOT NULL)`).one().oldest;
    if (oldest === null && materialOldest === null) return null;
    const dueAt = Math.min(oldest ?? Infinity, materialOldest ?? Infinity) + EVENT_POLICY_V1.terminalDeduplicationRetentionMs;
    return safeInteger(dueAt) ? dueAt : null;
  }
  /** Storage-only retention work, safe to run after source authority has been revoked. */
  pruneExpiredJournal(now = Date.now()): void {
    const current = this.snapshot();
    if (!current) return;
    const committedAt = Math.max(now, Date.now());
    this.storage.transactionSync(() => {
      const key = subjectKey(current.subject);
      this.pruneJournalVersions(key, committedAt);
    });
  }
  /** Earliest expiry among unpinned journal versions, if any. */
  nextJournalCleanupAt(): number | null {
    const current = this.snapshot();
    return current ? this.nextJournalCleanupAtFor(subjectKey(current.subject)) : null;
  }
  acknowledgePublication(id: string, event: Pick<GitHubAttentionV1, 'publicationId' | 'subject' | 'sourceVersion'>): void {
    this.storage.transactionSync(() => {
      const handoff = this.storage.sql.exec<{ request: string | null; state: string }>('SELECT request,state FROM github_handoffs WHERE id=?', id).toArray()[0];
      if (!handoff?.request || !event || event.publicationId !== id || !validSubject(event.subject) || !positiveInteger(event.sourceVersion))
        throw new Error('github_publication_pin_missing');
      const stored = JSON.parse(handoff.request) as { event?: Pick<GitHubAttentionV1, 'publicationId' | 'subject' | 'sourceVersion'> };
      if (!stored.event || stored.event.publicationId !== event.publicationId || stored.event.sourceVersion !== event.sourceVersion ||
        subjectKey(stored.event.subject) !== subjectKey(event.subject)) throw new Error('github_publication_pin_conflict');
      const outbox = this.storage.sql.exec<{ value: string }>('SELECT value FROM github_outbox WHERE id=?', id).toArray()[0];
      if (outbox) {
        const pending = JSON.parse(outbox.value) as GitHubAttentionV1;
        if (pending.publicationId !== event.publicationId || pending.sourceVersion !== event.sourceVersion || subjectKey(pending.subject) !== subjectKey(event.subject))
          throw new Error('github_publication_pin_conflict');
      } else if (handoff.state !== 'accepted' && handoff.state !== 'release_pending' && handoff.state !== 'pending') {
        throw new Error('github_publication_conflict');
      }
      this.storage.sql.exec("UPDATE github_handoffs SET state='accepted',reason='coordinator_accepted' WHERE id=? AND request IS NOT NULL", id);
      this.storage.sql.exec('DELETE FROM github_outbox WHERE id=?', id);
      this.storage.sql.exec('DELETE FROM github_publication_authority WHERE id=?', id);
      this.storage.sql.exec('DELETE FROM github_publication_created WHERE id=?', id);
    });
  }
  /** Persist the exact metadata request before the first coordinator RPC; its source-version suffix is now pinned. */
  acquirePublicationPin(id: string, request: { event: Pick<GitHubAttentionV1, 'publicationId' | 'subject' | 'sourceVersion'> }, now = Date.now()): void {
    const event = request?.event;
    assertJournal(typeof id === 'string' && id.length > 0 && event?.publicationId === id && validSubject(event.subject) && positiveInteger(event.sourceVersion));
    const value = JSON.stringify(request), key = subjectKey(event.subject);
    this.storage.transactionSync(() => {
      const current = this.snapshot();
      assertJournal(current && subjectKey(current.subject) === key && event.sourceVersion <= current.version);
      const coverage = this.storage.sql.exec<{ count: number; first: number | null; last: number | null; incomplete: number }>(`SELECT
        count(*) AS count,MIN(source_version) AS first,MAX(source_version) AS last,
        sum(CASE WHEN json_extract(value,'$.complete') IS NOT 1 THEN 1 ELSE 0 END) AS incomplete
        FROM github_source_journal WHERE subject_key=? AND record_type='version' AND source_version BETWEEN ? AND ?`,
      key, event.sourceVersion, current.version).one();
      assertJournal(coverage.count === current.version - event.sourceVersion + 1 && coverage.first === event.sourceVersion &&
        coverage.last === current.version && coverage.incomplete === 0);
      const prior = this.storage.sql.exec<{ request: string | null }>('SELECT request FROM github_handoffs WHERE id=?', id).toArray()[0];
      if (prior?.request !== null && prior?.request !== undefined) {
        if (prior.request !== value) throw new Error('github_publication_conflict');
        return;
      }
      const pins = this.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_handoffs WHERE request IS NOT NULL').one().n;
      assertJournalCapacity(pins < GITHUB_SOURCE_LIMITS.outbox);
      this.storage.sql.exec(`INSERT INTO github_handoffs(id,request,reason,checked_at,state) VALUES (?,?,?,?,'pending')
        ON CONFLICT(id) DO UPDATE SET request=excluded.request,reason=excluded.reason,checked_at=excluded.checked_at,state='pending'`,
      id, value, 'publication_pending', now);
    });
  }
  /** The source pin remains until exact coordinator disposition and release acknowledgment. */
  markPublicationReleasePending(id: string, disposition: 'settled' | 'terminal'): boolean {
    return this.storage.transactionSync(() => {
      const row = this.storage.sql.exec<{ state: string; reason: string }>('SELECT state,reason FROM github_handoffs WHERE id=? AND request IS NOT NULL', id).toArray()[0];
      if (!row) return false;
      const reason = disposition === 'settled' ? 'release_pending_settled' : 'release_pending_terminal';
      if (row.state === 'release_pending') {
        const prior = row.reason === 'release_pending_settled' ? 'settled' : row.reason === 'release_pending_terminal' ? 'terminal' : null;
        if (prior !== null && prior !== disposition) throw new Error('github_publication_state_conflict');
        // A validated coordinator disposition may upgrade an older ambiguous release_pending row.
        this.storage.sql.exec("UPDATE github_handoffs SET reason=? WHERE id=? AND state='release_pending'", reason, id);
        return true;
      }
      if (row.state !== 'accepted') throw new Error('github_publication_conflict');
      this.storage.sql.exec("UPDATE github_handoffs SET state='release_pending',reason=? WHERE id=?", reason, id);
      return true;
    });
  }
  /** Returns only an exact release disposition persisted before the coordinator ACK RPC. */
  publicationReleaseDisposition(id: string): 'settled' | 'terminal' | null {
    const row = this.storage.sql.exec<{ state: string; reason: string }>('SELECT state,reason FROM github_handoffs WHERE id=? AND request IS NOT NULL', id).toArray()[0];
    if (row?.state !== 'release_pending') return null;
    return row.reason === 'release_pending_settled' ? 'settled' : row.reason === 'release_pending_terminal' ? 'terminal' : null;
  }
  /** Called only after an exact validated coordinator release acknowledgment. */
  releasePublicationPin(id: string): void {
    this.storage.transactionSync(() => {
      const current = this.snapshot();
      const key = current ? subjectKey(current.subject) : null;
      this.storage.sql.exec("DELETE FROM github_handoffs WHERE id=? AND state='release_pending'", id);
      if (key) this.pruneJournalVersions(key, Math.max(Date.now(), current?.lastSuccess ?? 0));
    });
  }
  /** Expired pending work may be archived; accepted obligations may never use this path. */
  discardUnacceptedPublication(id: string): boolean {
    return this.storage.transactionSync(() => {
      const row = this.storage.sql.exec<{ state: string }>('SELECT state FROM github_handoffs WHERE id=?', id).toArray()[0];
      if (row && row.state !== 'pending') return false;
      this.storage.sql.exec('DELETE FROM github_outbox WHERE id=?', id);
      this.storage.sql.exec('DELETE FROM github_publication_authority WHERE id=?', id);
      this.storage.sql.exec('DELETE FROM github_publication_created WHERE id=?', id);
      this.storage.sql.exec('DELETE FROM github_handoffs WHERE id=? AND state=\'pending\'', id);
      return true;
    });
  }
  async retryPublications(at: number, preserveEarlierAlarm = false): Promise<void> {
    await this.storage.transaction(async () => {
      const earlierAlarm = preserveEarlierAlarm ? await this.storage.getAlarm() : null;
      if (this.pending().length) this.storage.sql.exec('INSERT OR REPLACE INTO github_publication_retry(id,due_at) VALUES (1,?)', at);
      else this.storage.sql.exec('DELETE FROM github_publication_retry WHERE id=1');
      await this.armCurrent();
      if (earlierAlarm !== null) {
        const scheduled = await this.storage.getAlarm();
        if (scheduled === null || scheduled > earlierAlarm) await this.storage.setAlarm(earlierAlarm);
      }
    });
  }
  private alarmAt(sourceDue: number): number {
    const retry = this.storage.sql.exec<{ due_at: number }>('SELECT due_at FROM github_publication_retry WHERE id=1').toArray()[0];
    const journalDue = this.nextJournalCleanupAt();
    return Math.min(sourceDue, retry?.due_at ?? Infinity, journalDue ?? Infinity);
  }
  private save(snapshot: Snapshot): void { this.storage.sql.exec('INSERT OR REPLACE INTO github_state (id,value) VALUES (1,?)', JSON.stringify(snapshot)); }
  private appendJournal(subject: GitHubSubjectV1, previous: GitHubObservationV1 | null, observation: GitHubObservationV1, version: number, epoch: number, generation: number, now: number): void {
    const key = subjectKey(subject), committedAt = Math.max(now, Date.now());
    assertJournal(validSubject(subject) && subjectKey(observation.subject) === key && positiveInteger(version) && positiveInteger(epoch) &&
      safeInteger(generation) && safeInteger(committedAt) && observation.epoch === epoch);
    this.pruneJournalVersions(key, committedAt);
    const survivingHeaders = this.storage.sql.exec<{ source_version: number; value: string }>(
      "SELECT source_version,value FROM github_source_journal WHERE subject_key=? AND record_type='version' AND source_version<? ORDER BY source_version DESC", key, version,
    ).toArray();
    let coverageStartVersion = version, expectedVersion = version - 1;
    for (const header of survivingHeaders) {
      if (header.source_version !== expectedVersion) break;
      const parsed = JSON.parse(header.value) as { complete?: unknown; coverageStartVersion?: unknown };
      assertJournal(parsed.complete === true && positiveInteger(parsed.coverageStartVersion) && parsed.coverageStartVersion <= header.source_version);
      // Older headers are immutable: their marker may predate a prefix pruned
      // in this commit, so the current range begins at the physical suffix.
      coverageStartVersion = header.source_version;
      expectedVersion--;
    }
    const previousInJournal = coverageStartVersion < version ? previous : null;
    const entries = journalEntries(previousInJournal, observation, generation, coverageStartVersion);
    // Include JSON escaping and duplicated identities before committing evidence that must fit a read page.
    for (const entry of [...entries, ...journalEntries(null, observation, generation, coverageStartVersion)]) {
      const item = { phase: 'transition', sourceVersion: version, epoch, recordType: entry.type, recordKey: entry.key, value: entry.value };
      assertJournalCapacity(new TextEncoder().encode(JSON.stringify(item)).length <= GITHUB_SOURCE_LIMITS.journalEntryBytes);
    }
    for (const entry of entries) {
      assertJournalCapacity(new TextEncoder().encode(entry.key).length <= GITHUB_SOURCE_LIMITS.journalEntryBytes);
      const value = JSON.stringify(entry.value);
      assertJournalCapacity(new TextEncoder().encode(value).length <= GITHUB_SOURCE_LIMITS.journalEntryBytes);
      this.storage.sql.exec(`INSERT INTO github_source_journal
        (subject_key,source_version,reconciliation_epoch,committed_at,record_type,record_key,value)
        VALUES (?,?,?,?,?,?,?)`, key, version, epoch, committedAt, entry.type, entry.key, value);
    }
    const size = this.storage.sql.exec<{ rows: number; bytes: number }>(
      'SELECT count(*) AS rows, COALESCE(sum(length(CAST(value AS BLOB))),0) AS bytes FROM github_source_journal',
    ).one();
    assertJournalCapacity(size.rows <= GITHUB_SOURCE_LIMITS.journalRows && size.bytes <= GITHUB_SOURCE_LIMITS.journalBytes);
  }
  /** Storage-only scheduler, also used inside receipt/failure transactions. */
  private async armCurrent(): Promise<number | null> {
    let current = this.snapshot();
    while (current) {
      if (!this.sourceAuthorityLocallyCurrent()) throw new Error('github_source_fenced');
      await this.storage.setAlarm(this.alarmAt(current.dueAt));
      if (!this.sourceAuthorityLocallyCurrent()) throw new Error('github_source_fenced');
      const latest = this.snapshot();
      if (latest?.epoch === current.epoch && latest.dueAt === current.dueAt) return current.epoch;
      current = latest;
    }
    return null;
  }
  /** An optional state update and its alarm commit in the same transaction. */
  private async armCommitted(update?: () => void): Promise<void> {
    while (true) {
      const armedEpoch = await this.storage.transaction(async () => {
        if (!this.sourceAuthorityLocallyCurrent()) return null;
        update?.();
        if (!this.sourceAuthorityLocallyCurrent()) throw new Error('github_source_fenced');
        return this.armCurrent();
      });
      update = undefined;
      if (this.snapshot()?.epoch === armedEpoch || armedEpoch === null) return;
    }
  }
  private async authorize(subject: GitHubSubjectV1, parentDeadline?: EventRequestDeadline): Promise<GitHubAdmissionV1 | null> {
    const deadline = parentDeadline ?? new EventRequestDeadline(10_000);
    try {
      const admission = await deadline.run(() => this.source.authorize(subject, deadline), 10_000);
      return admission?.mergeQueue === 'excluded' ? admission : null;
    } finally { if (!parentDeadline) deadline.dispose(); }
  }
  private async sourceAuthorityCurrent(): Promise<boolean> {
    return !this.sourceGuard || await this.sourceGuard();
  }
  private sourceAuthorityLocallyCurrent(): boolean {
    return !this.sourceGuardLocal || this.sourceGuardLocal();
  }
  private canAdvanceEpoch(epoch: number): boolean {
    return safeInteger(epoch) && epoch < Number.MAX_SAFE_INTEGER;
  }
  private canClaimSourceEpoch(): boolean {
    try { return this.sourceClaimGuard?.() ?? true; } catch { return false; }
  }
  async attach(subject: GitHubSubjectV1, now = Date.now(), initializeOnly = false): Promise<void> {
    const deadline = new EventRequestDeadline(10_000);
    try {
      if (!await this.sourceAuthorityCurrent()) throw new Error('github_source_fenced');
      if (!validSubject(subject)) throw new Error('github_denied');
      const admission = await this.authorize(subject, deadline);
      if (!admission) throw new Error('github_denied');
      if (!await this.sourceAuthorityCurrent()) throw new Error('github_source_fenced');
      const current = await this.authorize(subject, deadline);
      if (!current || current.revision !== admission.revision || current.policyRevision !== admission.policyRevision
        || !await this.sourceAuthorityCurrent()) throw new Error('github_denied');
      await this.storage.transaction(async () => {
        if (!this.sourceAuthorityLocallyCurrent()) throw new Error('github_source_fenced');
        const latest = this.snapshot();
        if (latest && subjectKey(latest.subject) !== subjectKey(subject)) throw new Error('github_subject_conflict');
        if (latest && !initializeOnly && !this.canAdvanceEpoch(latest.epoch)) throw new Error('github_source_fenced');
        // No provider/coordinator RPC is allowed while the SQLite transaction is open.
        const previousAlarm = initializeOnly ? await this.storage.getAlarm() : null;
        const due = this.alarmAt(initializeOnly && latest ? latest.dueAt : now);
        await deadline.run(() => this.storage.setAlarm(initializeOnly && previousAlarm !== null ? Math.min(previousAlarm, due) : due), 10_000);
        if (!this.sourceAuthorityLocallyCurrent()) throw new Error('github_source_fenced');
        const latestAtCommit = this.snapshot();
        if (latestAtCommit && subjectKey(latestAtCommit.subject) !== subjectKey(subject)) throw new Error('github_subject_conflict');
        if (initializeOnly && latestAtCommit) return;
        if (latestAtCommit && !this.canAdvanceEpoch(latestAtCommit.epoch)) throw new Error('github_source_fenced');
        this.save(latestAtCommit ? { ...latestAtCommit, epoch: latestAtCommit.epoch + 1, dueAt: now } : createInitialGitHubSnapshot(subject, now));
      });
    } finally { deadline.dispose(); }
  }
  async accept(trigger: GitHubTriggerV1, now = Date.now()): Promise<'accepted' | 'denied'> {
    const deadline = new EventRequestDeadline(10_000);
    try {
      if (!await this.sourceAuthorityCurrent()) return 'denied';
      const current = this.snapshot();
      const matches = (snapshot: Snapshot | null) => !!snapshot && trigger.installationId === snapshot.subject.installationId && trigger.repositoryId === snapshot.subject.repositoryId &&
        (trigger.prNumber !== null ? trigger.prNumber === snapshot.subject.prNumber : !!trigger.commitSha && [snapshot.observation?.candidate.headSha, snapshot.observation?.candidate.observedMergeSha].includes(trigger.commitSha));
      if (!current || !matches(current)) return 'denied';
      const admission = await this.authorize(current.subject, deadline);
      if (!admission) return 'denied';
      if (!await this.sourceAuthorityCurrent()) return 'denied';
      const currentAdmission = await this.authorize(current.subject, deadline);
      if (!currentAdmission || currentAdmission.revision !== admission.revision || currentAdmission.policyRevision !== admission.policyRevision
        || !await this.sourceAuthorityCurrent()) return 'denied';
      await this.storage.transaction(async () => {
        if (!this.sourceAuthorityLocallyCurrent()) throw new Error('github_denied');
        // Duplicate receipts stay quiet after the initial fresh authorization.
        if (this.storage.sql.exec('SELECT 1 FROM github_receipts WHERE id=?', trigger.deliveryId).toArray().length) return;
        const latest = this.snapshot();
        if (!latest || !matches(latest) || !this.canAdvanceEpoch(latest.epoch) || !this.canClaimSourceEpoch()) throw new Error('github_denied');
        await deadline.run(() => this.storage.setAlarm(this.alarmAt(now)), 10_000);
        const latestAtCommit = this.snapshot();
        if (!this.sourceAuthorityLocallyCurrent() || !latestAtCommit || !matches(latestAtCommit)
          || latestAtCommit.epoch !== latest.epoch || !this.canAdvanceEpoch(latestAtCommit.epoch) || !this.canClaimSourceEpoch()) throw new Error('github_denied');
        this.storage.sql.exec('DELETE FROM github_receipts WHERE received_at < ?', now - 7 * 86400_000);
        if (this.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_receipts').one().n >= GITHUB_SOURCE_LIMITS.receipts) throw new Error('github_capacity');
        this.storage.sql.exec('INSERT INTO github_receipts (id,received_at) VALUES (?,?)', trigger.deliveryId, now);
        this.save({ ...latestAtCommit, epoch: latestAtCommit.epoch + 1, dueAt: now });
      });
      return 'accepted';
    } catch (error) {
      if (error instanceof Error && error.message === 'github_denied') return 'denied';
      throw error;
    } finally { deadline.dispose(); }
  }
  async reconcile(now = Date.now()): Promise<void> {
    if (!this.sourceAuthorityLocallyCurrent() || !this.canClaimSourceEpoch() || !await this.sourceAuthorityCurrent()
      || !this.sourceAuthorityLocallyCurrent() || !this.canClaimSourceEpoch()) return;
    const initial = this.snapshot();
    if (!initial || !this.sourceAuthorityLocallyCurrent()) return;
    // Recover a crash after the bounded read. Keep the local epoch claim and
    // alarm atomic, and do not hold the transaction across provider/coordinator RPCs.
    const started = await this.storage.transaction(async () => {
      if (!this.sourceAuthorityLocallyCurrent() || !this.canClaimSourceEpoch()) return null;
      const latest = this.snapshot();
      // A source-only guard may have completed before canonical ownership changed.
      // Reserve the increment even when no watch-specific claim guard is supplied.
      if (!latest || latest.epoch !== initial.epoch || !this.canAdvanceEpoch(latest.epoch) || !this.canClaimSourceEpoch()) return null;
      await this.storage.setAlarm(this.alarmAt(now + 60_000));
      // An authority transition can re-enter while the alarm write yields.
      // Throwing rolls back that alarm together with this claim, so an old
      // poll cannot leave a wake behind after stop or disable.
      if (!this.sourceAuthorityLocallyCurrent() || !this.canClaimSourceEpoch()) throw new Error('github_source_fenced');
      const latestAfterAlarm = this.snapshot();
      if (!latestAfterAlarm || latestAfterAlarm.epoch !== latest.epoch || !this.canAdvanceEpoch(latestAfterAlarm.epoch)) throw new Error('github_source_fenced');
      const claimed = { ...latest, epoch: latest.epoch + 1, dueAt: now + 60_000 };
      this.save(claimed);
      return claimed;
    });
    if (!started) return;
    const epoch = started.epoch;
    const deadline = new EventRequestDeadline(50_000);
    let retryAt = 0;
    let completeness: GitHubCompletenessV1 | null = null;
    try {
      const admission = await this.authorize(started.subject, deadline);
      if (!this.sourceAuthorityLocallyCurrent() || this.snapshot()?.epoch !== epoch) return;
      if (!admission) throw new Error('github_denied');
      // Promotion or stop may have advanced authority while admission was waiting.
      // The final coordinator and local guards must run immediately before provider I/O.
      if (!this.sourceAuthorityLocallyCurrent() || !await this.sourceAuthorityCurrent()
        || !this.sourceAuthorityLocallyCurrent() || this.snapshot()?.epoch !== epoch) return;
      const observed = await deadline.run(() => this.source.observe(started.subject, admission.policyRevision, epoch), 30_000);
      if (!this.sourceAuthorityLocallyCurrent() || this.snapshot()?.epoch !== epoch) return;
      const { findingMaterials = [], ...observation } = observed;
      if (new TextEncoder().encode(JSON.stringify(observed)).length > GITHUB_SOURCE_LIMITS.observationBytes) throw new Error('github_capacity');
      retryAt = observation.retryAt ?? 0;
      completeness = observation.completeness;
      if (observation.schemaVersion !== 1 || observation.epoch !== epoch || subjectKey(observation.subject) !== subjectKey(started.subject) || observation.candidate.policyRevision !== admission.policyRevision || GITHUB_ENDPOINTS.some(key => observation.completeness[key] !== 'complete')) throw new Error('github_incomplete');
      if (!await this.sourceAuthorityCurrent() || !this.sourceAuthorityLocallyCurrent() || this.snapshot()?.epoch !== epoch) return;
      const dueAt = now + POLL_MS + Math.floor(this.random() * 60_001) - 30_000;
      // An older read must not move an alarm past newer webhook work.
      if (this.snapshot()?.epoch !== epoch) return;
      const currentAdmission = await this.authorize(started.subject, deadline);
      if (!this.sourceAuthorityLocallyCurrent() || this.snapshot()?.epoch !== epoch) return;
      if (!currentAdmission || currentAdmission.revision !== admission.revision || currentAdmission.policyRevision !== admission.policyRevision
        || !await this.sourceAuthorityCurrent() || !this.sourceAuthorityLocallyCurrent() || this.snapshot()?.epoch !== epoch) throw new Error('github_denied');
      this.storage.transactionSync(() => {
        if (!this.sourceAuthorityLocallyCurrent()) throw new Error('github_source_fenced');
        const latest = this.snapshot()!;
        if (latest.epoch !== epoch) return;
        const generation = latest.generation + Number(!latest.observation || candidateKey(latest.observation.candidate) !== candidateKey(observation.candidate));
        const version = latest.version + 1;
        const reasons = new Set<GitHubAttentionV1['reasonCode']>();
        const oldRequests = new Set(latest.observation?.reviewRequests?.map(request => JSON.stringify([request.kind, request.sourceId])));
        if (observation.reviewRequests.some(request => !oldRequests.has(JSON.stringify([request.kind, request.sourceId])))) reasons.add('review_requested');
        const retained = new Map(this.findings().map(finding => [finding.sourceId, finding]));
        for (const finding of observation.findings) {
          const previous = retained.get(finding.sourceId);
          if (finding.disposition === 'open' && (!previous || previous.fingerprint !== finding.fingerprint || previous.disposition !== 'open')) reasons.add(finding.kind === 'review' ? 'review_submitted' : 'review_comment');
          const next = { ...finding, discoveryGeneration: previous?.discoveryGeneration ?? generation };
          this.storage.sql.exec('INSERT OR REPLACE INTO github_findings (id,value) VALUES (?,?)', finding.sourceId, JSON.stringify(next));
        }
        if (this.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_findings').one().n > GITHUB_SOURCE_LIMITS.findings) throw new Error('github_capacity');
        // Missing/deleted/outdated source records never dispose retained findings.
        // Batch matrix failures within this observation, but never hide a newly failing source.
        const oldFailures = new Set(latest.observation?.runs.filter(failed).map(run => JSON.stringify(run)));
        for (const run of observation.runs.filter(failed)) if (!oldFailures.has(JSON.stringify(run))) reasons.add(run.kind === 'status' ? 'status_failed' : 'check_failed');
        if (observation.state !== 'open' && observation.state !== latest.observation?.state) reasons.add(observation.state === 'merged' ? 'pull_request_merged' : 'pull_request_closed');
        for (const reasonCode of this.createPublications ? reasons : []) {
          const event: GitHubAttentionV1 = { publicationId: `${subjectKey(started.subject)}:${version}:${reasonCode}`, subject: started.subject, sourceVersion: version, candidateGeneration: generation, observedAt: observation.observedAt, eventKind: reasonCode.startsWith('pull_request_') ? 'terminal' : reasonCode.endsWith('_failed') ? 'ci' : 'attention', reasonCode };
          this.storage.sql.exec('INSERT INTO github_outbox (id,value) VALUES (?,?)', event.publicationId, JSON.stringify(event));
          this.storage.sql.exec('INSERT INTO github_publication_created(id,created_at) VALUES (?,?)', event.publicationId, Math.min(now, event.observedAt));
          this.storage.sql.exec('INSERT INTO github_publication_authority (id,revision,policy_revision) VALUES (?,?,?)', event.publicationId, admission.revision, admission.policyRevision);
          if (this.publicationsEnabled) this.storage.sql.exec('INSERT OR REPLACE INTO github_publication_retry(id,due_at) VALUES (1,?)', now);
        }
        if (this.storage.sql.exec<{ n: number }>('SELECT count(*) AS n FROM github_outbox').one().n > GITHUB_SOURCE_LIMITS.outbox) throw new Error('github_capacity');
        if (observed.findingMaterials !== undefined && findingMaterials.length !== observation.findings.length) throw new Error('github_invalid_material');
        this.appendJournal(started.subject, latest.observation, observation, version, epoch, generation, now);
        this.retainFindingMaterials(findingMaterials, observation, version, now);
        this.save({ ...latest, version, generation, observation, dueAt, failures: 0, lastSuccess: now, health: 'fresh', lastAttemptCompleteness: completeness, failureReason: null });
      });
      await this.armCommitted();
    } catch (error) {
      if (!await this.sourceAuthorityCurrent() || !this.sourceAuthorityLocallyCurrent()) return;
      const current = this.snapshot()!;
      if (current.epoch !== epoch) return;
      const failureAt = Math.max(now, Date.now());
      const hintedRetry = error && typeof error === 'object' && 'retryAt' in error ? Number(error.retryAt) : retryAt;
      const backoff = Math.min(900_000, 5000 * 2 ** Math.min(current.failures, 8));
      const jitteredBackoff = Math.min(900_000, Math.floor(backoff * (0.8 + 0.4 * this.random())));
      const dueAt = failureAt + Math.max(jitteredBackoff, Number.isFinite(hintedRetry) ? Math.min(3600_000, Math.max(0, hintedRetry - failureAt)) : 0);
      await this.armCommitted(() => {
        const latest = this.snapshot()!;
        if (latest.epoch !== epoch) return;
        this.save({ ...latest, dueAt, failures: latest.failures + 1, lastAttemptCompleteness: completeness, failureReason: error instanceof Error && error.message === 'github_denied' ? 'denied' : error instanceof Error && error.message === 'github_incomplete' ? 'incomplete' : error instanceof Error && error.message === 'github_capacity' ? 'capacity' : 'unavailable', health: error instanceof Error && error.message === 'github_denied' ? 'denied' : failureAt - (latest.lastSuccess ?? latest.firstAttachedAt) >= GITHUB_SOURCE_STALE_MS ? 'stale' : 'unknown' });
      });
    } finally { deadline.dispose(); }
  }
}
