import { assertGitHubHostStorageVersion } from './host-storage-version';
import { InitialWatchPreparationSchema, InitialWatchPreparationReceiptSchema,
  type InitialWatchPreparation, type InitialWatchPreparationReceipt } from './initial-watch-preparation';
import { WATCH_CONTROL_LIMITS } from './watch-control-internal';

export interface HostInitialPreparation { input: InitialWatchPreparation; state: 'prepared' | 'refused' | 'aborted' | 'committed'; receipt: InitialWatchPreparationReceipt }
/** Protected receipts share a fixed host bound. Generation survives receipt acknowledgment/collection. */
export class InitialWatchHostStore {
  constructor(private readonly storage: DurableObjectStorage) {}
  private exists(): boolean { return this.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE name='github_initial_watch_preparations'").toArray().length > 0; }
  private ensure(): void {
    assertGitHubHostStorageVersion(this.storage.sql);
    this.storage.sql.exec('CREATE TABLE IF NOT EXISTS github_initial_watch_prepare_generation(id INTEGER PRIMARY KEY CHECK(id=1),generation INTEGER NOT NULL)');
    this.storage.sql.exec('INSERT OR IGNORE INTO github_initial_watch_prepare_generation VALUES(1,0)');
    this.storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_initial_watch_preparations(operation_id TEXT PRIMARY KEY,
      request TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ('prepared','refused','aborted','committed')),receipt TEXT NOT NULL)`);
  }
  generation(): number {
    if (!this.storage.sql.exec("SELECT 1 FROM sqlite_master WHERE name='github_initial_watch_prepare_generation'").toArray().length) return 0;
    const value = this.storage.sql.exec<{ generation: number }>('SELECT generation FROM github_initial_watch_prepare_generation WHERE id=1').toArray()[0]?.generation;
    if (!Number.isSafeInteger(value) || value! < 0) throw new Error('github_source_conflict');
    return value!;
  }
  get(operationId: string): HostInitialPreparation | null {
    if (!this.exists()) return null;
    const row = this.storage.sql.exec<{ request: string; state: HostInitialPreparation['state']; receipt: string }>(
      'SELECT request,state,receipt FROM github_initial_watch_preparations WHERE operation_id=?', operationId).toArray()[0];
    if (!row) return null;
    const input = InitialWatchPreparationSchema.parse(JSON.parse(row.request));
    const receipt = InitialWatchPreparationReceiptSchema.parse(JSON.parse(row.receipt));
    if (input.request.operationId !== operationId || receipt.operationId !== operationId
      || JSON.stringify(receipt.token) !== JSON.stringify(input.promotion.token) || receipt.preparationGeneration !== input.preparationGeneration || receipt.manifestBytes !== input.manifestBytes
      || !['prepared', 'refused', 'aborted', 'committed'].includes(row.state)
      || receipt.status !== (row.state === 'committed' ? 'prepared' : row.state)
      || (receipt.status === 'prepared' || receipt.status === 'aborted' && receipt.effect === 'pinned')
        && (!receipt.obligation || receipt.obligation.toVersion < input.promotion.expectedSourceVersion
          || receipt.obligation.hostEpoch <= input.promotion.expectedHostEpoch)) throw new Error('github_source_conflict');
    return { input, state: row.state, receipt };
  }
  active(): HostInitialPreparation | null {
    if (!this.exists()) return null;
    const rows = this.storage.sql.exec<{ operation_id: string }>("SELECT operation_id FROM github_initial_watch_preparations WHERE state='prepared' LIMIT 2").toArray();
    if (rows.length > 1) throw new Error('github_source_conflict');
    return rows[0] ? this.get(rows[0].operation_id) : null;
  }
  record(input: InitialWatchPreparation, receipt: InitialWatchPreparationReceipt, state: 'prepared' | 'refused' | 'aborted'): void {
    const parsed = InitialWatchPreparationSchema.parse(input), result = InitialWatchPreparationReceiptSchema.parse(receipt);
    const request = JSON.stringify(parsed), serialized = JSON.stringify(result), id = parsed.request.operationId;
    if (result.operationId !== id || JSON.stringify(result.token) !== JSON.stringify(parsed.promotion.token)
      || result.preparationGeneration !== parsed.preparationGeneration || result.manifestBytes !== parsed.manifestBytes) throw new Error('github_source_conflict');
    this.storage.transactionSync(() => {
      this.ensure();
      const existing = this.get(id), generation = this.generation();
      if (existing && JSON.stringify(existing.input) !== request) throw new Error('github_source_conflict');
      if (existing?.state === state && JSON.stringify(existing.receipt) === serialized) return;
      if (existing && (state !== 'aborted' || existing.state !== 'prepared')) throw new Error('github_source_conflict');
      if (state === 'prepared' && generation > Number.MAX_SAFE_INTEGER - 2
        || generation !== (existing ? parsed.preparationGeneration + 1 : parsed.preparationGeneration)
        || generation >= Number.MAX_SAFE_INTEGER) throw new Error('github_source_conflict');
      if (!existing && this.active()) throw new Error('github_source_conflict');
      if (result.status !== state || result.status !== 'prepared' && result.nextPreparationGeneration !== generation + 1)
        throw new Error('github_source_conflict');
      const totals = this.storage.sql.exec<{ count: number; bytes: number }>(`SELECT count(*) AS count,
        COALESCE(sum(length(CAST(request AS BLOB))+length(CAST(receipt AS BLOB))),0) AS bytes FROM github_initial_watch_preparations WHERE operation_id!=?`, id).one();
      const terminal = result.status === 'prepared' ? { status: 'aborted', operationId: id, token: parsed.promotion.token,
        preparationGeneration: parsed.preparationGeneration, manifestBytes: parsed.manifestBytes, nextPreparationGeneration: Number.MAX_SAFE_INTEGER,
        effect: 'pinned', obligation: result.obligation } : result;
      const bytes = Math.max(new TextEncoder().encode(request + serialized).length,
        new TextEncoder().encode(request + JSON.stringify(terminal)).length);
      if (bytes > 2 * WATCH_CONTROL_LIMITS.hostProtectedBytes || totals.count >= WATCH_CONTROL_LIMITS.retainedOperations
        || (totals.count + 1) * 2 * WATCH_CONTROL_LIMITS.hostProtectedBytes > WATCH_CONTROL_LIMITS.retainedBytes) throw new Error('github_capacity');
      this.storage.sql.exec('UPDATE github_initial_watch_prepare_generation SET generation=? WHERE id=1', generation + 1);
      this.storage.sql.exec('INSERT OR REPLACE INTO github_initial_watch_preparations VALUES(?,?,?,?)', id, request, state, serialized);
      this.get(id); // Validate the persisted cross-bindings before committing.
    });
  }
  commit(input: InitialWatchPreparation): void {
    const row = this.get(input.request.operationId);
    if (!row || row.state !== 'prepared' || JSON.stringify(row.input) !== JSON.stringify(input)) throw new Error('github_source_conflict');
    this.storage.sql.exec("UPDATE github_initial_watch_preparations SET state='committed' WHERE operation_id=?", input.request.operationId);
  }
  acknowledgeNoEffect(input: InitialWatchPreparation, receipt: InitialWatchPreparationReceipt): void {
    input = InitialWatchPreparationSchema.parse(input); receipt = InitialWatchPreparationReceiptSchema.parse(receipt);
    const row = this.get(input.request.operationId);
    if (!row) {
      if (this.generation() <= input.preparationGeneration) throw new Error('github_source_conflict');
      return;
    }
    if (!['refused', 'aborted'].includes(row.state) || row.receipt.status === 'prepared' || row.receipt.effect !== 'none' || JSON.stringify(row.input) !== JSON.stringify(input)
      || JSON.stringify(row.receipt) !== JSON.stringify(receipt)) throw new Error('github_source_conflict');
    this.storage.sql.exec("DELETE FROM github_initial_watch_preparations WHERE operation_id=? AND state IN ('refused','aborted')", input.request.operationId);
  }
}
