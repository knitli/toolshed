import { AccessDenied, AccessUnavailable, canonicalEmail, identifier, type AccessPorts } from 'openapi-operator/src/access.ts';
import { configured, verifyAdminAssertionWithExpiry, verifyAdminMutation } from 'gatekeeper-memory/src/admin-security.ts';
import { productionPorts } from 'gatekeeper-memory/src/auth.ts';
import { parseAllowedPrincipals, principalAllowed } from 'gatekeeper-memory/src/principals.ts';
import type { EventAdminCall } from '../admin-types.ts';
import { parseOwnerAgentResult } from '../authority-client.ts';
import { agent, EventApiError, type EventApiEnvironment } from '../contracts.ts';
import type { EventRequestDeadline } from '../request-deadline.ts';
import type { WatchOperationKind } from './watch-control-internal.ts';

export type WatchOwnerIdentity = Readonly<{ principal: string; agent: string }>;
export type WatchOwnerEnvironment = Pick<EventApiEnvironment,
  'ACCESS_ISSUER' | 'ACCESS_UI_AUD' | 'ACCESS_EVENT_AUD' | 'ADMIN_UI_ORIGIN' | 'ALLOWED_PRINCIPALS' | 'MESSAGE_AUTHORITY'>;
type OwnerPolicySnapshot = Readonly<Pick<WatchOwnerEnvironment,
  'ACCESS_ISSUER' | 'ACCESS_UI_AUD' | 'ACCESS_EVENT_AUD' | 'ADMIN_UI_ORIGIN' | 'ALLOWED_PRINCIPALS'>>;
export type WatchOwnerProof = Readonly<{
  verifiedPrincipal: string;
  verifiedAgent: string;
  verifiedExpiresAtSeconds: number;
  verifiedAtSeconds: number;
  policySnapshot: OwnerPolicySnapshot;
}>;

/** Internal human-owner proof only. It neither proves a current agent key nor enables delivery. */
export class WatchOwnerProofVerifier {
  readonly #ports: AccessPorts;
  readonly #proofs = new WeakSet<WatchOwnerProof>();
  constructor(private readonly env: WatchOwnerEnvironment, ports?: AccessPorts) {
    this.#ports = ports ?? productionPorts(env.ACCESS_ISSUER);
  }

  #policy(): OwnerPolicySnapshot {
    configured(this.env);
    parseAllowedPrincipals(this.env.ALLOWED_PRINCIPALS);
    // Keep audience separation without requiring live runtime, node, or source configuration.
    if (!identifier(this.env.ACCESS_EVENT_AUD, 256) || this.env.ACCESS_UI_AUD === this.env.ACCESS_EVENT_AUD) throw new AccessUnavailable();
    return Object.freeze({ ACCESS_ISSUER: this.env.ACCESS_ISSUER, ACCESS_UI_AUD: this.env.ACCESS_UI_AUD,
      ACCESS_EVENT_AUD: this.env.ACCESS_EVENT_AUD, ADMIN_UI_ORIGIN: this.env.ADMIN_UI_ORIGIN,
      ALLOWED_PRINCIPALS: this.env.ALLOWED_PRINCIPALS });
  }

  async requireOwner(call: Readonly<EventAdminCall>, expected: WatchOwnerIdentity,
    operation: WatchOperationKind | 'material_delete' | 'material_delete_read', deadline: EventRequestDeadline): Promise<WatchOwnerProof> {
    if (!['create', 'read', 'operation_readback', 'detach', 'unsubscribe', 'material_delete', 'material_delete_read'].includes(operation))
      throw new EventApiError('unsupported', 400);
    if (!expected || !call) throw new AccessDenied();
    const identity = Object.freeze({ principal: expected.principal, agent: expected.agent });
    if (!canonicalEmail(identity.principal) || identity.principal !== identity.principal.toLowerCase()
      || !agent.safeParse(identity.agent).success) throw new AccessDenied();
    // Snapshot the original primitive proof before validation or awaits; request objects are not authority.
    const original = Object.freeze({ token: call.token, origin: call.origin, fetchSite: call.fetchSite, csrf: call.csrf });
    if (typeof original.token !== 'string' || !original.token || new TextEncoder().encode(original.token).length > 16384)
      throw new AccessDenied();
    const policySnapshot = this.#policy();
    const verified = await deadline.run(() => verifyAdminAssertionWithExpiry(original.token, policySnapshot, this.#ports));
    if (verified.principal.principal !== identity.principal || !principalAllowed(this.env, identity.principal))
      throw new AccessDenied();
    if (operation === 'create' || operation === 'detach' || operation === 'unsubscribe' || operation === 'material_delete') {
      if (typeof original.origin !== 'string' || original.origin.length > 512
        || typeof original.fetchSite !== 'string' || original.fetchSite.length > 32
        || typeof original.csrf !== 'string' || original.csrf.length > 128) throw new AccessDenied();
      await deadline.run(() => verifyAdminMutation(original.token,
        { origin: original.origin!, fetchSite: original.fetchSite!, csrf: original.csrf! }, policySnapshot));
    }
    const proof = Object.freeze({ verifiedPrincipal: identity.principal, verifiedAgent: identity.agent,
      verifiedExpiresAtSeconds: verified.expiresAtSeconds, verifiedAtSeconds: this.#ports.now(), policySnapshot });
    const result = parseOwnerAgentResult(await deadline.run(() => this.env.MESSAGE_AUTHORITY.registeredOwnerAgent(
      { accessAssertion: original.token, agent: identity.agent }), 5000));
    if (result.status === 'not_registered') throw new EventApiError('agent_not_registered', 409);
    if (result.status === 'invalid') throw new EventApiError('invalid', 400);
    if (result.status === 'unavailable') throw new AccessUnavailable();
    if (result.status !== 'authorized' || result.identity.principal !== identity.principal || result.identity.agent !== identity.agent)
      throw new AccessDenied();
    this.#proofs.add(proof);
    this.assertCurrent(proof);
    return proof;
  }

  /** Call after the final await, immediately before synchronous commit or exact-replay return.
   * Remote registration/key revocation is not linearizable with this local check. */
  assertCurrent(proof: WatchOwnerProof): void {
    if (!this.#proofs.has(proof)) throw new AccessDenied();
    const now = this.#ports.now();
    if (!Number.isSafeInteger(now) || now < proof.verifiedAtSeconds || now >= proof.verifiedExpiresAtSeconds)
      throw new AccessDenied();
    const current = this.#policy();
    if (!principalAllowed(this.env, proof.verifiedPrincipal)) throw new AccessDenied();
    if (Object.keys(current).some(key => current[key as keyof OwnerPolicySnapshot] !== proof.policySnapshot[key as keyof OwnerPolicySnapshot]))
      throw new AccessDenied();
  }
}
