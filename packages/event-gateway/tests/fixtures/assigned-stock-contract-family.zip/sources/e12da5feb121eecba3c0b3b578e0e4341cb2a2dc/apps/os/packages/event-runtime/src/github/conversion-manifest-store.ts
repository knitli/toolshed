import { z } from 'zod';
import { generation, uuid } from '../contracts';
import { materialDigest } from './material-read';
import { WatchActivateTokenSchema, WatchHolderSchema } from './watch-control-internal';

/** Local retention limits, not source-host pins or transport policy. No production caller. */
export const CONVERSION_MANIFEST_LIMITS = Object.freeze({ rows: 1000, bytes: 4 * 1024 * 1024,
  controlBytes: 4096, pageBytes: 8192, pages: 1024, entries: 16_384 });
const L = CONVERSION_MANIFEST_LIMITS;
const digest = z.string().regex(/^[a-f0-9]{64}$/);
const sourceId = z.string().min(1).max(4096).regex(/^(?:review:[1-9][0-9]*|comment:[1-9][0-9]*|thread-comment:.+)$/s);
export const ConversionManifestFenceSchema = z.strictObject({ token: WatchActivateTokenSchema, holder: WatchHolderSchema, leaseRevision: generation });
const materialSchema = z.strictObject({ kind: z.literal('material'), sourceId, fingerprint: digest,
  firstVersion: generation, bodyDigest: digest, availability: z.enum(['available', 'deleted', 'unavailable']) });
const transitionSchema = z.strictObject({ kind: z.literal('transition'), sourceVersion: generation, epoch: generation,
  recordType: z.enum(['version', 'terminal', 'finding', 'request', 'run']), recordKey: z.string().max(4096),
  valueDigest: digest }).refine(entry => entry.recordType === 'version' ? entry.recordKey === '' : entry.recordKey.length > 0);
const evidenceSchema = z.discriminatedUnion('kind', [materialSchema, transitionSchema]);
const pageSchema = z.strictObject({ index: z.number().int().min(0).max(L.pages - 1),
  entries: z.array(evidenceSchema).min(1).max(L.entries) });
const reconciliationSchema = z.strictObject({ cause: z.enum(['initial', 'backfill', 'source_change', 'replacement']),
  fromVersion: generation, toVersion: generation, anchorVersion: generation, hostEpoch: generation,
  observationEpoch: generation, coverageStartVersion: generation, complete: z.literal(true),
  pageCount: z.number().int().min(1).max(L.pages), evidenceCount: z.number().int().min(1).max(L.entries) });
const inputSchema = z.strictObject({ operationId: uuid, fence: ConversionManifestFenceSchema, reconciliation: reconciliationSchema,
  pages: z.array(pageSchema).min(1).max(L.pages) });
const headerSchema = inputSchema.omit({ pages: true }).extend({ status: z.literal('held'),
  // Never accept predecessor ACK/read/disposition coverage through the input seam.
  observation: z.strictObject({ inputRecorded: z.literal(false), materialRead: z.literal(false), disposition: z.literal('pending') }) });
export const ManifestReservationSchema = z.strictObject({ operationId: uuid, fence: ConversionManifestFenceSchema,
  preparationGeneration: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER), manifestBytes: z.number().int().positive().max(L.bytes) });
export type ManifestReservation = z.infer<typeof ManifestReservationSchema>;
export type ConversionManifestFence = z.infer<typeof ConversionManifestFenceSchema>;
export type ConversionManifestInput = z.infer<typeof inputSchema>;
export type HeldConversionManifest = z.infer<typeof headerSchema> & { pages: Array<z.infer<typeof pageSchema>>; digest: string };
export type ConversionManifestResult = HeldConversionManifest | { status: 'invalid' | 'coverage_unavailable' | 'conflict' | 'capacity' | 'unavailable' };
const jsonBytes = (value: string) => new TextEncoder().encode(value).byteLength;
export const conversionManifestByteUsage = (headerBytes: number, pageBytes: readonly number[]) =>
  headerBytes + 36 + 64 + pageBytes.reduce((total, bytes) => total + bytes + 36 + 8, 0);
const equal = (left: unknown, right: unknown) => JSON.stringify(left) === JSON.stringify(right);
const evidenceKey = (entry: z.infer<typeof evidenceSchema>) => JSON.stringify(entry.kind === 'material'
  ? [entry.kind, entry.sourceId, entry.fingerprint]
  : [entry.kind, entry.sourceVersion, entry.recordType, entry.recordKey]);

/**
 * Dormant, internal persistence seam. Input must already represent the complete authorized
 * source union. Local shape/range checks do not establish source authority, body availability,
 * omission-free remote reads, or durable source-host retention. No release/ACK/dispatch method.
 */
export class GitHubConversionManifestStore {
  // eslint-disable-next-line no-unused-vars -- Retains the real Durable Object SQLite storage.
  constructor(private readonly storage: DurableObjectStorage) {
    storage.transactionSync(() => {
      storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_conversion_manifests(
        operation_id TEXT PRIMARY KEY, header TEXT NOT NULL, digest TEXT NOT NULL)`);
      storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_conversion_manifest_reservations(
        operation_id TEXT PRIMARY KEY,fence TEXT NOT NULL,preparation_generation INTEGER NOT NULL,bytes INTEGER NOT NULL)`);
      storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_conversion_manifest_pages(
        operation_id TEXT NOT NULL, page_index INTEGER NOT NULL, value TEXT NOT NULL,
        PRIMARY KEY(operation_id,page_index))`);
    });
  }

  private usage(): { rows: number; bytes: number } {
    return this.storage.sql.exec<{ rows: number; bytes: number }>(
      `SELECT count(*) AS rows,COALESCE(sum(length(CAST(operation_id AS BLOB))+length(CAST(header AS BLOB))+length(CAST(digest AS BLOB))),0)
        +(SELECT COALESCE(sum(length(CAST(operation_id AS BLOB))+length(CAST(value AS BLOB))+8),0)
          FROM github_conversion_manifest_pages) AS bytes FROM github_conversion_manifests`).one();
  }
  private reservations(): ManifestReservation[] {
    return this.storage.sql.exec<{ operation_id: string; fence: string; preparation_generation: number; bytes: number }>(
      'SELECT * FROM github_conversion_manifest_reservations').toArray().map(row => ManifestReservationSchema.parse({
      operationId: row.operation_id, fence: JSON.parse(row.fence), preparationGeneration: row.preparation_generation, manifestBytes: row.bytes }));
  }
  /** Legacy pinned work has no proven allowance; preserve its custody and refuse new capacity. */
  private unreservedCustody(): boolean {
    for (const [table, predicate] of [['github_initial_watch_preparations', "phase!='refused'"],
      ['github_initial_activation_intents', '1'], ['github_initial_reconciliations', '1']]) {
      if (this.storage.sql.exec('SELECT 1 FROM sqlite_master WHERE name=?', table!).toArray().length
        && this.storage.sql.exec(`SELECT 1 FROM ${table} AS custody WHERE ${predicate}
          AND NOT EXISTS(SELECT 1 FROM github_conversion_manifest_reservations WHERE operation_id=custody.operation_id)
          AND NOT EXISTS(SELECT 1 FROM github_conversion_manifests WHERE operation_id=custody.operation_id) LIMIT 1`).toArray().length) return true;
    }
    return false;
  }
  reservation(operationId: string, fence: ConversionManifestFence): ManifestReservation | null {
    const proof = this.reservations().find(value => value.operationId === operationId);
    if (proof && !equal(proof.fence, ConversionManifestFenceSchema.parse(fence))) throw new Error('github_source_conflict');
    return proof ?? null;
  }
  /** Caller atomically persists preparation with this reservation, before contacting the host. */
  reserve(operationId: string, fence: ConversionManifestFence, preparationGeneration: number): ManifestReservation {
    const parsed = ManifestReservationSchema.parse({ operationId, fence, preparationGeneration, manifestBytes: 1 });
    if (parsed.operationId !== parsed.fence.token.operationId || jsonBytes(JSON.stringify(parsed)) > 8192) throw new Error('github_source_conflict');
    return this.storage.transactionSync(() => {
      const reservations = this.reservations(), old = reservations.find(value => value.operationId === operationId);
      if (old) {
        if (!equal(old.fence, parsed.fence) || old.preparationGeneration !== preparationGeneration) throw new Error('github_source_conflict');
        return old;
      }
      if (this.storage.sql.exec('SELECT 1 FROM github_conversion_manifests WHERE operation_id=?', operationId).toArray().length)
        throw new Error('github_source_conflict');
      const used = this.usage(), free = L.bytes - used.bytes - reservations.reduce((sum, value) => sum + value.manifestBytes, 0);
      if (this.unreservedCustody() || used.rows + reservations.length >= L.rows || free < 1) throw new Error('capacity');
      const proof = { ...parsed, manifestBytes: free };
      this.storage.sql.exec('INSERT INTO github_conversion_manifest_reservations VALUES(?,?,?,?)',
        operationId, JSON.stringify(parsed.fence), preparationGeneration, free);
      return proof;
    });
  }
  releaseReservation(proof: ManifestReservation): void {
    const parsed = ManifestReservationSchema.parse(proof), current = this.reservation(parsed.operationId, parsed.fence);
    if (!current || !equal(current, parsed)) throw new Error('github_source_conflict');
    this.storage.sql.exec('DELETE FROM github_conversion_manifest_reservations WHERE operation_id=?', parsed.operationId);
  }

  /** Reads require an exact descriptive fence, not a claim of current authority. */
  async read(operationId: string, fence: ConversionManifestFence): Promise<ConversionManifestResult> {
    const parsed = ConversionManifestFenceSchema.safeParse(fence);
    if (!uuid.safeParse(operationId).success || !parsed.success) return { status: 'invalid' };
    const snapshot = this.storage.transactionSync(() => {
      const row = this.storage.sql.exec<{ header: string; digest: string }>(
        'SELECT header,digest FROM github_conversion_manifests WHERE operation_id=?', operationId).toArray()[0];
      if (!row) return null;
      const pages = this.storage.sql.exec<{ page_index: number; value: string }>(
        'SELECT page_index,value FROM github_conversion_manifest_pages WHERE operation_id=? ORDER BY page_index', operationId).toArray();
      return { row, pages };
    });
    if (!snapshot) return { status: 'unavailable' };
    try {
      const header = headerSchema.parse(JSON.parse(snapshot.row.header));
      if (!equal(header.fence, parsed.data)) return { status: 'conflict' };
      const pages = snapshot.pages.map(row => pageSchema.parse(JSON.parse(row.value)));
      if (snapshot.pages.some((row, index) => row.page_index !== index)) return { status: 'unavailable' };
      const prepared = this.prepare({ ...headerInput(header), pages });
      if ('status' in prepared) return { status: 'unavailable' };
      if (header.operationId !== operationId || await materialDigest(prepared.serialized) !== snapshot.row.digest) return { status: 'unavailable' };
      return { ...header, pages, digest: snapshot.row.digest };
    } catch { return { status: 'unavailable' }; }
  }

  private prepare(value: unknown): { header: z.infer<typeof headerSchema>; pages: ConversionManifestInput['pages'];
    serialized: string; bytes: number } | { status: 'invalid' | 'coverage_unavailable' | 'conflict' | 'capacity' | 'unavailable' } {
    const parsed = inputSchema.safeParse(value);
    if (!parsed.success) return { status: 'invalid' };
    const input = parsed.data, coverage = input.reconciliation;
    if (coverage.fromVersion > coverage.toVersion || coverage.toVersion !== coverage.anchorVersion
      || coverage.coverageStartVersion > coverage.fromVersion || coverage.observationEpoch > coverage.hostEpoch
      || input.pages.length !== coverage.pageCount) return { status: 'coverage_unavailable' };
    const identities = new Set<string>();
    const versionEpochs = new Map<number, number>();
    let entries = 0;
    for (const [index, page] of input.pages.entries()) {
      if (page.index !== index) return { status: 'coverage_unavailable' };
      if (jsonBytes(JSON.stringify(page)) > L.pageBytes) return { status: 'capacity' };
      for (const entry of page.entries) {
        if (entry.kind === 'material' && entry.availability !== 'available') return { status: 'unavailable' };
        const version = entry.kind === 'material' ? entry.firstVersion : entry.sourceVersion;
        if (version < coverage.fromVersion || version > coverage.toVersion
          || entry.kind === 'transition' && entry.epoch > coverage.observationEpoch) return { status: 'coverage_unavailable' };
        if (entry.kind === 'transition') {
          const priorEpoch = versionEpochs.get(entry.sourceVersion);
          // Journal identity excludes epoch; every record in one committed version shares it.
          if (priorEpoch !== undefined && priorEpoch !== entry.epoch) return { status: 'conflict' };
          versionEpochs.set(entry.sourceVersion, entry.epoch);
        }
        const key = evidenceKey(entry);
        // The trusted union must be deduplicated before paging; ambiguity never overwrites evidence.
        if (identities.has(key)) return { status: 'conflict' };
        identities.add(key);
        entries++;
        if (entries > L.entries) return { status: 'capacity' };
      }
    }
    if (entries !== coverage.evidenceCount) return { status: 'coverage_unavailable' };
    const { pages, ...control } = input;
    const header = headerSchema.parse({ ...control, status: 'held',
      observation: { inputRecorded: false, materialRead: false, disposition: 'pending' } });
    if (jsonBytes(JSON.stringify(header)) > L.controlBytes) return { status: 'capacity' };
    const serialized = JSON.stringify({ ...header, pages });
    // Count every stored payload column (including repeated operation IDs), not a mutable ledger.
    const bytes = conversionManifestByteUsage(jsonBytes(JSON.stringify(header)), pages.map(page => jsonBytes(JSON.stringify(page))));
    if (bytes > L.bytes) return { status: 'capacity' };
    return { header, pages, serialized, bytes };
  }

  /** No await occurs inside the atomic compare/capacity/write section. */
  async retain(value: unknown, commit?: { reservation?: ManifestReservation; afterDigest?: () => Promise<boolean>; authorize: (fence: ConversionManifestFence) => boolean; retained: (manifest: HeldConversionManifest) => undefined }): Promise<ConversionManifestResult> {
    const prepared = this.prepare(value);
    if ('status' in prepared) return prepared;
    // prepare() parses/clones the input before hashing; caller mutation cannot change the commit.
    const reservation = commit?.reservation ? ManifestReservationSchema.parse(commit.reservation) : undefined;
    const hash = await materialDigest(prepared.serialized);
    if (commit?.afterDigest && !await commit.afterDigest()) return { status: 'conflict' };
    return this.storage.transactionSync(() => {
      if (commit && !commit.authorize(prepared.header.fence)) return { status: 'conflict' };
      const result = { ...prepared.header, pages: prepared.pages, digest: hash };
      const id = prepared.header.operationId;
      if (reservation && (reservation.operationId !== id || !equal(reservation.fence, prepared.header.fence))) return { status: 'conflict' };
      const prior = this.storage.sql.exec<{ header: string; digest: string }>(
        'SELECT header,digest FROM github_conversion_manifests WHERE operation_id=?', id).toArray()[0];
      if (prior) {
        const pages = this.storage.sql.exec<{ page_index: number; value: string }>(
          'SELECT page_index,value FROM github_conversion_manifest_pages WHERE operation_id=? ORDER BY page_index', id).toArray();
        if (prior.header !== JSON.stringify(prepared.header) || prior.digest !== hash
          || pages.some((row, index) => row.page_index !== index)
          || !equal(pages.map(row => row.value), prepared.pages.map(page => JSON.stringify(page)))) return { status: 'conflict' };
        if (commit && commit.retained(result) !== undefined) throw new Error('github_async_receipt_refused');
        return result;
      }
      const reservations = this.reservations(), own = reservations.find(value => value.operationId === id);
      if (reservation && (!own || !equal(own, reservation) || !equal(reservation.fence, prepared.header.fence))
        || own && !reservation) return { status: 'conflict' };
      if (own && prepared.bytes > own.manifestBytes) return { status: 'capacity' };
      const used = this.usage(), others = reservations.filter(value => value.operationId !== own?.operationId);
      if (this.unreservedCustody() || used.rows + others.length >= L.rows
        || used.bytes + others.reduce((sum, value) => sum + value.manifestBytes, 0) + prepared.bytes > L.bytes) return { status: 'capacity' };
      this.storage.sql.exec('INSERT INTO github_conversion_manifests(operation_id,header,digest) VALUES(?,?,?)',
        id, JSON.stringify(prepared.header), hash);
      for (const page of prepared.pages) this.storage.sql.exec(
        'INSERT INTO github_conversion_manifest_pages(operation_id,page_index,value) VALUES(?,?,?)', id, page.index, JSON.stringify(page));
      if (own) this.releaseReservation(own);
      if (commit && commit.retained(result) !== undefined) throw new Error('github_async_receipt_refused');
      return result;
    });
  }
}

function headerInput(header: z.infer<typeof headerSchema>): Omit<ConversionManifestInput, 'pages'> {
  const { status: _status, observation: _observation, ...input } = header;
  return input;
}
