import { z } from 'zod';
import { uuid } from '../contracts';
import { CONVERSION_MANIFEST_LIMITS, ConversionManifestFenceSchema } from './conversion-manifest-store';
import { serializedBytes } from './conversion-planning';
import { GitHubMaterialReadRequestSchema, GitHubMaterialReadResultSchema, materialPageMatches,
  type GitHubMaterialReadRequest, type GitHubMaterialReadResult } from './material-read-contract';
import type { InitialReconciliationPlan } from './reconciliation-planner';

export const INITIAL_PLAN_MATERIAL_PATH = '/internal/github/initial-plan/material';
export const INITIAL_PLAN_MATERIAL_REQUEST_BYTES = 4096;
export const INITIAL_PLAN_MATERIAL_RESPONSE_BYTES = 9216;
const identity = { operationId: uuid, revision: z.literal(1), manifestDigest: z.string().regex(/^[a-f0-9]{64}$/) };
const locator = { pageIndex: z.number().int().nonnegative().max(CONVERSION_MANIFEST_LIMITS.pages - 1),
  entryIndex: z.number().int().nonnegative().max(CONVERSION_MANIFEST_LIMITS.entries - 1) };
export const InitialPlanMaterialReadRequestSchema = z.strictObject({ ...identity, fence: ConversionManifestFenceSchema,
  material: z.strictObject({ ...locator, cursor: GitHubMaterialReadRequestSchema.shape.cursor }) })
  .refine(value => serializedBytes(value) <= INITIAL_PLAN_MATERIAL_REQUEST_BYTES);
export type InitialPlanMaterialReadRequest = z.infer<typeof InitialPlanMaterialReadRequestSchema>;
export const InitialPlanMaterialReadResponseSchema = z.strictObject({ ...identity, ...locator, result: GitHubMaterialReadResultSchema })
  .refine(value => serializedBytes(value) <= INITIAL_PLAN_MATERIAL_RESPONSE_BYTES);
export type InitialPlanMaterialReadResponse = z.infer<typeof InitialPlanMaterialReadResponseSchema>;

/** Selection is descriptive; the caller must independently revalidate current read authority. */
export function initialPlanMaterialHostRequest(plan: InitialReconciliationPlan, input: InitialPlanMaterialReadRequest): GitHubMaterialReadRequest {
  const request = InitialPlanMaterialReadRequestSchema.parse(input);
  const reference = plan.obligations.materials.find(ref => ref.pageIndex === request.material.pageIndex && ref.entryIndex === request.material.entryIndex);
  if (request.operationId !== plan.record.operationId || request.revision !== plan.record.revision
    || request.manifestDigest !== plan.record.manifestDigest
    || JSON.stringify(request.fence) !== JSON.stringify(ConversionManifestFenceSchema.parse(plan.member.fence))
    || !reference) throw new Error('github_source_conflict');
  const { token, fromVersion, toVersion } = plan.member.obligation;
  return GitHubMaterialReadRequestSchema.parse({ subject: { installationId: token.installationId,
    repositoryId: token.subject.repositoryId, prNumber: token.subject.prNumber }, sourceId: reference.evidence.sourceId,
    fingerprint: reference.evidence.fingerprint, fromVersion, toVersion,
    ...(request.material.cursor === undefined ? {} : { cursor: request.material.cursor }) });
}

export function initialPlanMaterialPageMatches(plan: InitialReconciliationPlan, request: InitialPlanMaterialReadRequest,
  input: GitHubMaterialReadResult): boolean {
  try {
    const hostRequest = initialPlanMaterialHostRequest(plan, request), result = GitHubMaterialReadResultSchema.parse(input);
    const reference = plan.obligations.materials.find(ref => ref.pageIndex === request.material.pageIndex && ref.entryIndex === request.material.entryIndex)!;
    return materialPageMatches(hostRequest, result) && (result.status !== 'ok'
      || result.firstVersion === reference.evidence.firstVersion && result.bodyDigest === reference.evidence.bodyDigest);
  } catch { return false; }
}
