import { CONVERSION_MANIFEST_LIMITS as L, type ConversionManifestInput } from './conversion-manifest-store';
import { GITHUB_SOURCE_READ_RESPONSE_BYTES } from './readback-contract';
import type { InitialReconciliationObligation } from './reconciliation-internal';

export const serializedBytes = (value: unknown) => new TextEncoder().encode(JSON.stringify(value)).length;
const fail = (): never => { throw new Error('github_capacity'); };
const digest = '0'.repeat(64);

/** Shares the reader's conservative page boundaries and counts each actual serialized envelope. */
export class RetainedMetadataPagePlanner {
  readonly pages = new Map<number, number>();
  #offset = 0; #start = 0; #payloadBytes = 0; #bytes = 0; #finished = false;
  readonly #overhead: number;
  constructor(private readonly envelope: object, private readonly count: number, private readonly itemBytes: number) {
    this.#overhead = this.overhead(count, false);
  }
  private overhead(offset: number, complete: boolean): number {
    return serializedBytes({ ...this.envelope, rangeDigest: digest, items: [],
      nextCursor: complete ? null : { rangeDigest: digest, offset }, complete });
  }
  private close(complete: boolean): void {
    if (this.#offset === this.#start) fail();
    this.pages.set(this.#start, this.#offset);
    this.#bytes += this.overhead(this.#offset, complete) + this.#payloadBytes;
  }
  append(bytes: number): number {
    if (this.#finished || !Number.isSafeInteger(bytes) || bytes < 1 || bytes > this.itemBytes
      || this.#overhead + bytes > GITHUB_SOURCE_READ_RESPONSE_BYTES || this.#offset >= this.count) fail();
    if (this.#overhead + this.#payloadBytes + bytes + Number(this.#offset > this.#start) > GITHUB_SOURCE_READ_RESPONSE_BYTES) {
      this.close(false); this.#start = this.#offset; this.#payloadBytes = 0;
    }
    this.#payloadBytes += bytes + Number(this.#offset > this.#start); this.#offset++;
    return this.#start;
  }
  get bytes(): number { return this.#bytes + this.overhead(this.#offset, true) + this.#payloadBytes; }
  get pageCount(): number { return this.pages.size + 1; }
  finish(): { bytes: number; pageCount: number; pages: Map<number, number> } {
    if (this.#offset !== this.count) fail();
    if (!this.#finished) { this.close(true); this.#finished = true; }
    return { bytes: this.#bytes, pageCount: this.pages.size, pages: this.pages };
  }
}

/** No evidence payloads are retained; actual conversion and preflight use identical packing. */
export class ConversionManifestPagePlanner {
  readonly pageBytes: number[] = [];
  #pageEntries = 0;
  entries = 0;
  append(entry: ConversionManifestInput['pages'][number]['entries'][number]): number {
    const bytes = serializedBytes(entry);
    let index = this.pageBytes.length - 1;
    if (index < 0 || this.pageBytes[index]! + bytes + Number(this.#pageEntries > 0) > L.pageBytes) {
      index++; this.pageBytes.push(serializedBytes({ index, entries: [] })); this.#pageEntries = 0;
    }
    this.pageBytes[index]! += bytes + Number(this.#pageEntries > 0); this.#pageEntries++; this.entries++;
    if (this.entries > L.entries || this.pageBytes.length > L.pages || this.pageBytes[index]! > L.pageBytes) fail();
    return index;
  }
}

export function initialConversionShape(obligation: InitialReconciliationObligation,
  fence: ConversionManifestInput['fence'], pageCount: number, evidenceCount: number): Omit<ConversionManifestInput, 'pages'> {
  return { operationId: obligation.operationId, fence, reconciliation: { cause: 'initial', fromVersion: 1,
    toVersion: obligation.toVersion, anchorVersion: obligation.toVersion, hostEpoch: obligation.hostEpoch,
    observationEpoch: obligation.observationEpoch, coverageStartVersion: 1, complete: true, pageCount, evidenceCount } };
}

/** One conversion-wide allowance; moving to another fingerprint does not reset it. */
export class ConversionMaterialReadBudget {
  #reads = 0;
  consume(): void { if (++this.#reads > L.pages) fail(); }
}
