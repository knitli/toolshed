/** Private evidence projection, not an authorization or recovery protocol. */
export type InventoryScope = 'registry' | 'coordinator';
export type InventoryRequest = Readonly<{
  scopeKind: InventoryScope;
  collection: string;
  limit: number;
  maxBytes: number;
  after?: readonly string[];
}>;
export type InventoryScalar = string | number | null;
export type InventoryRow = {
  key: string[] | null;
  interpretation: 'raw' | 'uninterpretable';
  values: Record<string, InventoryScalar>;
  issues: string[];
};
export type InventoryPage = {
  scopeKind: InventoryScope | null;
  collection: string | null;
  rows: InventoryRow[];
  nextKey: string[] | null;
  /** Only exhaustion of this query's current suffix, never historical coverage. */
  pageComplete: boolean;
  historicalCoverage: 'unknown';
  clearanceAssessment: 'not_performed';
  consistency: 'single_page_only';
} & ({ status: 'page' } | {
  status: 'unavailable';
  reason: 'invalid_request' | 'schema_unknown' | 'query_failed' | 'uninterpretable_key' | 'page_budget';
});

export const INVENTORY_LIMITS = Object.freeze({
  rows: 100, defaultRows: 50, minBytes: 1024, bytes: 65_536, defaultBytes: 32_768,
  keyBytes: 256, textBytes: 512,
});
