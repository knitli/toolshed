import { z } from 'zod';
import { uuid } from '../contracts';
import { GitHubGrantSubjectSchema } from './grants';

const counter = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER);
// Unavailable receipts cannot consume the existing retained-target cleanup allowance.
export const MATERIAL_DELETE_LIMITS = Object.freeze({ rows: 4096, bytes: 4 * 1024 * 1024,
  unavailableRows: 256, unavailableBytes: 256 * 1024, requestBytes: 4096 });
export const MaterialDeleteScopeSchema = z.strictObject({ lifetime: uuid, sourceIncarnation: counter, hostEpoch: counter, sourceRpcGeneration: counter });
export type MaterialDeleteScope = z.infer<typeof MaterialDeleteScopeSchema>;
export const MaterialDeleteRequestSchema = z.strictObject({ operationId: uuid, subject: GitHubGrantSubjectSchema,
  scope: MaterialDeleteScopeSchema, sourceId: z.string().min(1).max(1024), fingerprint: z.string().regex(/^[a-f0-9]{64}$/),
  reason: z.string().min(1).max(512).refine(value => value.trim().length > 0) });
export type MaterialDeleteRequest = z.infer<typeof MaterialDeleteRequestSchema>;
export type MaterialDeleteReceipt = MaterialDeleteRequest & { actor: { principal: string; agent: string }; committedAt: number;
  outcome: 'deleted' | 'already_deleted' | 'unavailable' };
export type MaterialDeleteResult = { status: 'committed'; receipt: MaterialDeleteReceipt } | { status: 'conflict' | 'capacity' | 'unavailable' };

/** Part of source storage, never reset on grant, watch, or reconciliation epochs. */
export function ensureMaterialDeletionStore(storage: DurableObjectStorage): void {
  storage.sql.exec('CREATE TABLE IF NOT EXISTS github_material_lifetime (id INTEGER PRIMARY KEY CHECK(id=1), lifetime TEXT NOT NULL)');
  storage.sql.exec('INSERT OR IGNORE INTO github_material_lifetime VALUES(1,?)', crypto.randomUUID());
  storage.sql.exec(`CREATE TABLE IF NOT EXISTS github_material_deletions (
    operation_id TEXT PRIMARY KEY, request_json TEXT NOT NULL, receipt_json TEXT NOT NULL)`);
}
export function materialLifetime(storage: DurableObjectStorage): string | null {
  if (!storage.sql.exec("SELECT 1 FROM sqlite_master WHERE type='table' AND name='github_material_lifetime'").toArray().length) return null;
  const lifetime = storage.sql.exec<{ lifetime: string }>('SELECT lifetime FROM github_material_lifetime WHERE id=1').toArray()[0]?.lifetime;
  return uuid.safeParse(lifetime).success ? lifetime! : null;
}
/** Internal synchronous commit. The host proves original human authority immediately before calling. */
export function deleteMaterial(storage: DurableObjectStorage, request: MaterialDeleteRequest,
  actor: MaterialDeleteReceipt['actor'], current: MaterialDeleteScope | null, now = Date.now()): MaterialDeleteResult {
  if (!Number.isSafeInteger(now) || now < 0) throw new Error('github_invalid_material');
  const exact = JSON.stringify({ request, actor });
  if (new TextEncoder().encode(exact).length > MATERIAL_DELETE_LIMITS.requestBytes) return { status: 'capacity' };
  return storage.transactionSync((): MaterialDeleteResult => {
    // Reset storage cannot authorize an old operation, even if its source counters repeat.
    if (materialLifetime(storage) !== request.scope.lifetime) return { status: 'conflict' };
    const prior = storage.sql.exec<{ request_json: string; receipt_json: string }>(
      'SELECT request_json,receipt_json FROM github_material_deletions WHERE operation_id=?', request.operationId).toArray()[0];
    if (prior) return prior.request_json === exact
      ? { status: 'committed', receipt: JSON.parse(prior.receipt_json) as MaterialDeleteReceipt } : { status: 'conflict' };
    if (!current || JSON.stringify(current) !== JSON.stringify(request.scope)) return { status: 'conflict' };
    const row = storage.sql.exec<{ deleted_at: number | null }>(
      'SELECT deleted_at FROM github_finding_material WHERE source_id=? AND fingerprint=?', request.sourceId, request.fingerprint).toArray()[0];
    const receipt: MaterialDeleteReceipt = { ...request, actor, committedAt: now,
      outcome: !row ? 'unavailable' : row.deleted_at === null ? 'deleted' : 'already_deleted' };
    const receiptJson = JSON.stringify(receipt);
    // Classify new work from the actual retained material row and historical work
    // from its immutable server-written outcome, never caller-supplied metadata.
    const unavailable = !row;
    const size = storage.sql.exec<{ rows: number; bytes: number }>(
      `SELECT count(*) AS rows,COALESCE(sum(length(CAST(request_json AS BLOB))+length(CAST(receipt_json AS BLOB))),0) AS bytes
       FROM github_material_deletions WHERE CASE WHEN json_extract(receipt_json,'$.outcome')='unavailable' THEN 1 ELSE 0 END=?`,
      unavailable ? 1 : 0).one();
    const rowLimit = unavailable ? MATERIAL_DELETE_LIMITS.unavailableRows : MATERIAL_DELETE_LIMITS.rows;
    const byteLimit = unavailable ? MATERIAL_DELETE_LIMITS.unavailableBytes : MATERIAL_DELETE_LIMITS.bytes;
    if (size.rows >= rowLimit || size.bytes + new TextEncoder().encode(exact + receiptJson).length > byteLimit)
      return { status: 'capacity' };
    if (row) storage.sql.exec('UPDATE github_finding_material SET body=NULL,deleted_at=COALESCE(deleted_at,?) WHERE source_id=? AND fingerprint=?',
      now, request.sourceId, request.fingerprint);
    storage.sql.exec('INSERT INTO github_material_deletions VALUES(?,?,?)', request.operationId, exact, receiptJson);
    return { status: 'committed', receipt };
  });
}
