import { parseInventoryOwnerCall, parseOwnerInventoryInput } from './quarantine-inventory-admin.ts';
import { parseInventoryPage } from './quarantine-inventory-validation.ts';
import type { InventoryPage } from './quarantine-inventory-contract.ts';
import { parseMessageRouteControlInput, parseMessageRouteControlResult, parseMessageRouteOwnerCall, type MessageRouteControlInput, type MessageRouteControlResult } from "gatekeeper-messaging/src/message-route-control-contract.ts";
import { WATCH_CONTROL_LIMITS, WatchRequestSchema, WatchOutcomeSchema, watchJson, type WatchOutcome } from './github/watch-control-internal';
import { requireManualCanary } from "./manual-canary.ts";
import { GitHubGrantInputSchema, GitHubGrantViewSchema, GitHubGrantSubjectSchema, GitHubSourceOwnerViewSchema, type GitHubGrantInput, type GitHubSourceOwnerView } from "./github/grants.ts";
import { GitHubSourceAdoptionInputSchema, GitHubSourceInitializationInputSchema } from "./github/source-control.ts";
import { WorkerEntrypoint } from "cloudflare:workers";
import { z } from "zod";
import { parseOwnerAgentResult } from "./authority-client.ts";
import { admitCoordinator } from "./coordinator-admission.ts";
import { AccessDenied, AccessUnavailable, identifier, type AccessPorts } from "openapi-operator/src/access.ts";
import { productionPorts } from "gatekeeper-memory/src/auth.ts";
import { configured, verifyAdminAssertionWithExpiry, verifyAdminMutation } from "gatekeeper-memory/src/admin-security.ts";
import { parseAllowedPrincipals, principalAllowed } from "gatekeeper-memory/src/principals.ts";
import type { EventAdminCall, EventAdminOutcome, EventAdminService, EventChallengeInput, EventEnabledInput, EventManualInput, EventNodeView, EventRevokeInput, EventTransferInput } from "./admin-types.ts";
import { agent, coordinatorName, EventApiError, generation, runtimeConfigured, uuid, type EventApiEnvironment } from "./contracts.ts";
import { ownerRegistryName, type NodeView } from "./registry.ts";
import { EventRequestDeadline } from "./request-deadline.ts";

const agentInput = z.strictObject({ agent });
const challengeInput = z.strictObject({
  nodeId: uuid, publicKey: z.string().regex(/^[A-Za-z0-9_-]{43}$/),
  meshIp: z.string().max(45), meshPort: z.number().int().min(1).max(65535),
  agents: z.array(agent).min(1).max(128).refine((values) => new Set(values).size === values.length),
});
const revokeInput = z.strictObject({ nodeId: uuid, expectedGeneration: generation });
const enabledInput = z.strictObject({ agent, enabled: z.boolean() });
const manualInput = z.strictObject({ agent, runtimeId: uuid, subjectId: z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/) });
const transferInput = z.strictObject({ agent, runtimeId: uuid, replacementRuntimeId: uuid, expectedAttachmentGeneration: generation });
const nodeView = (node: NodeView): EventNodeView => ({ ...node, publicKey: node.publicKey.x! });
function requireAcceptedSourceOperation(result: GitHubSourceOwnerView, input: { operationId: string; expectedRevision: number; subject: GitHubGrantInput['subject'] }, kind: 'initialize' | 'adopt'): void {
  if (!result.operation || result.operation.operationId !== input.operationId || result.operation.kind !== kind
    || (result.grant && JSON.stringify(result.grant.subject) !== JSON.stringify(input.subject)))
    throw new EventApiError("unavailable", 503);
  if (result.operation.status === 'parked' || (result.operation.status === 'active'
    && (result.control.status === 'parked' || result.control.status === 'parking' || result.source.hostControl === 'parked')))
    throw new EventApiError('github_source_revalidation_required', 409);
  if (result.operation.status === 'legacy' || result.operation.status === 'refused')
    throw new EventApiError("github_source_conflict", 409);
  if (result.operation.status === 'active' && (!result.sourceControlEnabled || result.control.status !== 'active' || result.control.pendingReason === 'waiting_for_authority'
    || result.control.operationId !== result.operation.operationId || result.control.sourceIncarnation !== result.operation.sourceIncarnation
    || result.control.lifecycleEpoch !== result.operation.lifecycleEpoch))
    throw new EventApiError("github_source_conflict", 409);
  if (!result.grant || !result.grant.enabled || !result.mappingCurrent || result.grant.revision !== input.expectedRevision) {
    // Completed history can conflict with current authority without becoming an outage.
    if (result.operation.status === 'active') throw new EventApiError("github_source_conflict", 409);
    throw new EventApiError("unavailable", 503);
  }
}

type OwnerReadPolicy = Readonly<Pick<EventApiEnvironment,
  'ACCESS_ISSUER' | 'ACCESS_UI_AUD' | 'ACCESS_EVENT_AUD' | 'ADMIN_UI_ORIGIN' | 'ALLOWED_PRINCIPALS'>>;
type OwnerReadProof = Readonly<{
  principal: string; expiresAtSeconds: number; checkedAtSeconds: number; policy: OwnerReadPolicy;
}>;
type AdminIdentity = { principal: string; readProof?: OwnerReadProof };

/** This narrow RPC receives the original browser proof; UI capability checks never authorize it. */
export class EventAdmin extends WorkerEntrypoint<EventApiEnvironment> implements EventAdminService {
  readonly #ports: AccessPorts;
  constructor(ctx: ExecutionContext, env: EventApiEnvironment, ports?: AccessPorts) {
    super(ctx, env);
    this.#ports = ports ?? productionPorts(env.ACCESS_ISSUER);
  }

  async #identity(call: EventAdminCall, mutation: boolean, deadline: EventRequestDeadline, requireRuntime: boolean, freshRead: boolean): Promise<AdminIdentity> {
    if (requireRuntime && !runtimeConfigured(this.env)) throw new AccessUnavailable();
    if (!requireRuntime && (!identifier(this.env.ACCESS_EVENT_AUD, 256) || this.env.ACCESS_UI_AUD === this.env.ACCESS_EVENT_AUD)) throw new AccessUnavailable();
    parseAllowedPrincipals(this.env.ALLOWED_PRINCIPALS);
    if (!call || typeof call.token !== "string" || !call.token || new TextEncoder().encode(call.token).length > 16384)
      throw new AccessDenied();
    const policy = freshRead ? this.#ownerReadPolicy() : undefined;
    const checkedAtSeconds = freshRead ? this.#ports.now() : 0;
    const verified = await deadline.run(() => verifyAdminAssertionWithExpiry(call.token, policy ?? this.env, this.#ports));
    const who = verified.principal;
    if (!principalAllowed(this.env, who.principal)) throw new AccessDenied();
    if (mutation) {
      const proof = this.#mutationProof(call);
      await deadline.run(() => verifyAdminMutation(call.token, proof, this.env));
    }
    return { principal: who.principal, ...(policy ? { readProof: Object.freeze({
      principal: who.principal, expiresAtSeconds: verified.expiresAtSeconds, checkedAtSeconds, policy,
    }) } : {}) };
  }

  #mutationProof(call: EventAdminCall): { origin: string; fetchSite: string; csrf: string } {
    if (typeof call.origin !== "string" || call.origin.length > 512 ||
      typeof call.fetchSite !== "string" || call.fetchSite.length > 32 ||
      typeof call.csrf !== "string" || call.csrf.length > 128) throw new AccessDenied();
    return { origin: call.origin, fetchSite: call.fetchSite, csrf: call.csrf };
  }

  #ownerReadPolicy(): OwnerReadPolicy {
    const policy = Object.freeze({ ACCESS_ISSUER: this.env.ACCESS_ISSUER, ACCESS_UI_AUD: this.env.ACCESS_UI_AUD,
      ACCESS_EVENT_AUD: this.env.ACCESS_EVENT_AUD, ADMIN_UI_ORIGIN: this.env.ADMIN_UI_ORIGIN,
      ALLOWED_PRINCIPALS: this.env.ALLOWED_PRINCIPALS });
    configured(policy);
    parseAllowedPrincipals(policy.ALLOWED_PRINCIPALS);
    if (!identifier(policy.ACCESS_EVENT_AUD, 256) || policy.ACCESS_UI_AUD === policy.ACCESS_EVENT_AUD)
      throw new AccessUnavailable();
    return policy;
  }

  #assertOwnerReadCurrent(proof: OwnerReadProof): OwnerReadProof {
    const now = this.#ports.now();
    if (!Number.isSafeInteger(proof.checkedAtSeconds) || !Number.isSafeInteger(now)
      || now < proof.checkedAtSeconds || now >= proof.expiresAtSeconds) throw new AccessDenied();
    const current = this.#ownerReadPolicy();
    if (!principalAllowed(current, proof.principal)
      || Object.keys(current).some(key => current[key as keyof OwnerReadPolicy] !== proof.policy[key as keyof OwnerReadPolicy]))
      throw new AccessDenied();
    return Object.freeze({ ...proof, checkedAtSeconds: now });
  }

  async #run<T>(call: EventAdminCall, mutation: boolean, action: (principal: string, deadline: EventRequestDeadline) => Promise<T>, requireRuntime = true, readFence?: () => void): Promise<EventAdminOutcome<T>> {
    const deadline = new EventRequestDeadline();
    try {
      const identity = await this.#identity(call, mutation, deadline, requireRuntime, readFence !== undefined);
      const readProof = identity.readProof ? this.#assertOwnerReadCurrent(identity.readProof) : undefined;
      readFence?.();
      const value = await action(identity.principal, deadline);
      if (readProof) this.#assertOwnerReadCurrent(readProof);
      readFence?.();
      return { outcome: "allowed", value };
    }
    catch (error) {
      if (error instanceof AccessDenied) return { outcome: "denied" };
      if (error instanceof z.ZodError) return { outcome: "refused", code: "invalid", message: "Invalid event request." };
      if (error instanceof EventApiError && error.status === 503) return { outcome: "unavailable" };
      if (error instanceof EventApiError || (error instanceof Error && /^(invalid|conflict|denied|capacity|not_found|expired|manual_disabled|native_binding_unqualified|github_denied|github_grant_conflict|github_capacity|github_cleanup_capacity|github_publication_conflict|github_source_conflict|github_operation_conflict|github_legacy_adoption_required|github_source_control_unavailable|github_source_gate_unqualified|github_source_history_capacity)$/.test(error.message))) {
        const code = error instanceof EventApiError ? error.code : error.message;
        return { outcome: "refused", code, message: code.replaceAll("_", " ") };
      }
      return { outcome: "unavailable" };
    } finally { deadline.dispose(); }
  }

  /** Owner evidence only: no current agent registration, admission, or runtime initialization. */
  async readQuarantineInventoryPage(call: EventAdminCall, input: unknown): Promise<EventAdminOutcome<InventoryPage>> {
    const parsed = parseOwnerInventoryInput(input);
    if (!parsed) return { outcome: 'refused', code: 'invalid', message: 'Invalid event request.' };
    const original = parseInventoryOwnerCall(call);
    if (!original) return { outcome: 'denied' };
    const registryScope = parsed.request.scopeKind === 'registry';
    const namespace = registryScope ? this.env.OWNER_REGISTRY : this.env.AGENT_COORDINATOR;
    const namespaceCurrent = () => namespace === (registryScope ? this.env.OWNER_REGISTRY : this.env.AGENT_COORDINATOR);
    return this.#run(original, false, async (principal, deadline) => {
      if (!namespace || !namespaceCurrent()) throw new AccessUnavailable();
      const name = registryScope ? ownerRegistryName(principal) : coordinatorName(principal, parsed.agent!);
      const raw = await deadline.run<unknown>(() => namespace.getByName(name).readQuarantineInventoryPage(parsed.request));
      if (!namespaceCurrent()) throw new AccessUnavailable();
      const page = parseInventoryPage(raw, parsed.request);
      if (!page) throw new AccessUnavailable();
      return page;
    }, false, () => {
      if (!namespace || !namespaceCurrent()) throw new AccessUnavailable();
    });
  }

  async githubWatchControl(call: EventAdminCall, input: { agent: string; request: string }): Promise<EventAdminOutcome<WatchOutcome>> {
    const parsed = z.strictObject({ agent, request: z.string().refine(value =>
      value.length <= WATCH_CONTROL_LIMITS.messageBytes && new TextEncoder().encode(value).byteLength <= WATCH_CONTROL_LIMITS.messageBytes) }).safeParse(input);
    if (!parsed.success) return { outcome: 'refused', code: 'invalid', message: 'Invalid event request.' };
    let request: unknown;
    try { request = JSON.parse(parsed.data.request); }
    catch { return { outcome: 'refused', code: 'invalid', message: 'Invalid event request.' }; }
    if (request && typeof request === 'object' && 'kind' in request && typeof request.kind === 'string'
      && !['create', 'read', 'operation_readback', 'detach', 'unsubscribe'].includes(request.kind))
      return { outcome: 'refused', code: 'unsupported', message: 'unsupported' };
    const operation = WatchRequestSchema.safeParse(request);
    if (!operation.success) return { outcome: 'refused', code: 'invalid', message: 'Invalid event request.' };
    const original = Object.freeze({ token: call?.token, origin: call?.origin, fetchSite: call?.fetchSite, csrf: call?.csrf });
    const mutation = ['create', 'detach', 'unsubscribe'].includes(operation.data.kind);
    return this.#run(original, mutation, async (principal, deadline) => {
      const coordinator = await this.#coordinator(original, principal, parsed.data.agent, deadline);
      const raw = await deadline.run<unknown>(() => coordinator.githubWatchControl(original, parsed.data.request));
      try { watchJson(raw); } catch { throw new EventApiError('unavailable', 503); }
      const result = WatchOutcomeSchema.safeParse(raw);
      if (!result.success) throw new EventApiError('unavailable', 503);
      return result.data;
    }, false);
  }

  async messageRouteControl(call: EventAdminCall, input: MessageRouteControlInput): Promise<EventAdminOutcome<MessageRouteControlResult>> {
    const parsed = parseMessageRouteControlInput(input);
    if (!parsed) return { outcome: "refused", code: "invalid", message: "Invalid event request." };
    const original = parseMessageRouteOwnerCall(call);
    if (!original) return { outcome: "denied" };
    const authority = this.env.MESSAGE_AUTHORITY;
    return this.#run(original, parsed.request.operation === "transfer", async (_principal, deadline) => {
      if (!authority || this.env.MESSAGE_AUTHORITY !== authority) throw new AccessUnavailable();
      const result = parseMessageRouteControlResult(await deadline.run(
        () => authority.messageRouteControl(original, parsed),
      ), parsed);
      if (!result || this.env.MESSAGE_AUTHORITY !== authority) throw new AccessUnavailable();
      return result;
    }, false);
  }

  capabilities(call: EventAdminCall) { return this.#run(call, false, () => Promise.resolve({ owner: true as const })); }

  async #registeredAgent(call: EventAdminCall, principal: string, agent: string, deadline: EventRequestDeadline) {
      const result = parseOwnerAgentResult(await deadline.run(
        () => this.env.MESSAGE_AUTHORITY.registeredOwnerAgent({ accessAssertion: call.token, agent }), 5000,
      ));
      if (result.status === "not_registered") throw new EventApiError("agent_not_registered", 409);
      if (result.status === "invalid") throw new EventApiError("invalid", 400);
      if (result.status === "unavailable") throw new AccessUnavailable();
      if (result.status !== "authorized" || result.identity.principal !== principal || result.identity.agent !== agent)
        throw new AccessDenied();
  }

  async #coordinator(call: EventAdminCall, principal: string, agent: string, deadline: EventRequestDeadline) {
      await this.#registeredAgent(call, principal, agent, deadline);
      try { await admitCoordinator(this.env, principal, agent, deadline); }
      catch (error) {
        if (error instanceof EventApiError && error.status === 503) throw new AccessUnavailable();
        throw error;
      }
      return this.env.AGENT_COORDINATOR.getByName(coordinatorName(principal, agent));
  }

  status(call: EventAdminCall, input: { agent: string }) {
    return this.#run(call, false, async (principal, deadline) => {
      const parsed = agentInput.parse(input);
      const registry = this.env.OWNER_REGISTRY.getByName(ownerRegistryName(principal));
      const coordinator = await this.#coordinator(call, principal, parsed.agent, deadline);
      const [nodes, status] = await Promise.all([
        deadline.run(() => registry.status()), deadline.run(() => coordinator.status()),
      ]);
      return { agent: parsed.agent, enabled: status.enabled, nodes: nodes.map(nodeView), counts: status.counts,
        recent: status.recent.slice(0, 20).map(({ deliveryId, runtimeId, state, reason, createdAt }) =>
          ({ deliveryId, runtimeId, state, reason, createdAt })),
        recentLimit: 20 as const, recentTruncated: status.recentTruncated || status.recent.length > 20,
        nativeBinding: "unqualified" as const,
        inFlightCaveat: "Disabling prevents new admissions; a turn already accepted by the client may still run." };
    });
  }

  createChallenge(call: EventAdminCall, input: EventChallengeInput) {
    return this.#run(call, true, async (principal, deadline) => {
      const parsed = challengeInput.parse(input);
      // Node admission may select only the human owner's currently registered agents.
      for (let start = 0; start < parsed.agents.length; start += 8)
        await Promise.all(parsed.agents.slice(start, start + 8).map(name => this.#registeredAgent(call, principal, name, deadline)));
      return deadline.run(() => this.env.OWNER_REGISTRY.getByName(ownerRegistryName(principal)).createChallenge({
        ...parsed, publicKey: { kty: "OKP", crv: "Ed25519", x: parsed.publicKey },
      }));
    });
  }

  revokeNode(call: EventAdminCall, input: EventRevokeInput) {
    return this.#run(call, true, async (principal, deadline) => nodeView(await deadline.run(() => this.env.OWNER_REGISTRY
      .getByName(ownerRegistryName(principal)).revokeNode(revokeInput.parse(input)))));
  }

  setEnabled(call: EventAdminCall, input: EventEnabledInput) {
    return this.#run(call, true, async (principal, deadline) => {
      const parsed = enabledInput.parse(input);
      const coordinator = await this.#coordinator(call, principal, parsed.agent, deadline);
      const status = await deadline.run(() => coordinator.setEnabled({ enabled: parsed.enabled }));
      return { enabled: status.enabled };
    });
  }

  manual(call: EventAdminCall, input: EventManualInput) {
    return this.#run(call, true, async (principal, deadline) => {
      const parsed = manualInput.parse(input);
      requireManualCanary(this.env, { principal, agent: parsed.agent }, parsed.subjectId);
      const coordinator = await this.#coordinator(call, principal, parsed.agent, deadline);
      requireManualCanary(this.env, { principal, agent: parsed.agent }, parsed.subjectId);
      return deadline.run(() => coordinator.publishManual({ runtimeId: parsed.runtimeId, subjectId: parsed.subjectId }));
    });
  }

  githubSourceStatus(call: EventAdminCall, input: { agent: string; subject: GitHubGrantInput['subject']; operationId?: string }) {
    return this.#run(call, false, async (principal, deadline) => {
      const parsed = z.strictObject({ agent, subject: GitHubGrantSubjectSchema, operationId: z.string().uuid().optional() }).parse(input);
      const coordinator = await this.#coordinator(call, principal, parsed.agent, deadline);
      const response = GitHubSourceOwnerViewSchema.safeParse(await deadline.run(() => coordinator.githubSourceStatus(parsed.subject, parsed.operationId)));
      if (!response.success) throw new EventApiError("unavailable", 503);
      const result = response.data;
      if (result.grant && JSON.stringify(result.grant.subject) !== JSON.stringify(parsed.subject)) throw new EventApiError("unavailable", 503);
      return result;
    });
  }

  initializeGitHubSource(call: EventAdminCall, input: { agent: string } & z.infer<typeof GitHubSourceInitializationInputSchema>) {
    return this.#run(call, true, async (principal, deadline) => {
      const parsed = GitHubSourceInitializationInputSchema.extend({ agent }).parse(input);
      const coordinator = await this.#coordinator(call, principal, parsed.agent, deadline);
      const { agent: _selectedAgent, ...request } = parsed;
      const response = GitHubSourceOwnerViewSchema.safeParse(await deadline.run(() => coordinator.initializeGitHubSource(request)));
      if (!response.success) throw new EventApiError("unavailable", 503);
      const result = response.data;
      // Exact immutable operation outcomes precede mutable grant checks. A
      // terminal authority_changed receipt is a known 409 even though its
      // retained owner view necessarily reflects a newer grant revision.
      requireAcceptedSourceOperation(result, parsed, 'initialize');
      return result;
    });
  }

  adoptGitHubSource(call: EventAdminCall, input: { agent: string } & z.infer<typeof GitHubSourceAdoptionInputSchema>) {
    return this.#run(call, true, async (principal, deadline) => {
      const parsed = GitHubSourceAdoptionInputSchema.extend({ agent }).parse(input);
      const coordinator = await this.#coordinator(call, principal, parsed.agent, deadline);
      const { agent: _selectedAgent, ...request } = parsed;
      const response = GitHubSourceOwnerViewSchema.safeParse(await deadline.run(() => coordinator.adoptGitHubSource(request)));
      if (!response.success) throw new EventApiError("unavailable", 503);
      const result = response.data;
      requireAcceptedSourceOperation(result, parsed, 'adopt');
      return result;
    });
  }

  setGitHubGrant(call: EventAdminCall, input: GitHubGrantInput & { agent: string }) {
    return this.#run(call, true, async (principal, deadline) => {
      const parsed = GitHubGrantInputSchema.extend({ agent }).parse(input);
      const coordinator = await this.#coordinator(call, principal, parsed.agent, deadline);
      const { agent: _selectedAgent, ...grant } = parsed;
      const result = GitHubGrantViewSchema.safeParse(await deadline.run(() => coordinator.setGitHubGrant(grant)));
      if (!result.success || JSON.stringify(result.data.subject) !== JSON.stringify(grant.subject) ||
        result.data.enabled !== grant.enabled || result.data.revision <= grant.expectedRevision || result.data.policyRevision !== grant.policyRevision)
        throw new EventApiError("invalid_github_grant_response", 503);
      return result.data;
    });
  }

  transfer(call: EventAdminCall, input: EventTransferInput): Promise<EventAdminOutcome<{ attachmentGeneration: number }>> {
    return this.#run(call, true, () => {
      transferInput.parse(input);
      // Public owner actions cannot manufacture proof of a live native binding.
      throw new EventApiError("native_binding_unqualified", 409);
    });
  }
}
